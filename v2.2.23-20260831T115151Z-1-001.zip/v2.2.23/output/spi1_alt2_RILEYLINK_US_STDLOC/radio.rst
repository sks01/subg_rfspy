                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.0.2 #11662 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module radio
                                      6 	.optsdcc -mmcs51 --model-medium
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rf_isr
                                     12 	.globl _rftxrx_isr
                                     13 	.globl _init_decoder
                                     14 	.globl _init_encoder
                                     15 	.globl _delay
                                     16 	.globl _serial_rx_byte
                                     17 	.globl _serial_tx_byte
                                     18 	.globl _mode_registers_enact
                                     19 	.globl _memset
                                     20 	.globl _MODE
                                     21 	.globl _RE
                                     22 	.globl _SLAVE
                                     23 	.globl _FE
                                     24 	.globl _ERR
                                     25 	.globl _RX_BYTE
                                     26 	.globl _TX_BYTE
                                     27 	.globl _ACTIVE
                                     28 	.globl _B_7
                                     29 	.globl _B_6
                                     30 	.globl _B_5
                                     31 	.globl _B_4
                                     32 	.globl _B_3
                                     33 	.globl _B_2
                                     34 	.globl _B_1
                                     35 	.globl _B_0
                                     36 	.globl _WDTIF
                                     37 	.globl _P1IF
                                     38 	.globl _UTX1IF
                                     39 	.globl _UTX0IF
                                     40 	.globl _P2IF
                                     41 	.globl _ACC_7
                                     42 	.globl _ACC_6
                                     43 	.globl _ACC_5
                                     44 	.globl _ACC_4
                                     45 	.globl _ACC_3
                                     46 	.globl _ACC_2
                                     47 	.globl _ACC_1
                                     48 	.globl _ACC_0
                                     49 	.globl _OVFIM
                                     50 	.globl _T4CH1IF
                                     51 	.globl _T4CH0IF
                                     52 	.globl _T4OVFIF
                                     53 	.globl _T3CH1IF
                                     54 	.globl _T3CH0IF
                                     55 	.globl _T3OVFIF
                                     56 	.globl _CY
                                     57 	.globl _AC
                                     58 	.globl _F0
                                     59 	.globl _RS1
                                     60 	.globl _RS0
                                     61 	.globl _OV
                                     62 	.globl _F1
                                     63 	.globl _P
                                     64 	.globl _STIF
                                     65 	.globl _P0IF
                                     66 	.globl _T4IF
                                     67 	.globl _T3IF
                                     68 	.globl _T2IF
                                     69 	.globl _T1IF
                                     70 	.globl _DMAIF
                                     71 	.globl _P0IE
                                     72 	.globl _T4IE
                                     73 	.globl _T3IE
                                     74 	.globl _T2IE
                                     75 	.globl _T1IE
                                     76 	.globl _DMAIE
                                     77 	.globl _EA
                                     78 	.globl _STIE
                                     79 	.globl _ENCIE
                                     80 	.globl _URX1IE
                                     81 	.globl _URX0IE
                                     82 	.globl _ADCIE
                                     83 	.globl _RFTXRXIE
                                     84 	.globl _P2_7
                                     85 	.globl _P2_6
                                     86 	.globl _P2_5
                                     87 	.globl _P2_4
                                     88 	.globl _P2_3
                                     89 	.globl _P2_2
                                     90 	.globl _P2_1
                                     91 	.globl _P2_0
                                     92 	.globl _ENCIF_1
                                     93 	.globl _ENCIF_0
                                     94 	.globl _P1_7
                                     95 	.globl _P1_6
                                     96 	.globl _P1_5
                                     97 	.globl _P1_4
                                     98 	.globl _P1_3
                                     99 	.globl _P1_2
                                    100 	.globl _P1_1
                                    101 	.globl _P1_0
                                    102 	.globl _URX1IF
                                    103 	.globl _ADCIF
                                    104 	.globl _URX0IF
                                    105 	.globl _IT1
                                    106 	.globl _RFTXRXIF
                                    107 	.globl _IT0
                                    108 	.globl _P0_7
                                    109 	.globl _P0_6
                                    110 	.globl _P0_5
                                    111 	.globl _P0_4
                                    112 	.globl _P0_3
                                    113 	.globl _P0_2
                                    114 	.globl _P0_1
                                    115 	.globl _P0_0
                                    116 	.globl _P2DIR
                                    117 	.globl _P1DIR
                                    118 	.globl _P0DIR
                                    119 	.globl _U1GCR
                                    120 	.globl _U1UCR
                                    121 	.globl _U1BAUD
                                    122 	.globl _U1DBUF
                                    123 	.globl _U1CSR
                                    124 	.globl _P2INP
                                    125 	.globl _P1INP
                                    126 	.globl _P2SEL
                                    127 	.globl _P1SEL
                                    128 	.globl _P0SEL
                                    129 	.globl _ADCCFG
                                    130 	.globl _PERCFG
                                    131 	.globl _B
                                    132 	.globl _T4CC1
                                    133 	.globl _T4CCTL1
                                    134 	.globl _T4CC0
                                    135 	.globl _T4CCTL0
                                    136 	.globl _T4CTL
                                    137 	.globl _T4CNT
                                    138 	.globl _RFIF
                                    139 	.globl _IRCON2
                                    140 	.globl _T1CCTL2
                                    141 	.globl _T1CCTL1
                                    142 	.globl _T1CCTL0
                                    143 	.globl _T1CTL
                                    144 	.globl _T1CNTH
                                    145 	.globl _T1CNTL
                                    146 	.globl _RFST
                                    147 	.globl _ACC
                                    148 	.globl _T1CC2H
                                    149 	.globl _T1CC2L
                                    150 	.globl _T1CC1H
                                    151 	.globl _T1CC1L
                                    152 	.globl _T1CC0H
                                    153 	.globl _T1CC0L
                                    154 	.globl _RFD
                                    155 	.globl _TIMIF
                                    156 	.globl _DMAREQ
                                    157 	.globl _DMAARM
                                    158 	.globl _DMA0CFGH
                                    159 	.globl _DMA0CFGL
                                    160 	.globl _DMA1CFGH
                                    161 	.globl _DMA1CFGL
                                    162 	.globl _DMAIRQ
                                    163 	.globl _PSW
                                    164 	.globl _T3CC1
                                    165 	.globl _T3CCTL1
                                    166 	.globl _T3CC0
                                    167 	.globl _T3CCTL0
                                    168 	.globl _T3CTL
                                    169 	.globl _T3CNT
                                    170 	.globl _WDCTL
                                    171 	.globl __SFRC8
                                    172 	.globl _MEMCTR
                                    173 	.globl _CLKCON
                                    174 	.globl _U0GCR
                                    175 	.globl _U0UCR
                                    176 	.globl __SFRC3
                                    177 	.globl _U0BAUD
                                    178 	.globl _U0DBUF
                                    179 	.globl _IRCON
                                    180 	.globl __SFRBF
                                    181 	.globl _SLEEP
                                    182 	.globl _RNDH
                                    183 	.globl _RNDL
                                    184 	.globl _ADCH
                                    185 	.globl _ADCL
                                    186 	.globl _IP1
                                    187 	.globl _IEN1
                                    188 	.globl __SFRB7
                                    189 	.globl _ADCCON3
                                    190 	.globl _ADCCON2
                                    191 	.globl _ADCCON1
                                    192 	.globl _ENCCS
                                    193 	.globl _ENCDO
                                    194 	.globl _ENCDI
                                    195 	.globl __SFRB0
                                    196 	.globl _FWDATA
                                    197 	.globl _FCTL
                                    198 	.globl _FADDRH
                                    199 	.globl _FADDRL
                                    200 	.globl _FWT
                                    201 	.globl __SFRAA
                                    202 	.globl _IP0
                                    203 	.globl _IEN0
                                    204 	.globl __SFRA7
                                    205 	.globl _WORTIME1
                                    206 	.globl _WORTIME0
                                    207 	.globl _WOREVT1
                                    208 	.globl _WOREVT0
                                    209 	.globl _WORCTRL
                                    210 	.globl _WORIRQ
                                    211 	.globl _P2
                                    212 	.globl __SFR9F
                                    213 	.globl _T2CTL
                                    214 	.globl _T2PR
                                    215 	.globl _T2CT
                                    216 	.globl _S1CON
                                    217 	.globl _IEN2
                                    218 	.globl __SFR99
                                    219 	.globl _S0CON
                                    220 	.globl __SFR97
                                    221 	.globl __SFR96
                                    222 	.globl __SFR95
                                    223 	.globl __SFR94
                                    224 	.globl __XPAGE
                                    225 	.globl _MPAGE
                                    226 	.globl _DPS
                                    227 	.globl _RFIM
                                    228 	.globl _P1
                                    229 	.globl _P0INP
                                    230 	.globl __SFR8E
                                    231 	.globl _P1IEN
                                    232 	.globl _PICTL
                                    233 	.globl _P2IFG
                                    234 	.globl _P1IFG
                                    235 	.globl _P0IFG
                                    236 	.globl _TCON
                                    237 	.globl _PCON
                                    238 	.globl _U0CSR
                                    239 	.globl _DPH1
                                    240 	.globl _DPL1
                                    241 	.globl _DPH0
                                    242 	.globl _DPL0
                                    243 	.globl _SP
                                    244 	.globl _P0
                                    245 	.globl _X_P2DIR
                                    246 	.globl _X_P1DIR
                                    247 	.globl _X_P0DIR
                                    248 	.globl _X_U1GCR
                                    249 	.globl _X_U1UCR
                                    250 	.globl _X_U1BAUD
                                    251 	.globl _X_U1DBUF
                                    252 	.globl _X_U1CSR
                                    253 	.globl _X_P2INP
                                    254 	.globl _X_P1INP
                                    255 	.globl _X_P2SEL
                                    256 	.globl _X_P1SEL
                                    257 	.globl _X_P0SEL
                                    258 	.globl _X_ADCCFG
                                    259 	.globl _X_PERCFG
                                    260 	.globl __NA_B
                                    261 	.globl _X_T4CC1
                                    262 	.globl _X_T4CCTL1
                                    263 	.globl _X_T4CC0
                                    264 	.globl _X_T4CCTL0
                                    265 	.globl _X_T4CTL
                                    266 	.globl _X_T4CNT
                                    267 	.globl _X_RFIF
                                    268 	.globl __NA_IRCON2
                                    269 	.globl _X_T1CCTL2
                                    270 	.globl _X_T1CCTL1
                                    271 	.globl _X_T1CCTL0
                                    272 	.globl _X_T1CTL
                                    273 	.globl _X_T1CNTH
                                    274 	.globl _X_T1CNTL
                                    275 	.globl _X_RFST
                                    276 	.globl __NA_ACC
                                    277 	.globl _X_T1CC2H
                                    278 	.globl _X_T1CC2L
                                    279 	.globl _X_T1CC1H
                                    280 	.globl _X_T1CC1L
                                    281 	.globl _X_T1CC0H
                                    282 	.globl _X_T1CC0L
                                    283 	.globl _X_RFD
                                    284 	.globl _X_TIMIF
                                    285 	.globl _X_DMAREQ
                                    286 	.globl _X_DMAARM
                                    287 	.globl _X_DMA0CFGH
                                    288 	.globl _X_DMA0CFGL
                                    289 	.globl _X_DMA1CFGH
                                    290 	.globl _X_DMA1CFGL
                                    291 	.globl _X_DMAIRQ
                                    292 	.globl __NA_PSW
                                    293 	.globl _X_T3CC1
                                    294 	.globl _X_T3CCTL1
                                    295 	.globl _X_T3CC0
                                    296 	.globl _X_T3CCTL0
                                    297 	.globl _X_T3CTL
                                    298 	.globl _X_T3CNT
                                    299 	.globl _X_WDCTL
                                    300 	.globl __X_SFRC8
                                    301 	.globl _X_MEMCTR
                                    302 	.globl _X_CLKCON
                                    303 	.globl _X_U0GCR
                                    304 	.globl _X_U0UCR
                                    305 	.globl __X_SFRC3
                                    306 	.globl _X_U0BAUD
                                    307 	.globl _X_U0DBUF
                                    308 	.globl __NA_IRCON
                                    309 	.globl __X_SFRBF
                                    310 	.globl _X_SLEEP
                                    311 	.globl _X_RNDH
                                    312 	.globl _X_RNDL
                                    313 	.globl _X_ADCH
                                    314 	.globl _X_ADCL
                                    315 	.globl __NA_IP1
                                    316 	.globl __NA_IEN1
                                    317 	.globl __X_SFRB7
                                    318 	.globl _X_ADCCON3
                                    319 	.globl _X_ADCCON2
                                    320 	.globl _X_ADCCON1
                                    321 	.globl _X_ENCCS
                                    322 	.globl _X_ENCDO
                                    323 	.globl _X_ENCDI
                                    324 	.globl __X_SFRB0
                                    325 	.globl _X_FWDATA
                                    326 	.globl _X_FCTL
                                    327 	.globl _X_FADDRH
                                    328 	.globl _X_FADDRL
                                    329 	.globl _X_FWT
                                    330 	.globl __X_SFRAA
                                    331 	.globl __NA_IP0
                                    332 	.globl __NA_IEN0
                                    333 	.globl __X_SFRA7
                                    334 	.globl _X_WORTIME1
                                    335 	.globl _X_WORTIME0
                                    336 	.globl _X_WOREVT1
                                    337 	.globl _X_WOREVT0
                                    338 	.globl _X_WORCTRL
                                    339 	.globl _X_WORIRQ
                                    340 	.globl __NA_P2
                                    341 	.globl __X_SFR9F
                                    342 	.globl _X_T2CTL
                                    343 	.globl _X_T2PR
                                    344 	.globl _X_T2CT
                                    345 	.globl __NA_S1CON
                                    346 	.globl __NA_IEN2
                                    347 	.globl __X_SFR99
                                    348 	.globl __NA_S0CON
                                    349 	.globl __X_SFR97
                                    350 	.globl __X_SFR96
                                    351 	.globl __X_SFR95
                                    352 	.globl __X_SFR94
                                    353 	.globl _X_MPAGE
                                    354 	.globl __NA_DPS
                                    355 	.globl _X_RFIM
                                    356 	.globl __NA_P1
                                    357 	.globl _X_P0INP
                                    358 	.globl __X_SFR8E
                                    359 	.globl _X_P1IEN
                                    360 	.globl _X_PICTL
                                    361 	.globl _X_P2IFG
                                    362 	.globl _X_P1IFG
                                    363 	.globl _X_P0IFG
                                    364 	.globl __NA_TCON
                                    365 	.globl __NA_PCON
                                    366 	.globl _X_U0CSR
                                    367 	.globl __NA_DPH1
                                    368 	.globl __NA_DPL1
                                    369 	.globl __NA_DPH0
                                    370 	.globl __NA_DPL0
                                    371 	.globl __NA_SP
                                    372 	.globl __NA_P0
                                    373 	.globl _I2SCLKF2
                                    374 	.globl _I2SCLKF1
                                    375 	.globl _I2SCLKF0
                                    376 	.globl _I2SSTAT
                                    377 	.globl _I2SWCNT
                                    378 	.globl _I2SDATH
                                    379 	.globl _I2SDATL
                                    380 	.globl _I2SCFG1
                                    381 	.globl _I2SCFG0
                                    382 	.globl _VCO_VC_DAC
                                    383 	.globl _PKTSTATUS
                                    384 	.globl _MARCSTATE
                                    385 	.globl _RSSI
                                    386 	.globl _LQI
                                    387 	.globl _FREQEST
                                    388 	.globl _VERSION
                                    389 	.globl _PARTNUM
                                    390 	.globl __XREGDF35
                                    391 	.globl __XREGDF34
                                    392 	.globl __XREGDF33
                                    393 	.globl __XREGDF32
                                    394 	.globl _IOCFG0
                                    395 	.globl _IOCFG1
                                    396 	.globl _IOCFG2
                                    397 	.globl _PA_TABLE0
                                    398 	.globl _PA_TABLE1
                                    399 	.globl _PA_TABLE2
                                    400 	.globl _PA_TABLE3
                                    401 	.globl _PA_TABLE4
                                    402 	.globl _PA_TABLE5
                                    403 	.globl _PA_TABLE6
                                    404 	.globl _PA_TABLE7
                                    405 	.globl __XREGDF26
                                    406 	.globl _TEST0
                                    407 	.globl _TEST1
                                    408 	.globl _TEST2
                                    409 	.globl __XREGDF22
                                    410 	.globl __XREGDF21
                                    411 	.globl __XREGDF20
                                    412 	.globl _FSCAL0
                                    413 	.globl _FSCAL1
                                    414 	.globl _FSCAL2
                                    415 	.globl _FSCAL3
                                    416 	.globl _FREND0
                                    417 	.globl _FREND1
                                    418 	.globl _AGCCTRL0
                                    419 	.globl _AGCCTRL1
                                    420 	.globl _AGCCTRL2
                                    421 	.globl _BSCFG
                                    422 	.globl _FOCCFG
                                    423 	.globl _MCSM0
                                    424 	.globl _MCSM1
                                    425 	.globl _MCSM2
                                    426 	.globl _DEVIATN
                                    427 	.globl _MDMCFG0
                                    428 	.globl _MDMCFG1
                                    429 	.globl _MDMCFG2
                                    430 	.globl _MDMCFG3
                                    431 	.globl _MDMCFG4
                                    432 	.globl _FREQ0
                                    433 	.globl _FREQ1
                                    434 	.globl _FREQ2
                                    435 	.globl _FSCTRL0
                                    436 	.globl _FSCTRL1
                                    437 	.globl _CHANNR
                                    438 	.globl _ADDR
                                    439 	.globl _PKTCTRL0
                                    440 	.globl _PKTCTRL1
                                    441 	.globl _PKTLEN
                                    442 	.globl _SYNC0
                                    443 	.globl _SYNC1
                                    444 	.globl _MDMCTRL0H
                                    445 	.globl _get_packet_and_write_to_serial_PARM_3
                                    446 	.globl _get_packet_and_write_to_serial_PARM_2
                                    447 	.globl _send_from_tx_buf_PARM_2
                                    448 	.globl _send_packet_from_serial_PARM_5
                                    449 	.globl _send_packet_from_serial_PARM_4
                                    450 	.globl _send_packet_from_serial_PARM_3
                                    451 	.globl _send_packet_from_serial_PARM_2
                                    452 	.globl _encoding_type
                                    453 	.globl _tx_state
                                    454 	.globl _configure_radio
                                    455 	.globl _set_encoding_type
                                    456 	.globl _send_packet_from_serial
                                    457 	.globl _send_from_tx_buf
                                    458 	.globl _get_packet_and_write_to_serial
                                    459 	.globl _radio_set_preamble
                                    460 ;--------------------------------------------------------
                                    461 ; special function registers
                                    462 ;--------------------------------------------------------
                                    463 	.area RSEG    (ABS,DATA)
      000000                        464 	.org 0x0000
                           000080   465 _P0	=	0x0080
                           000081   466 _SP	=	0x0081
                           000082   467 _DPL0	=	0x0082
                           000083   468 _DPH0	=	0x0083
                           000084   469 _DPL1	=	0x0084
                           000085   470 _DPH1	=	0x0085
                           000086   471 _U0CSR	=	0x0086
                           000087   472 _PCON	=	0x0087
                           000088   473 _TCON	=	0x0088
                           000089   474 _P0IFG	=	0x0089
                           00008A   475 _P1IFG	=	0x008a
                           00008B   476 _P2IFG	=	0x008b
                           00008C   477 _PICTL	=	0x008c
                           00008D   478 _P1IEN	=	0x008d
                           00008E   479 __SFR8E	=	0x008e
                           00008F   480 _P0INP	=	0x008f
                           000090   481 _P1	=	0x0090
                           000091   482 _RFIM	=	0x0091
                           000092   483 _DPS	=	0x0092
                           000093   484 _MPAGE	=	0x0093
                           000093   485 __XPAGE	=	0x0093
                           000094   486 __SFR94	=	0x0094
                           000095   487 __SFR95	=	0x0095
                           000096   488 __SFR96	=	0x0096
                           000097   489 __SFR97	=	0x0097
                           000098   490 _S0CON	=	0x0098
                           000099   491 __SFR99	=	0x0099
                           00009A   492 _IEN2	=	0x009a
                           00009B   493 _S1CON	=	0x009b
                           00009C   494 _T2CT	=	0x009c
                           00009D   495 _T2PR	=	0x009d
                           00009E   496 _T2CTL	=	0x009e
                           00009F   497 __SFR9F	=	0x009f
                           0000A0   498 _P2	=	0x00a0
                           0000A1   499 _WORIRQ	=	0x00a1
                           0000A2   500 _WORCTRL	=	0x00a2
                           0000A3   501 _WOREVT0	=	0x00a3
                           0000A4   502 _WOREVT1	=	0x00a4
                           0000A5   503 _WORTIME0	=	0x00a5
                           0000A6   504 _WORTIME1	=	0x00a6
                           0000A7   505 __SFRA7	=	0x00a7
                           0000A8   506 _IEN0	=	0x00a8
                           0000A9   507 _IP0	=	0x00a9
                           0000AA   508 __SFRAA	=	0x00aa
                           0000AB   509 _FWT	=	0x00ab
                           0000AC   510 _FADDRL	=	0x00ac
                           0000AD   511 _FADDRH	=	0x00ad
                           0000AE   512 _FCTL	=	0x00ae
                           0000AF   513 _FWDATA	=	0x00af
                           0000B0   514 __SFRB0	=	0x00b0
                           0000B1   515 _ENCDI	=	0x00b1
                           0000B2   516 _ENCDO	=	0x00b2
                           0000B3   517 _ENCCS	=	0x00b3
                           0000B4   518 _ADCCON1	=	0x00b4
                           0000B5   519 _ADCCON2	=	0x00b5
                           0000B6   520 _ADCCON3	=	0x00b6
                           0000B7   521 __SFRB7	=	0x00b7
                           0000B8   522 _IEN1	=	0x00b8
                           0000B9   523 _IP1	=	0x00b9
                           0000BA   524 _ADCL	=	0x00ba
                           0000BB   525 _ADCH	=	0x00bb
                           0000BC   526 _RNDL	=	0x00bc
                           0000BD   527 _RNDH	=	0x00bd
                           0000BE   528 _SLEEP	=	0x00be
                           0000BF   529 __SFRBF	=	0x00bf
                           0000C0   530 _IRCON	=	0x00c0
                           0000C1   531 _U0DBUF	=	0x00c1
                           0000C2   532 _U0BAUD	=	0x00c2
                           0000C3   533 __SFRC3	=	0x00c3
                           0000C4   534 _U0UCR	=	0x00c4
                           0000C5   535 _U0GCR	=	0x00c5
                           0000C6   536 _CLKCON	=	0x00c6
                           0000C7   537 _MEMCTR	=	0x00c7
                           0000C8   538 __SFRC8	=	0x00c8
                           0000C9   539 _WDCTL	=	0x00c9
                           0000CA   540 _T3CNT	=	0x00ca
                           0000CB   541 _T3CTL	=	0x00cb
                           0000CC   542 _T3CCTL0	=	0x00cc
                           0000CD   543 _T3CC0	=	0x00cd
                           0000CE   544 _T3CCTL1	=	0x00ce
                           0000CF   545 _T3CC1	=	0x00cf
                           0000D0   546 _PSW	=	0x00d0
                           0000D1   547 _DMAIRQ	=	0x00d1
                           0000D2   548 _DMA1CFGL	=	0x00d2
                           0000D3   549 _DMA1CFGH	=	0x00d3
                           0000D4   550 _DMA0CFGL	=	0x00d4
                           0000D5   551 _DMA0CFGH	=	0x00d5
                           0000D6   552 _DMAARM	=	0x00d6
                           0000D7   553 _DMAREQ	=	0x00d7
                           0000D8   554 _TIMIF	=	0x00d8
                           0000D9   555 _RFD	=	0x00d9
                           0000DA   556 _T1CC0L	=	0x00da
                           0000DB   557 _T1CC0H	=	0x00db
                           0000DC   558 _T1CC1L	=	0x00dc
                           0000DD   559 _T1CC1H	=	0x00dd
                           0000DE   560 _T1CC2L	=	0x00de
                           0000DF   561 _T1CC2H	=	0x00df
                           0000E0   562 _ACC	=	0x00e0
                           0000E1   563 _RFST	=	0x00e1
                           0000E2   564 _T1CNTL	=	0x00e2
                           0000E3   565 _T1CNTH	=	0x00e3
                           0000E4   566 _T1CTL	=	0x00e4
                           0000E5   567 _T1CCTL0	=	0x00e5
                           0000E6   568 _T1CCTL1	=	0x00e6
                           0000E7   569 _T1CCTL2	=	0x00e7
                           0000E8   570 _IRCON2	=	0x00e8
                           0000E9   571 _RFIF	=	0x00e9
                           0000EA   572 _T4CNT	=	0x00ea
                           0000EB   573 _T4CTL	=	0x00eb
                           0000EC   574 _T4CCTL0	=	0x00ec
                           0000ED   575 _T4CC0	=	0x00ed
                           0000EE   576 _T4CCTL1	=	0x00ee
                           0000EF   577 _T4CC1	=	0x00ef
                           0000F0   578 _B	=	0x00f0
                           0000F1   579 _PERCFG	=	0x00f1
                           0000F2   580 _ADCCFG	=	0x00f2
                           0000F3   581 _P0SEL	=	0x00f3
                           0000F4   582 _P1SEL	=	0x00f4
                           0000F5   583 _P2SEL	=	0x00f5
                           0000F6   584 _P1INP	=	0x00f6
                           0000F7   585 _P2INP	=	0x00f7
                           0000F8   586 _U1CSR	=	0x00f8
                           0000F9   587 _U1DBUF	=	0x00f9
                           0000FA   588 _U1BAUD	=	0x00fa
                           0000FB   589 _U1UCR	=	0x00fb
                           0000FC   590 _U1GCR	=	0x00fc
                           0000FD   591 _P0DIR	=	0x00fd
                           0000FE   592 _P1DIR	=	0x00fe
                           0000FF   593 _P2DIR	=	0x00ff
                                    594 ;--------------------------------------------------------
                                    595 ; special function bits
                                    596 ;--------------------------------------------------------
                                    597 	.area RSEG    (ABS,DATA)
      000000                        598 	.org 0x0000
                           000080   599 _P0_0	=	0x0080
                           000081   600 _P0_1	=	0x0081
                           000082   601 _P0_2	=	0x0082
                           000083   602 _P0_3	=	0x0083
                           000084   603 _P0_4	=	0x0084
                           000085   604 _P0_5	=	0x0085
                           000086   605 _P0_6	=	0x0086
                           000087   606 _P0_7	=	0x0087
                           000088   607 _IT0	=	0x0088
                           000089   608 _RFTXRXIF	=	0x0089
                           00008A   609 _IT1	=	0x008a
                           00008B   610 _URX0IF	=	0x008b
                           00008D   611 _ADCIF	=	0x008d
                           00008F   612 _URX1IF	=	0x008f
                           000090   613 _P1_0	=	0x0090
                           000091   614 _P1_1	=	0x0091
                           000092   615 _P1_2	=	0x0092
                           000093   616 _P1_3	=	0x0093
                           000094   617 _P1_4	=	0x0094
                           000095   618 _P1_5	=	0x0095
                           000096   619 _P1_6	=	0x0096
                           000097   620 _P1_7	=	0x0097
                           000098   621 _ENCIF_0	=	0x0098
                           000099   622 _ENCIF_1	=	0x0099
                           0000A0   623 _P2_0	=	0x00a0
                           0000A1   624 _P2_1	=	0x00a1
                           0000A2   625 _P2_2	=	0x00a2
                           0000A3   626 _P2_3	=	0x00a3
                           0000A4   627 _P2_4	=	0x00a4
                           0000A5   628 _P2_5	=	0x00a5
                           0000A6   629 _P2_6	=	0x00a6
                           0000A7   630 _P2_7	=	0x00a7
                           0000A8   631 _RFTXRXIE	=	0x00a8
                           0000A9   632 _ADCIE	=	0x00a9
                           0000AA   633 _URX0IE	=	0x00aa
                           0000AB   634 _URX1IE	=	0x00ab
                           0000AC   635 _ENCIE	=	0x00ac
                           0000AD   636 _STIE	=	0x00ad
                           0000AF   637 _EA	=	0x00af
                           0000B8   638 _DMAIE	=	0x00b8
                           0000B9   639 _T1IE	=	0x00b9
                           0000BA   640 _T2IE	=	0x00ba
                           0000BB   641 _T3IE	=	0x00bb
                           0000BC   642 _T4IE	=	0x00bc
                           0000BD   643 _P0IE	=	0x00bd
                           0000C0   644 _DMAIF	=	0x00c0
                           0000C1   645 _T1IF	=	0x00c1
                           0000C2   646 _T2IF	=	0x00c2
                           0000C3   647 _T3IF	=	0x00c3
                           0000C4   648 _T4IF	=	0x00c4
                           0000C5   649 _P0IF	=	0x00c5
                           0000C7   650 _STIF	=	0x00c7
                           0000D0   651 _P	=	0x00d0
                           0000D1   652 _F1	=	0x00d1
                           0000D2   653 _OV	=	0x00d2
                           0000D3   654 _RS0	=	0x00d3
                           0000D4   655 _RS1	=	0x00d4
                           0000D5   656 _F0	=	0x00d5
                           0000D6   657 _AC	=	0x00d6
                           0000D7   658 _CY	=	0x00d7
                           0000D8   659 _T3OVFIF	=	0x00d8
                           0000D9   660 _T3CH0IF	=	0x00d9
                           0000DA   661 _T3CH1IF	=	0x00da
                           0000DB   662 _T4OVFIF	=	0x00db
                           0000DC   663 _T4CH0IF	=	0x00dc
                           0000DD   664 _T4CH1IF	=	0x00dd
                           0000DE   665 _OVFIM	=	0x00de
                           0000E0   666 _ACC_0	=	0x00e0
                           0000E1   667 _ACC_1	=	0x00e1
                           0000E2   668 _ACC_2	=	0x00e2
                           0000E3   669 _ACC_3	=	0x00e3
                           0000E4   670 _ACC_4	=	0x00e4
                           0000E5   671 _ACC_5	=	0x00e5
                           0000E6   672 _ACC_6	=	0x00e6
                           0000E7   673 _ACC_7	=	0x00e7
                           0000E8   674 _P2IF	=	0x00e8
                           0000E9   675 _UTX0IF	=	0x00e9
                           0000EA   676 _UTX1IF	=	0x00ea
                           0000EB   677 _P1IF	=	0x00eb
                           0000EC   678 _WDTIF	=	0x00ec
                           0000F0   679 _B_0	=	0x00f0
                           0000F1   680 _B_1	=	0x00f1
                           0000F2   681 _B_2	=	0x00f2
                           0000F3   682 _B_3	=	0x00f3
                           0000F4   683 _B_4	=	0x00f4
                           0000F5   684 _B_5	=	0x00f5
                           0000F6   685 _B_6	=	0x00f6
                           0000F7   686 _B_7	=	0x00f7
                           0000F8   687 _ACTIVE	=	0x00f8
                           0000F9   688 _TX_BYTE	=	0x00f9
                           0000FA   689 _RX_BYTE	=	0x00fa
                           0000FB   690 _ERR	=	0x00fb
                           0000FC   691 _FE	=	0x00fc
                           0000FD   692 _SLAVE	=	0x00fd
                           0000FE   693 _RE	=	0x00fe
                           0000FF   694 _MODE	=	0x00ff
                                    695 ;--------------------------------------------------------
                                    696 ; overlayable register banks
                                    697 ;--------------------------------------------------------
                                    698 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        699 	.ds 8
                                    700 ;--------------------------------------------------------
                                    701 ; internal ram data
                                    702 ;--------------------------------------------------------
                                    703 	.area DSEG    (DATA)
      000008                        704 _get_packet_and_write_to_serial_sloc0_1_0:
      000008                        705 	.ds 2
      00000A                        706 _get_packet_and_write_to_serial_sloc1_1_0:
      00000A                        707 	.ds 1
      00000B                        708 _get_packet_and_write_to_serial_sloc2_1_0:
      00000B                        709 	.ds 4
      00000F                        710 _get_packet_and_write_to_serial_sloc3_1_0:
      00000F                        711 	.ds 3
      000012                        712 _get_packet_and_write_to_serial_sloc4_1_0:
      000012                        713 	.ds 3
                                    714 ;--------------------------------------------------------
                                    715 ; overlayable items in internal ram 
                                    716 ;--------------------------------------------------------
                                    717 ;--------------------------------------------------------
                                    718 ; indirectly addressable internal ram data
                                    719 ;--------------------------------------------------------
                                    720 	.area ISEG    (DATA)
                                    721 ;--------------------------------------------------------
                                    722 ; absolute internal ram data
                                    723 ;--------------------------------------------------------
                                    724 	.area IABS    (ABS,DATA)
                                    725 	.area IABS    (ABS,DATA)
                                    726 ;--------------------------------------------------------
                                    727 ; bit data
                                    728 ;--------------------------------------------------------
                                    729 	.area BSEG    (BIT)
      000000                        730 _send_packet_from_serial_sloc0_1_0:
      000000                        731 	.ds 1
                                    732 ;--------------------------------------------------------
                                    733 ; paged external ram data
                                    734 ;--------------------------------------------------------
                                    735 	.area PSEG    (PAG,XDATA)
      00F002                        736 _rx_len:
      00F002                        737 	.ds 1
      00F003                        738 _stop_custom_preamble_semaphore:
      00F003                        739 	.ds 1
      00F004                        740 _tx_state::
      00F004                        741 	.ds 1
      00F005                        742 _encoding_type::
      00F005                        743 	.ds 1
      00F006                        744 _send_packet_from_serial_PARM_2:
      00F006                        745 	.ds 1
      00F007                        746 _send_packet_from_serial_PARM_3:
      00F007                        747 	.ds 2
      00F009                        748 _send_packet_from_serial_PARM_4:
      00F009                        749 	.ds 2
      00F00B                        750 _send_packet_from_serial_PARM_5:
      00F00B                        751 	.ds 1
      00F00C                        752 _send_packet_from_serial_channel_65536_127:
      00F00C                        753 	.ds 1
      00F00D                        754 _send_packet_from_serial_s_byte_65536_128:
      00F00D                        755 	.ds 1
      00F00E                        756 _send_packet_from_serial_encoder_65536_128:
      00F00E                        757 	.ds 4
      00F012                        758 _send_packet_from_serial_encoder_state_65536_128:
      00F012                        759 	.ds 3
      00F015                        760 _send_from_tx_buf_PARM_2:
      00F015                        761 	.ds 2
      00F017                        762 _get_packet_and_write_to_serial_PARM_2:
      00F017                        763 	.ds 4
      00F01B                        764 _get_packet_and_write_to_serial_PARM_3:
      00F01B                        765 	.ds 1
      00F01C                        766 _get_packet_and_write_to_serial___1310720043_131072_145:
      00F01C                        767 	.ds 1
      00F01D                        768 _get_packet_and_write_to_serial_read_idx_65536_145:
      00F01D                        769 	.ds 1
      00F01E                        770 _get_packet_and_write_to_serial_d_byte_65536_145:
      00F01E                        771 	.ds 1
      00F01F                        772 _get_packet_and_write_to_serial_rval_65536_145:
      00F01F                        773 	.ds 1
      00F020                        774 _get_packet_and_write_to_serial_timer_start_65536_145:
      00F020                        775 	.ds 4
      00F024                        776 _get_packet_and_write_to_serial___1966080033_196608_147:
      00F024                        777 	.ds 1
      00F025                        778 _get_packet_and_write_to_serial_b_327680_169:
      00F025                        779 	.ds 3
      00F028                        780 _get_packet_and_write_to_serial___1310720012_393216_170:
      00F028                        781 	.ds 1
      00F029                        782 _get_packet_and_write_to_serial_rval_327680_180:
      00F029                        783 	.ds 1
      00F02A                        784 _get_packet_and_write_to_serial_b_262144_188:
      00F02A                        785 	.ds 3
      00F02D                        786 _get_packet_and_write_to_serial___1310720012_327680_189:
      00F02D                        787 	.ds 1
                                    788 ;--------------------------------------------------------
                                    789 ; external ram data
                                    790 ;--------------------------------------------------------
                                    791 	.area XSEG    (XDATA)
                           00DF02   792 _MDMCTRL0H	=	0xdf02
                           00DF00   793 _SYNC1	=	0xdf00
                           00DF01   794 _SYNC0	=	0xdf01
                           00DF02   795 _PKTLEN	=	0xdf02
                           00DF03   796 _PKTCTRL1	=	0xdf03
                           00DF04   797 _PKTCTRL0	=	0xdf04
                           00DF05   798 _ADDR	=	0xdf05
                           00DF06   799 _CHANNR	=	0xdf06
                           00DF07   800 _FSCTRL1	=	0xdf07
                           00DF08   801 _FSCTRL0	=	0xdf08
                           00DF09   802 _FREQ2	=	0xdf09
                           00DF0A   803 _FREQ1	=	0xdf0a
                           00DF0B   804 _FREQ0	=	0xdf0b
                           00DF0C   805 _MDMCFG4	=	0xdf0c
                           00DF0D   806 _MDMCFG3	=	0xdf0d
                           00DF0E   807 _MDMCFG2	=	0xdf0e
                           00DF0F   808 _MDMCFG1	=	0xdf0f
                           00DF10   809 _MDMCFG0	=	0xdf10
                           00DF11   810 _DEVIATN	=	0xdf11
                           00DF12   811 _MCSM2	=	0xdf12
                           00DF13   812 _MCSM1	=	0xdf13
                           00DF14   813 _MCSM0	=	0xdf14
                           00DF15   814 _FOCCFG	=	0xdf15
                           00DF16   815 _BSCFG	=	0xdf16
                           00DF17   816 _AGCCTRL2	=	0xdf17
                           00DF18   817 _AGCCTRL1	=	0xdf18
                           00DF19   818 _AGCCTRL0	=	0xdf19
                           00DF1A   819 _FREND1	=	0xdf1a
                           00DF1B   820 _FREND0	=	0xdf1b
                           00DF1C   821 _FSCAL3	=	0xdf1c
                           00DF1D   822 _FSCAL2	=	0xdf1d
                           00DF1E   823 _FSCAL1	=	0xdf1e
                           00DF1F   824 _FSCAL0	=	0xdf1f
                           00DF20   825 __XREGDF20	=	0xdf20
                           00DF21   826 __XREGDF21	=	0xdf21
                           00DF22   827 __XREGDF22	=	0xdf22
                           00DF23   828 _TEST2	=	0xdf23
                           00DF24   829 _TEST1	=	0xdf24
                           00DF25   830 _TEST0	=	0xdf25
                           00DF26   831 __XREGDF26	=	0xdf26
                           00DF27   832 _PA_TABLE7	=	0xdf27
                           00DF28   833 _PA_TABLE6	=	0xdf28
                           00DF29   834 _PA_TABLE5	=	0xdf29
                           00DF2A   835 _PA_TABLE4	=	0xdf2a
                           00DF2B   836 _PA_TABLE3	=	0xdf2b
                           00DF2C   837 _PA_TABLE2	=	0xdf2c
                           00DF2D   838 _PA_TABLE1	=	0xdf2d
                           00DF2E   839 _PA_TABLE0	=	0xdf2e
                           00DF2F   840 _IOCFG2	=	0xdf2f
                           00DF30   841 _IOCFG1	=	0xdf30
                           00DF31   842 _IOCFG0	=	0xdf31
                           00DF32   843 __XREGDF32	=	0xdf32
                           00DF33   844 __XREGDF33	=	0xdf33
                           00DF34   845 __XREGDF34	=	0xdf34
                           00DF35   846 __XREGDF35	=	0xdf35
                           00DF36   847 _PARTNUM	=	0xdf36
                           00DF37   848 _VERSION	=	0xdf37
                           00DF38   849 _FREQEST	=	0xdf38
                           00DF39   850 _LQI	=	0xdf39
                           00DF3A   851 _RSSI	=	0xdf3a
                           00DF3B   852 _MARCSTATE	=	0xdf3b
                           00DF3C   853 _PKTSTATUS	=	0xdf3c
                           00DF3D   854 _VCO_VC_DAC	=	0xdf3d
                           00DF40   855 _I2SCFG0	=	0xdf40
                           00DF41   856 _I2SCFG1	=	0xdf41
                           00DF42   857 _I2SDATL	=	0xdf42
                           00DF43   858 _I2SDATH	=	0xdf43
                           00DF44   859 _I2SWCNT	=	0xdf44
                           00DF45   860 _I2SSTAT	=	0xdf45
                           00DF46   861 _I2SCLKF0	=	0xdf46
                           00DF47   862 _I2SCLKF1	=	0xdf47
                           00DF48   863 _I2SCLKF2	=	0xdf48
                           00DF80   864 __NA_P0	=	0xdf80
                           00DF81   865 __NA_SP	=	0xdf81
                           00DF82   866 __NA_DPL0	=	0xdf82
                           00DF83   867 __NA_DPH0	=	0xdf83
                           00DF84   868 __NA_DPL1	=	0xdf84
                           00DF85   869 __NA_DPH1	=	0xdf85
                           00DF86   870 _X_U0CSR	=	0xdf86
                           00DF87   871 __NA_PCON	=	0xdf87
                           00DF88   872 __NA_TCON	=	0xdf88
                           00DF89   873 _X_P0IFG	=	0xdf89
                           00DF8A   874 _X_P1IFG	=	0xdf8a
                           00DF8B   875 _X_P2IFG	=	0xdf8b
                           00DF8C   876 _X_PICTL	=	0xdf8c
                           00DF8D   877 _X_P1IEN	=	0xdf8d
                           00DF8E   878 __X_SFR8E	=	0xdf8e
                           00DF8F   879 _X_P0INP	=	0xdf8f
                           00DF90   880 __NA_P1	=	0xdf90
                           00DF91   881 _X_RFIM	=	0xdf91
                           00DF92   882 __NA_DPS	=	0xdf92
                           00DF93   883 _X_MPAGE	=	0xdf93
                           00DF94   884 __X_SFR94	=	0xdf94
                           00DF95   885 __X_SFR95	=	0xdf95
                           00DF96   886 __X_SFR96	=	0xdf96
                           00DF97   887 __X_SFR97	=	0xdf97
                           00DF98   888 __NA_S0CON	=	0xdf98
                           00DF99   889 __X_SFR99	=	0xdf99
                           00DF9A   890 __NA_IEN2	=	0xdf9a
                           00DF9B   891 __NA_S1CON	=	0xdf9b
                           00DF9C   892 _X_T2CT	=	0xdf9c
                           00DF9D   893 _X_T2PR	=	0xdf9d
                           00DF9E   894 _X_T2CTL	=	0xdf9e
                           00DF9F   895 __X_SFR9F	=	0xdf9f
                           00DFA0   896 __NA_P2	=	0xdfa0
                           00DFA1   897 _X_WORIRQ	=	0xdfa1
                           00DFA2   898 _X_WORCTRL	=	0xdfa2
                           00DFA3   899 _X_WOREVT0	=	0xdfa3
                           00DFA4   900 _X_WOREVT1	=	0xdfa4
                           00DFA5   901 _X_WORTIME0	=	0xdfa5
                           00DFA6   902 _X_WORTIME1	=	0xdfa6
                           00DFA7   903 __X_SFRA7	=	0xdfa7
                           00DFA8   904 __NA_IEN0	=	0xdfa8
                           00DFA9   905 __NA_IP0	=	0xdfa9
                           00DFAA   906 __X_SFRAA	=	0xdfaa
                           00DFAB   907 _X_FWT	=	0xdfab
                           00DFAC   908 _X_FADDRL	=	0xdfac
                           00DFAD   909 _X_FADDRH	=	0xdfad
                           00DFAE   910 _X_FCTL	=	0xdfae
                           00DFAF   911 _X_FWDATA	=	0xdfaf
                           00DFB0   912 __X_SFRB0	=	0xdfb0
                           00DFB1   913 _X_ENCDI	=	0xdfb1
                           00DFB2   914 _X_ENCDO	=	0xdfb2
                           00DFB3   915 _X_ENCCS	=	0xdfb3
                           00DFB4   916 _X_ADCCON1	=	0xdfb4
                           00DFB5   917 _X_ADCCON2	=	0xdfb5
                           00DFB6   918 _X_ADCCON3	=	0xdfb6
                           00DFB7   919 __X_SFRB7	=	0xdfb7
                           00DFB8   920 __NA_IEN1	=	0xdfb8
                           00DFB9   921 __NA_IP1	=	0xdfb9
                           00DFBA   922 _X_ADCL	=	0xdfba
                           00DFBB   923 _X_ADCH	=	0xdfbb
                           00DFBC   924 _X_RNDL	=	0xdfbc
                           00DFBD   925 _X_RNDH	=	0xdfbd
                           00DFBE   926 _X_SLEEP	=	0xdfbe
                           00DFBF   927 __X_SFRBF	=	0xdfbf
                           00DFC0   928 __NA_IRCON	=	0xdfc0
                           00DFC1   929 _X_U0DBUF	=	0xdfc1
                           00DFC2   930 _X_U0BAUD	=	0xdfc2
                           00DFC3   931 __X_SFRC3	=	0xdfc3
                           00DFC4   932 _X_U0UCR	=	0xdfc4
                           00DFC5   933 _X_U0GCR	=	0xdfc5
                           00DFC6   934 _X_CLKCON	=	0xdfc6
                           00DFC7   935 _X_MEMCTR	=	0xdfc7
                           00DFC8   936 __X_SFRC8	=	0xdfc8
                           00DFC9   937 _X_WDCTL	=	0xdfc9
                           00DFCA   938 _X_T3CNT	=	0xdfca
                           00DFCB   939 _X_T3CTL	=	0xdfcb
                           00DFCC   940 _X_T3CCTL0	=	0xdfcc
                           00DFCD   941 _X_T3CC0	=	0xdfcd
                           00DFCE   942 _X_T3CCTL1	=	0xdfce
                           00DFCF   943 _X_T3CC1	=	0xdfcf
                           00DFD0   944 __NA_PSW	=	0xdfd0
                           00DFD1   945 _X_DMAIRQ	=	0xdfd1
                           00DFD2   946 _X_DMA1CFGL	=	0xdfd2
                           00DFD3   947 _X_DMA1CFGH	=	0xdfd3
                           00DFD4   948 _X_DMA0CFGL	=	0xdfd4
                           00DFD5   949 _X_DMA0CFGH	=	0xdfd5
                           00DFD6   950 _X_DMAARM	=	0xdfd6
                           00DFD7   951 _X_DMAREQ	=	0xdfd7
                           00DFD8   952 _X_TIMIF	=	0xdfd8
                           00DFD9   953 _X_RFD	=	0xdfd9
                           00DFDA   954 _X_T1CC0L	=	0xdfda
                           00DFDB   955 _X_T1CC0H	=	0xdfdb
                           00DFDC   956 _X_T1CC1L	=	0xdfdc
                           00DFDD   957 _X_T1CC1H	=	0xdfdd
                           00DFDE   958 _X_T1CC2L	=	0xdfde
                           00DFDF   959 _X_T1CC2H	=	0xdfdf
                           00DFE0   960 __NA_ACC	=	0xdfe0
                           00DFE1   961 _X_RFST	=	0xdfe1
                           00DFE2   962 _X_T1CNTL	=	0xdfe2
                           00DFE3   963 _X_T1CNTH	=	0xdfe3
                           00DFE4   964 _X_T1CTL	=	0xdfe4
                           00DFE5   965 _X_T1CCTL0	=	0xdfe5
                           00DFE6   966 _X_T1CCTL1	=	0xdfe6
                           00DFE7   967 _X_T1CCTL2	=	0xdfe7
                           00DFE8   968 __NA_IRCON2	=	0xdfe8
                           00DFE9   969 _X_RFIF	=	0xdfe9
                           00DFEA   970 _X_T4CNT	=	0xdfea
                           00DFEB   971 _X_T4CTL	=	0xdfeb
                           00DFEC   972 _X_T4CCTL0	=	0xdfec
                           00DFED   973 _X_T4CC0	=	0xdfed
                           00DFEE   974 _X_T4CCTL1	=	0xdfee
                           00DFEF   975 _X_T4CC1	=	0xdfef
                           00DFF0   976 __NA_B	=	0xdff0
                           00DFF1   977 _X_PERCFG	=	0xdff1
                           00DFF2   978 _X_ADCCFG	=	0xdff2
                           00DFF3   979 _X_P0SEL	=	0xdff3
                           00DFF4   980 _X_P1SEL	=	0xdff4
                           00DFF5   981 _X_P2SEL	=	0xdff5
                           00DFF6   982 _X_P1INP	=	0xdff6
                           00DFF7   983 _X_P2INP	=	0xdff7
                           00DFF8   984 _X_U1CSR	=	0xdff8
                           00DFF9   985 _X_U1DBUF	=	0xdff9
                           00DFFA   986 _X_U1BAUD	=	0xdffa
                           00DFFB   987 _X_U1UCR	=	0xdffb
                           00DFFC   988 _X_U1GCR	=	0xdffc
                           00DFFD   989 _X_P0DIR	=	0xdffd
                           00DFFE   990 _X_P1DIR	=	0xdffe
                           00DFFF   991 _X_P2DIR	=	0xdfff
      00F0B8                        992 _radio_rx_buf:
      00F0B8                        993 	.ds 32
      00F0D8                        994 _rx_fifo:
      00F0D8                        995 	.ds 6
      00F0DE                        996 _radio_tx_buf:
      00F0DE                        997 	.ds 255
      00F1DD                        998 _radio_tx_buf_read_idx:
      00F1DD                        999 	.ds 1
      00F1DE                       1000 _radio_tx_buf_len:
      00F1DE                       1001 	.ds 1
      00F1DF                       1002 _preamble_word:
      00F1DF                       1003 	.ds 2
      00F1E1                       1004 _get_packet_and_write_to_serial_decoder_65536_145:
      00F1E1                       1005 	.ds 4
      00F1E5                       1006 _get_packet_and_write_to_serial_decoder_state_65536_145:
      00F1E5                       1007 	.ds 6
                                   1008 ;--------------------------------------------------------
                                   1009 ; absolute external ram data
                                   1010 ;--------------------------------------------------------
                                   1011 	.area XABS    (ABS,XDATA)
                                   1012 ;--------------------------------------------------------
                                   1013 ; external initialized ram data
                                   1014 ;--------------------------------------------------------
                                   1015 	.area XISEG   (XDATA)
                                   1016 	.area HOME    (CODE)
                                   1017 	.area GSINIT0 (CODE)
                                   1018 	.area GSINIT1 (CODE)
                                   1019 	.area GSINIT2 (CODE)
                                   1020 	.area GSINIT3 (CODE)
                                   1021 	.area GSINIT4 (CODE)
                                   1022 	.area GSINIT5 (CODE)
                                   1023 	.area GSINIT  (CODE)
                                   1024 	.area GSFINAL (CODE)
                                   1025 	.area CSEG    (CODE)
                                   1026 ;--------------------------------------------------------
                                   1027 ; global & static initialisations
                                   1028 ;--------------------------------------------------------
                                   1029 	.area HOME    (CODE)
                                   1030 	.area GSINIT  (CODE)
                                   1031 	.area GSFINAL (CODE)
                                   1032 	.area GSINIT  (CODE)
                                   1033 ;	radio.c:51: EncodingType encoding_type = EncodingTypeNone;
      0000E4 78 05            [12] 1034 	mov	r0,#_encoding_type
      0000E6 E4               [12] 1035 	clr	a
      0000E7 F2               [24] 1036 	movx	@r0,a
                                   1037 ;--------------------------------------------------------
                                   1038 ; Home
                                   1039 ;--------------------------------------------------------
                                   1040 	.area HOME    (CODE)
                                   1041 	.area HOME    (CODE)
                                   1042 ;--------------------------------------------------------
                                   1043 ; code
                                   1044 ;--------------------------------------------------------
                                   1045 	.area CSEG    (CODE)
                                   1046 ;------------------------------------------------------------
                                   1047 ;Allocation info for local variables in function 'configure_radio'
                                   1048 ;------------------------------------------------------------
                                   1049 ;	radio.c:53: void configure_radio()
                                   1050 ;	-----------------------------------------
                                   1051 ;	 function configure_radio
                                   1052 ;	-----------------------------------------
      0001C7                       1053 _configure_radio:
                           000007  1054 	ar7 = 0x07
                           000006  1055 	ar6 = 0x06
                           000005  1056 	ar5 = 0x05
                           000004  1057 	ar4 = 0x04
                           000003  1058 	ar3 = 0x03
                           000002  1059 	ar2 = 0x02
                           000001  1060 	ar1 = 0x01
                           000000  1061 	ar0 = 0x00
                                   1062 ;	radio.c:56: SYNC1     = 0xFF; // sync word, high byte
      0001C7 90 DF 00         [24] 1063 	mov	dptr,#_SYNC1
      0001CA 74 FF            [12] 1064 	mov	a,#0xff
      0001CC F0               [24] 1065 	movx	@dptr,a
                                   1066 ;	radio.c:57: SYNC0     = 0x00; // sync word, low byte
      0001CD 90 DF 01         [24] 1067 	mov	dptr,#_SYNC0
      0001D0 E4               [12] 1068 	clr	a
      0001D1 F0               [24] 1069 	movx	@dptr,a
                                   1070 ;	radio.c:58: PKTLEN    = 0xFF; // packet length
      0001D2 90 DF 02         [24] 1071 	mov	dptr,#_PKTLEN
      0001D5 14               [12] 1072 	dec	a
      0001D6 F0               [24] 1073 	movx	@dptr,a
                                   1074 ;	radio.c:59: PKTCTRL1  = 0x00; // packet automation control
      0001D7 90 DF 03         [24] 1075 	mov	dptr,#_PKTCTRL1
      0001DA E4               [12] 1076 	clr	a
      0001DB F0               [24] 1077 	movx	@dptr,a
                                   1078 ;	radio.c:60: PKTCTRL0  = 0x00; // packet automation control
      0001DC 90 DF 04         [24] 1079 	mov	dptr,#_PKTCTRL0
      0001DF F0               [24] 1080 	movx	@dptr,a
                                   1081 ;	radio.c:61: ADDR      = 0x00;
      0001E0 90 DF 05         [24] 1082 	mov	dptr,#_ADDR
      0001E3 F0               [24] 1083 	movx	@dptr,a
                                   1084 ;	radio.c:63: FSCTRL1   = 0x06; // frequency synthesizer control
      0001E4 90 DF 07         [24] 1085 	mov	dptr,#_FSCTRL1
      0001E7 74 06            [12] 1086 	mov	a,#0x06
      0001E9 F0               [24] 1087 	movx	@dptr,a
                                   1088 ;	radio.c:64: FSCTRL0   = 0x00;
      0001EA 90 DF 08         [24] 1089 	mov	dptr,#_FSCTRL0
      0001ED E4               [12] 1090 	clr	a
      0001EE F0               [24] 1091 	movx	@dptr,a
                                   1092 ;	radio.c:66: MDMCFG4   = 0x99; // 150.5 kHz rx filter bandwidth. Narrower can improve range,
      0001EF 90 DF 0C         [24] 1093 	mov	dptr,#_MDMCFG4
      0001F2 74 99            [12] 1094 	mov	a,#0x99
      0001F4 F0               [24] 1095 	movx	@dptr,a
                                   1096 ;	radio.c:69: MDMCFG3   = 0x66; // modem configuration
      0001F5 90 DF 0D         [24] 1097 	mov	dptr,#_MDMCFG3
      0001F8 F4               [12] 1098 	cpl	a
      0001F9 F0               [24] 1099 	movx	@dptr,a
                                   1100 ;	radio.c:70: MDMCFG2   = 0x33; // modem configuration
      0001FA 90 DF 0E         [24] 1101 	mov	dptr,#_MDMCFG2
      0001FD 03               [12] 1102 	rr	a
      0001FE F0               [24] 1103 	movx	@dptr,a
                                   1104 ;	radio.c:71: MDMCFG1   = 0x61; // modem configuration
      0001FF 90 DF 0F         [24] 1105 	mov	dptr,#_MDMCFG1
      000202 74 61            [12] 1106 	mov	a,#0x61
      000204 F0               [24] 1107 	movx	@dptr,a
                                   1108 ;	radio.c:72: MDMCFG0   = 0x7E; // modem configuration
      000205 90 DF 10         [24] 1109 	mov	dptr,#_MDMCFG0
      000208 74 7E            [12] 1110 	mov	a,#0x7e
      00020A F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	radio.c:73: DEVIATN   = 0x15; // modem deviation setting
      00020B 90 DF 11         [24] 1113 	mov	dptr,#_DEVIATN
      00020E 74 15            [12] 1114 	mov	a,#0x15
      000210 F0               [24] 1115 	movx	@dptr,a
                                   1116 ;	radio.c:74: MCSM2     = 0x07;
      000211 90 DF 12         [24] 1117 	mov	dptr,#_MCSM2
      000214 74 07            [12] 1118 	mov	a,#0x07
      000216 F0               [24] 1119 	movx	@dptr,a
                                   1120 ;	radio.c:75: MCSM1     = 0x30;
      000217 90 DF 13         [24] 1121 	mov	dptr,#_MCSM1
      00021A 74 30            [12] 1122 	mov	a,#0x30
      00021C F0               [24] 1123 	movx	@dptr,a
                                   1124 ;	radio.c:76: MCSM0     = 0x18; // main radio control state machine configuration
      00021D 90 DF 14         [24] 1125 	mov	dptr,#_MCSM0
      000220 03               [12] 1126 	rr	a
      000221 F0               [24] 1127 	movx	@dptr,a
                                   1128 ;	radio.c:77: FOCCFG    = 0x17; // frequency offset compensation configuration
      000222 90 DF 15         [24] 1129 	mov	dptr,#_FOCCFG
      000225 14               [12] 1130 	dec	a
      000226 F0               [24] 1131 	movx	@dptr,a
                                   1132 ;	radio.c:78: BSCFG     = 0x6C; // bit synchronization configuration
      000227 90 DF 16         [24] 1133 	mov	dptr,#_BSCFG
      00022A 74 6C            [12] 1134 	mov	a,#0x6c
      00022C F0               [24] 1135 	movx	@dptr,a
                                   1136 ;	radio.c:79: FREND1    = 0xB6; // front end tx configuration
      00022D 90 DF 1A         [24] 1137 	mov	dptr,#_FREND1
      000230 74 B6            [12] 1138 	mov	a,#0xb6
      000232 F0               [24] 1139 	movx	@dptr,a
                                   1140 ;	radio.c:80: FREND0    = 0x11; // front end tx configuration
      000233 90 DF 1B         [24] 1141 	mov	dptr,#_FREND0
      000236 74 11            [12] 1142 	mov	a,#0x11
      000238 F0               [24] 1143 	movx	@dptr,a
                                   1144 ;	radio.c:81: FSCAL3    = 0xE9; // frequency synthesizer calibration
      000239 90 DF 1C         [24] 1145 	mov	dptr,#_FSCAL3
      00023C 74 E9            [12] 1146 	mov	a,#0xe9
      00023E F0               [24] 1147 	movx	@dptr,a
                                   1148 ;	radio.c:82: FSCAL2    = 0x2A; // frequency synthesizer calibration
      00023F 90 DF 1D         [24] 1149 	mov	dptr,#_FSCAL2
      000242 74 2A            [12] 1150 	mov	a,#0x2a
      000244 F0               [24] 1151 	movx	@dptr,a
                                   1152 ;	radio.c:83: FSCAL1    = 0x00; // frequency synthesizer calibration
      000245 90 DF 1E         [24] 1153 	mov	dptr,#_FSCAL1
      000248 E4               [12] 1154 	clr	a
      000249 F0               [24] 1155 	movx	@dptr,a
                                   1156 ;	radio.c:84: FSCAL0    = 0x1F; // frequency synthesizer calibration
      00024A 90 DF 1F         [24] 1157 	mov	dptr,#_FSCAL0
      00024D 74 1F            [12] 1158 	mov	a,#0x1f
      00024F F0               [24] 1159 	movx	@dptr,a
                                   1160 ;	radio.c:85: TEST1     = 0x31; // various test settings
      000250 90 DF 24         [24] 1161 	mov	dptr,#_TEST1
      000253 74 31            [12] 1162 	mov	a,#0x31
      000255 F0               [24] 1163 	movx	@dptr,a
                                   1164 ;	radio.c:86: TEST0     = 0x09; // various test settings
      000256 90 DF 25         [24] 1165 	mov	dptr,#_TEST0
      000259 74 09            [12] 1166 	mov	a,#0x09
      00025B F0               [24] 1167 	movx	@dptr,a
                                   1168 ;	radio.c:87: PA_TABLE0 = 0x00; // needs to be explicitly set!
      00025C 90 DF 2E         [24] 1169 	mov	dptr,#_PA_TABLE0
      00025F E4               [12] 1170 	clr	a
      000260 F0               [24] 1171 	movx	@dptr,a
                                   1172 ;	radio.c:90: AGCCTRL2 = 0x07; // 0x03 to 0x07 - default: 0x03
      000261 90 DF 17         [24] 1173 	mov	dptr,#_AGCCTRL2
      000264 74 07            [12] 1174 	mov	a,#0x07
      000266 F0               [24] 1175 	movx	@dptr,a
                                   1176 ;	radio.c:91: AGCCTRL1 = 0x00; // 0x00         - default: 0x40
      000267 90 DF 18         [24] 1177 	mov	dptr,#_AGCCTRL1
      00026A E4               [12] 1178 	clr	a
      00026B F0               [24] 1179 	movx	@dptr,a
                                   1180 ;	radio.c:92: AGCCTRL0 = 0x91; // 0x91 or 0x92 - default: 0x91
      00026C 90 DF 19         [24] 1181 	mov	dptr,#_AGCCTRL0
      00026F 74 91            [12] 1182 	mov	a,#0x91
      000271 F0               [24] 1183 	movx	@dptr,a
                                   1184 ;	radio.c:95: FREQ2     = 0x26; // 916.541MHz is midpoint between freq of pump in free space,
      000272 90 DF 09         [24] 1185 	mov	dptr,#_FREQ2
      000275 74 26            [12] 1186 	mov	a,#0x26
      000277 F0               [24] 1187 	movx	@dptr,a
                                   1188 ;	radio.c:96: FREQ1     = 0x30; // and pump held close to the body.
      000278 90 DF 0A         [24] 1189 	mov	dptr,#_FREQ1
      00027B 74 30            [12] 1190 	mov	a,#0x30
      00027D F0               [24] 1191 	movx	@dptr,a
                                   1192 ;	radio.c:97: FREQ0     = 0x70; //
      00027E 90 DF 0B         [24] 1193 	mov	dptr,#_FREQ0
      000281 74 70            [12] 1194 	mov	a,#0x70
      000283 F0               [24] 1195 	movx	@dptr,a
                                   1196 ;	radio.c:98: CHANNR    = 0x02; // channel number
      000284 90 DF 06         [24] 1197 	mov	dptr,#_CHANNR
      000287 74 02            [12] 1198 	mov	a,#0x02
      000289 F0               [24] 1199 	movx	@dptr,a
                                   1200 ;	radio.c:99: PA_TABLE1 = 0xC0; // pa power setting 10 dBm
      00028A 90 DF 2D         [24] 1201 	mov	dptr,#_PA_TABLE1
      00028D 74 C0            [12] 1202 	mov	a,#0xc0
      00028F F0               [24] 1203 	movx	@dptr,a
                                   1204 ;	radio.c:108: IEN2 |= IEN2_RFIE;
      000290 43 9A 01         [24] 1205 	orl	_IEN2,#0x01
                                   1206 ;	radio.c:109: RFTXRXIE = 1;
                                   1207 ;	assignBit
      000293 D2 A8            [12] 1208 	setb	_RFTXRXIE
                                   1209 ;	radio.c:111: fifo_init(&rx_fifo, radio_rx_buf, RX_FIFO_SIZE);
                                   1210 ;	fifo.h:71: if (b) {
      000295 74 D8            [12] 1211 	mov	a,#_rx_fifo
      000297 44 F0            [12] 1212 	orl	a,#(_rx_fifo >> 8)
      000299 60 2F            [24] 1213 	jz	00104$
                                   1214 ;	fifo.h:72: b->head = 0;
      00029B 90 F0 D8         [24] 1215 	mov	dptr,#_rx_fifo
      00029E E4               [12] 1216 	clr	a
      00029F F0               [24] 1217 	movx	@dptr,a
                                   1218 ;	fifo.h:73: b->tail = 0;
      0002A0 90 F0 D9         [24] 1219 	mov	dptr,#(_rx_fifo + 0x0001)
      0002A3 75 F0 00         [24] 1220 	mov	b,#0x00
      0002A6 12 2D 8A         [24] 1221 	lcall	__gptrput
                                   1222 ;	fifo.h:74: b->buffer = buffer;
      0002A9 90 F0 DA         [24] 1223 	mov	dptr,#(_rx_fifo + 0x0002)
      0002AC 75 F0 00         [24] 1224 	mov	b,#0x00
      0002AF 74 B8            [12] 1225 	mov	a,#_radio_rx_buf
      0002B1 12 2D 8A         [24] 1226 	lcall	__gptrput
      0002B4 A3               [24] 1227 	inc	dptr
      0002B5 74 F0            [12] 1228 	mov	a,#(_radio_rx_buf >> 8)
      0002B7 12 2D 8A         [24] 1229 	lcall	__gptrput
      0002BA A3               [24] 1230 	inc	dptr
      0002BB E4               [12] 1231 	clr	a
      0002BC 12 2D 8A         [24] 1232 	lcall	__gptrput
                                   1233 ;	fifo.h:75: b->buffer_len = size;
      0002BF 90 F0 DD         [24] 1234 	mov	dptr,#(_rx_fifo + 0x0005)
      0002C2 75 F0 00         [24] 1235 	mov	b,#0x00
      0002C5 74 20            [12] 1236 	mov	a,#0x20
                                   1237 ;	radio.c:111: fifo_init(&rx_fifo, radio_rx_buf, RX_FIFO_SIZE);
                                   1238 ;	radio.c:112: }
      0002C7 02 2D 8A         [24] 1239 	ljmp	__gptrput
      0002CA                       1240 00104$:
      0002CA 22               [24] 1241 	ret
                                   1242 ;------------------------------------------------------------
                                   1243 ;Allocation info for local variables in function 'set_encoding_type'
                                   1244 ;------------------------------------------------------------
                                   1245 ;	radio.c:115: bool set_encoding_type(EncodingType new_type) {
                                   1246 ;	-----------------------------------------
                                   1247 ;	 function set_encoding_type
                                   1248 ;	-----------------------------------------
      0002CB                       1249 _set_encoding_type:
                                   1250 ;	radio.c:116: if (new_type <= MaxEncodingTypeValue) {
      0002CB E5 82            [12] 1251 	mov	a,dpl
      0002CD FF               [12] 1252 	mov	r7,a
      0002CE 24 FD            [12] 1253 	add	a,#0xff - 0x02
      0002D0 40 08            [24] 1254 	jc	00102$
                                   1255 ;	radio.c:117: encoding_type = new_type;
      0002D2 78 05            [12] 1256 	mov	r0,#_encoding_type
      0002D4 EF               [12] 1257 	mov	a,r7
      0002D5 F2               [24] 1258 	movx	@r0,a
                                   1259 ;	radio.c:118: return true;
      0002D6 75 82 01         [24] 1260 	mov	dpl,#0x01
      0002D9 22               [24] 1261 	ret
      0002DA                       1262 00102$:
                                   1263 ;	radio.c:120: return false;
      0002DA 75 82 00         [24] 1264 	mov	dpl,#0x00
                                   1265 ;	radio.c:122: }
      0002DD 22               [24] 1266 	ret
                                   1267 ;------------------------------------------------------------
                                   1268 ;Allocation info for local variables in function 'rftxrx_isr'
                                   1269 ;------------------------------------------------------------
                                   1270 ;	radio.c:132: void rftxrx_isr(void) __interrupt RFTXRX_VECTOR {
                                   1271 ;	-----------------------------------------
                                   1272 ;	 function rftxrx_isr
                                   1273 ;	-----------------------------------------
      0002DE                       1274 _rftxrx_isr:
      0002DE C0 E0            [24] 1275 	push	acc
      0002E0 C0 F0            [24] 1276 	push	b
      0002E2 C0 82            [24] 1277 	push	dpl
      0002E4 C0 83            [24] 1278 	push	dph
      0002E6 C0 07            [24] 1279 	push	ar7
      0002E8 C0 06            [24] 1280 	push	ar6
      0002EA C0 05            [24] 1281 	push	ar5
      0002EC C0 04            [24] 1282 	push	ar4
      0002EE C0 03            [24] 1283 	push	ar3
      0002F0 C0 02            [24] 1284 	push	ar2
      0002F2 C0 00            [24] 1285 	push	ar0
      0002F4 C0 D0            [24] 1286 	push	psw
      0002F6 75 D0 00         [24] 1287 	mov	psw,#0x00
                                   1288 ;	radio.c:134: CLKCON =  0xA8;		//CLKSPD = 24Mhz, TICKSPD = 750Khz
      0002F9 75 C6 A8         [24] 1289 	mov	_CLKCON,#0xa8
                                   1290 ;	radio.c:135: if (MARCSTATE==MARC_STATE_RX) {
      0002FC 90 DF 3B         [24] 1291 	mov	dptr,#_MARCSTATE
      0002FF E0               [24] 1292 	movx	a,@dptr
      000300 FF               [12] 1293 	mov	r7,a
      000301 BF 0D 02         [24] 1294 	cjne	r7,#0x0d,00171$
      000304 80 03            [24] 1295 	sjmp	00172$
      000306                       1296 00171$:
      000306 02 04 4D         [24] 1297 	ljmp	00119$
      000309                       1298 00172$:
                                   1299 ;	radio.c:136: d_byte = RFD;
      000309 AF D9            [24] 1300 	mov	r7,_RFD
                                   1301 ;	radio.c:137: if (rx_len == 0) {
      00030B 78 02            [12] 1302 	mov	r0,#_rx_len
      00030D E2               [24] 1303 	movx	a,@r0
      00030E 60 03            [24] 1304 	jz	00173$
      000310 02 03 E5         [24] 1305 	ljmp	00102$
      000313                       1306 00173$:
                                   1307 ;	radio.c:138: put_rx(RSSI);
      000313 90 DF 3A         [24] 1308 	mov	dptr,#_RSSI
      000316 E0               [24] 1309 	movx	a,@dptr
      000317 FE               [12] 1310 	mov	r6,a
                                   1311 ;	radio.c:125: if (rx_fifo.head - rx_fifo.tail == RX_FIFO_SIZE) radio_rx_fifo_overflow_count++;
      000318 90 F0 D8         [24] 1312 	mov	dptr,#_rx_fifo
      00031B E0               [24] 1313 	movx	a,@dptr
      00031C FD               [12] 1314 	mov	r5,a
      00031D 7C 00            [12] 1315 	mov	r4,#0x00
      00031F 90 F0 D9         [24] 1316 	mov	dptr,#(_rx_fifo + 0x0001)
      000322 E0               [24] 1317 	movx	a,@dptr
      000323 FB               [12] 1318 	mov	r3,a
      000324 7A 00            [12] 1319 	mov	r2,#0x00
      000326 ED               [12] 1320 	mov	a,r5
      000327 C3               [12] 1321 	clr	c
      000328 9B               [12] 1322 	subb	a,r3
      000329 FD               [12] 1323 	mov	r5,a
      00032A EC               [12] 1324 	mov	a,r4
      00032B 9A               [12] 1325 	subb	a,r2
      00032C FC               [12] 1326 	mov	r4,a
      00032D BD 20 16         [24] 1327 	cjne	r5,#0x20,00122$
      000330 BC 00 13         [24] 1328 	cjne	r4,#0x00,00122$
      000333 78 67            [12] 1329 	mov	r0,#_radio_rx_fifo_overflow_count
      000335 E2               [24] 1330 	movx	a,@r0
      000336 FC               [12] 1331 	mov	r4,a
      000337 08               [12] 1332 	inc	r0
      000338 E2               [24] 1333 	movx	a,@r0
      000339 FD               [12] 1334 	mov	r5,a
      00033A 78 67            [12] 1335 	mov	r0,#_radio_rx_fifo_overflow_count
      00033C 74 01            [12] 1336 	mov	a,#0x01
      00033E 2C               [12] 1337 	add	a,r4
      00033F F2               [24] 1338 	movx	@r0,a
      000340 E4               [12] 1339 	clr	a
      000341 3D               [12] 1340 	addc	a,r5
      000342 08               [12] 1341 	inc	r0
      000343 F2               [24] 1342 	movx	@r0,a
      000344 80 34            [24] 1343 	sjmp	00124$
      000346                       1344 00122$:
                                   1345 ;	radio.c:127: rx_fifo.buffer[rx_fifo.head & RX_FIFO_MASK] = data; 
      000346 C0 07            [24] 1346 	push	ar7
      000348 90 F0 DA         [24] 1347 	mov	dptr,#(_rx_fifo + 0x0002)
      00034B E0               [24] 1348 	movx	a,@dptr
      00034C FB               [12] 1349 	mov	r3,a
      00034D A3               [24] 1350 	inc	dptr
      00034E E0               [24] 1351 	movx	a,@dptr
      00034F FC               [12] 1352 	mov	r4,a
      000350 A3               [24] 1353 	inc	dptr
      000351 E0               [24] 1354 	movx	a,@dptr
      000352 FD               [12] 1355 	mov	r5,a
      000353 90 F0 D8         [24] 1356 	mov	dptr,#_rx_fifo
      000356 E0               [24] 1357 	movx	a,@dptr
      000357 FA               [12] 1358 	mov	r2,a
      000358 53 02 1F         [24] 1359 	anl	ar2,#0x1f
      00035B 7F 00            [12] 1360 	mov	r7,#0x00
      00035D EA               [12] 1361 	mov	a,r2
      00035E 2B               [12] 1362 	add	a,r3
      00035F FB               [12] 1363 	mov	r3,a
      000360 EF               [12] 1364 	mov	a,r7
      000361 3C               [12] 1365 	addc	a,r4
      000362 FC               [12] 1366 	mov	r4,a
      000363 8B 82            [24] 1367 	mov	dpl,r3
      000365 8C 83            [24] 1368 	mov	dph,r4
      000367 8D F0            [24] 1369 	mov	b,r5
      000369 EE               [12] 1370 	mov	a,r6
      00036A 12 2D 8A         [24] 1371 	lcall	__gptrput
                                   1372 ;	radio.c:128: rx_fifo.head++;
      00036D 90 F0 D8         [24] 1373 	mov	dptr,#_rx_fifo
      000370 E0               [24] 1374 	movx	a,@dptr
      000371 FF               [12] 1375 	mov	r7,a
      000372 0F               [12] 1376 	inc	r7
      000373 90 F0 D8         [24] 1377 	mov	dptr,#_rx_fifo
      000376 EF               [12] 1378 	mov	a,r7
      000377 F0               [24] 1379 	movx	@dptr,a
                                   1380 ;	radio.c:179: }
      000378 D0 07            [24] 1381 	pop	ar7
                                   1382 ;	radio.c:138: put_rx(RSSI);
      00037A                       1383 00124$:
                                   1384 ;	radio.c:139: put_rx(packet_rx_count & 0xff);
      00037A 78 69            [12] 1385 	mov	r0,#_packet_rx_count
      00037C E2               [24] 1386 	movx	a,@r0
      00037D FE               [12] 1387 	mov	r6,a
                                   1388 ;	radio.c:125: if (rx_fifo.head - rx_fifo.tail == RX_FIFO_SIZE) radio_rx_fifo_overflow_count++;
      00037E 90 F0 D8         [24] 1389 	mov	dptr,#_rx_fifo
      000381 E0               [24] 1390 	movx	a,@dptr
      000382 FD               [12] 1391 	mov	r5,a
      000383 7C 00            [12] 1392 	mov	r4,#0x00
      000385 90 F0 D9         [24] 1393 	mov	dptr,#(_rx_fifo + 0x0001)
      000388 E0               [24] 1394 	movx	a,@dptr
      000389 FB               [12] 1395 	mov	r3,a
      00038A 7A 00            [12] 1396 	mov	r2,#0x00
      00038C ED               [12] 1397 	mov	a,r5
      00038D C3               [12] 1398 	clr	c
      00038E 9B               [12] 1399 	subb	a,r3
      00038F FD               [12] 1400 	mov	r5,a
      000390 EC               [12] 1401 	mov	a,r4
      000391 9A               [12] 1402 	subb	a,r2
      000392 FC               [12] 1403 	mov	r4,a
      000393 BD 20 16         [24] 1404 	cjne	r5,#0x20,00126$
      000396 BC 00 13         [24] 1405 	cjne	r4,#0x00,00126$
      000399 78 67            [12] 1406 	mov	r0,#_radio_rx_fifo_overflow_count
      00039B E2               [24] 1407 	movx	a,@r0
      00039C FC               [12] 1408 	mov	r4,a
      00039D 08               [12] 1409 	inc	r0
      00039E E2               [24] 1410 	movx	a,@r0
      00039F FD               [12] 1411 	mov	r5,a
      0003A0 78 67            [12] 1412 	mov	r0,#_radio_rx_fifo_overflow_count
      0003A2 74 01            [12] 1413 	mov	a,#0x01
      0003A4 2C               [12] 1414 	add	a,r4
      0003A5 F2               [24] 1415 	movx	@r0,a
      0003A6 E4               [12] 1416 	clr	a
      0003A7 3D               [12] 1417 	addc	a,r5
      0003A8 08               [12] 1418 	inc	r0
      0003A9 F2               [24] 1419 	movx	@r0,a
      0003AA 80 34            [24] 1420 	sjmp	00128$
      0003AC                       1421 00126$:
                                   1422 ;	radio.c:127: rx_fifo.buffer[rx_fifo.head & RX_FIFO_MASK] = data; 
      0003AC C0 07            [24] 1423 	push	ar7
      0003AE 90 F0 DA         [24] 1424 	mov	dptr,#(_rx_fifo + 0x0002)
      0003B1 E0               [24] 1425 	movx	a,@dptr
      0003B2 FB               [12] 1426 	mov	r3,a
      0003B3 A3               [24] 1427 	inc	dptr
      0003B4 E0               [24] 1428 	movx	a,@dptr
      0003B5 FC               [12] 1429 	mov	r4,a
      0003B6 A3               [24] 1430 	inc	dptr
      0003B7 E0               [24] 1431 	movx	a,@dptr
      0003B8 FD               [12] 1432 	mov	r5,a
      0003B9 90 F0 D8         [24] 1433 	mov	dptr,#_rx_fifo
      0003BC E0               [24] 1434 	movx	a,@dptr
      0003BD FA               [12] 1435 	mov	r2,a
      0003BE 53 02 1F         [24] 1436 	anl	ar2,#0x1f
      0003C1 7F 00            [12] 1437 	mov	r7,#0x00
      0003C3 EA               [12] 1438 	mov	a,r2
      0003C4 2B               [12] 1439 	add	a,r3
      0003C5 FB               [12] 1440 	mov	r3,a
      0003C6 EF               [12] 1441 	mov	a,r7
      0003C7 3C               [12] 1442 	addc	a,r4
      0003C8 FC               [12] 1443 	mov	r4,a
      0003C9 8B 82            [24] 1444 	mov	dpl,r3
      0003CB 8C 83            [24] 1445 	mov	dph,r4
      0003CD 8D F0            [24] 1446 	mov	b,r5
      0003CF EE               [12] 1447 	mov	a,r6
      0003D0 12 2D 8A         [24] 1448 	lcall	__gptrput
                                   1449 ;	radio.c:128: rx_fifo.head++;
      0003D3 90 F0 D8         [24] 1450 	mov	dptr,#_rx_fifo
      0003D6 E0               [24] 1451 	movx	a,@dptr
      0003D7 FF               [12] 1452 	mov	r7,a
      0003D8 0F               [12] 1453 	inc	r7
      0003D9 90 F0 D8         [24] 1454 	mov	dptr,#_rx_fifo
      0003DC EF               [12] 1455 	mov	a,r7
      0003DD F0               [24] 1456 	movx	@dptr,a
                                   1457 ;	radio.c:179: }
      0003DE D0 07            [24] 1458 	pop	ar7
                                   1459 ;	radio.c:139: put_rx(packet_rx_count & 0xff);
      0003E0                       1460 00128$:
                                   1461 ;	radio.c:140: rx_len = 2;
      0003E0 78 02            [12] 1462 	mov	r0,#_rx_len
      0003E2 74 02            [12] 1463 	mov	a,#0x02
      0003E4 F2               [24] 1464 	movx	@r0,a
      0003E5                       1465 00102$:
                                   1466 ;	radio.c:125: if (rx_fifo.head - rx_fifo.tail == RX_FIFO_SIZE) radio_rx_fifo_overflow_count++;
      0003E5 90 F0 D8         [24] 1467 	mov	dptr,#_rx_fifo
      0003E8 E0               [24] 1468 	movx	a,@dptr
      0003E9 FE               [12] 1469 	mov	r6,a
      0003EA 7D 00            [12] 1470 	mov	r5,#0x00
      0003EC 90 F0 D9         [24] 1471 	mov	dptr,#(_rx_fifo + 0x0001)
      0003EF E0               [24] 1472 	movx	a,@dptr
      0003F0 FC               [12] 1473 	mov	r4,a
      0003F1 7B 00            [12] 1474 	mov	r3,#0x00
      0003F3 EE               [12] 1475 	mov	a,r6
      0003F4 C3               [12] 1476 	clr	c
      0003F5 9C               [12] 1477 	subb	a,r4
      0003F6 FE               [12] 1478 	mov	r6,a
      0003F7 ED               [12] 1479 	mov	a,r5
      0003F8 9B               [12] 1480 	subb	a,r3
      0003F9 FD               [12] 1481 	mov	r5,a
      0003FA BE 20 16         [24] 1482 	cjne	r6,#0x20,00130$
      0003FD BD 00 13         [24] 1483 	cjne	r5,#0x00,00130$
      000400 78 67            [12] 1484 	mov	r0,#_radio_rx_fifo_overflow_count
      000402 E2               [24] 1485 	movx	a,@r0
      000403 FD               [12] 1486 	mov	r5,a
      000404 08               [12] 1487 	inc	r0
      000405 E2               [24] 1488 	movx	a,@r0
      000406 FE               [12] 1489 	mov	r6,a
      000407 78 67            [12] 1490 	mov	r0,#_radio_rx_fifo_overflow_count
      000409 74 01            [12] 1491 	mov	a,#0x01
      00040B 2D               [12] 1492 	add	a,r5
      00040C F2               [24] 1493 	movx	@r0,a
      00040D E4               [12] 1494 	clr	a
      00040E 3E               [12] 1495 	addc	a,r6
      00040F 08               [12] 1496 	inc	r0
      000410 F2               [24] 1497 	movx	@r0,a
      000411 80 30            [24] 1498 	sjmp	00132$
      000413                       1499 00130$:
                                   1500 ;	radio.c:127: rx_fifo.buffer[rx_fifo.head & RX_FIFO_MASK] = data; 
      000413 90 F0 DA         [24] 1501 	mov	dptr,#(_rx_fifo + 0x0002)
      000416 E0               [24] 1502 	movx	a,@dptr
      000417 FC               [12] 1503 	mov	r4,a
      000418 A3               [24] 1504 	inc	dptr
      000419 E0               [24] 1505 	movx	a,@dptr
      00041A FD               [12] 1506 	mov	r5,a
      00041B A3               [24] 1507 	inc	dptr
      00041C E0               [24] 1508 	movx	a,@dptr
      00041D FE               [12] 1509 	mov	r6,a
      00041E 90 F0 D8         [24] 1510 	mov	dptr,#_rx_fifo
      000421 E0               [24] 1511 	movx	a,@dptr
      000422 FB               [12] 1512 	mov	r3,a
      000423 53 03 1F         [24] 1513 	anl	ar3,#0x1f
      000426 7A 00            [12] 1514 	mov	r2,#0x00
      000428 EB               [12] 1515 	mov	a,r3
      000429 2C               [12] 1516 	add	a,r4
      00042A FC               [12] 1517 	mov	r4,a
      00042B EA               [12] 1518 	mov	a,r2
      00042C 3D               [12] 1519 	addc	a,r5
      00042D FD               [12] 1520 	mov	r5,a
      00042E 8C 82            [24] 1521 	mov	dpl,r4
      000430 8D 83            [24] 1522 	mov	dph,r5
      000432 8E F0            [24] 1523 	mov	b,r6
      000434 EF               [12] 1524 	mov	a,r7
      000435 12 2D 8A         [24] 1525 	lcall	__gptrput
                                   1526 ;	radio.c:128: rx_fifo.head++;
      000438 90 F0 D8         [24] 1527 	mov	dptr,#_rx_fifo
      00043B E0               [24] 1528 	movx	a,@dptr
      00043C FF               [12] 1529 	mov	r7,a
      00043D 0F               [12] 1530 	inc	r7
      00043E 90 F0 D8         [24] 1531 	mov	dptr,#_rx_fifo
      000441 EF               [12] 1532 	mov	a,r7
      000442 F0               [24] 1533 	movx	@dptr,a
                                   1534 ;	radio.c:142: put_rx(d_byte);
      000443                       1535 00132$:
                                   1536 ;	radio.c:143: rx_len++;
      000443 78 02            [12] 1537 	mov	r0,#_rx_len
      000445 E2               [24] 1538 	movx	a,@r0
      000446 78 02            [12] 1539 	mov	r0,#_rx_len
      000448 04               [12] 1540 	inc	a
      000449 F2               [24] 1541 	movx	@r0,a
      00044A 02 04 E8         [24] 1542 	ljmp	00133$
      00044D                       1543 00119$:
                                   1544 ;	radio.c:145: else if (MARCSTATE==MARC_STATE_TX) {
      00044D 90 DF 3B         [24] 1545 	mov	dptr,#_MARCSTATE
      000450 E0               [24] 1546 	movx	a,@dptr
      000451 FF               [12] 1547 	mov	r7,a
      000452 BF 13 02         [24] 1548 	cjne	r7,#0x13,00180$
      000455 80 03            [24] 1549 	sjmp	00181$
      000457                       1550 00180$:
      000457 02 04 E8         [24] 1551 	ljmp	00133$
      00045A                       1552 00181$:
                                   1553 ;	radio.c:146: switch (tx_state) {
      00045A 78 04            [12] 1554 	mov	r0,#_tx_state
      00045C E2               [24] 1555 	movx	a,@r0
      00045D FF               [12] 1556 	mov  r7,a
      00045E 24 F9            [12] 1557 	add	a,#0xff - 0x06
      000460 50 03            [24] 1558 	jnc	00182$
      000462 02 04 E8         [24] 1559 	ljmp	00133$
      000465                       1560 00182$:
      000465 EF               [12] 1561 	mov	a,r7
      000466 2F               [12] 1562 	add	a,r7
                                   1563 ;	radio.c:147: case TxStatePreambleByte0:
      000467 90 04 6B         [24] 1564 	mov	dptr,#00183$
      00046A 73               [24] 1565 	jmp	@a+dptr
      00046B                       1566 00183$:
      00046B 80 0C            [24] 1567 	sjmp	00103$
      00046D 80 1B            [24] 1568 	sjmp	00104$
      00046F 80 77            [24] 1569 	sjmp	00133$
      000471 80 40            [24] 1570 	sjmp	00109$
      000473 80 31            [24] 1571 	sjmp	00108$
      000475 80 49            [24] 1572 	sjmp	00110$
      000477 80 6F            [24] 1573 	sjmp	00133$
      000479                       1574 00103$:
                                   1575 ;	radio.c:148: RFD = preamble_word >> 8;
      000479 90 F1 DF         [24] 1576 	mov	dptr,#_preamble_word
      00047C E0               [24] 1577 	movx	a,@dptr
      00047D FE               [12] 1578 	mov	r6,a
      00047E A3               [24] 1579 	inc	dptr
      00047F E0               [24] 1580 	movx	a,@dptr
      000480 FF               [12] 1581 	mov	r7,a
      000481 8F D9            [24] 1582 	mov	_RFD,r7
                                   1583 ;	radio.c:149: tx_state = TxStatePreambleByte1;
      000483 78 04            [12] 1584 	mov	r0,#_tx_state
      000485 74 01            [12] 1585 	mov	a,#0x01
      000487 F2               [24] 1586 	movx	@r0,a
                                   1587 ;	radio.c:150: break;
                                   1588 ;	radio.c:151: case TxStatePreambleByte1:
      000488 80 5E            [24] 1589 	sjmp	00133$
      00048A                       1590 00104$:
                                   1591 ;	radio.c:152: RFD = preamble_word & 0xff;
      00048A 90 F1 DF         [24] 1592 	mov	dptr,#_preamble_word
      00048D E0               [24] 1593 	movx	a,@dptr
      00048E FE               [12] 1594 	mov	r6,a
      00048F A3               [24] 1595 	inc	dptr
      000490 E0               [24] 1596 	movx	a,@dptr
      000491 FF               [12] 1597 	mov	r7,a
      000492 8E D9            [24] 1598 	mov	_RFD,r6
                                   1599 ;	radio.c:153: if (stop_custom_preamble_semaphore) {
      000494 78 03            [12] 1600 	mov	r0,#_stop_custom_preamble_semaphore
      000496 E2               [24] 1601 	movx	a,@r0
      000497 60 07            [24] 1602 	jz	00106$
                                   1603 ;	radio.c:154: tx_state = TxStateSync1;
      000499 78 04            [12] 1604 	mov	r0,#_tx_state
      00049B 74 04            [12] 1605 	mov	a,#0x04
      00049D F2               [24] 1606 	movx	@r0,a
      00049E 80 48            [24] 1607 	sjmp	00133$
      0004A0                       1608 00106$:
                                   1609 ;	radio.c:156: tx_state = TxStatePreambleByte0;
      0004A0 78 04            [12] 1610 	mov	r0,#_tx_state
      0004A2 E4               [12] 1611 	clr	a
      0004A3 F2               [24] 1612 	movx	@r0,a
                                   1613 ;	radio.c:158: break;
                                   1614 ;	radio.c:159: case TxStateSync1:
      0004A4 80 42            [24] 1615 	sjmp	00133$
      0004A6                       1616 00108$:
                                   1617 ;	radio.c:160: RFD = SYNC1;
      0004A6 90 DF 00         [24] 1618 	mov	dptr,#_SYNC1
      0004A9 E0               [24] 1619 	movx	a,@dptr
      0004AA F5 D9            [12] 1620 	mov	_RFD,a
                                   1621 ;	radio.c:161: tx_state = TxStateSync0;
      0004AC 78 04            [12] 1622 	mov	r0,#_tx_state
      0004AE 74 03            [12] 1623 	mov	a,#0x03
      0004B0 F2               [24] 1624 	movx	@r0,a
                                   1625 ;	radio.c:162: break;
                                   1626 ;	radio.c:163: case TxStateSync0:
      0004B1 80 35            [24] 1627 	sjmp	00133$
      0004B3                       1628 00109$:
                                   1629 ;	radio.c:164: RFD = SYNC0;
      0004B3 90 DF 01         [24] 1630 	mov	dptr,#_SYNC0
      0004B6 E0               [24] 1631 	movx	a,@dptr
      0004B7 F5 D9            [12] 1632 	mov	_RFD,a
                                   1633 ;	radio.c:165: tx_state = TxStateData;
      0004B9 78 04            [12] 1634 	mov	r0,#_tx_state
      0004BB 74 05            [12] 1635 	mov	a,#0x05
      0004BD F2               [24] 1636 	movx	@r0,a
                                   1637 ;	radio.c:166: break;
                                   1638 ;	radio.c:167: case TxStateData:
      0004BE 80 28            [24] 1639 	sjmp	00133$
      0004C0                       1640 00110$:
                                   1641 ;	radio.c:168: RFD = radio_tx_buf[radio_tx_buf_read_idx++];
      0004C0 90 F1 DD         [24] 1642 	mov	dptr,#_radio_tx_buf_read_idx
      0004C3 E0               [24] 1643 	movx	a,@dptr
      0004C4 FF               [12] 1644 	mov	r7,a
      0004C5 04               [12] 1645 	inc	a
      0004C6 F0               [24] 1646 	movx	@dptr,a
      0004C7 EF               [12] 1647 	mov	a,r7
      0004C8 24 DE            [12] 1648 	add	a,#_radio_tx_buf
      0004CA F5 82            [12] 1649 	mov	dpl,a
      0004CC E4               [12] 1650 	clr	a
      0004CD 34 F0            [12] 1651 	addc	a,#(_radio_tx_buf >> 8)
      0004CF F5 83            [12] 1652 	mov	dph,a
      0004D1 E0               [24] 1653 	movx	a,@dptr
      0004D2 F5 D9            [12] 1654 	mov	_RFD,a
                                   1655 ;	radio.c:169: if (radio_tx_buf_read_idx >= radio_tx_buf_len) {
      0004D4 90 F1 DD         [24] 1656 	mov	dptr,#_radio_tx_buf_read_idx
      0004D7 E0               [24] 1657 	movx	a,@dptr
      0004D8 FF               [12] 1658 	mov	r7,a
      0004D9 90 F1 DE         [24] 1659 	mov	dptr,#_radio_tx_buf_len
      0004DC E0               [24] 1660 	movx	a,@dptr
      0004DD FE               [12] 1661 	mov	r6,a
      0004DE C3               [12] 1662 	clr	c
      0004DF EF               [12] 1663 	mov	a,r7
      0004E0 9E               [12] 1664 	subb	a,r6
      0004E1 40 05            [24] 1665 	jc	00133$
                                   1666 ;	radio.c:170: tx_state = TxStateDone;
      0004E3 78 04            [12] 1667 	mov	r0,#_tx_state
      0004E5 74 06            [12] 1668 	mov	a,#0x06
      0004E7 F2               [24] 1669 	movx	@r0,a
                                   1670 ;	radio.c:179: }
      0004E8                       1671 00133$:
                                   1672 ;	radio.c:182: }
      0004E8 D0 D0            [24] 1673 	pop	psw
      0004EA D0 00            [24] 1674 	pop	ar0
      0004EC D0 02            [24] 1675 	pop	ar2
      0004EE D0 03            [24] 1676 	pop	ar3
      0004F0 D0 04            [24] 1677 	pop	ar4
      0004F2 D0 05            [24] 1678 	pop	ar5
      0004F4 D0 06            [24] 1679 	pop	ar6
      0004F6 D0 07            [24] 1680 	pop	ar7
      0004F8 D0 83            [24] 1681 	pop	dph
      0004FA D0 82            [24] 1682 	pop	dpl
      0004FC D0 F0            [24] 1683 	pop	b
      0004FE D0 E0            [24] 1684 	pop	acc
      000500 32               [24] 1685 	reti
                                   1686 ;	eliminated unneeded push/pop ar1
                                   1687 ;------------------------------------------------------------
                                   1688 ;Allocation info for local variables in function 'rf_isr'
                                   1689 ;------------------------------------------------------------
                                   1690 ;	radio.c:184: void rf_isr(void) __interrupt RF_VECTOR {
                                   1691 ;	-----------------------------------------
                                   1692 ;	 function rf_isr
                                   1693 ;	-----------------------------------------
      000501                       1694 _rf_isr:
      000501 C0 E0            [24] 1695 	push	acc
      000503 C0 07            [24] 1696 	push	ar7
      000505 C0 06            [24] 1697 	push	ar6
      000507 C0 00            [24] 1698 	push	ar0
      000509 C0 D0            [24] 1699 	push	psw
      00050B 75 D0 00         [24] 1700 	mov	psw,#0x00
                                   1701 ;	radio.c:185: S1CON &= ~0x03; // Clear CPU interrupt flag
      00050E 53 9B FC         [24] 1702 	anl	_S1CON,#0xfc
                                   1703 ;	radio.c:186: if(RFIF & 0x80) // TX underflow
      000511 E5 E9            [12] 1704 	mov	a,_RFIF
      000513 30 E7 08         [24] 1705 	jnb	acc.7,00107$
                                   1706 ;	radio.c:189: RFST = RFST_SIDLE;
      000516 75 E1 04         [24] 1707 	mov	_RFST,#0x04
                                   1708 ;	radio.c:190: RFIF &= ~0x80; // Clear module interrupt flag
      000519 53 E9 7F         [24] 1709 	anl	_RFIF,#0x7f
      00051C 80 23            [24] 1710 	sjmp	00109$
      00051E                       1711 00107$:
                                   1712 ;	radio.c:192: else if(RFIF & 0x40) // RX overflow
      00051E E5 E9            [12] 1713 	mov	a,_RFIF
      000520 30 E6 16         [24] 1714 	jnb	acc.6,00104$
                                   1715 ;	radio.c:194: radio_rx_overflow_count++;
      000523 78 65            [12] 1716 	mov	r0,#_radio_rx_overflow_count
      000525 E2               [24] 1717 	movx	a,@r0
      000526 FE               [12] 1718 	mov	r6,a
      000527 08               [12] 1719 	inc	r0
      000528 E2               [24] 1720 	movx	a,@r0
      000529 FF               [12] 1721 	mov	r7,a
      00052A 78 65            [12] 1722 	mov	r0,#_radio_rx_overflow_count
      00052C 74 01            [12] 1723 	mov	a,#0x01
      00052E 2E               [12] 1724 	add	a,r6
      00052F F2               [24] 1725 	movx	@r0,a
      000530 E4               [12] 1726 	clr	a
      000531 3F               [12] 1727 	addc	a,r7
      000532 08               [12] 1728 	inc	r0
      000533 F2               [24] 1729 	movx	@r0,a
                                   1730 ;	radio.c:195: RFIF &= ~0x40; // Clear module interrupt flag
      000534 53 E9 BF         [24] 1731 	anl	_RFIF,#0xbf
      000537 80 08            [24] 1732 	sjmp	00109$
      000539                       1733 00104$:
                                   1734 ;	radio.c:197: else if(RFIF & 0x20) // RX timeout
      000539 E5 E9            [12] 1735 	mov	a,_RFIF
      00053B 30 E5 03         [24] 1736 	jnb	acc.5,00109$
                                   1737 ;	radio.c:199: RFIF &= ~0x20; // Clear module interrupt flag
      00053E 53 E9 DF         [24] 1738 	anl	_RFIF,#0xdf
      000541                       1739 00109$:
                                   1740 ;	radio.c:202: }
      000541 D0 D0            [24] 1741 	pop	psw
      000543 D0 00            [24] 1742 	pop	ar0
      000545 D0 06            [24] 1743 	pop	ar6
      000547 D0 07            [24] 1744 	pop	ar7
      000549 D0 E0            [24] 1745 	pop	acc
      00054B 32               [24] 1746 	reti
                                   1747 ;	eliminated unneeded push/pop ar1
                                   1748 ;	eliminated unneeded push/pop dpl
                                   1749 ;	eliminated unneeded push/pop dph
                                   1750 ;	eliminated unneeded push/pop b
                                   1751 ;------------------------------------------------------------
                                   1752 ;Allocation info for local variables in function 'send_packet_from_serial'
                                   1753 ;------------------------------------------------------------
                                   1754 ;	radio.c:204: void send_packet_from_serial(uint8_t channel, uint8_t repeat_count, uint16_t delay_ms, uint16_t preamble_extend_ms, uint8_t len) {
                                   1755 ;	-----------------------------------------
                                   1756 ;	 function send_packet_from_serial
                                   1757 ;	-----------------------------------------
      00054C                       1758 _send_packet_from_serial:
      00054C E5 82            [12] 1759 	mov	a,dpl
      00054E 78 0C            [12] 1760 	mov	r0,#_send_packet_from_serial_channel_65536_127
      000550 F2               [24] 1761 	movx	@r0,a
                                   1762 ;	radio.c:207: uint16_t total_send_count = repeat_count + 1;
      000551 78 06            [12] 1763 	mov	r0,#_send_packet_from_serial_PARM_2
      000553 E2               [24] 1764 	movx	a,@r0
      000554 FD               [12] 1765 	mov	r5,a
      000555 7E 00            [12] 1766 	mov	r6,#0x00
      000557 0D               [12] 1767 	inc	r5
      000558 BD 00 01         [24] 1768 	cjne	r5,#0x00,00155$
      00055B 0E               [12] 1769 	inc	r6
      00055C                       1770 00155$:
                                   1771 ;	radio.c:212: init_encoder(encoding_type, &encoder, &encoder_state);
      00055C 78 3D            [12] 1772 	mov	r0,#_init_encoder_PARM_2
      00055E 74 0E            [12] 1773 	mov	a,#_send_packet_from_serial_encoder_65536_128
      000560 F2               [24] 1774 	movx	@r0,a
      000561 08               [12] 1775 	inc	r0
      000562 E4               [12] 1776 	clr	a
      000563 F2               [24] 1777 	movx	@r0,a
      000564 08               [12] 1778 	inc	r0
      000565 74 60            [12] 1779 	mov	a,#0x60
      000567 F2               [24] 1780 	movx	@r0,a
      000568 78 40            [12] 1781 	mov	r0,#_init_encoder_PARM_3
      00056A 74 12            [12] 1782 	mov	a,#_send_packet_from_serial_encoder_state_65536_128
      00056C F2               [24] 1783 	movx	@r0,a
      00056D 08               [12] 1784 	inc	r0
      00056E E4               [12] 1785 	clr	a
      00056F F2               [24] 1786 	movx	@r0,a
      000570 08               [12] 1787 	inc	r0
      000571 74 60            [12] 1788 	mov	a,#0x60
      000573 F2               [24] 1789 	movx	@r0,a
      000574 78 05            [12] 1790 	mov	r0,#_encoding_type
      000576 E2               [24] 1791 	movx	a,@r0
      000577 F5 82            [12] 1792 	mov	dpl,a
      000579 C0 06            [24] 1793 	push	ar6
      00057B C0 05            [24] 1794 	push	ar5
      00057D 12 0E 79         [24] 1795 	lcall	_init_encoder
                                   1796 ;	radio.c:214: mode_registers_enact(&tx_registers);
      000580 90 F1 EB         [24] 1797 	mov	dptr,#_tx_registers
      000583 75 F0 00         [24] 1798 	mov	b,#0x00
      000586 12 1F 95         [24] 1799 	lcall	_mode_registers_enact
      000589 D0 05            [24] 1800 	pop	ar5
      00058B D0 06            [24] 1801 	pop	ar6
                                   1802 ;	radio.c:216: CHANNR = channel;
      00058D 78 0C            [12] 1803 	mov	r0,#_send_packet_from_serial_channel_65536_127
      00058F 90 DF 06         [24] 1804 	mov	dptr,#_CHANNR
      000592 E2               [24] 1805 	movx	a,@r0
      000593 F0               [24] 1806 	movx	@dptr,a
                                   1807 ;	radio.c:218: radio_tx_buf_len = 0;
      000594 90 F1 DE         [24] 1808 	mov	dptr,#_radio_tx_buf_len
      000597 E4               [12] 1809 	clr	a
      000598 F0               [24] 1810 	movx	@dptr,a
                                   1811 ;	radio.c:219: while (len > 0) {
      000599 78 0B            [12] 1812 	mov	r0,#_send_packet_from_serial_PARM_5
      00059B E2               [24] 1813 	movx	a,@r0
      00059C FC               [12] 1814 	mov	r4,a
      00059D                       1815 00106$:
      00059D EC               [12] 1816 	mov	a,r4
      00059E 70 03            [24] 1817 	jnz	00156$
      0005A0 02 06 67         [24] 1818 	ljmp	00125$
      0005A3                       1819 00156$:
                                   1820 ;	radio.c:220: s_byte = serial_rx_byte();
      0005A3 C0 05            [24] 1821 	push	ar5
      0005A5 C0 06            [24] 1822 	push	ar6
      0005A7 C0 06            [24] 1823 	push	ar6
      0005A9 C0 05            [24] 1824 	push	ar5
      0005AB C0 04            [24] 1825 	push	ar4
      0005AD 12 22 ED         [24] 1826 	lcall	_serial_rx_byte
      0005B0 AB 82            [24] 1827 	mov	r3,dpl
      0005B2 D0 04            [24] 1828 	pop	ar4
      0005B4 D0 05            [24] 1829 	pop	ar5
      0005B6 D0 06            [24] 1830 	pop	ar6
      0005B8 78 0D            [12] 1831 	mov	r0,#_send_packet_from_serial_s_byte_65536_128
      0005BA EB               [12] 1832 	mov	a,r3
      0005BB F2               [24] 1833 	movx	@r0,a
                                   1834 ;	radio.c:221: len--;
      0005BC 1C               [12] 1835 	dec	r4
                                   1836 ;	radio.c:222: encoder.add_raw_byte(&encoder_state, s_byte);
      0005BD 78 0E            [12] 1837 	mov	r0,#_send_packet_from_serial_encoder_65536_128
      0005BF E2               [24] 1838 	movx	a,@r0
      0005C0 FA               [12] 1839 	mov	r2,a
      0005C1 08               [12] 1840 	inc	r0
      0005C2 E2               [24] 1841 	movx	a,@r0
      0005C3 FE               [12] 1842 	mov	r6,a
      0005C4 C0 06            [24] 1843 	push	ar6
      0005C6 C0 05            [24] 1844 	push	ar5
      0005C8 C0 04            [24] 1845 	push	ar4
      0005CA C0 02            [24] 1846 	push	ar2
      0005CC C0 03            [24] 1847 	push	ar3
      0005CE 12 05 D3         [24] 1848 	lcall	00157$
      0005D1 80 0B            [24] 1849 	sjmp	00158$
      0005D3                       1850 00157$:
      0005D3 C0 02            [24] 1851 	push	ar2
      0005D5 C0 06            [24] 1852 	push	ar6
      0005D7 90 F0 12         [24] 1853 	mov	dptr,#_send_packet_from_serial_encoder_state_65536_128
      0005DA 75 F0 60         [24] 1854 	mov	b,#0x60
      0005DD 22               [24] 1855 	ret
      0005DE                       1856 00158$:
      0005DE 15 81            [12] 1857 	dec	sp
      0005E0 D0 02            [24] 1858 	pop	ar2
      0005E2 D0 04            [24] 1859 	pop	ar4
      0005E4 D0 05            [24] 1860 	pop	ar5
      0005E6 D0 06            [24] 1861 	pop	ar6
                                   1862 ;	radio.c:223: while (encoder.next_encoded_byte(&encoder_state, &s_byte, len == 0)) {
      0005E8 EC               [12] 1863 	mov	a,r4
      0005E9 B4 01 00         [24] 1864 	cjne	a,#0x01,00159$
      0005EC                       1865 00159$:
      0005EC 92 00            [24] 1866 	mov	_send_packet_from_serial_sloc0_1_0,c
                                   1867 ;	radio.c:240: send_count++;
      0005EE D0 06            [24] 1868 	pop	ar6
      0005F0 D0 05            [24] 1869 	pop	ar5
                                   1870 ;	radio.c:223: while (encoder.next_encoded_byte(&encoder_state, &s_byte, len == 0)) {
      0005F2                       1871 00103$:
      0005F2 78 10            [12] 1872 	mov	r0,#(_send_packet_from_serial_encoder_65536_128 + 0x0002)
      0005F4 E2               [24] 1873 	movx	a,@r0
      0005F5 FA               [12] 1874 	mov	r2,a
      0005F6 08               [12] 1875 	inc	r0
      0005F7 E2               [24] 1876 	movx	a,@r0
      0005F8 FB               [12] 1877 	mov	r3,a
      0005F9 C0 06            [24] 1878 	push	ar6
      0005FB C0 05            [24] 1879 	push	ar5
      0005FD C0 04            [24] 1880 	push	ar4
      0005FF C0 03            [24] 1881 	push	ar3
      000601 A2 00            [12] 1882 	mov	c,_send_packet_from_serial_sloc0_1_0
      000603 E4               [12] 1883 	clr	a
      000604 33               [12] 1884 	rlc	a
      000605 C0 E0            [24] 1885 	push	acc
      000607 74 0D            [12] 1886 	mov	a,#_send_packet_from_serial_s_byte_65536_128
      000609 C0 E0            [24] 1887 	push	acc
      00060B 74 F0            [12] 1888 	mov	a,#(_send_packet_from_serial_s_byte_65536_128 >> 8)
      00060D C0 E0            [24] 1889 	push	acc
      00060F 74 60            [12] 1890 	mov	a,#0x60
      000611 C0 E0            [24] 1891 	push	acc
      000613 12 06 18         [24] 1892 	lcall	00160$
      000616 80 0B            [24] 1893 	sjmp	00161$
      000618                       1894 00160$:
      000618 C0 02            [24] 1895 	push	ar2
      00061A C0 03            [24] 1896 	push	ar3
      00061C 90 F0 12         [24] 1897 	mov	dptr,#_send_packet_from_serial_encoder_state_65536_128
      00061F 75 F0 60         [24] 1898 	mov	b,#0x60
      000622 22               [24] 1899 	ret
      000623                       1900 00161$:
      000623 AA 82            [24] 1901 	mov	r2,dpl
      000625 E5 81            [12] 1902 	mov	a,sp
      000627 24 FC            [12] 1903 	add	a,#0xfc
      000629 F5 81            [12] 1904 	mov	sp,a
      00062B D0 03            [24] 1905 	pop	ar3
      00062D D0 04            [24] 1906 	pop	ar4
      00062F D0 05            [24] 1907 	pop	ar5
      000631 D0 06            [24] 1908 	pop	ar6
      000633 EA               [12] 1909 	mov	a,r2
      000634 70 03            [24] 1910 	jnz	00162$
      000636 02 05 9D         [24] 1911 	ljmp	00106$
      000639                       1912 00162$:
                                   1913 ;	radio.c:224: if (radio_tx_buf_len+1 < TX_BUF_SIZE) {
      000639 90 F1 DE         [24] 1914 	mov	dptr,#_radio_tx_buf_len
      00063C E0               [24] 1915 	movx	a,@dptr
      00063D FB               [12] 1916 	mov	r3,a
      00063E 7A 00            [12] 1917 	mov	r2,#0x00
      000640 0B               [12] 1918 	inc	r3
      000641 BB 00 01         [24] 1919 	cjne	r3,#0x00,00163$
      000644 0A               [12] 1920 	inc	r2
      000645                       1921 00163$:
      000645 C3               [12] 1922 	clr	c
      000646 EB               [12] 1923 	mov	a,r3
      000647 94 FF            [12] 1924 	subb	a,#0xff
      000649 EA               [12] 1925 	mov	a,r2
      00064A 64 80            [12] 1926 	xrl	a,#0x80
      00064C 94 80            [12] 1927 	subb	a,#0x80
      00064E 50 A2            [24] 1928 	jnc	00103$
                                   1929 ;	radio.c:225: radio_tx_buf[radio_tx_buf_len++] = s_byte;
      000650 90 F1 DE         [24] 1930 	mov	dptr,#_radio_tx_buf_len
      000653 E0               [24] 1931 	movx	a,@dptr
      000654 FB               [12] 1932 	mov	r3,a
      000655 04               [12] 1933 	inc	a
      000656 F0               [24] 1934 	movx	@dptr,a
      000657 EB               [12] 1935 	mov	a,r3
      000658 24 DE            [12] 1936 	add	a,#_radio_tx_buf
      00065A F5 82            [12] 1937 	mov	dpl,a
      00065C E4               [12] 1938 	clr	a
      00065D 34 F0            [12] 1939 	addc	a,#(_radio_tx_buf >> 8)
      00065F F5 83            [12] 1940 	mov	dph,a
      000661 78 0D            [12] 1941 	mov	r0,#_send_packet_from_serial_s_byte_65536_128
      000663 E2               [24] 1942 	movx	a,@r0
      000664 F0               [24] 1943 	movx	@dptr,a
                                   1944 ;	radio.c:230: while(send_count < total_send_count) {
      000665 80 8B            [24] 1945 	sjmp	00103$
      000667                       1946 00125$:
      000667 7B 00            [12] 1947 	mov	r3,#0x00
      000669 7C 00            [12] 1948 	mov	r4,#0x00
      00066B                       1949 00112$:
      00066B C3               [12] 1950 	clr	c
      00066C EB               [12] 1951 	mov	a,r3
      00066D 9D               [12] 1952 	subb	a,r5
      00066E EC               [12] 1953 	mov	a,r4
      00066F 9E               [12] 1954 	subb	a,r6
      000670 50 65            [24] 1955 	jnc	00115$
                                   1956 ;	radio.c:233: if (send_count > 0 && delay_ms > 0) {
      000672 EB               [12] 1957 	mov	a,r3
      000673 4C               [12] 1958 	orl	a,r4
      000674 60 38            [24] 1959 	jz	00110$
      000676 78 07            [12] 1960 	mov	r0,#_send_packet_from_serial_PARM_3
      000678 E2               [24] 1961 	movx	a,@r0
      000679 F5 F0            [12] 1962 	mov	b,a
      00067B 08               [12] 1963 	inc	r0
      00067C E2               [24] 1964 	movx	a,@r0
      00067D 45 F0            [12] 1965 	orl	a,b
      00067F 60 2D            [24] 1966 	jz	00110$
                                   1967 ;	radio.c:234: delay(delay_ms);
      000681 C0 05            [24] 1968 	push	ar5
      000683 C0 06            [24] 1969 	push	ar6
      000685 78 07            [12] 1970 	mov	r0,#_send_packet_from_serial_PARM_3
      000687 E2               [24] 1971 	movx	a,@r0
      000688 FA               [12] 1972 	mov	r2,a
      000689 08               [12] 1973 	inc	r0
      00068A E2               [24] 1974 	movx	a,@r0
      00068B FD               [12] 1975 	mov	r5,a
      00068C 7E 00            [12] 1976 	mov	r6,#0x00
      00068E 7F 00            [12] 1977 	mov	r7,#0x00
      000690 8A 82            [24] 1978 	mov	dpl,r2
      000692 8D 83            [24] 1979 	mov	dph,r5
      000694 8E F0            [24] 1980 	mov	b,r6
      000696 EF               [12] 1981 	mov	a,r7
      000697 C0 06            [24] 1982 	push	ar6
      000699 C0 05            [24] 1983 	push	ar5
      00069B C0 04            [24] 1984 	push	ar4
      00069D C0 03            [24] 1985 	push	ar3
      00069F 12 0C 73         [24] 1986 	lcall	_delay
      0006A2 D0 03            [24] 1987 	pop	ar3
      0006A4 D0 04            [24] 1988 	pop	ar4
      0006A6 D0 05            [24] 1989 	pop	ar5
      0006A8 D0 06            [24] 1990 	pop	ar6
                                   1991 ;	radio.c:240: send_count++;
      0006AA D0 06            [24] 1992 	pop	ar6
      0006AC D0 05            [24] 1993 	pop	ar5
                                   1994 ;	radio.c:234: delay(delay_ms);
      0006AE                       1995 00110$:
                                   1996 ;	radio.c:238: send_from_tx_buf(channel, preamble_extend_ms);
      0006AE 78 09            [12] 1997 	mov	r0,#_send_packet_from_serial_PARM_4
      0006B0 79 15            [12] 1998 	mov	r1,#_send_from_tx_buf_PARM_2
      0006B2 E2               [24] 1999 	movx	a,@r0
      0006B3 F3               [24] 2000 	movx	@r1,a
      0006B4 08               [12] 2001 	inc	r0
      0006B5 E2               [24] 2002 	movx	a,@r0
      0006B6 09               [12] 2003 	inc	r1
      0006B7 F3               [24] 2004 	movx	@r1,a
      0006B8 78 0C            [12] 2005 	mov	r0,#_send_packet_from_serial_channel_65536_127
      0006BA E2               [24] 2006 	movx	a,@r0
      0006BB F5 82            [12] 2007 	mov	dpl,a
      0006BD C0 06            [24] 2008 	push	ar6
      0006BF C0 05            [24] 2009 	push	ar5
      0006C1 C0 04            [24] 2010 	push	ar4
      0006C3 C0 03            [24] 2011 	push	ar3
      0006C5 12 06 D8         [24] 2012 	lcall	_send_from_tx_buf
      0006C8 D0 03            [24] 2013 	pop	ar3
      0006CA D0 04            [24] 2014 	pop	ar4
      0006CC D0 05            [24] 2015 	pop	ar5
      0006CE D0 06            [24] 2016 	pop	ar6
                                   2017 ;	radio.c:240: send_count++;
      0006D0 0B               [12] 2018 	inc	r3
      0006D1 BB 00 97         [24] 2019 	cjne	r3,#0x00,00112$
      0006D4 0C               [12] 2020 	inc	r4
      0006D5 80 94            [24] 2021 	sjmp	00112$
      0006D7                       2022 00115$:
                                   2023 ;	radio.c:242: }
      0006D7 22               [24] 2024 	ret
                                   2025 ;------------------------------------------------------------
                                   2026 ;Allocation info for local variables in function 'send_from_tx_buf'
                                   2027 ;------------------------------------------------------------
                                   2028 ;	radio.c:244: void send_from_tx_buf(uint8_t channel, uint16_t preamble_extend_ms) {
                                   2029 ;	-----------------------------------------
                                   2030 ;	 function send_from_tx_buf
                                   2031 ;	-----------------------------------------
      0006D8                       2032 _send_from_tx_buf:
      0006D8 AF 82            [24] 2033 	mov	r7,dpl
                                   2034 ;	radio.c:249: mdmcfg2_save = MDMCFG2;
      0006DA 90 DF 0E         [24] 2035 	mov	dptr,#_MDMCFG2
      0006DD E0               [24] 2036 	movx	a,@dptr
      0006DE FE               [12] 2037 	mov	r6,a
                                   2038 ;	radio.c:250: pktlen_save = PKTLEN;
      0006DF 90 DF 02         [24] 2039 	mov	dptr,#_PKTLEN
      0006E2 E0               [24] 2040 	movx	a,@dptr
      0006E3 FD               [12] 2041 	mov	r5,a
                                   2042 ;	radio.c:251: pktctrl0_save = PKTCTRL0;
      0006E4 90 DF 04         [24] 2043 	mov	dptr,#_PKTCTRL0
      0006E7 E0               [24] 2044 	movx	a,@dptr
      0006E8 FC               [12] 2045 	mov	r4,a
                                   2046 ;	radio.c:253: packet_tx_count++;
      0006E9 78 6B            [12] 2047 	mov	r0,#_packet_tx_count
      0006EB E2               [24] 2048 	movx	a,@r0
      0006EC 24 01            [12] 2049 	add	a,#0x01
      0006EE F2               [24] 2050 	movx	@r0,a
      0006EF 08               [12] 2051 	inc	r0
      0006F0 E2               [24] 2052 	movx	a,@r0
      0006F1 34 00            [12] 2053 	addc	a,#0x00
      0006F3 F2               [24] 2054 	movx	@r0,a
                                   2055 ;	radio.c:255: if (preamble_word != 0) {
      0006F4 90 F1 DF         [24] 2056 	mov	dptr,#_preamble_word
      0006F7 E0               [24] 2057 	movx	a,@dptr
      0006F8 FA               [12] 2058 	mov	r2,a
      0006F9 A3               [24] 2059 	inc	dptr
      0006FA E0               [24] 2060 	movx	a,@dptr
      0006FB FB               [12] 2061 	mov	r3,a
      0006FC 4A               [12] 2062 	orl	a,r2
      0006FD 60 1E            [24] 2063 	jz	00105$
                                   2064 ;	radio.c:257: MDMCFG2 &= 0b11111100;  // Disable PREAMBLE/SYNC
      0006FF 90 DF 0E         [24] 2065 	mov	dptr,#_MDMCFG2
      000702 E0               [24] 2066 	movx	a,@dptr
      000703 53 E0 FC         [24] 2067 	anl	acc,#0xfc
      000706 F0               [24] 2068 	movx	@dptr,a
                                   2069 ;	radio.c:258: PKTCTRL0 = (PKTCTRL0 & ~0b11) | 0b10; // Enter "infinite" tx mode
      000707 90 DF 04         [24] 2070 	mov	dptr,#_PKTCTRL0
      00070A E0               [24] 2071 	movx	a,@dptr
      00070B 54 FC            [12] 2072 	anl	a,#0xfc
      00070D 44 02            [12] 2073 	orl	a,#0x02
      00070F F0               [24] 2074 	movx	@dptr,a
                                   2075 ;	radio.c:259: PKTLEN = 0;
      000710 90 DF 02         [24] 2076 	mov	dptr,#_PKTLEN
      000713 E4               [12] 2077 	clr	a
      000714 F0               [24] 2078 	movx	@dptr,a
                                   2079 ;	radio.c:260: stop_custom_preamble_semaphore = 0;
      000715 78 03            [12] 2080 	mov	r0,#_stop_custom_preamble_semaphore
      000717 F2               [24] 2081 	movx	@r0,a
                                   2082 ;	radio.c:261: tx_state = TxStatePreambleByte0;
      000718 78 04            [12] 2083 	mov	r0,#_tx_state
      00071A F2               [24] 2084 	movx	@r0,a
      00071B 80 1F            [24] 2085 	sjmp	00106$
      00071D                       2086 00105$:
                                   2087 ;	radio.c:263: if (preamble_extend_ms) {
      00071D 78 15            [12] 2088 	mov	r0,#_send_from_tx_buf_PARM_2
      00071F E2               [24] 2089 	movx	a,@r0
      000720 F5 F0            [12] 2090 	mov	b,a
      000722 08               [12] 2091 	inc	r0
      000723 E2               [24] 2092 	movx	a,@r0
      000724 45 F0            [12] 2093 	orl	a,b
      000726 60 07            [24] 2094 	jz	00102$
                                   2095 ;	radio.c:264: tx_state = TxStatePreambleDefault;
      000728 78 04            [12] 2096 	mov	r0,#_tx_state
      00072A 74 02            [12] 2097 	mov	a,#0x02
      00072C F2               [24] 2098 	movx	@r0,a
      00072D 80 05            [24] 2099 	sjmp	00103$
      00072F                       2100 00102$:
                                   2101 ;	radio.c:266: tx_state = TxStateData;
      00072F 78 04            [12] 2102 	mov	r0,#_tx_state
      000731 74 05            [12] 2103 	mov	a,#0x05
      000733 F2               [24] 2104 	movx	@r0,a
      000734                       2105 00103$:
                                   2106 ;	radio.c:268: PKTLEN = radio_tx_buf_len;
      000734 90 F1 DE         [24] 2107 	mov	dptr,#_radio_tx_buf_len
      000737 E0               [24] 2108 	movx	a,@dptr
      000738 90 DF 02         [24] 2109 	mov	dptr,#_PKTLEN
      00073B F0               [24] 2110 	movx	@dptr,a
      00073C                       2111 00106$:
                                   2112 ;	radio.c:271: RFST = RFST_SIDLE;
      00073C 75 E1 04         [24] 2113 	mov	_RFST,#0x04
                                   2114 ;	radio.c:272: while(MARCSTATE!=MARC_STATE_IDLE);
      00073F                       2115 00107$:
      00073F 90 DF 3B         [24] 2116 	mov	dptr,#_MARCSTATE
      000742 E0               [24] 2117 	movx	a,@dptr
      000743 FB               [12] 2118 	mov	r3,a
      000744 BB 01 F8         [24] 2119 	cjne	r3,#0x01,00107$
                                   2120 ;	radio.c:274: CHANNR = channel;
      000747 90 DF 06         [24] 2121 	mov	dptr,#_CHANNR
      00074A EF               [12] 2122 	mov	a,r7
      00074B F0               [24] 2123 	movx	@dptr,a
                                   2124 ;	radio.c:276: radio_tx_buf_read_idx = 0;
      00074C 90 F1 DD         [24] 2125 	mov	dptr,#_radio_tx_buf_read_idx
      00074F E4               [12] 2126 	clr	a
      000750 F0               [24] 2127 	movx	@dptr,a
                                   2128 ;	radio.c:279: RFST = RFST_STX;
      000751 75 E1 03         [24] 2129 	mov	_RFST,#0x03
                                   2130 ;	radio.c:280: while(MARCSTATE!=MARC_STATE_TX);
      000754                       2131 00110$:
      000754 90 DF 3B         [24] 2132 	mov	dptr,#_MARCSTATE
      000757 E0               [24] 2133 	movx	a,@dptr
      000758 FF               [12] 2134 	mov	r7,a
      000759 BF 13 F8         [24] 2135 	cjne	r7,#0x13,00110$
                                   2136 ;	radio.c:282: if (preamble_extend_ms > 0) {
      00075C 78 15            [12] 2137 	mov	r0,#_send_from_tx_buf_PARM_2
      00075E E2               [24] 2138 	movx	a,@r0
      00075F F5 F0            [12] 2139 	mov	b,a
      000761 08               [12] 2140 	inc	r0
      000762 E2               [24] 2141 	movx	a,@r0
      000763 45 F0            [12] 2142 	orl	a,b
      000765 60 38            [24] 2143 	jz	00116$
                                   2144 ;	radio.c:283: delay(preamble_extend_ms);
      000767 C0 04            [24] 2145 	push	ar4
      000769 78 15            [12] 2146 	mov	r0,#_send_from_tx_buf_PARM_2
      00076B E2               [24] 2147 	movx	a,@r0
      00076C FA               [12] 2148 	mov	r2,a
      00076D 08               [12] 2149 	inc	r0
      00076E E2               [24] 2150 	movx	a,@r0
      00076F FB               [12] 2151 	mov	r3,a
      000770 7C 00            [12] 2152 	mov	r4,#0x00
      000772 7F 00            [12] 2153 	mov	r7,#0x00
      000774 8A 82            [24] 2154 	mov	dpl,r2
      000776 8B 83            [24] 2155 	mov	dph,r3
      000778 8C F0            [24] 2156 	mov	b,r4
      00077A EF               [12] 2157 	mov	a,r7
      00077B C0 06            [24] 2158 	push	ar6
      00077D C0 05            [24] 2159 	push	ar5
      00077F C0 04            [24] 2160 	push	ar4
      000781 12 0C 73         [24] 2161 	lcall	_delay
      000784 D0 04            [24] 2162 	pop	ar4
      000786 D0 05            [24] 2163 	pop	ar5
      000788 D0 06            [24] 2164 	pop	ar6
                                   2165 ;	radio.c:284: if(preamble_word==0) {
      00078A 90 F1 DF         [24] 2166 	mov	dptr,#_preamble_word
      00078D E0               [24] 2167 	movx	a,@dptr
      00078E FC               [12] 2168 	mov	r4,a
      00078F A3               [24] 2169 	inc	dptr
      000790 E0               [24] 2170 	movx	a,@dptr
      000791 FF               [12] 2171 	mov	r7,a
      000792 4C               [12] 2172 	orl	a,r4
      000793 D0 04            [24] 2173 	pop	ar4
      000795 70 08            [24] 2174 	jnz	00116$
                                   2175 ;	radio.c:285: tx_state = TxStateData;
      000797 78 04            [12] 2176 	mov	r0,#_tx_state
      000799 74 05            [12] 2177 	mov	a,#0x05
      00079B F2               [24] 2178 	movx	@r0,a
                                   2179 ;	radio.c:286: TCON |= 0b10;  // Manually trigger RFTXRX vector.
      00079C 43 88 02         [24] 2180 	orl	_TCON,#0x02
      00079F                       2181 00116$:
                                   2182 ;	radio.c:290: if (preamble_word != 0) {
      00079F 90 F1 DF         [24] 2183 	mov	dptr,#_preamble_word
      0007A2 E0               [24] 2184 	movx	a,@dptr
      0007A3 FB               [12] 2185 	mov	r3,a
      0007A4 A3               [24] 2186 	inc	dptr
      0007A5 E0               [24] 2187 	movx	a,@dptr
      0007A6 FF               [12] 2188 	mov	r7,a
      0007A7 4B               [12] 2189 	orl	a,r3
      0007A8 60 05            [24] 2190 	jz	00119$
                                   2191 ;	radio.c:291: stop_custom_preamble_semaphore = 1;
      0007AA 78 03            [12] 2192 	mov	r0,#_stop_custom_preamble_semaphore
      0007AC 74 01            [12] 2193 	mov	a,#0x01
      0007AE F2               [24] 2194 	movx	@r0,a
                                   2195 ;	radio.c:295: while(MARCSTATE==MARC_STATE_TX);
      0007AF                       2196 00119$:
      0007AF 90 DF 3B         [24] 2197 	mov	dptr,#_MARCSTATE
      0007B2 E0               [24] 2198 	movx	a,@dptr
      0007B3 FF               [12] 2199 	mov	r7,a
      0007B4 BF 13 02         [24] 2200 	cjne	r7,#0x13,00183$
      0007B7 80 F6            [24] 2201 	sjmp	00119$
      0007B9                       2202 00183$:
                                   2203 ;	radio.c:297: if (MARCSTATE==MARC_STATE_TX_UNDERFLOW) {
      0007B9 90 DF 3B         [24] 2204 	mov	dptr,#_MARCSTATE
      0007BC E0               [24] 2205 	movx	a,@dptr
      0007BD FF               [12] 2206 	mov	r7,a
      0007BE BF 16 03         [24] 2207 	cjne	r7,#0x16,00123$
                                   2208 ;	radio.c:298: RFST = RFST_SIDLE;
      0007C1 75 E1 04         [24] 2209 	mov	_RFST,#0x04
      0007C4                       2210 00123$:
                                   2211 ;	radio.c:301: PKTLEN = pktlen_save;
      0007C4 90 DF 02         [24] 2212 	mov	dptr,#_PKTLEN
      0007C7 ED               [12] 2213 	mov	a,r5
      0007C8 F0               [24] 2214 	movx	@dptr,a
                                   2215 ;	radio.c:302: MDMCFG2 = mdmcfg2_save;
      0007C9 90 DF 0E         [24] 2216 	mov	dptr,#_MDMCFG2
      0007CC EE               [12] 2217 	mov	a,r6
      0007CD F0               [24] 2218 	movx	@dptr,a
                                   2219 ;	radio.c:303: PKTCTRL0 = pktctrl0_save;
      0007CE 90 DF 04         [24] 2220 	mov	dptr,#_PKTCTRL0
      0007D1 EC               [12] 2221 	mov	a,r4
      0007D2 F0               [24] 2222 	movx	@dptr,a
                                   2223 ;	radio.c:305: }
      0007D3 22               [24] 2224 	ret
                                   2225 ;------------------------------------------------------------
                                   2226 ;Allocation info for local variables in function 'get_packet_and_write_to_serial'
                                   2227 ;------------------------------------------------------------
                                   2228 ;sloc0                     Allocated with name '_get_packet_and_write_to_serial_sloc0_1_0'
                                   2229 ;sloc1                     Allocated with name '_get_packet_and_write_to_serial_sloc1_1_0'
                                   2230 ;sloc2                     Allocated with name '_get_packet_and_write_to_serial_sloc2_1_0'
                                   2231 ;sloc3                     Allocated with name '_get_packet_and_write_to_serial_sloc3_1_0'
                                   2232 ;sloc4                     Allocated with name '_get_packet_and_write_to_serial_sloc4_1_0'
                                   2233 ;decoder                   Allocated with name '_get_packet_and_write_to_serial_decoder_65536_145'
                                   2234 ;decoder_state             Allocated with name '_get_packet_and_write_to_serial_decoder_state_65536_145'
                                   2235 ;------------------------------------------------------------
                                   2236 ;	radio.c:307: uint8_t get_packet_and_write_to_serial(uint8_t channel, uint32_t timeout_ms, uint8_t use_pktlen) {
                                   2237 ;	-----------------------------------------
                                   2238 ;	 function get_packet_and_write_to_serial
                                   2239 ;	-----------------------------------------
      0007D4                       2240 _get_packet_and_write_to_serial:
      0007D4 AF 82            [24] 2241 	mov	r7,dpl
                                   2242 ;	radio.c:310: uint8_t d_byte = 0;
      0007D6 78 1E            [12] 2243 	mov	r0,#_get_packet_and_write_to_serial_d_byte_65536_145
      0007D8 E4               [12] 2244 	clr	a
      0007D9 F2               [24] 2245 	movx	@r0,a
                                   2246 ;	radio.c:311: uint8_t rval = 0;
      0007DA 78 1F            [12] 2247 	mov	r0,#_get_packet_and_write_to_serial_rval_65536_145
      0007DC F2               [24] 2248 	movx	@r0,a
                                   2249 ;	radio.c:312: uint8_t encoding_error = 0;
                                   2250 ;	1-genFromRTrack replaced	mov	_get_packet_and_write_to_serial_sloc1_1_0,#0x00
      0007DD F5 0A            [12] 2251 	mov	_get_packet_and_write_to_serial_sloc1_1_0,a
                                   2252 ;	radio.c:318: if (timeout_ms > 0) {
      0007DF 78 17            [12] 2253 	mov	r0,#_get_packet_and_write_to_serial_PARM_2
      0007E1 E2               [24] 2254 	movx	a,@r0
      0007E2 F5 F0            [12] 2255 	mov	b,a
      0007E4 08               [12] 2256 	inc	r0
      0007E5 E2               [24] 2257 	movx	a,@r0
      0007E6 42 F0            [12] 2258 	orl	b,a
      0007E8 08               [12] 2259 	inc	r0
      0007E9 E2               [24] 2260 	movx	a,@r0
      0007EA 42 F0            [12] 2261 	orl	b,a
      0007EC 08               [12] 2262 	inc	r0
      0007ED E2               [24] 2263 	movx	a,@r0
      0007EE 45 F0            [12] 2264 	orl	a,b
      0007F0 60 16            [24] 2265 	jz	00102$
                                   2266 ;	radio.c:319: read_timer(&timer_start);
                                   2267 ;	timer.h:14: EA = 0;
                                   2268 ;	assignBit
      0007F2 C2 AF            [12] 2269 	clr	_EA
                                   2270 ;	timer.h:15: *result = __timerCounter;
      0007F4 78 20            [12] 2271 	mov	r0,#_get_packet_and_write_to_serial_timer_start_65536_145
      0007F6 79 2E            [12] 2272 	mov	r1,#___timerCounter
      0007F8 E3               [24] 2273 	movx	a,@r1
      0007F9 F2               [24] 2274 	movx	@r0,a
      0007FA 08               [12] 2275 	inc	r0
      0007FB 09               [12] 2276 	inc	r1
      0007FC E3               [24] 2277 	movx	a,@r1
      0007FD F2               [24] 2278 	movx	@r0,a
      0007FE 08               [12] 2279 	inc	r0
      0007FF 09               [12] 2280 	inc	r1
      000800 E3               [24] 2281 	movx	a,@r1
      000801 F2               [24] 2282 	movx	@r0,a
      000802 08               [12] 2283 	inc	r0
      000803 09               [12] 2284 	inc	r1
      000804 E3               [24] 2285 	movx	a,@r1
      000805 F2               [24] 2286 	movx	@r0,a
                                   2287 ;	timer.h:16: EA = 1;
                                   2288 ;	assignBit
      000806 D2 AF            [12] 2289 	setb	_EA
                                   2290 ;	radio.c:319: read_timer(&timer_start);
      000808                       2291 00102$:
                                   2292 ;	radio.c:322: mode_registers_enact(&rx_registers);
      000808 90 F1 FC         [24] 2293 	mov	dptr,#_rx_registers
      00080B 75 F0 00         [24] 2294 	mov	b,#0x00
      00080E C0 07            [24] 2295 	push	ar7
      000810 12 1F 95         [24] 2296 	lcall	_mode_registers_enact
                                   2297 ;	radio.c:324: init_decoder(encoding_type, &decoder, &decoder_state);
      000813 78 43            [12] 2298 	mov	r0,#_init_decoder_PARM_2
      000815 74 E1            [12] 2299 	mov	a,#_get_packet_and_write_to_serial_decoder_65536_145
      000817 F2               [24] 2300 	movx	@r0,a
      000818 08               [12] 2301 	inc	r0
      000819 74 F1            [12] 2302 	mov	a,#(_get_packet_and_write_to_serial_decoder_65536_145 >> 8)
      00081B F2               [24] 2303 	movx	@r0,a
      00081C 08               [12] 2304 	inc	r0
      00081D E4               [12] 2305 	clr	a
      00081E F2               [24] 2306 	movx	@r0,a
      00081F 78 46            [12] 2307 	mov	r0,#_init_decoder_PARM_3
      000821 74 E5            [12] 2308 	mov	a,#_get_packet_and_write_to_serial_decoder_state_65536_145
      000823 F2               [24] 2309 	movx	@r0,a
      000824 08               [12] 2310 	inc	r0
      000825 74 F1            [12] 2311 	mov	a,#(_get_packet_and_write_to_serial_decoder_state_65536_145 >> 8)
      000827 F2               [24] 2312 	movx	@r0,a
      000828 08               [12] 2313 	inc	r0
      000829 E4               [12] 2314 	clr	a
      00082A F2               [24] 2315 	movx	@r0,a
      00082B 78 05            [12] 2316 	mov	r0,#_encoding_type
      00082D E2               [24] 2317 	movx	a,@r0
      00082E F5 82            [12] 2318 	mov	dpl,a
      000830 12 0F 55         [24] 2319 	lcall	_init_decoder
      000833 D0 07            [24] 2320 	pop	ar7
                                   2321 ;	radio.c:326: RFST = RFST_SIDLE;
      000835 75 E1 04         [24] 2322 	mov	_RFST,#0x04
                                   2323 ;	radio.c:327: while(MARCSTATE!=MARC_STATE_IDLE);
      000838                       2324 00103$:
      000838 90 DF 3B         [24] 2325 	mov	dptr,#_MARCSTATE
      00083B E0               [24] 2326 	movx	a,@dptr
      00083C FC               [12] 2327 	mov	r4,a
      00083D BC 01 F8         [24] 2328 	cjne	r4,#0x01,00103$
                                   2329 ;	radio.c:329: CHANNR = channel;
      000840 90 DF 06         [24] 2330 	mov	dptr,#_CHANNR
      000843 EF               [12] 2331 	mov	a,r7
      000844 F0               [24] 2332 	movx	@dptr,a
                                   2333 ;	radio.c:331: rx_len = 0;
      000845 78 02            [12] 2334 	mov	r0,#_rx_len
      000847 E4               [12] 2335 	clr	a
      000848 F2               [24] 2336 	movx	@r0,a
                                   2337 ;	radio.c:332: memset((void*)radio_rx_buf, 0x11, RX_FIFO_SIZE);
      000849 78 AB            [12] 2338 	mov	r0,#_memset_PARM_2
      00084B 74 11            [12] 2339 	mov	a,#0x11
      00084D F2               [24] 2340 	movx	@r0,a
      00084E 78 AC            [12] 2341 	mov	r0,#_memset_PARM_3
      000850 74 20            [12] 2342 	mov	a,#0x20
      000852 F2               [24] 2343 	movx	@r0,a
      000853 08               [12] 2344 	inc	r0
      000854 E4               [12] 2345 	clr	a
      000855 F2               [24] 2346 	movx	@r0,a
      000856 90 F0 B8         [24] 2347 	mov	dptr,#_radio_rx_buf
      000859 75 F0 00         [24] 2348 	mov	b,#0x00
      00085C 12 2D 36         [24] 2349 	lcall	_memset
                                   2350 ;	radio.c:334: CLKCON = 0xAB;  	//slow down now, you just wait for a packet that may never come; CLKSPD = 3Mhz, TICKSPD = 750Khz
      00085F 75 C6 AB         [24] 2351 	mov	_CLKCON,#0xab
                                   2352 ;	radio.c:336: RFST = RFST_SRX;
      000862 75 E1 02         [24] 2353 	mov	_RFST,#0x02
                                   2354 ;	radio.c:337: while(MARCSTATE!=MARC_STATE_RX);
      000865                       2355 00106$:
      000865 90 DF 3B         [24] 2356 	mov	dptr,#_MARCSTATE
      000868 E0               [24] 2357 	movx	a,@dptr
      000869 FF               [12] 2358 	mov	r7,a
      00086A BF 0D F8         [24] 2359 	cjne	r7,#0x0d,00106$
                                   2360 ;	radio.c:339: while(1) {
      00086D 78 17            [12] 2361 	mov	r0,#_get_packet_and_write_to_serial_PARM_2
      00086F E2               [24] 2362 	movx	a,@r0
      000870 F5 0B            [12] 2363 	mov	_get_packet_and_write_to_serial_sloc2_1_0,a
      000872 08               [12] 2364 	inc	r0
      000873 E2               [24] 2365 	movx	a,@r0
      000874 F5 0C            [12] 2366 	mov	(_get_packet_and_write_to_serial_sloc2_1_0 + 1),a
      000876 08               [12] 2367 	inc	r0
      000877 E2               [24] 2368 	movx	a,@r0
      000878 F5 0D            [12] 2369 	mov	(_get_packet_and_write_to_serial_sloc2_1_0 + 2),a
      00087A 08               [12] 2370 	inc	r0
      00087B E2               [24] 2371 	movx	a,@r0
      00087C F5 0E            [12] 2372 	mov	(_get_packet_and_write_to_serial_sloc2_1_0 + 3),a
      00087E 78 1D            [12] 2373 	mov	r0,#_get_packet_and_write_to_serial_read_idx_65536_145
      000880 E4               [12] 2374 	clr	a
      000881 F2               [24] 2375 	movx	@r0,a
      000882                       2376 00130$:
                                   2377 ;	radio.c:344: if (!fifo_empty(&rx_fifo)) {
                                   2378 ;	fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
      000882 74 D8            [12] 2379 	mov	a,#_rx_fifo
      000884 44 F0            [12] 2380 	orl	a,#(_rx_fifo >> 8)
      000886 60 32            [24] 2381 	jz	00158$
                                   2382 ;	fifo.h:28: return (b ? (b->head - b->tail) : 0);
      000888 74 D8            [12] 2383 	mov	a,#_rx_fifo
      00088A 44 F0            [12] 2384 	orl	a,#(_rx_fifo >> 8)
      00088C 60 1A            [24] 2385 	jz	00160$
      00088E 90 F0 D8         [24] 2386 	mov	dptr,#_rx_fifo
      000891 E0               [24] 2387 	movx	a,@dptr
      000892 FD               [12] 2388 	mov	r5,a
      000893 90 F0 D9         [24] 2389 	mov	dptr,#(_rx_fifo + 0x0001)
      000896 75 F0 00         [24] 2390 	mov	b,#0x00
      000899 12 2E 55         [24] 2391 	lcall	__gptrget
      00089C FE               [12] 2392 	mov	r6,a
      00089D ED               [12] 2393 	mov	a,r5
      00089E C3               [12] 2394 	clr	c
      00089F 9E               [12] 2395 	subb	a,r6
      0008A0 FD               [12] 2396 	mov	r5,a
      0008A1 8D 08            [24] 2397 	mov	_get_packet_and_write_to_serial_sloc0_1_0,r5
      0008A3 75 09 00         [24] 2398 	mov	(_get_packet_and_write_to_serial_sloc0_1_0 + 1),#0x00
      0008A6 80 05            [24] 2399 	sjmp	00161$
      0008A8                       2400 00160$:
      0008A8 E4               [12] 2401 	clr	a
      0008A9 F5 08            [12] 2402 	mov	_get_packet_and_write_to_serial_sloc0_1_0,a
      0008AB F5 09            [12] 2403 	mov	(_get_packet_and_write_to_serial_sloc0_1_0 + 1),a
      0008AD                       2404 00161$:
      0008AD AE 08            [24] 2405 	mov	r6,_get_packet_and_write_to_serial_sloc0_1_0
                                   2406 ;	fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
      0008AF 78 24            [12] 2407 	mov	r0,#_get_packet_and_write_to_serial___1966080033_196608_147
      0008B1 EE               [12] 2408 	mov	a,r6
      0008B2 B4 01 00         [24] 2409 	cjne	a,#0x01,00303$
      0008B5                       2410 00303$:
      0008B5 E4               [12] 2411 	clr	a
      0008B6 33               [12] 2412 	rlc	a
      0008B7 F2               [24] 2413 	movx	@r0,a
      0008B8 80 05            [24] 2414 	sjmp	00159$
      0008BA                       2415 00158$:
      0008BA 78 24            [12] 2416 	mov	r0,#_get_packet_and_write_to_serial___1966080033_196608_147
      0008BC 74 01            [12] 2417 	mov	a,#0x01
      0008BE F2               [24] 2418 	movx	@r0,a
      0008BF                       2419 00159$:
                                   2420 ;	radio.c:344: if (!fifo_empty(&rx_fifo)) {
      0008BF 78 24            [12] 2421 	mov	r0,#_get_packet_and_write_to_serial___1966080033_196608_147
      0008C1 E2               [24] 2422 	movx	a,@r0
      0008C2 60 03            [24] 2423 	jz	00304$
      0008C4 02 0A 4A         [24] 2424 	ljmp	00123$
      0008C7                       2425 00304$:
                                   2426 ;	radio.c:346: d_byte = fifo_get(&rx_fifo);
      0008C7 78 25            [12] 2427 	mov	r0,#_get_packet_and_write_to_serial_b_327680_169
      0008C9 74 D8            [12] 2428 	mov	a,#_rx_fifo
      0008CB F2               [24] 2429 	movx	@r0,a
      0008CC 08               [12] 2430 	inc	r0
      0008CD 74 F0            [12] 2431 	mov	a,#(_rx_fifo >> 8)
      0008CF F2               [24] 2432 	movx	@r0,a
      0008D0 08               [12] 2433 	inc	r0
      0008D1 E4               [12] 2434 	clr	a
      0008D2 F2               [24] 2435 	movx	@r0,a
                                   2436 ;	fifo.h:36: uint8_t data_byte = 0;
      0008D3 7C 00            [12] 2437 	mov	r4,#0x00
                                   2438 ;	fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
      0008D5 74 D8            [12] 2439 	mov	a,#_rx_fifo
      0008D7 44 F0            [12] 2440 	orl	a,#(_rx_fifo >> 8)
      0008D9 60 2C            [24] 2441 	jz	00162$
                                   2442 ;	fifo.h:28: return (b ? (b->head - b->tail) : 0);
      0008DB 74 D8            [12] 2443 	mov	a,#_rx_fifo
      0008DD 44 F0            [12] 2444 	orl	a,#(_rx_fifo >> 8)
      0008DF 60 17            [24] 2445 	jz	00164$
      0008E1 90 F0 D8         [24] 2446 	mov	dptr,#_rx_fifo
      0008E4 E0               [24] 2447 	movx	a,@dptr
      0008E5 FB               [12] 2448 	mov	r3,a
      0008E6 90 F0 D9         [24] 2449 	mov	dptr,#(_rx_fifo + 0x0001)
      0008E9 75 F0 00         [24] 2450 	mov	b,#0x00
      0008EC 12 2E 55         [24] 2451 	lcall	__gptrget
      0008EF FA               [12] 2452 	mov	r2,a
      0008F0 EB               [12] 2453 	mov	a,r3
      0008F1 C3               [12] 2454 	clr	c
      0008F2 9A               [12] 2455 	subb	a,r2
      0008F3 FA               [12] 2456 	mov	r2,a
      0008F4 7B 00            [12] 2457 	mov	r3,#0x00
      0008F6 80 04            [24] 2458 	sjmp	00165$
      0008F8                       2459 00164$:
      0008F8 7A 00            [12] 2460 	mov	r2,#0x00
      0008FA 7B 00            [12] 2461 	mov	r3,#0x00
      0008FC                       2462 00165$:
                                   2463 ;	fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
      0008FC 78 28            [12] 2464 	mov	r0,#_get_packet_and_write_to_serial___1310720012_393216_170
      0008FE EA               [12] 2465 	mov	a,r2
      0008FF B4 01 00         [24] 2466 	cjne	a,#0x01,00307$
      000902                       2467 00307$:
      000902 E4               [12] 2468 	clr	a
      000903 33               [12] 2469 	rlc	a
      000904 F2               [24] 2470 	movx	@r0,a
      000905 80 05            [24] 2471 	sjmp	00163$
      000907                       2472 00162$:
      000907 78 28            [12] 2473 	mov	r0,#_get_packet_and_write_to_serial___1310720012_393216_170
      000909 74 01            [12] 2474 	mov	a,#0x01
      00090B F2               [24] 2475 	movx	@r0,a
      00090C                       2476 00163$:
                                   2477 ;	fifo.h:38: if (!fifo_empty(b)) {
      00090C 78 28            [12] 2478 	mov	r0,#_get_packet_and_write_to_serial___1310720012_393216_170
      00090E E2               [24] 2479 	movx	a,@r0
      00090F 60 03            [24] 2480 	jz	00308$
      000911 02 09 A5         [24] 2481 	ljmp	00146$
      000914                       2482 00308$:
                                   2483 ;	fifo.h:39: data_byte = b->buffer[b->tail % b->buffer_len];
      000914 78 25            [12] 2484 	mov	r0,#_get_packet_and_write_to_serial_b_327680_169
      000916 E2               [24] 2485 	movx	a,@r0
      000917 24 02            [12] 2486 	add	a,#0x02
      000919 FA               [12] 2487 	mov	r2,a
      00091A 08               [12] 2488 	inc	r0
      00091B E2               [24] 2489 	movx	a,@r0
      00091C 34 00            [12] 2490 	addc	a,#0x00
      00091E FB               [12] 2491 	mov	r3,a
      00091F 08               [12] 2492 	inc	r0
      000920 E2               [24] 2493 	movx	a,@r0
      000921 FF               [12] 2494 	mov	r7,a
      000922 8A 82            [24] 2495 	mov	dpl,r2
      000924 8B 83            [24] 2496 	mov	dph,r3
      000926 8F F0            [24] 2497 	mov	b,r7
      000928 12 2E 55         [24] 2498 	lcall	__gptrget
      00092B F5 0F            [12] 2499 	mov	_get_packet_and_write_to_serial_sloc3_1_0,a
      00092D A3               [24] 2500 	inc	dptr
      00092E 12 2E 55         [24] 2501 	lcall	__gptrget
      000931 F5 10            [12] 2502 	mov	(_get_packet_and_write_to_serial_sloc3_1_0 + 1),a
      000933 A3               [24] 2503 	inc	dptr
      000934 12 2E 55         [24] 2504 	lcall	__gptrget
      000937 F5 11            [12] 2505 	mov	(_get_packet_and_write_to_serial_sloc3_1_0 + 2),a
      000939 78 25            [12] 2506 	mov	r0,#_get_packet_and_write_to_serial_b_327680_169
      00093B E2               [24] 2507 	movx	a,@r0
      00093C 24 01            [12] 2508 	add	a,#0x01
      00093E F5 12            [12] 2509 	mov	_get_packet_and_write_to_serial_sloc4_1_0,a
      000940 08               [12] 2510 	inc	r0
      000941 E2               [24] 2511 	movx	a,@r0
      000942 34 00            [12] 2512 	addc	a,#0x00
      000944 F5 13            [12] 2513 	mov	(_get_packet_and_write_to_serial_sloc4_1_0 + 1),a
      000946 08               [12] 2514 	inc	r0
      000947 E2               [24] 2515 	movx	a,@r0
      000948 F5 14            [12] 2516 	mov	(_get_packet_and_write_to_serial_sloc4_1_0 + 2),a
      00094A 85 12 82         [24] 2517 	mov	dpl,_get_packet_and_write_to_serial_sloc4_1_0
      00094D 85 13 83         [24] 2518 	mov	dph,(_get_packet_and_write_to_serial_sloc4_1_0 + 1)
      000950 85 14 F0         [24] 2519 	mov	b,(_get_packet_and_write_to_serial_sloc4_1_0 + 2)
      000953 12 2E 55         [24] 2520 	lcall	__gptrget
      000956 F5 08            [12] 2521 	mov	_get_packet_and_write_to_serial_sloc0_1_0,a
      000958 78 25            [12] 2522 	mov	r0,#_get_packet_and_write_to_serial_b_327680_169
      00095A E2               [24] 2523 	movx	a,@r0
      00095B 24 05            [12] 2524 	add	a,#0x05
      00095D FA               [12] 2525 	mov	r2,a
      00095E 08               [12] 2526 	inc	r0
      00095F E2               [24] 2527 	movx	a,@r0
      000960 34 00            [12] 2528 	addc	a,#0x00
      000962 FB               [12] 2529 	mov	r3,a
      000963 08               [12] 2530 	inc	r0
      000964 E2               [24] 2531 	movx	a,@r0
      000965 FF               [12] 2532 	mov	r7,a
      000966 8A 82            [24] 2533 	mov	dpl,r2
      000968 8B 83            [24] 2534 	mov	dph,r3
      00096A 8F F0            [24] 2535 	mov	b,r7
      00096C 12 2E 55         [24] 2536 	lcall	__gptrget
      00096F FA               [12] 2537 	mov	r2,a
      000970 8A F0            [24] 2538 	mov	b,r2
      000972 E5 08            [12] 2539 	mov	a,_get_packet_and_write_to_serial_sloc0_1_0
      000974 84               [48] 2540 	div	ab
      000975 E5 F0            [12] 2541 	mov	a,b
      000977 25 0F            [12] 2542 	add	a,_get_packet_and_write_to_serial_sloc3_1_0
      000979 FA               [12] 2543 	mov	r2,a
      00097A E4               [12] 2544 	clr	a
      00097B 35 10            [12] 2545 	addc	a,(_get_packet_and_write_to_serial_sloc3_1_0 + 1)
      00097D FF               [12] 2546 	mov	r7,a
      00097E AE 11            [24] 2547 	mov	r6,(_get_packet_and_write_to_serial_sloc3_1_0 + 2)
      000980 8A 82            [24] 2548 	mov	dpl,r2
      000982 8F 83            [24] 2549 	mov	dph,r7
      000984 8E F0            [24] 2550 	mov	b,r6
      000986 12 2E 55         [24] 2551 	lcall	__gptrget
      000989 FC               [12] 2552 	mov	r4,a
                                   2553 ;	fifo.h:40: b->tail++;
      00098A 85 12 82         [24] 2554 	mov	dpl,_get_packet_and_write_to_serial_sloc4_1_0
      00098D 85 13 83         [24] 2555 	mov	dph,(_get_packet_and_write_to_serial_sloc4_1_0 + 1)
      000990 85 14 F0         [24] 2556 	mov	b,(_get_packet_and_write_to_serial_sloc4_1_0 + 2)
      000993 12 2E 55         [24] 2557 	lcall	__gptrget
      000996 FF               [12] 2558 	mov	r7,a
      000997 0F               [12] 2559 	inc	r7
      000998 85 12 82         [24] 2560 	mov	dpl,_get_packet_and_write_to_serial_sloc4_1_0
      00099B 85 13 83         [24] 2561 	mov	dph,(_get_packet_and_write_to_serial_sloc4_1_0 + 1)
      00099E 85 14 F0         [24] 2562 	mov	b,(_get_packet_and_write_to_serial_sloc4_1_0 + 2)
      0009A1 EF               [12] 2563 	mov	a,r7
      0009A2 12 2D 8A         [24] 2564 	lcall	__gptrput
      0009A5                       2565 00146$:
                                   2566 ;	radio.c:346: d_byte = fifo_get(&rx_fifo);
      0009A5 78 1E            [12] 2567 	mov	r0,#_get_packet_and_write_to_serial_d_byte_65536_145
      0009A7 EC               [12] 2568 	mov	a,r4
      0009A8 F2               [24] 2569 	movx	@r0,a
                                   2570 ;	radio.c:347: read_idx++;
      0009A9 78 1D            [12] 2571 	mov	r0,#_get_packet_and_write_to_serial_read_idx_65536_145
      0009AB E2               [24] 2572 	movx	a,@r0
      0009AC 24 01            [12] 2573 	add	a,#0x01
      0009AE F2               [24] 2574 	movx	@r0,a
                                   2575 ;	radio.c:350: if (read_idx == 1) {
      0009AF 78 1D            [12] 2576 	mov	r0,#_get_packet_and_write_to_serial_read_idx_65536_145
      0009B1 E2               [24] 2577 	movx	a,@r0
      0009B2 B4 01 06         [24] 2578 	cjne	a,#0x01,00110$
                                   2579 ;	radio.c:351: serial_tx_byte(RESPONSE_CODE_SUCCESS);
      0009B5 75 82 DD         [24] 2580 	mov	dpl,#0xdd
      0009B8 12 24 7F         [24] 2581 	lcall	_serial_tx_byte
      0009BB                       2582 00110$:
                                   2583 ;	radio.c:354: if (read_idx < 3) {
      0009BB 78 1D            [12] 2584 	mov	r0,#_get_packet_and_write_to_serial_read_idx_65536_145
      0009BD E2               [24] 2585 	movx	a,@r0
      0009BE B4 03 00         [24] 2586 	cjne	a,#0x03,00311$
      0009C1                       2587 00311$:
      0009C1 50 0A            [24] 2588 	jnc	00115$
                                   2589 ;	radio.c:355: serial_tx_byte(d_byte);
      0009C3 78 1E            [12] 2590 	mov	r0,#_get_packet_and_write_to_serial_d_byte_65536_145
      0009C5 E2               [24] 2591 	movx	a,@r0
      0009C6 F5 82            [12] 2592 	mov	dpl,a
      0009C8 12 24 7F         [24] 2593 	lcall	_serial_tx_byte
      0009CB 80 67            [24] 2594 	sjmp	00116$
      0009CD                       2595 00115$:
                                   2596 ;	radio.c:357: encoding_error = decoder.add_encoded_byte(&decoder_state, d_byte);
      0009CD 90 F1 E1         [24] 2597 	mov	dptr,#_get_packet_and_write_to_serial_decoder_65536_145
      0009D0 E0               [24] 2598 	movx	a,@dptr
      0009D1 FE               [12] 2599 	mov	r6,a
      0009D2 A3               [24] 2600 	inc	dptr
      0009D3 E0               [24] 2601 	movx	a,@dptr
      0009D4 FF               [12] 2602 	mov	r7,a
      0009D5 C0 07            [24] 2603 	push	ar7
      0009D7 C0 06            [24] 2604 	push	ar6
      0009D9 78 1E            [12] 2605 	mov	r0,#_get_packet_and_write_to_serial_d_byte_65536_145
      0009DB E2               [24] 2606 	movx	a,@r0
      0009DC C0 E0            [24] 2607 	push	acc
      0009DE 12 09 E3         [24] 2608 	lcall	00313$
      0009E1 80 0B            [24] 2609 	sjmp	00314$
      0009E3                       2610 00313$:
      0009E3 C0 06            [24] 2611 	push	ar6
      0009E5 C0 07            [24] 2612 	push	ar7
      0009E7 90 F1 E5         [24] 2613 	mov	dptr,#_get_packet_and_write_to_serial_decoder_state_65536_145
      0009EA 75 F0 00         [24] 2614 	mov	b,#0x00
      0009ED 22               [24] 2615 	ret
      0009EE                       2616 00314$:
      0009EE 85 82 0A         [24] 2617 	mov	_get_packet_and_write_to_serial_sloc1_1_0,dpl
      0009F1 15 81            [12] 2618 	dec	sp
      0009F3 D0 06            [24] 2619 	pop	ar6
      0009F5 D0 07            [24] 2620 	pop	ar7
                                   2621 ;	radio.c:359: while (decoder.next_decoded_byte(&decoder_state, &d_byte)) {
      0009F7                       2622 00111$:
      0009F7 90 F1 E3         [24] 2623 	mov	dptr,#(_get_packet_and_write_to_serial_decoder_65536_145 + 0x0002)
      0009FA E0               [24] 2624 	movx	a,@dptr
      0009FB FE               [12] 2625 	mov	r6,a
      0009FC A3               [24] 2626 	inc	dptr
      0009FD E0               [24] 2627 	movx	a,@dptr
      0009FE FF               [12] 2628 	mov	r7,a
      0009FF C0 07            [24] 2629 	push	ar7
      000A01 74 1E            [12] 2630 	mov	a,#_get_packet_and_write_to_serial_d_byte_65536_145
      000A03 C0 E0            [24] 2631 	push	acc
      000A05 74 F0            [12] 2632 	mov	a,#(_get_packet_and_write_to_serial_d_byte_65536_145 >> 8)
      000A07 C0 E0            [24] 2633 	push	acc
      000A09 74 60            [12] 2634 	mov	a,#0x60
      000A0B C0 E0            [24] 2635 	push	acc
      000A0D 12 0A 12         [24] 2636 	lcall	00315$
      000A10 80 0B            [24] 2637 	sjmp	00316$
      000A12                       2638 00315$:
      000A12 C0 06            [24] 2639 	push	ar6
      000A14 C0 07            [24] 2640 	push	ar7
      000A16 90 F1 E5         [24] 2641 	mov	dptr,#_get_packet_and_write_to_serial_decoder_state_65536_145
      000A19 75 F0 00         [24] 2642 	mov	b,#0x00
      000A1C 22               [24] 2643 	ret
      000A1D                       2644 00316$:
      000A1D AE 82            [24] 2645 	mov	r6,dpl
      000A1F 15 81            [12] 2646 	dec	sp
      000A21 15 81            [12] 2647 	dec	sp
      000A23 15 81            [12] 2648 	dec	sp
      000A25 D0 07            [24] 2649 	pop	ar7
      000A27 EE               [12] 2650 	mov	a,r6
      000A28 60 0A            [24] 2651 	jz	00116$
                                   2652 ;	radio.c:360: serial_tx_byte(d_byte);
      000A2A 78 1E            [12] 2653 	mov	r0,#_get_packet_and_write_to_serial_d_byte_65536_145
      000A2C E2               [24] 2654 	movx	a,@r0
      000A2D F5 82            [12] 2655 	mov	dpl,a
      000A2F 12 24 7F         [24] 2656 	lcall	_serial_tx_byte
      000A32 80 C3            [24] 2657 	sjmp	00111$
      000A34                       2658 00116$:
                                   2659 ;	radio.c:364: if (encoding_error) {
      000A34 E5 0A            [12] 2660 	mov	a,_get_packet_and_write_to_serial_sloc1_1_0
      000A36 70 7A            [24] 2661 	jnz	00131$
                                   2662 ;	radio.c:369: if (use_pktlen && read_idx == PKTLEN) {
      000A38 78 1B            [12] 2663 	mov	r0,#_get_packet_and_write_to_serial_PARM_3
      000A3A E2               [24] 2664 	movx	a,@r0
      000A3B 60 0D            [24] 2665 	jz	00123$
      000A3D 90 DF 02         [24] 2666 	mov	dptr,#_PKTLEN
      000A40 E0               [24] 2667 	movx	a,@dptr
      000A41 FF               [12] 2668 	mov	r7,a
      000A42 78 1D            [12] 2669 	mov	r0,#_get_packet_and_write_to_serial_read_idx_65536_145
      000A44 E2               [24] 2670 	movx	a,@r0
      000A45 B5 07 02         [24] 2671 	cjne	a,ar7,00320$
      000A48 80 68            [24] 2672 	sjmp	00131$
      000A4A                       2673 00320$:
                                   2674 ;	radio.c:370: break;
      000A4A                       2675 00123$:
                                   2676 ;	radio.c:374: if (timeout_ms > 0 && check_elapsed(timer_start, timeout_ms)) {
      000A4A E5 0B            [12] 2677 	mov	a,_get_packet_and_write_to_serial_sloc2_1_0
      000A4C 45 0C            [12] 2678 	orl	a,(_get_packet_and_write_to_serial_sloc2_1_0 + 1)
      000A4E 45 0D            [12] 2679 	orl	a,(_get_packet_and_write_to_serial_sloc2_1_0 + 2)
      000A50 45 0E            [12] 2680 	orl	a,(_get_packet_and_write_to_serial_sloc2_1_0 + 3)
      000A52 60 49            [24] 2681 	jz	00125$
                                   2682 ;	timer.h:22: EA = 0;
                                   2683 ;	assignBit
      000A54 C2 AF            [12] 2684 	clr	_EA
                                   2685 ;	timer.h:23: rval = (__timerCounter - start_time) > duration;
      000A56 78 2E            [12] 2686 	mov	r0,#___timerCounter
      000A58 79 20            [12] 2687 	mov	r1,#_get_packet_and_write_to_serial_timer_start_65536_145
      000A5A E3               [24] 2688 	movx	a,@r1
      000A5B F5 F0            [12] 2689 	mov	b,a
      000A5D C3               [12] 2690 	clr	c
      000A5E E2               [24] 2691 	movx	a,@r0
      000A5F 95 F0            [12] 2692 	subb	a,b
      000A61 FC               [12] 2693 	mov	r4,a
      000A62 09               [12] 2694 	inc	r1
      000A63 E3               [24] 2695 	movx	a,@r1
      000A64 F5 F0            [12] 2696 	mov	b,a
      000A66 08               [12] 2697 	inc	r0
      000A67 E2               [24] 2698 	movx	a,@r0
      000A68 95 F0            [12] 2699 	subb	a,b
      000A6A FD               [12] 2700 	mov	r5,a
      000A6B 09               [12] 2701 	inc	r1
      000A6C E3               [24] 2702 	movx	a,@r1
      000A6D F5 F0            [12] 2703 	mov	b,a
      000A6F 08               [12] 2704 	inc	r0
      000A70 E2               [24] 2705 	movx	a,@r0
      000A71 95 F0            [12] 2706 	subb	a,b
      000A73 FE               [12] 2707 	mov	r6,a
      000A74 09               [12] 2708 	inc	r1
      000A75 E3               [24] 2709 	movx	a,@r1
      000A76 F5 F0            [12] 2710 	mov	b,a
      000A78 08               [12] 2711 	inc	r0
      000A79 E2               [24] 2712 	movx	a,@r0
      000A7A 95 F0            [12] 2713 	subb	a,b
      000A7C FF               [12] 2714 	mov	r7,a
      000A7D 78 29            [12] 2715 	mov	r0,#_get_packet_and_write_to_serial_rval_327680_180
      000A7F C3               [12] 2716 	clr	c
      000A80 E5 0B            [12] 2717 	mov	a,_get_packet_and_write_to_serial_sloc2_1_0
      000A82 9C               [12] 2718 	subb	a,r4
      000A83 E5 0C            [12] 2719 	mov	a,(_get_packet_and_write_to_serial_sloc2_1_0 + 1)
      000A85 9D               [12] 2720 	subb	a,r5
      000A86 E5 0D            [12] 2721 	mov	a,(_get_packet_and_write_to_serial_sloc2_1_0 + 2)
      000A88 9E               [12] 2722 	subb	a,r6
      000A89 E5 0E            [12] 2723 	mov	a,(_get_packet_and_write_to_serial_sloc2_1_0 + 3)
      000A8B 9F               [12] 2724 	subb	a,r7
      000A8C E4               [12] 2725 	clr	a
      000A8D 33               [12] 2726 	rlc	a
      000A8E F2               [24] 2727 	movx	@r0,a
                                   2728 ;	timer.h:24: EA = 1;
                                   2729 ;	assignBit
      000A8F D2 AF            [12] 2730 	setb	_EA
                                   2731 ;	radio.c:374: if (timeout_ms > 0 && check_elapsed(timer_start, timeout_ms)) {
      000A91 78 29            [12] 2732 	mov	r0,#_get_packet_and_write_to_serial_rval_327680_180
      000A93 E2               [24] 2733 	movx	a,@r0
      000A94 60 07            [24] 2734 	jz	00125$
                                   2735 ;	radio.c:375: rval = RESPONSE_CODE_RX_TIMEOUT;
      000A96 78 1F            [12] 2736 	mov	r0,#_get_packet_and_write_to_serial_rval_65536_145
      000A98 74 AA            [12] 2737 	mov	a,#0xaa
      000A9A F2               [24] 2738 	movx	@r0,a
                                   2739 ;	radio.c:376: break;
      000A9B 80 15            [24] 2740 	sjmp	00131$
      000A9D                       2741 00125$:
                                   2742 ;	radio.c:380: if (SERIAL_DATA_AVAILABLE) {
      000A9D 78 72            [12] 2743 	mov	r0,#_serial_data_available
      000A9F E2               [24] 2744 	movx	a,@r0
      000AA0 70 03            [24] 2745 	jnz	00323$
      000AA2 02 08 82         [24] 2746 	ljmp	00130$
      000AA5                       2747 00323$:
                                   2748 ;	radio.c:383: interrupting_cmd = serial_rx_byte();
      000AA5 12 22 ED         [24] 2749 	lcall	_serial_rx_byte
      000AA8 E5 82            [12] 2750 	mov	a,dpl
      000AAA 78 49            [12] 2751 	mov	r0,#_interrupting_cmd
      000AAC F2               [24] 2752 	movx	@r0,a
                                   2753 ;	radio.c:384: rval = RESPONSE_CODE_CMD_INTERRUPTED;
      000AAD 78 1F            [12] 2754 	mov	r0,#_get_packet_and_write_to_serial_rval_65536_145
      000AAF 74 BB            [12] 2755 	mov	a,#0xbb
      000AB1 F2               [24] 2756 	movx	@r0,a
                                   2757 ;	radio.c:385: break;
      000AB2                       2758 00131$:
                                   2759 ;	radio.c:389: RFST = RFST_SIDLE;
      000AB2 75 E1 04         [24] 2760 	mov	_RFST,#0x04
                                   2761 ;	radio.c:390: while(MARCSTATE!=MARC_STATE_IDLE);
      000AB5                       2762 00132$:
      000AB5 90 DF 3B         [24] 2763 	mov	dptr,#_MARCSTATE
      000AB8 E0               [24] 2764 	movx	a,@dptr
      000AB9 FF               [12] 2765 	mov	r7,a
      000ABA BF 01 F8         [24] 2766 	cjne	r7,#0x01,00132$
                                   2767 ;	radio.c:392: while(!fifo_empty(&rx_fifo)) {
      000ABD                       2768 00135$:
                                   2769 ;	fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
      000ABD 74 D8            [12] 2770 	mov	a,#_rx_fifo
      000ABF 44 F0            [12] 2771 	orl	a,#(_rx_fifo >> 8)
      000AC1 60 2C            [24] 2772 	jz	00166$
                                   2773 ;	fifo.h:28: return (b ? (b->head - b->tail) : 0);
      000AC3 74 D8            [12] 2774 	mov	a,#_rx_fifo
      000AC5 44 F0            [12] 2775 	orl	a,#(_rx_fifo >> 8)
      000AC7 60 17            [24] 2776 	jz	00168$
      000AC9 90 F0 D8         [24] 2777 	mov	dptr,#_rx_fifo
      000ACC E0               [24] 2778 	movx	a,@dptr
      000ACD FF               [12] 2779 	mov	r7,a
      000ACE 90 F0 D9         [24] 2780 	mov	dptr,#(_rx_fifo + 0x0001)
      000AD1 75 F0 00         [24] 2781 	mov	b,#0x00
      000AD4 12 2E 55         [24] 2782 	lcall	__gptrget
      000AD7 FE               [12] 2783 	mov	r6,a
      000AD8 EF               [12] 2784 	mov	a,r7
      000AD9 C3               [12] 2785 	clr	c
      000ADA 9E               [12] 2786 	subb	a,r6
      000ADB FE               [12] 2787 	mov	r6,a
      000ADC 7F 00            [12] 2788 	mov	r7,#0x00
      000ADE 80 04            [24] 2789 	sjmp	00169$
      000AE0                       2790 00168$:
      000AE0 7E 00            [12] 2791 	mov	r6,#0x00
      000AE2 7F 00            [12] 2792 	mov	r7,#0x00
      000AE4                       2793 00169$:
                                   2794 ;	fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
      000AE4 78 1C            [12] 2795 	mov	r0,#_get_packet_and_write_to_serial___1310720043_131072_145
      000AE6 EE               [12] 2796 	mov	a,r6
      000AE7 B4 01 00         [24] 2797 	cjne	a,#0x01,00328$
      000AEA                       2798 00328$:
      000AEA E4               [12] 2799 	clr	a
      000AEB 33               [12] 2800 	rlc	a
      000AEC F2               [24] 2801 	movx	@r0,a
      000AED 80 05            [24] 2802 	sjmp	00167$
      000AEF                       2803 00166$:
      000AEF 78 1C            [12] 2804 	mov	r0,#_get_packet_and_write_to_serial___1310720043_131072_145
      000AF1 74 01            [12] 2805 	mov	a,#0x01
      000AF3 F2               [24] 2806 	movx	@r0,a
      000AF4                       2807 00167$:
                                   2808 ;	radio.c:392: while(!fifo_empty(&rx_fifo)) {
      000AF4 78 1C            [12] 2809 	mov	r0,#_get_packet_and_write_to_serial___1310720043_131072_145
      000AF6 E2               [24] 2810 	movx	a,@r0
      000AF7 60 03            [24] 2811 	jz	00329$
      000AF9 02 0B CE         [24] 2812 	ljmp	00137$
      000AFC                       2813 00329$:
                                   2814 ;	radio.c:393: fifo_get(&rx_fifo);
      000AFC 78 2A            [12] 2815 	mov	r0,#_get_packet_and_write_to_serial_b_262144_188
      000AFE 74 D8            [12] 2816 	mov	a,#_rx_fifo
      000B00 F2               [24] 2817 	movx	@r0,a
      000B01 08               [12] 2818 	inc	r0
      000B02 74 F0            [12] 2819 	mov	a,#(_rx_fifo >> 8)
      000B04 F2               [24] 2820 	movx	@r0,a
      000B05 08               [12] 2821 	inc	r0
      000B06 E4               [12] 2822 	clr	a
      000B07 F2               [24] 2823 	movx	@r0,a
                                   2824 ;	fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
      000B08 74 D8            [12] 2825 	mov	a,#_rx_fifo
      000B0A 44 F0            [12] 2826 	orl	a,#(_rx_fifo >> 8)
      000B0C 60 2C            [24] 2827 	jz	00170$
                                   2828 ;	fifo.h:28: return (b ? (b->head - b->tail) : 0);
      000B0E 74 D8            [12] 2829 	mov	a,#_rx_fifo
      000B10 44 F0            [12] 2830 	orl	a,#(_rx_fifo >> 8)
      000B12 60 17            [24] 2831 	jz	00172$
      000B14 90 F0 D8         [24] 2832 	mov	dptr,#_rx_fifo
      000B17 E0               [24] 2833 	movx	a,@dptr
      000B18 FC               [12] 2834 	mov	r4,a
      000B19 90 F0 D9         [24] 2835 	mov	dptr,#(_rx_fifo + 0x0001)
      000B1C 75 F0 00         [24] 2836 	mov	b,#0x00
      000B1F 12 2E 55         [24] 2837 	lcall	__gptrget
      000B22 FB               [12] 2838 	mov	r3,a
      000B23 EC               [12] 2839 	mov	a,r4
      000B24 C3               [12] 2840 	clr	c
      000B25 9B               [12] 2841 	subb	a,r3
      000B26 FB               [12] 2842 	mov	r3,a
      000B27 7C 00            [12] 2843 	mov	r4,#0x00
      000B29 80 04            [24] 2844 	sjmp	00173$
      000B2B                       2845 00172$:
      000B2B 7B 00            [12] 2846 	mov	r3,#0x00
      000B2D 7C 00            [12] 2847 	mov	r4,#0x00
      000B2F                       2848 00173$:
                                   2849 ;	fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
      000B2F 78 2D            [12] 2850 	mov	r0,#_get_packet_and_write_to_serial___1310720012_327680_189
      000B31 EB               [12] 2851 	mov	a,r3
      000B32 B4 01 00         [24] 2852 	cjne	a,#0x01,00332$
      000B35                       2853 00332$:
      000B35 E4               [12] 2854 	clr	a
      000B36 33               [12] 2855 	rlc	a
      000B37 F2               [24] 2856 	movx	@r0,a
      000B38 80 05            [24] 2857 	sjmp	00171$
      000B3A                       2858 00170$:
      000B3A 78 2D            [12] 2859 	mov	r0,#_get_packet_and_write_to_serial___1310720012_327680_189
      000B3C 74 01            [12] 2860 	mov	a,#0x01
      000B3E F2               [24] 2861 	movx	@r0,a
      000B3F                       2862 00171$:
                                   2863 ;	fifo.h:38: if (!fifo_empty(b)) {
      000B3F 78 2D            [12] 2864 	mov	r0,#_get_packet_and_write_to_serial___1310720012_327680_189
      000B41 E2               [24] 2865 	movx	a,@r0
      000B42 60 03            [24] 2866 	jz	00333$
      000B44 02 0A BD         [24] 2867 	ljmp	00135$
      000B47                       2868 00333$:
                                   2869 ;	fifo.h:39: data_byte = b->buffer[b->tail % b->buffer_len];
      000B47 78 2A            [12] 2870 	mov	r0,#_get_packet_and_write_to_serial_b_262144_188
      000B49 E2               [24] 2871 	movx	a,@r0
      000B4A 24 02            [12] 2872 	add	a,#0x02
      000B4C FA               [12] 2873 	mov	r2,a
      000B4D 08               [12] 2874 	inc	r0
      000B4E E2               [24] 2875 	movx	a,@r0
      000B4F 34 00            [12] 2876 	addc	a,#0x00
      000B51 FB               [12] 2877 	mov	r3,a
      000B52 08               [12] 2878 	inc	r0
      000B53 E2               [24] 2879 	movx	a,@r0
      000B54 FC               [12] 2880 	mov	r4,a
      000B55 8A 82            [24] 2881 	mov	dpl,r2
      000B57 8B 83            [24] 2882 	mov	dph,r3
      000B59 8C F0            [24] 2883 	mov	b,r4
      000B5B 12 2E 55         [24] 2884 	lcall	__gptrget
      000B5E F5 12            [12] 2885 	mov	_get_packet_and_write_to_serial_sloc4_1_0,a
      000B60 A3               [24] 2886 	inc	dptr
      000B61 12 2E 55         [24] 2887 	lcall	__gptrget
      000B64 F5 13            [12] 2888 	mov	(_get_packet_and_write_to_serial_sloc4_1_0 + 1),a
      000B66 A3               [24] 2889 	inc	dptr
      000B67 12 2E 55         [24] 2890 	lcall	__gptrget
      000B6A F5 14            [12] 2891 	mov	(_get_packet_and_write_to_serial_sloc4_1_0 + 2),a
      000B6C 78 2A            [12] 2892 	mov	r0,#_get_packet_and_write_to_serial_b_262144_188
      000B6E E2               [24] 2893 	movx	a,@r0
      000B6F 24 01            [12] 2894 	add	a,#0x01
      000B71 FD               [12] 2895 	mov	r5,a
      000B72 08               [12] 2896 	inc	r0
      000B73 E2               [24] 2897 	movx	a,@r0
      000B74 34 00            [12] 2898 	addc	a,#0x00
      000B76 FE               [12] 2899 	mov	r6,a
      000B77 08               [12] 2900 	inc	r0
      000B78 E2               [24] 2901 	movx	a,@r0
      000B79 FF               [12] 2902 	mov	r7,a
      000B7A 8D 82            [24] 2903 	mov	dpl,r5
      000B7C 8E 83            [24] 2904 	mov	dph,r6
      000B7E 8F F0            [24] 2905 	mov	b,r7
      000B80 12 2E 55         [24] 2906 	lcall	__gptrget
      000B83 F5 0F            [12] 2907 	mov	_get_packet_and_write_to_serial_sloc3_1_0,a
      000B85 78 2A            [12] 2908 	mov	r0,#_get_packet_and_write_to_serial_b_262144_188
      000B87 E2               [24] 2909 	movx	a,@r0
      000B88 24 05            [12] 2910 	add	a,#0x05
      000B8A FA               [12] 2911 	mov	r2,a
      000B8B 08               [12] 2912 	inc	r0
      000B8C E2               [24] 2913 	movx	a,@r0
      000B8D 34 00            [12] 2914 	addc	a,#0x00
      000B8F FB               [12] 2915 	mov	r3,a
      000B90 08               [12] 2916 	inc	r0
      000B91 E2               [24] 2917 	movx	a,@r0
      000B92 FC               [12] 2918 	mov	r4,a
      000B93 8A 82            [24] 2919 	mov	dpl,r2
      000B95 8B 83            [24] 2920 	mov	dph,r3
      000B97 8C F0            [24] 2921 	mov	b,r4
      000B99 12 2E 55         [24] 2922 	lcall	__gptrget
      000B9C FA               [12] 2923 	mov	r2,a
      000B9D 8A F0            [24] 2924 	mov	b,r2
      000B9F E5 0F            [12] 2925 	mov	a,_get_packet_and_write_to_serial_sloc3_1_0
      000BA1 84               [48] 2926 	div	ab
      000BA2 E5 F0            [12] 2927 	mov	a,b
      000BA4 25 12            [12] 2928 	add	a,_get_packet_and_write_to_serial_sloc4_1_0
      000BA6 FA               [12] 2929 	mov	r2,a
      000BA7 E4               [12] 2930 	clr	a
      000BA8 35 13            [12] 2931 	addc	a,(_get_packet_and_write_to_serial_sloc4_1_0 + 1)
      000BAA FC               [12] 2932 	mov	r4,a
      000BAB AB 14            [24] 2933 	mov	r3,(_get_packet_and_write_to_serial_sloc4_1_0 + 2)
      000BAD 8A 82            [24] 2934 	mov	dpl,r2
      000BAF 8C 83            [24] 2935 	mov	dph,r4
      000BB1 8B F0            [24] 2936 	mov	b,r3
      000BB3 12 2E 55         [24] 2937 	lcall	__gptrget
                                   2938 ;	fifo.h:40: b->tail++;
      000BB6 8D 82            [24] 2939 	mov	dpl,r5
      000BB8 8E 83            [24] 2940 	mov	dph,r6
      000BBA 8F F0            [24] 2941 	mov	b,r7
      000BBC 12 2E 55         [24] 2942 	lcall	__gptrget
      000BBF FC               [12] 2943 	mov	r4,a
      000BC0 0C               [12] 2944 	inc	r4
      000BC1 8D 82            [24] 2945 	mov	dpl,r5
      000BC3 8E 83            [24] 2946 	mov	dph,r6
      000BC5 8F F0            [24] 2947 	mov	b,r7
      000BC7 EC               [12] 2948 	mov	a,r4
      000BC8 12 2D 8A         [24] 2949 	lcall	__gptrput
                                   2950 ;	radio.c:393: fifo_get(&rx_fifo);
      000BCB 02 0A BD         [24] 2951 	ljmp	00135$
      000BCE                       2952 00137$:
                                   2953 ;	radio.c:396: if (rval == 0) {
      000BCE 78 1F            [12] 2954 	mov	r0,#_get_packet_and_write_to_serial_rval_65536_145
      000BD0 E2               [24] 2955 	movx	a,@r0
      000BD1 70 0B            [24] 2956 	jnz	00139$
                                   2957 ;	radio.c:397: packet_rx_count++;
      000BD3 78 69            [12] 2958 	mov	r0,#_packet_rx_count
      000BD5 E2               [24] 2959 	movx	a,@r0
      000BD6 24 01            [12] 2960 	add	a,#0x01
      000BD8 F2               [24] 2961 	movx	@r0,a
      000BD9 08               [12] 2962 	inc	r0
      000BDA E2               [24] 2963 	movx	a,@r0
      000BDB 34 00            [12] 2964 	addc	a,#0x00
      000BDD F2               [24] 2965 	movx	@r0,a
      000BDE                       2966 00139$:
                                   2967 ;	radio.c:400: return rval;
      000BDE 78 1F            [12] 2968 	mov	r0,#_get_packet_and_write_to_serial_rval_65536_145
      000BE0 E2               [24] 2969 	movx	a,@r0
      000BE1 F5 82            [12] 2970 	mov	dpl,a
                                   2971 ;	radio.c:401: }
      000BE3 22               [24] 2972 	ret
                                   2973 ;------------------------------------------------------------
                                   2974 ;Allocation info for local variables in function 'radio_set_preamble'
                                   2975 ;------------------------------------------------------------
                                   2976 ;	radio.c:404: void radio_set_preamble(uint16_t p) {
                                   2977 ;	-----------------------------------------
                                   2978 ;	 function radio_set_preamble
                                   2979 ;	-----------------------------------------
      000BE4                       2980 _radio_set_preamble:
      000BE4 AF 83            [24] 2981 	mov	r7,dph
      000BE6 E5 82            [12] 2982 	mov	a,dpl
      000BE8 90 F1 DF         [24] 2983 	mov	dptr,#_preamble_word
      000BEB F0               [24] 2984 	movx	@dptr,a
      000BEC EF               [12] 2985 	mov	a,r7
      000BED A3               [24] 2986 	inc	dptr
      000BEE F0               [24] 2987 	movx	@dptr,a
                                   2988 ;	radio.c:405: preamble_word = p;
                                   2989 ;	radio.c:406: }
      000BEF 22               [24] 2990 	ret
                                   2991 	.area CSEG    (CODE)
                                   2992 	.area CONST   (CODE)
                                   2993 	.area XINIT   (CODE)
                                   2994 	.area CABS    (ABS,CODE)
