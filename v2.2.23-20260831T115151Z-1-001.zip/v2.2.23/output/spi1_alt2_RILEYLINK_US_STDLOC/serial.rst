                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.0.2 #11662 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module serial
                                      6 	.optsdcc -mmcs51 --model-medium
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _tx1_isr
                                     12 	.globl _rx1_isr
                                     13 	.globl _MODE
                                     14 	.globl _RE
                                     15 	.globl _SLAVE
                                     16 	.globl _FE
                                     17 	.globl _ERR
                                     18 	.globl _RX_BYTE
                                     19 	.globl _TX_BYTE
                                     20 	.globl _ACTIVE
                                     21 	.globl _B_7
                                     22 	.globl _B_6
                                     23 	.globl _B_5
                                     24 	.globl _B_4
                                     25 	.globl _B_3
                                     26 	.globl _B_2
                                     27 	.globl _B_1
                                     28 	.globl _B_0
                                     29 	.globl _WDTIF
                                     30 	.globl _P1IF
                                     31 	.globl _UTX1IF
                                     32 	.globl _UTX0IF
                                     33 	.globl _P2IF
                                     34 	.globl _ACC_7
                                     35 	.globl _ACC_6
                                     36 	.globl _ACC_5
                                     37 	.globl _ACC_4
                                     38 	.globl _ACC_3
                                     39 	.globl _ACC_2
                                     40 	.globl _ACC_1
                                     41 	.globl _ACC_0
                                     42 	.globl _OVFIM
                                     43 	.globl _T4CH1IF
                                     44 	.globl _T4CH0IF
                                     45 	.globl _T4OVFIF
                                     46 	.globl _T3CH1IF
                                     47 	.globl _T3CH0IF
                                     48 	.globl _T3OVFIF
                                     49 	.globl _CY
                                     50 	.globl _AC
                                     51 	.globl _F0
                                     52 	.globl _RS1
                                     53 	.globl _RS0
                                     54 	.globl _OV
                                     55 	.globl _F1
                                     56 	.globl _P
                                     57 	.globl _STIF
                                     58 	.globl _P0IF
                                     59 	.globl _T4IF
                                     60 	.globl _T3IF
                                     61 	.globl _T2IF
                                     62 	.globl _T1IF
                                     63 	.globl _DMAIF
                                     64 	.globl _P0IE
                                     65 	.globl _T4IE
                                     66 	.globl _T3IE
                                     67 	.globl _T2IE
                                     68 	.globl _T1IE
                                     69 	.globl _DMAIE
                                     70 	.globl _EA
                                     71 	.globl _STIE
                                     72 	.globl _ENCIE
                                     73 	.globl _URX1IE
                                     74 	.globl _URX0IE
                                     75 	.globl _ADCIE
                                     76 	.globl _RFTXRXIE
                                     77 	.globl _P2_7
                                     78 	.globl _P2_6
                                     79 	.globl _P2_5
                                     80 	.globl _P2_4
                                     81 	.globl _P2_3
                                     82 	.globl _P2_2
                                     83 	.globl _P2_1
                                     84 	.globl _P2_0
                                     85 	.globl _ENCIF_1
                                     86 	.globl _ENCIF_0
                                     87 	.globl _P1_7
                                     88 	.globl _P1_6
                                     89 	.globl _P1_5
                                     90 	.globl _P1_4
                                     91 	.globl _P1_3
                                     92 	.globl _P1_2
                                     93 	.globl _P1_1
                                     94 	.globl _P1_0
                                     95 	.globl _URX1IF
                                     96 	.globl _ADCIF
                                     97 	.globl _URX0IF
                                     98 	.globl _IT1
                                     99 	.globl _RFTXRXIF
                                    100 	.globl _IT0
                                    101 	.globl _P0_7
                                    102 	.globl _P0_6
                                    103 	.globl _P0_5
                                    104 	.globl _P0_4
                                    105 	.globl _P0_3
                                    106 	.globl _P0_2
                                    107 	.globl _P0_1
                                    108 	.globl _P0_0
                                    109 	.globl _P2DIR
                                    110 	.globl _P1DIR
                                    111 	.globl _P0DIR
                                    112 	.globl _U1GCR
                                    113 	.globl _U1UCR
                                    114 	.globl _U1BAUD
                                    115 	.globl _U1DBUF
                                    116 	.globl _U1CSR
                                    117 	.globl _P2INP
                                    118 	.globl _P1INP
                                    119 	.globl _P2SEL
                                    120 	.globl _P1SEL
                                    121 	.globl _P0SEL
                                    122 	.globl _ADCCFG
                                    123 	.globl _PERCFG
                                    124 	.globl _B
                                    125 	.globl _T4CC1
                                    126 	.globl _T4CCTL1
                                    127 	.globl _T4CC0
                                    128 	.globl _T4CCTL0
                                    129 	.globl _T4CTL
                                    130 	.globl _T4CNT
                                    131 	.globl _RFIF
                                    132 	.globl _IRCON2
                                    133 	.globl _T1CCTL2
                                    134 	.globl _T1CCTL1
                                    135 	.globl _T1CCTL0
                                    136 	.globl _T1CTL
                                    137 	.globl _T1CNTH
                                    138 	.globl _T1CNTL
                                    139 	.globl _RFST
                                    140 	.globl _ACC
                                    141 	.globl _T1CC2H
                                    142 	.globl _T1CC2L
                                    143 	.globl _T1CC1H
                                    144 	.globl _T1CC1L
                                    145 	.globl _T1CC0H
                                    146 	.globl _T1CC0L
                                    147 	.globl _RFD
                                    148 	.globl _TIMIF
                                    149 	.globl _DMAREQ
                                    150 	.globl _DMAARM
                                    151 	.globl _DMA0CFGH
                                    152 	.globl _DMA0CFGL
                                    153 	.globl _DMA1CFGH
                                    154 	.globl _DMA1CFGL
                                    155 	.globl _DMAIRQ
                                    156 	.globl _PSW
                                    157 	.globl _T3CC1
                                    158 	.globl _T3CCTL1
                                    159 	.globl _T3CC0
                                    160 	.globl _T3CCTL0
                                    161 	.globl _T3CTL
                                    162 	.globl _T3CNT
                                    163 	.globl _WDCTL
                                    164 	.globl __SFRC8
                                    165 	.globl _MEMCTR
                                    166 	.globl _CLKCON
                                    167 	.globl _U0GCR
                                    168 	.globl _U0UCR
                                    169 	.globl __SFRC3
                                    170 	.globl _U0BAUD
                                    171 	.globl _U0DBUF
                                    172 	.globl _IRCON
                                    173 	.globl __SFRBF
                                    174 	.globl _SLEEP
                                    175 	.globl _RNDH
                                    176 	.globl _RNDL
                                    177 	.globl _ADCH
                                    178 	.globl _ADCL
                                    179 	.globl _IP1
                                    180 	.globl _IEN1
                                    181 	.globl __SFRB7
                                    182 	.globl _ADCCON3
                                    183 	.globl _ADCCON2
                                    184 	.globl _ADCCON1
                                    185 	.globl _ENCCS
                                    186 	.globl _ENCDO
                                    187 	.globl _ENCDI
                                    188 	.globl __SFRB0
                                    189 	.globl _FWDATA
                                    190 	.globl _FCTL
                                    191 	.globl _FADDRH
                                    192 	.globl _FADDRL
                                    193 	.globl _FWT
                                    194 	.globl __SFRAA
                                    195 	.globl _IP0
                                    196 	.globl _IEN0
                                    197 	.globl __SFRA7
                                    198 	.globl _WORTIME1
                                    199 	.globl _WORTIME0
                                    200 	.globl _WOREVT1
                                    201 	.globl _WOREVT0
                                    202 	.globl _WORCTRL
                                    203 	.globl _WORIRQ
                                    204 	.globl _P2
                                    205 	.globl __SFR9F
                                    206 	.globl _T2CTL
                                    207 	.globl _T2PR
                                    208 	.globl _T2CT
                                    209 	.globl _S1CON
                                    210 	.globl _IEN2
                                    211 	.globl __SFR99
                                    212 	.globl _S0CON
                                    213 	.globl __SFR97
                                    214 	.globl __SFR96
                                    215 	.globl __SFR95
                                    216 	.globl __SFR94
                                    217 	.globl __XPAGE
                                    218 	.globl _MPAGE
                                    219 	.globl _DPS
                                    220 	.globl _RFIM
                                    221 	.globl _P1
                                    222 	.globl _P0INP
                                    223 	.globl __SFR8E
                                    224 	.globl _P1IEN
                                    225 	.globl _PICTL
                                    226 	.globl _P2IFG
                                    227 	.globl _P1IFG
                                    228 	.globl _P0IFG
                                    229 	.globl _TCON
                                    230 	.globl _PCON
                                    231 	.globl _U0CSR
                                    232 	.globl _DPH1
                                    233 	.globl _DPL1
                                    234 	.globl _DPH0
                                    235 	.globl _DPL0
                                    236 	.globl _SP
                                    237 	.globl _P0
                                    238 	.globl _X_P2DIR
                                    239 	.globl _X_P1DIR
                                    240 	.globl _X_P0DIR
                                    241 	.globl _X_U1GCR
                                    242 	.globl _X_U1UCR
                                    243 	.globl _X_U1BAUD
                                    244 	.globl _X_U1DBUF
                                    245 	.globl _X_U1CSR
                                    246 	.globl _X_P2INP
                                    247 	.globl _X_P1INP
                                    248 	.globl _X_P2SEL
                                    249 	.globl _X_P1SEL
                                    250 	.globl _X_P0SEL
                                    251 	.globl _X_ADCCFG
                                    252 	.globl _X_PERCFG
                                    253 	.globl __NA_B
                                    254 	.globl _X_T4CC1
                                    255 	.globl _X_T4CCTL1
                                    256 	.globl _X_T4CC0
                                    257 	.globl _X_T4CCTL0
                                    258 	.globl _X_T4CTL
                                    259 	.globl _X_T4CNT
                                    260 	.globl _X_RFIF
                                    261 	.globl __NA_IRCON2
                                    262 	.globl _X_T1CCTL2
                                    263 	.globl _X_T1CCTL1
                                    264 	.globl _X_T1CCTL0
                                    265 	.globl _X_T1CTL
                                    266 	.globl _X_T1CNTH
                                    267 	.globl _X_T1CNTL
                                    268 	.globl _X_RFST
                                    269 	.globl __NA_ACC
                                    270 	.globl _X_T1CC2H
                                    271 	.globl _X_T1CC2L
                                    272 	.globl _X_T1CC1H
                                    273 	.globl _X_T1CC1L
                                    274 	.globl _X_T1CC0H
                                    275 	.globl _X_T1CC0L
                                    276 	.globl _X_RFD
                                    277 	.globl _X_TIMIF
                                    278 	.globl _X_DMAREQ
                                    279 	.globl _X_DMAARM
                                    280 	.globl _X_DMA0CFGH
                                    281 	.globl _X_DMA0CFGL
                                    282 	.globl _X_DMA1CFGH
                                    283 	.globl _X_DMA1CFGL
                                    284 	.globl _X_DMAIRQ
                                    285 	.globl __NA_PSW
                                    286 	.globl _X_T3CC1
                                    287 	.globl _X_T3CCTL1
                                    288 	.globl _X_T3CC0
                                    289 	.globl _X_T3CCTL0
                                    290 	.globl _X_T3CTL
                                    291 	.globl _X_T3CNT
                                    292 	.globl _X_WDCTL
                                    293 	.globl __X_SFRC8
                                    294 	.globl _X_MEMCTR
                                    295 	.globl _X_CLKCON
                                    296 	.globl _X_U0GCR
                                    297 	.globl _X_U0UCR
                                    298 	.globl __X_SFRC3
                                    299 	.globl _X_U0BAUD
                                    300 	.globl _X_U0DBUF
                                    301 	.globl __NA_IRCON
                                    302 	.globl __X_SFRBF
                                    303 	.globl _X_SLEEP
                                    304 	.globl _X_RNDH
                                    305 	.globl _X_RNDL
                                    306 	.globl _X_ADCH
                                    307 	.globl _X_ADCL
                                    308 	.globl __NA_IP1
                                    309 	.globl __NA_IEN1
                                    310 	.globl __X_SFRB7
                                    311 	.globl _X_ADCCON3
                                    312 	.globl _X_ADCCON2
                                    313 	.globl _X_ADCCON1
                                    314 	.globl _X_ENCCS
                                    315 	.globl _X_ENCDO
                                    316 	.globl _X_ENCDI
                                    317 	.globl __X_SFRB0
                                    318 	.globl _X_FWDATA
                                    319 	.globl _X_FCTL
                                    320 	.globl _X_FADDRH
                                    321 	.globl _X_FADDRL
                                    322 	.globl _X_FWT
                                    323 	.globl __X_SFRAA
                                    324 	.globl __NA_IP0
                                    325 	.globl __NA_IEN0
                                    326 	.globl __X_SFRA7
                                    327 	.globl _X_WORTIME1
                                    328 	.globl _X_WORTIME0
                                    329 	.globl _X_WOREVT1
                                    330 	.globl _X_WOREVT0
                                    331 	.globl _X_WORCTRL
                                    332 	.globl _X_WORIRQ
                                    333 	.globl __NA_P2
                                    334 	.globl __X_SFR9F
                                    335 	.globl _X_T2CTL
                                    336 	.globl _X_T2PR
                                    337 	.globl _X_T2CT
                                    338 	.globl __NA_S1CON
                                    339 	.globl __NA_IEN2
                                    340 	.globl __X_SFR99
                                    341 	.globl __NA_S0CON
                                    342 	.globl __X_SFR97
                                    343 	.globl __X_SFR96
                                    344 	.globl __X_SFR95
                                    345 	.globl __X_SFR94
                                    346 	.globl _X_MPAGE
                                    347 	.globl __NA_DPS
                                    348 	.globl _X_RFIM
                                    349 	.globl __NA_P1
                                    350 	.globl _X_P0INP
                                    351 	.globl __X_SFR8E
                                    352 	.globl _X_P1IEN
                                    353 	.globl _X_PICTL
                                    354 	.globl _X_P2IFG
                                    355 	.globl _X_P1IFG
                                    356 	.globl _X_P0IFG
                                    357 	.globl __NA_TCON
                                    358 	.globl __NA_PCON
                                    359 	.globl _X_U0CSR
                                    360 	.globl __NA_DPH1
                                    361 	.globl __NA_DPL1
                                    362 	.globl __NA_DPH0
                                    363 	.globl __NA_DPL0
                                    364 	.globl __NA_SP
                                    365 	.globl __NA_P0
                                    366 	.globl _I2SCLKF2
                                    367 	.globl _I2SCLKF1
                                    368 	.globl _I2SCLKF0
                                    369 	.globl _I2SSTAT
                                    370 	.globl _I2SWCNT
                                    371 	.globl _I2SDATH
                                    372 	.globl _I2SDATL
                                    373 	.globl _I2SCFG1
                                    374 	.globl _I2SCFG0
                                    375 	.globl _VCO_VC_DAC
                                    376 	.globl _PKTSTATUS
                                    377 	.globl _MARCSTATE
                                    378 	.globl _RSSI
                                    379 	.globl _LQI
                                    380 	.globl _FREQEST
                                    381 	.globl _VERSION
                                    382 	.globl _PARTNUM
                                    383 	.globl __XREGDF35
                                    384 	.globl __XREGDF34
                                    385 	.globl __XREGDF33
                                    386 	.globl __XREGDF32
                                    387 	.globl _IOCFG0
                                    388 	.globl _IOCFG1
                                    389 	.globl _IOCFG2
                                    390 	.globl _PA_TABLE0
                                    391 	.globl _PA_TABLE1
                                    392 	.globl _PA_TABLE2
                                    393 	.globl _PA_TABLE3
                                    394 	.globl _PA_TABLE4
                                    395 	.globl _PA_TABLE5
                                    396 	.globl _PA_TABLE6
                                    397 	.globl _PA_TABLE7
                                    398 	.globl __XREGDF26
                                    399 	.globl _TEST0
                                    400 	.globl _TEST1
                                    401 	.globl _TEST2
                                    402 	.globl __XREGDF22
                                    403 	.globl __XREGDF21
                                    404 	.globl __XREGDF20
                                    405 	.globl _FSCAL0
                                    406 	.globl _FSCAL1
                                    407 	.globl _FSCAL2
                                    408 	.globl _FSCAL3
                                    409 	.globl _FREND0
                                    410 	.globl _FREND1
                                    411 	.globl _AGCCTRL0
                                    412 	.globl _AGCCTRL1
                                    413 	.globl _AGCCTRL2
                                    414 	.globl _BSCFG
                                    415 	.globl _FOCCFG
                                    416 	.globl _MCSM0
                                    417 	.globl _MCSM1
                                    418 	.globl _MCSM2
                                    419 	.globl _DEVIATN
                                    420 	.globl _MDMCFG0
                                    421 	.globl _MDMCFG1
                                    422 	.globl _MDMCFG2
                                    423 	.globl _MDMCFG3
                                    424 	.globl _MDMCFG4
                                    425 	.globl _FREQ0
                                    426 	.globl _FREQ1
                                    427 	.globl _FREQ2
                                    428 	.globl _FSCTRL0
                                    429 	.globl _FSCTRL1
                                    430 	.globl _CHANNR
                                    431 	.globl _ADDR
                                    432 	.globl _PKTCTRL0
                                    433 	.globl _PKTCTRL1
                                    434 	.globl _PKTLEN
                                    435 	.globl _SYNC0
                                    436 	.globl _SYNC1
                                    437 	.globl _MDMCTRL0H
                                    438 	.globl _xfer_size
                                    439 	.globl _slave_send_size
                                    440 	.globl _master_send_size
                                    441 	.globl _spi_mode
                                    442 	.globl _serial_data_available
                                    443 	.globl _ready_to_send
                                    444 	.globl _configure_serial
                                    445 	.globl _serial_rx_avail
                                    446 	.globl _serial_rx_byte
                                    447 	.globl _serial_rx_word
                                    448 	.globl _serial_rx_long
                                    449 	.globl _serial_tx_byte
                                    450 	.globl _serial_tx_word
                                    451 	.globl _serial_tx_long
                                    452 	.globl _serial_flush
                                    453 	.globl _serial_tx_str
                                    454 ;--------------------------------------------------------
                                    455 ; special function registers
                                    456 ;--------------------------------------------------------
                                    457 	.area RSEG    (ABS,DATA)
      000000                        458 	.org 0x0000
                           000080   459 _P0	=	0x0080
                           000081   460 _SP	=	0x0081
                           000082   461 _DPL0	=	0x0082
                           000083   462 _DPH0	=	0x0083
                           000084   463 _DPL1	=	0x0084
                           000085   464 _DPH1	=	0x0085
                           000086   465 _U0CSR	=	0x0086
                           000087   466 _PCON	=	0x0087
                           000088   467 _TCON	=	0x0088
                           000089   468 _P0IFG	=	0x0089
                           00008A   469 _P1IFG	=	0x008a
                           00008B   470 _P2IFG	=	0x008b
                           00008C   471 _PICTL	=	0x008c
                           00008D   472 _P1IEN	=	0x008d
                           00008E   473 __SFR8E	=	0x008e
                           00008F   474 _P0INP	=	0x008f
                           000090   475 _P1	=	0x0090
                           000091   476 _RFIM	=	0x0091
                           000092   477 _DPS	=	0x0092
                           000093   478 _MPAGE	=	0x0093
                           000093   479 __XPAGE	=	0x0093
                           000094   480 __SFR94	=	0x0094
                           000095   481 __SFR95	=	0x0095
                           000096   482 __SFR96	=	0x0096
                           000097   483 __SFR97	=	0x0097
                           000098   484 _S0CON	=	0x0098
                           000099   485 __SFR99	=	0x0099
                           00009A   486 _IEN2	=	0x009a
                           00009B   487 _S1CON	=	0x009b
                           00009C   488 _T2CT	=	0x009c
                           00009D   489 _T2PR	=	0x009d
                           00009E   490 _T2CTL	=	0x009e
                           00009F   491 __SFR9F	=	0x009f
                           0000A0   492 _P2	=	0x00a0
                           0000A1   493 _WORIRQ	=	0x00a1
                           0000A2   494 _WORCTRL	=	0x00a2
                           0000A3   495 _WOREVT0	=	0x00a3
                           0000A4   496 _WOREVT1	=	0x00a4
                           0000A5   497 _WORTIME0	=	0x00a5
                           0000A6   498 _WORTIME1	=	0x00a6
                           0000A7   499 __SFRA7	=	0x00a7
                           0000A8   500 _IEN0	=	0x00a8
                           0000A9   501 _IP0	=	0x00a9
                           0000AA   502 __SFRAA	=	0x00aa
                           0000AB   503 _FWT	=	0x00ab
                           0000AC   504 _FADDRL	=	0x00ac
                           0000AD   505 _FADDRH	=	0x00ad
                           0000AE   506 _FCTL	=	0x00ae
                           0000AF   507 _FWDATA	=	0x00af
                           0000B0   508 __SFRB0	=	0x00b0
                           0000B1   509 _ENCDI	=	0x00b1
                           0000B2   510 _ENCDO	=	0x00b2
                           0000B3   511 _ENCCS	=	0x00b3
                           0000B4   512 _ADCCON1	=	0x00b4
                           0000B5   513 _ADCCON2	=	0x00b5
                           0000B6   514 _ADCCON3	=	0x00b6
                           0000B7   515 __SFRB7	=	0x00b7
                           0000B8   516 _IEN1	=	0x00b8
                           0000B9   517 _IP1	=	0x00b9
                           0000BA   518 _ADCL	=	0x00ba
                           0000BB   519 _ADCH	=	0x00bb
                           0000BC   520 _RNDL	=	0x00bc
                           0000BD   521 _RNDH	=	0x00bd
                           0000BE   522 _SLEEP	=	0x00be
                           0000BF   523 __SFRBF	=	0x00bf
                           0000C0   524 _IRCON	=	0x00c0
                           0000C1   525 _U0DBUF	=	0x00c1
                           0000C2   526 _U0BAUD	=	0x00c2
                           0000C3   527 __SFRC3	=	0x00c3
                           0000C4   528 _U0UCR	=	0x00c4
                           0000C5   529 _U0GCR	=	0x00c5
                           0000C6   530 _CLKCON	=	0x00c6
                           0000C7   531 _MEMCTR	=	0x00c7
                           0000C8   532 __SFRC8	=	0x00c8
                           0000C9   533 _WDCTL	=	0x00c9
                           0000CA   534 _T3CNT	=	0x00ca
                           0000CB   535 _T3CTL	=	0x00cb
                           0000CC   536 _T3CCTL0	=	0x00cc
                           0000CD   537 _T3CC0	=	0x00cd
                           0000CE   538 _T3CCTL1	=	0x00ce
                           0000CF   539 _T3CC1	=	0x00cf
                           0000D0   540 _PSW	=	0x00d0
                           0000D1   541 _DMAIRQ	=	0x00d1
                           0000D2   542 _DMA1CFGL	=	0x00d2
                           0000D3   543 _DMA1CFGH	=	0x00d3
                           0000D4   544 _DMA0CFGL	=	0x00d4
                           0000D5   545 _DMA0CFGH	=	0x00d5
                           0000D6   546 _DMAARM	=	0x00d6
                           0000D7   547 _DMAREQ	=	0x00d7
                           0000D8   548 _TIMIF	=	0x00d8
                           0000D9   549 _RFD	=	0x00d9
                           0000DA   550 _T1CC0L	=	0x00da
                           0000DB   551 _T1CC0H	=	0x00db
                           0000DC   552 _T1CC1L	=	0x00dc
                           0000DD   553 _T1CC1H	=	0x00dd
                           0000DE   554 _T1CC2L	=	0x00de
                           0000DF   555 _T1CC2H	=	0x00df
                           0000E0   556 _ACC	=	0x00e0
                           0000E1   557 _RFST	=	0x00e1
                           0000E2   558 _T1CNTL	=	0x00e2
                           0000E3   559 _T1CNTH	=	0x00e3
                           0000E4   560 _T1CTL	=	0x00e4
                           0000E5   561 _T1CCTL0	=	0x00e5
                           0000E6   562 _T1CCTL1	=	0x00e6
                           0000E7   563 _T1CCTL2	=	0x00e7
                           0000E8   564 _IRCON2	=	0x00e8
                           0000E9   565 _RFIF	=	0x00e9
                           0000EA   566 _T4CNT	=	0x00ea
                           0000EB   567 _T4CTL	=	0x00eb
                           0000EC   568 _T4CCTL0	=	0x00ec
                           0000ED   569 _T4CC0	=	0x00ed
                           0000EE   570 _T4CCTL1	=	0x00ee
                           0000EF   571 _T4CC1	=	0x00ef
                           0000F0   572 _B	=	0x00f0
                           0000F1   573 _PERCFG	=	0x00f1
                           0000F2   574 _ADCCFG	=	0x00f2
                           0000F3   575 _P0SEL	=	0x00f3
                           0000F4   576 _P1SEL	=	0x00f4
                           0000F5   577 _P2SEL	=	0x00f5
                           0000F6   578 _P1INP	=	0x00f6
                           0000F7   579 _P2INP	=	0x00f7
                           0000F8   580 _U1CSR	=	0x00f8
                           0000F9   581 _U1DBUF	=	0x00f9
                           0000FA   582 _U1BAUD	=	0x00fa
                           0000FB   583 _U1UCR	=	0x00fb
                           0000FC   584 _U1GCR	=	0x00fc
                           0000FD   585 _P0DIR	=	0x00fd
                           0000FE   586 _P1DIR	=	0x00fe
                           0000FF   587 _P2DIR	=	0x00ff
                                    588 ;--------------------------------------------------------
                                    589 ; special function bits
                                    590 ;--------------------------------------------------------
                                    591 	.area RSEG    (ABS,DATA)
      000000                        592 	.org 0x0000
                           000080   593 _P0_0	=	0x0080
                           000081   594 _P0_1	=	0x0081
                           000082   595 _P0_2	=	0x0082
                           000083   596 _P0_3	=	0x0083
                           000084   597 _P0_4	=	0x0084
                           000085   598 _P0_5	=	0x0085
                           000086   599 _P0_6	=	0x0086
                           000087   600 _P0_7	=	0x0087
                           000088   601 _IT0	=	0x0088
                           000089   602 _RFTXRXIF	=	0x0089
                           00008A   603 _IT1	=	0x008a
                           00008B   604 _URX0IF	=	0x008b
                           00008D   605 _ADCIF	=	0x008d
                           00008F   606 _URX1IF	=	0x008f
                           000090   607 _P1_0	=	0x0090
                           000091   608 _P1_1	=	0x0091
                           000092   609 _P1_2	=	0x0092
                           000093   610 _P1_3	=	0x0093
                           000094   611 _P1_4	=	0x0094
                           000095   612 _P1_5	=	0x0095
                           000096   613 _P1_6	=	0x0096
                           000097   614 _P1_7	=	0x0097
                           000098   615 _ENCIF_0	=	0x0098
                           000099   616 _ENCIF_1	=	0x0099
                           0000A0   617 _P2_0	=	0x00a0
                           0000A1   618 _P2_1	=	0x00a1
                           0000A2   619 _P2_2	=	0x00a2
                           0000A3   620 _P2_3	=	0x00a3
                           0000A4   621 _P2_4	=	0x00a4
                           0000A5   622 _P2_5	=	0x00a5
                           0000A6   623 _P2_6	=	0x00a6
                           0000A7   624 _P2_7	=	0x00a7
                           0000A8   625 _RFTXRXIE	=	0x00a8
                           0000A9   626 _ADCIE	=	0x00a9
                           0000AA   627 _URX0IE	=	0x00aa
                           0000AB   628 _URX1IE	=	0x00ab
                           0000AC   629 _ENCIE	=	0x00ac
                           0000AD   630 _STIE	=	0x00ad
                           0000AF   631 _EA	=	0x00af
                           0000B8   632 _DMAIE	=	0x00b8
                           0000B9   633 _T1IE	=	0x00b9
                           0000BA   634 _T2IE	=	0x00ba
                           0000BB   635 _T3IE	=	0x00bb
                           0000BC   636 _T4IE	=	0x00bc
                           0000BD   637 _P0IE	=	0x00bd
                           0000C0   638 _DMAIF	=	0x00c0
                           0000C1   639 _T1IF	=	0x00c1
                           0000C2   640 _T2IF	=	0x00c2
                           0000C3   641 _T3IF	=	0x00c3
                           0000C4   642 _T4IF	=	0x00c4
                           0000C5   643 _P0IF	=	0x00c5
                           0000C7   644 _STIF	=	0x00c7
                           0000D0   645 _P	=	0x00d0
                           0000D1   646 _F1	=	0x00d1
                           0000D2   647 _OV	=	0x00d2
                           0000D3   648 _RS0	=	0x00d3
                           0000D4   649 _RS1	=	0x00d4
                           0000D5   650 _F0	=	0x00d5
                           0000D6   651 _AC	=	0x00d6
                           0000D7   652 _CY	=	0x00d7
                           0000D8   653 _T3OVFIF	=	0x00d8
                           0000D9   654 _T3CH0IF	=	0x00d9
                           0000DA   655 _T3CH1IF	=	0x00da
                           0000DB   656 _T4OVFIF	=	0x00db
                           0000DC   657 _T4CH0IF	=	0x00dc
                           0000DD   658 _T4CH1IF	=	0x00dd
                           0000DE   659 _OVFIM	=	0x00de
                           0000E0   660 _ACC_0	=	0x00e0
                           0000E1   661 _ACC_1	=	0x00e1
                           0000E2   662 _ACC_2	=	0x00e2
                           0000E3   663 _ACC_3	=	0x00e3
                           0000E4   664 _ACC_4	=	0x00e4
                           0000E5   665 _ACC_5	=	0x00e5
                           0000E6   666 _ACC_6	=	0x00e6
                           0000E7   667 _ACC_7	=	0x00e7
                           0000E8   668 _P2IF	=	0x00e8
                           0000E9   669 _UTX0IF	=	0x00e9
                           0000EA   670 _UTX1IF	=	0x00ea
                           0000EB   671 _P1IF	=	0x00eb
                           0000EC   672 _WDTIF	=	0x00ec
                           0000F0   673 _B_0	=	0x00f0
                           0000F1   674 _B_1	=	0x00f1
                           0000F2   675 _B_2	=	0x00f2
                           0000F3   676 _B_3	=	0x00f3
                           0000F4   677 _B_4	=	0x00f4
                           0000F5   678 _B_5	=	0x00f5
                           0000F6   679 _B_6	=	0x00f6
                           0000F7   680 _B_7	=	0x00f7
                           0000F8   681 _ACTIVE	=	0x00f8
                           0000F9   682 _TX_BYTE	=	0x00f9
                           0000FA   683 _RX_BYTE	=	0x00fa
                           0000FB   684 _ERR	=	0x00fb
                           0000FC   685 _FE	=	0x00fc
                           0000FD   686 _SLAVE	=	0x00fd
                           0000FE   687 _RE	=	0x00fe
                           0000FF   688 _MODE	=	0x00ff
                                    689 ;--------------------------------------------------------
                                    690 ; overlayable register banks
                                    691 ;--------------------------------------------------------
                                    692 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        693 	.ds 8
                                    694 ;--------------------------------------------------------
                                    695 ; internal ram data
                                    696 ;--------------------------------------------------------
                                    697 	.area DSEG    (DATA)
                                    698 ;--------------------------------------------------------
                                    699 ; overlayable items in internal ram 
                                    700 ;--------------------------------------------------------
                                    701 	.area	OSEG    (OVR,DATA)
      000021                        702 _serial_rx_byte_sloc0_1_0:
      000021                        703 	.ds 3
      000024                        704 _serial_rx_byte_sloc1_1_0:
      000024                        705 	.ds 1
      000025                        706 _serial_rx_byte_sloc2_1_0:
      000025                        707 	.ds 3
                                    708 	.area	OSEG    (OVR,DATA)
      000021                        709 _serial_tx_byte_sloc0_1_0:
      000021                        710 	.ds 1
      000022                        711 _serial_tx_byte_sloc1_1_0:
      000022                        712 	.ds 2
                                    713 	.area	OSEG    (OVR,DATA)
      000021                        714 _serial_tx_word_sloc0_1_0:
      000021                        715 	.ds 2
      000023                        716 _serial_tx_word_sloc1_1_0:
      000023                        717 	.ds 3
      000026                        718 _serial_tx_word_sloc2_1_0:
      000026                        719 	.ds 3
                                    720 	.area	OSEG    (OVR,DATA)
      000021                        721 _serial_tx_long_sloc0_1_0:
      000021                        722 	.ds 1
      000022                        723 _serial_tx_long_sloc1_1_0:
      000022                        724 	.ds 2
                                    725 ;--------------------------------------------------------
                                    726 ; indirectly addressable internal ram data
                                    727 ;--------------------------------------------------------
                                    728 	.area ISEG    (DATA)
                                    729 ;--------------------------------------------------------
                                    730 ; absolute internal ram data
                                    731 ;--------------------------------------------------------
                                    732 	.area IABS    (ABS,DATA)
                                    733 	.area IABS    (ABS,DATA)
                                    734 ;--------------------------------------------------------
                                    735 ; bit data
                                    736 ;--------------------------------------------------------
                                    737 	.area BSEG    (BIT)
                                    738 ;--------------------------------------------------------
                                    739 ; paged external ram data
                                    740 ;--------------------------------------------------------
                                    741 	.area PSEG    (PAG,XDATA)
      00F071                        742 _ready_to_send::
      00F071                        743 	.ds 1
      00F072                        744 _serial_data_available::
      00F072                        745 	.ds 1
      00F073                        746 _spi_mode::
      00F073                        747 	.ds 1
      00F074                        748 _master_send_size::
      00F074                        749 	.ds 1
      00F075                        750 _slave_send_size::
      00F075                        751 	.ds 1
      00F076                        752 _xfer_size::
      00F076                        753 	.ds 1
      00F077                        754 _serial_rx_byte___1310720032_131072_103:
      00F077                        755 	.ds 1
      00F078                        756 _serial_rx_byte_b_196608_108:
      00F078                        757 	.ds 3
      00F07B                        758 _serial_rx_byte___1310720012_262144_109:
      00F07B                        759 	.ds 1
      00F07C                        760 _serial_tx_byte_b_196608_128:
      00F07C                        761 	.ds 3
      00F07F                        762 _serial_tx_byte_data_byte_196608_128:
      00F07F                        763 	.ds 1
      00F080                        764 _serial_tx_byte___1966080018_327680_130:
      00F080                        765 	.ds 1
      00F081                        766 _serial_tx_byte___1310720015_524288_133:
      00F081                        767 	.ds 1
      00F082                        768 _serial_tx_word_b_196608_141:
      00F082                        769 	.ds 3
      00F085                        770 _serial_tx_word___1966080018_327680_143:
      00F085                        771 	.ds 1
      00F086                        772 _serial_tx_word___1310720015_524288_146:
      00F086                        773 	.ds 1
      00F087                        774 _serial_tx_word_b_196608_152:
      00F087                        775 	.ds 3
      00F08A                        776 _serial_tx_word___1966080018_327680_154:
      00F08A                        777 	.ds 1
      00F08B                        778 _serial_tx_long_tx_long_65536_162:
      00F08B                        779 	.ds 4
      00F08F                        780 _serial_tx_long_b_196608_165:
      00F08F                        781 	.ds 3
      00F092                        782 _serial_tx_long_data_byte_196608_165:
      00F092                        783 	.ds 1
      00F093                        784 _serial_tx_long___1966080018_327680_167:
      00F093                        785 	.ds 1
      00F094                        786 _serial_tx_long_b_196608_176:
      00F094                        787 	.ds 3
      00F097                        788 _serial_tx_long_data_byte_196608_176:
      00F097                        789 	.ds 1
      00F098                        790 _serial_tx_long___1966080018_327680_178:
      00F098                        791 	.ds 1
      00F099                        792 _serial_tx_long_b_196608_187:
      00F099                        793 	.ds 3
      00F09C                        794 _serial_tx_long_data_byte_196608_187:
      00F09C                        795 	.ds 1
      00F09D                        796 _serial_tx_long___1966080018_327680_189:
      00F09D                        797 	.ds 1
      00F09E                        798 _serial_tx_long_b_196608_198:
      00F09E                        799 	.ds 3
      00F0A1                        800 _serial_tx_long_data_byte_196608_198:
      00F0A1                        801 	.ds 1
      00F0A2                        802 _serial_tx_long___1966080018_327680_200:
      00F0A2                        803 	.ds 1
      00F0A3                        804 _serial_flush___1310720068_131072_208:
      00F0A3                        805 	.ds 1
      00F0A4                        806 _serial_flush___1310720063_131072_208:
      00F0A4                        807 	.ds 1
      00F0A5                        808 _serial_flush_start_time_65536_208:
      00F0A5                        809 	.ds 4
      00F0A9                        810 _serial_flush_rval_327680_231:
      00F0A9                        811 	.ds 1
      00F0AA                        812 _serial_flush_rval_327680_234:
      00F0AA                        813 	.ds 1
                                    814 ;--------------------------------------------------------
                                    815 ; external ram data
                                    816 ;--------------------------------------------------------
                                    817 	.area XSEG    (XDATA)
                           00DF02   818 _MDMCTRL0H	=	0xdf02
                           00DF00   819 _SYNC1	=	0xdf00
                           00DF01   820 _SYNC0	=	0xdf01
                           00DF02   821 _PKTLEN	=	0xdf02
                           00DF03   822 _PKTCTRL1	=	0xdf03
                           00DF04   823 _PKTCTRL0	=	0xdf04
                           00DF05   824 _ADDR	=	0xdf05
                           00DF06   825 _CHANNR	=	0xdf06
                           00DF07   826 _FSCTRL1	=	0xdf07
                           00DF08   827 _FSCTRL0	=	0xdf08
                           00DF09   828 _FREQ2	=	0xdf09
                           00DF0A   829 _FREQ1	=	0xdf0a
                           00DF0B   830 _FREQ0	=	0xdf0b
                           00DF0C   831 _MDMCFG4	=	0xdf0c
                           00DF0D   832 _MDMCFG3	=	0xdf0d
                           00DF0E   833 _MDMCFG2	=	0xdf0e
                           00DF0F   834 _MDMCFG1	=	0xdf0f
                           00DF10   835 _MDMCFG0	=	0xdf10
                           00DF11   836 _DEVIATN	=	0xdf11
                           00DF12   837 _MCSM2	=	0xdf12
                           00DF13   838 _MCSM1	=	0xdf13
                           00DF14   839 _MCSM0	=	0xdf14
                           00DF15   840 _FOCCFG	=	0xdf15
                           00DF16   841 _BSCFG	=	0xdf16
                           00DF17   842 _AGCCTRL2	=	0xdf17
                           00DF18   843 _AGCCTRL1	=	0xdf18
                           00DF19   844 _AGCCTRL0	=	0xdf19
                           00DF1A   845 _FREND1	=	0xdf1a
                           00DF1B   846 _FREND0	=	0xdf1b
                           00DF1C   847 _FSCAL3	=	0xdf1c
                           00DF1D   848 _FSCAL2	=	0xdf1d
                           00DF1E   849 _FSCAL1	=	0xdf1e
                           00DF1F   850 _FSCAL0	=	0xdf1f
                           00DF20   851 __XREGDF20	=	0xdf20
                           00DF21   852 __XREGDF21	=	0xdf21
                           00DF22   853 __XREGDF22	=	0xdf22
                           00DF23   854 _TEST2	=	0xdf23
                           00DF24   855 _TEST1	=	0xdf24
                           00DF25   856 _TEST0	=	0xdf25
                           00DF26   857 __XREGDF26	=	0xdf26
                           00DF27   858 _PA_TABLE7	=	0xdf27
                           00DF28   859 _PA_TABLE6	=	0xdf28
                           00DF29   860 _PA_TABLE5	=	0xdf29
                           00DF2A   861 _PA_TABLE4	=	0xdf2a
                           00DF2B   862 _PA_TABLE3	=	0xdf2b
                           00DF2C   863 _PA_TABLE2	=	0xdf2c
                           00DF2D   864 _PA_TABLE1	=	0xdf2d
                           00DF2E   865 _PA_TABLE0	=	0xdf2e
                           00DF2F   866 _IOCFG2	=	0xdf2f
                           00DF30   867 _IOCFG1	=	0xdf30
                           00DF31   868 _IOCFG0	=	0xdf31
                           00DF32   869 __XREGDF32	=	0xdf32
                           00DF33   870 __XREGDF33	=	0xdf33
                           00DF34   871 __XREGDF34	=	0xdf34
                           00DF35   872 __XREGDF35	=	0xdf35
                           00DF36   873 _PARTNUM	=	0xdf36
                           00DF37   874 _VERSION	=	0xdf37
                           00DF38   875 _FREQEST	=	0xdf38
                           00DF39   876 _LQI	=	0xdf39
                           00DF3A   877 _RSSI	=	0xdf3a
                           00DF3B   878 _MARCSTATE	=	0xdf3b
                           00DF3C   879 _PKTSTATUS	=	0xdf3c
                           00DF3D   880 _VCO_VC_DAC	=	0xdf3d
                           00DF40   881 _I2SCFG0	=	0xdf40
                           00DF41   882 _I2SCFG1	=	0xdf41
                           00DF42   883 _I2SDATL	=	0xdf42
                           00DF43   884 _I2SDATH	=	0xdf43
                           00DF44   885 _I2SWCNT	=	0xdf44
                           00DF45   886 _I2SSTAT	=	0xdf45
                           00DF46   887 _I2SCLKF0	=	0xdf46
                           00DF47   888 _I2SCLKF1	=	0xdf47
                           00DF48   889 _I2SCLKF2	=	0xdf48
                           00DF80   890 __NA_P0	=	0xdf80
                           00DF81   891 __NA_SP	=	0xdf81
                           00DF82   892 __NA_DPL0	=	0xdf82
                           00DF83   893 __NA_DPH0	=	0xdf83
                           00DF84   894 __NA_DPL1	=	0xdf84
                           00DF85   895 __NA_DPH1	=	0xdf85
                           00DF86   896 _X_U0CSR	=	0xdf86
                           00DF87   897 __NA_PCON	=	0xdf87
                           00DF88   898 __NA_TCON	=	0xdf88
                           00DF89   899 _X_P0IFG	=	0xdf89
                           00DF8A   900 _X_P1IFG	=	0xdf8a
                           00DF8B   901 _X_P2IFG	=	0xdf8b
                           00DF8C   902 _X_PICTL	=	0xdf8c
                           00DF8D   903 _X_P1IEN	=	0xdf8d
                           00DF8E   904 __X_SFR8E	=	0xdf8e
                           00DF8F   905 _X_P0INP	=	0xdf8f
                           00DF90   906 __NA_P1	=	0xdf90
                           00DF91   907 _X_RFIM	=	0xdf91
                           00DF92   908 __NA_DPS	=	0xdf92
                           00DF93   909 _X_MPAGE	=	0xdf93
                           00DF94   910 __X_SFR94	=	0xdf94
                           00DF95   911 __X_SFR95	=	0xdf95
                           00DF96   912 __X_SFR96	=	0xdf96
                           00DF97   913 __X_SFR97	=	0xdf97
                           00DF98   914 __NA_S0CON	=	0xdf98
                           00DF99   915 __X_SFR99	=	0xdf99
                           00DF9A   916 __NA_IEN2	=	0xdf9a
                           00DF9B   917 __NA_S1CON	=	0xdf9b
                           00DF9C   918 _X_T2CT	=	0xdf9c
                           00DF9D   919 _X_T2PR	=	0xdf9d
                           00DF9E   920 _X_T2CTL	=	0xdf9e
                           00DF9F   921 __X_SFR9F	=	0xdf9f
                           00DFA0   922 __NA_P2	=	0xdfa0
                           00DFA1   923 _X_WORIRQ	=	0xdfa1
                           00DFA2   924 _X_WORCTRL	=	0xdfa2
                           00DFA3   925 _X_WOREVT0	=	0xdfa3
                           00DFA4   926 _X_WOREVT1	=	0xdfa4
                           00DFA5   927 _X_WORTIME0	=	0xdfa5
                           00DFA6   928 _X_WORTIME1	=	0xdfa6
                           00DFA7   929 __X_SFRA7	=	0xdfa7
                           00DFA8   930 __NA_IEN0	=	0xdfa8
                           00DFA9   931 __NA_IP0	=	0xdfa9
                           00DFAA   932 __X_SFRAA	=	0xdfaa
                           00DFAB   933 _X_FWT	=	0xdfab
                           00DFAC   934 _X_FADDRL	=	0xdfac
                           00DFAD   935 _X_FADDRH	=	0xdfad
                           00DFAE   936 _X_FCTL	=	0xdfae
                           00DFAF   937 _X_FWDATA	=	0xdfaf
                           00DFB0   938 __X_SFRB0	=	0xdfb0
                           00DFB1   939 _X_ENCDI	=	0xdfb1
                           00DFB2   940 _X_ENCDO	=	0xdfb2
                           00DFB3   941 _X_ENCCS	=	0xdfb3
                           00DFB4   942 _X_ADCCON1	=	0xdfb4
                           00DFB5   943 _X_ADCCON2	=	0xdfb5
                           00DFB6   944 _X_ADCCON3	=	0xdfb6
                           00DFB7   945 __X_SFRB7	=	0xdfb7
                           00DFB8   946 __NA_IEN1	=	0xdfb8
                           00DFB9   947 __NA_IP1	=	0xdfb9
                           00DFBA   948 _X_ADCL	=	0xdfba
                           00DFBB   949 _X_ADCH	=	0xdfbb
                           00DFBC   950 _X_RNDL	=	0xdfbc
                           00DFBD   951 _X_RNDH	=	0xdfbd
                           00DFBE   952 _X_SLEEP	=	0xdfbe
                           00DFBF   953 __X_SFRBF	=	0xdfbf
                           00DFC0   954 __NA_IRCON	=	0xdfc0
                           00DFC1   955 _X_U0DBUF	=	0xdfc1
                           00DFC2   956 _X_U0BAUD	=	0xdfc2
                           00DFC3   957 __X_SFRC3	=	0xdfc3
                           00DFC4   958 _X_U0UCR	=	0xdfc4
                           00DFC5   959 _X_U0GCR	=	0xdfc5
                           00DFC6   960 _X_CLKCON	=	0xdfc6
                           00DFC7   961 _X_MEMCTR	=	0xdfc7
                           00DFC8   962 __X_SFRC8	=	0xdfc8
                           00DFC9   963 _X_WDCTL	=	0xdfc9
                           00DFCA   964 _X_T3CNT	=	0xdfca
                           00DFCB   965 _X_T3CTL	=	0xdfcb
                           00DFCC   966 _X_T3CCTL0	=	0xdfcc
                           00DFCD   967 _X_T3CC0	=	0xdfcd
                           00DFCE   968 _X_T3CCTL1	=	0xdfce
                           00DFCF   969 _X_T3CC1	=	0xdfcf
                           00DFD0   970 __NA_PSW	=	0xdfd0
                           00DFD1   971 _X_DMAIRQ	=	0xdfd1
                           00DFD2   972 _X_DMA1CFGL	=	0xdfd2
                           00DFD3   973 _X_DMA1CFGH	=	0xdfd3
                           00DFD4   974 _X_DMA0CFGL	=	0xdfd4
                           00DFD5   975 _X_DMA0CFGH	=	0xdfd5
                           00DFD6   976 _X_DMAARM	=	0xdfd6
                           00DFD7   977 _X_DMAREQ	=	0xdfd7
                           00DFD8   978 _X_TIMIF	=	0xdfd8
                           00DFD9   979 _X_RFD	=	0xdfd9
                           00DFDA   980 _X_T1CC0L	=	0xdfda
                           00DFDB   981 _X_T1CC0H	=	0xdfdb
                           00DFDC   982 _X_T1CC1L	=	0xdfdc
                           00DFDD   983 _X_T1CC1H	=	0xdfdd
                           00DFDE   984 _X_T1CC2L	=	0xdfde
                           00DFDF   985 _X_T1CC2H	=	0xdfdf
                           00DFE0   986 __NA_ACC	=	0xdfe0
                           00DFE1   987 _X_RFST	=	0xdfe1
                           00DFE2   988 _X_T1CNTL	=	0xdfe2
                           00DFE3   989 _X_T1CNTH	=	0xdfe3
                           00DFE4   990 _X_T1CTL	=	0xdfe4
                           00DFE5   991 _X_T1CCTL0	=	0xdfe5
                           00DFE6   992 _X_T1CCTL1	=	0xdfe6
                           00DFE7   993 _X_T1CCTL2	=	0xdfe7
                           00DFE8   994 __NA_IRCON2	=	0xdfe8
                           00DFE9   995 _X_RFIF	=	0xdfe9
                           00DFEA   996 _X_T4CNT	=	0xdfea
                           00DFEB   997 _X_T4CTL	=	0xdfeb
                           00DFEC   998 _X_T4CCTL0	=	0xdfec
                           00DFED   999 _X_T4CC0	=	0xdfed
                           00DFEE  1000 _X_T4CCTL1	=	0xdfee
                           00DFEF  1001 _X_T4CC1	=	0xdfef
                           00DFF0  1002 __NA_B	=	0xdff0
                           00DFF1  1003 _X_PERCFG	=	0xdff1
                           00DFF2  1004 _X_ADCCFG	=	0xdff2
                           00DFF3  1005 _X_P0SEL	=	0xdff3
                           00DFF4  1006 _X_P1SEL	=	0xdff4
                           00DFF5  1007 _X_P2SEL	=	0xdff5
                           00DFF6  1008 _X_P1INP	=	0xdff6
                           00DFF7  1009 _X_P2INP	=	0xdff7
                           00DFF8  1010 _X_U1CSR	=	0xdff8
                           00DFF9  1011 _X_U1DBUF	=	0xdff9
                           00DFFA  1012 _X_U1BAUD	=	0xdffa
                           00DFFB  1013 _X_U1UCR	=	0xdffb
                           00DFFC  1014 _X_U1GCR	=	0xdffc
                           00DFFD  1015 _X_P0DIR	=	0xdffd
                           00DFFE  1016 _X_P1DIR	=	0xdffe
                           00DFFF  1017 _X_P2DIR	=	0xdfff
      00F20D                       1018 _input_buffer:
      00F20D                       1019 	.ds 6
      00F213                       1020 _input_buffer_mem:
      00F213                       1021 	.ds 128
      00F293                       1022 _output_buffer:
      00F293                       1023 	.ds 6
      00F299                       1024 _output_buffer_mem:
      00F299                       1025 	.ds 128
                                   1026 ;--------------------------------------------------------
                                   1027 ; absolute external ram data
                                   1028 ;--------------------------------------------------------
                                   1029 	.area XABS    (ABS,XDATA)
                                   1030 ;--------------------------------------------------------
                                   1031 ; external initialized ram data
                                   1032 ;--------------------------------------------------------
                                   1033 	.area XISEG   (XDATA)
                                   1034 	.area HOME    (CODE)
                                   1035 	.area GSINIT0 (CODE)
                                   1036 	.area GSINIT1 (CODE)
                                   1037 	.area GSINIT2 (CODE)
                                   1038 	.area GSINIT3 (CODE)
                                   1039 	.area GSINIT4 (CODE)
                                   1040 	.area GSINIT5 (CODE)
                                   1041 	.area GSINIT  (CODE)
                                   1042 	.area GSFINAL (CODE)
                                   1043 	.area CSEG    (CODE)
                                   1044 ;--------------------------------------------------------
                                   1045 ; global & static initialisations
                                   1046 ;--------------------------------------------------------
                                   1047 	.area HOME    (CODE)
                                   1048 	.area GSINIT  (CODE)
                                   1049 	.area GSFINAL (CODE)
                                   1050 	.area GSINIT  (CODE)
                                   1051 ;	spi1_alt2/serial.c:30: volatile uint8_t ready_to_send = 0;
      0000FC 78 71            [12] 1052 	mov	r0,#_ready_to_send
      0000FE E4               [12] 1053 	clr	a
      0000FF F2               [24] 1054 	movx	@r0,a
                                   1055 ;	spi1_alt2/serial.c:40: volatile uint8_t master_send_size = 0;
      000100 78 74            [12] 1056 	mov	r0,#_master_send_size
      000102 F2               [24] 1057 	movx	@r0,a
                                   1058 ;	spi1_alt2/serial.c:41: volatile uint8_t slave_send_size = 0;
      000103 78 75            [12] 1059 	mov	r0,#_slave_send_size
      000105 F2               [24] 1060 	movx	@r0,a
                                   1061 ;	spi1_alt2/serial.c:42: volatile uint8_t xfer_size = 0;
      000106 78 76            [12] 1062 	mov	r0,#_xfer_size
      000108 F2               [24] 1063 	movx	@r0,a
                                   1064 ;--------------------------------------------------------
                                   1065 ; Home
                                   1066 ;--------------------------------------------------------
                                   1067 	.area HOME    (CODE)
                                   1068 	.area HOME    (CODE)
                                   1069 ;--------------------------------------------------------
                                   1070 ; code
                                   1071 ;--------------------------------------------------------
                                   1072 	.area CSEG    (CODE)
                                   1073 ;------------------------------------------------------------
                                   1074 ;Allocation info for local variables in function 'configure_serial'
                                   1075 ;------------------------------------------------------------
                                   1076 ;	spi1_alt2/serial.c:55: void configure_serial()
                                   1077 ;	-----------------------------------------
                                   1078 ;	 function configure_serial
                                   1079 ;	-----------------------------------------
      002046                       1080 _configure_serial:
                           000007  1081 	ar7 = 0x07
                           000006  1082 	ar6 = 0x06
                           000005  1083 	ar5 = 0x05
                           000004  1084 	ar4 = 0x04
                           000003  1085 	ar3 = 0x03
                           000002  1086 	ar2 = 0x02
                           000001  1087 	ar1 = 0x01
                           000000  1088 	ar0 = 0x00
                                   1089 ;	spi1_alt2/serial.c:70: PERCFG = (PERCFG & ~PERCFG_U0CFG) | PERCFG_U1CFG;
      002046 74 FE            [12] 1090 	mov	a,#0xfe
      002048 55 F1            [12] 1091 	anl	a,_PERCFG
      00204A 44 02            [12] 1092 	orl	a,#0x02
      00204C F5 F1            [12] 1093 	mov	_PERCFG,a
                                   1094 ;	spi1_alt2/serial.c:73: P1SEL = P1SEL | BIT4 | BIT5 | BIT6 | BIT7;
      00204E 43 F4 F0         [24] 1095 	orl	_P1SEL,#0xf0
                                   1096 ;	spi1_alt2/serial.c:74: P1DIR = P1DIR & ~(BIT4 | BIT5 | BIT6 | BIT7);
      002051 53 FE 0F         [24] 1097 	anl	_P1DIR,#0x0f
                                   1098 ;	spi1_alt2/serial.c:81: U1CSR = (U1CSR & ~U1CSR_MODE) | U1CSR_SLAVE;
      002054 74 7F            [12] 1099 	mov	a,#0x7f
      002056 55 F8            [12] 1100 	anl	a,_U1CSR
      002058 44 20            [12] 1101 	orl	a,#0x20
      00205A F5 F8            [12] 1102 	mov	_U1CSR,a
                                   1103 ;	spi1_alt2/serial.c:94: U1BAUD = SPI_BAUD_M;
      00205C 75 FA 3B         [24] 1104 	mov	_U1BAUD,#0x3b
                                   1105 ;	spi1_alt2/serial.c:95: U1GCR = (U1GCR & ~(U1GCR_BAUD_E | U1GCR_CPOL | U1GCR_CPHA | U1GCR_ORDER))
      00205F E5 FC            [12] 1106 	mov	a,_U1GCR
      002061 75 FC 0B         [24] 1107 	mov	_U1GCR,#0x0b
                                   1108 ;	spi1_alt2/serial.c:98: TCON &= ~BIT3; // Clear URX1IF
      002064 53 88 F7         [24] 1109 	anl	_TCON,#0xf7
                                   1110 ;	spi1_alt2/serial.c:99: URX1IE = 1;    // Enable URX1IE interrupt
                                   1111 ;	assignBit
      002067 D2 AB            [12] 1112 	setb	_URX1IE
                                   1113 ;	spi1_alt2/serial.c:101: IRCON2 &= ~BIT2; // Clear UTX1IF
      002069 53 E8 FB         [24] 1114 	anl	_IRCON2,#0xfb
                                   1115 ;	spi1_alt2/serial.c:102: IEN2 |= BIT3;    // Enable UTX1IE interrupt
      00206C 43 9A 08         [24] 1116 	orl	_IEN2,#0x08
                                   1117 ;	spi1_alt2/serial.c:104: U1DBUF_write = 0x44;
      00206F 75 F9 44         [24] 1118 	mov	_U1DBUF,#0x44
                                   1119 ;	spi1_alt2/serial.c:107: fifo_init(&input_buffer, input_buffer_mem, SPI_BUF_LEN);
                                   1120 ;	./fifo.h:71: if (b) {
      002072 74 0D            [12] 1121 	mov	a,#_input_buffer
      002074 44 F2            [12] 1122 	orl	a,#(_input_buffer >> 8)
      002076 60 2F            [24] 1123 	jz	00103$
                                   1124 ;	./fifo.h:72: b->head = 0;
      002078 90 F2 0D         [24] 1125 	mov	dptr,#_input_buffer
      00207B E4               [12] 1126 	clr	a
      00207C F0               [24] 1127 	movx	@dptr,a
                                   1128 ;	./fifo.h:73: b->tail = 0;
      00207D 90 F2 0E         [24] 1129 	mov	dptr,#(_input_buffer + 0x0001)
      002080 75 F0 00         [24] 1130 	mov	b,#0x00
      002083 12 2D 8A         [24] 1131 	lcall	__gptrput
                                   1132 ;	./fifo.h:74: b->buffer = buffer;
      002086 90 F2 0F         [24] 1133 	mov	dptr,#(_input_buffer + 0x0002)
      002089 75 F0 00         [24] 1134 	mov	b,#0x00
      00208C 74 13            [12] 1135 	mov	a,#_input_buffer_mem
      00208E 12 2D 8A         [24] 1136 	lcall	__gptrput
      002091 A3               [24] 1137 	inc	dptr
      002092 74 F2            [12] 1138 	mov	a,#(_input_buffer_mem >> 8)
      002094 12 2D 8A         [24] 1139 	lcall	__gptrput
      002097 A3               [24] 1140 	inc	dptr
      002098 E4               [12] 1141 	clr	a
      002099 12 2D 8A         [24] 1142 	lcall	__gptrput
                                   1143 ;	./fifo.h:75: b->buffer_len = size;
      00209C 90 F2 12         [24] 1144 	mov	dptr,#(_input_buffer + 0x0005)
      00209F 75 F0 00         [24] 1145 	mov	b,#0x00
      0020A2 74 80            [12] 1146 	mov	a,#0x80
      0020A4 12 2D 8A         [24] 1147 	lcall	__gptrput
                                   1148 ;	spi1_alt2/serial.c:107: fifo_init(&input_buffer, input_buffer_mem, SPI_BUF_LEN);
      0020A7                       1149 00103$:
                                   1150 ;	spi1_alt2/serial.c:108: fifo_init(&output_buffer, output_buffer_mem, SPI_BUF_LEN);
                                   1151 ;	./fifo.h:71: if (b) {
      0020A7 74 93            [12] 1152 	mov	a,#_output_buffer
      0020A9 44 F2            [12] 1153 	orl	a,#(_output_buffer >> 8)
      0020AB 60 2F            [24] 1154 	jz	00107$
                                   1155 ;	./fifo.h:72: b->head = 0;
      0020AD 90 F2 93         [24] 1156 	mov	dptr,#_output_buffer
      0020B0 E4               [12] 1157 	clr	a
      0020B1 F0               [24] 1158 	movx	@dptr,a
                                   1159 ;	./fifo.h:73: b->tail = 0;
      0020B2 90 F2 94         [24] 1160 	mov	dptr,#(_output_buffer + 0x0001)
      0020B5 75 F0 00         [24] 1161 	mov	b,#0x00
      0020B8 12 2D 8A         [24] 1162 	lcall	__gptrput
                                   1163 ;	./fifo.h:74: b->buffer = buffer;
      0020BB 90 F2 95         [24] 1164 	mov	dptr,#(_output_buffer + 0x0002)
      0020BE 75 F0 00         [24] 1165 	mov	b,#0x00
      0020C1 74 99            [12] 1166 	mov	a,#_output_buffer_mem
      0020C3 12 2D 8A         [24] 1167 	lcall	__gptrput
      0020C6 A3               [24] 1168 	inc	dptr
      0020C7 74 F2            [12] 1169 	mov	a,#(_output_buffer_mem >> 8)
      0020C9 12 2D 8A         [24] 1170 	lcall	__gptrput
      0020CC A3               [24] 1171 	inc	dptr
      0020CD E4               [12] 1172 	clr	a
      0020CE 12 2D 8A         [24] 1173 	lcall	__gptrput
                                   1174 ;	./fifo.h:75: b->buffer_len = size;
      0020D1 90 F2 98         [24] 1175 	mov	dptr,#(_output_buffer + 0x0005)
      0020D4 75 F0 00         [24] 1176 	mov	b,#0x00
      0020D7 74 80            [12] 1177 	mov	a,#0x80
                                   1178 ;	spi1_alt2/serial.c:108: fifo_init(&output_buffer, output_buffer_mem, SPI_BUF_LEN);
                                   1179 ;	spi1_alt2/serial.c:109: }
      0020D9 02 2D 8A         [24] 1180 	ljmp	__gptrput
      0020DC                       1181 00107$:
      0020DC 22               [24] 1182 	ret
                                   1183 ;------------------------------------------------------------
                                   1184 ;Allocation info for local variables in function 'rx1_isr'
                                   1185 ;------------------------------------------------------------
                                   1186 ;	spi1_alt2/serial.c:111: void rx1_isr(void) __interrupt URX1_VECTOR
                                   1187 ;	-----------------------------------------
                                   1188 ;	 function rx1_isr
                                   1189 ;	-----------------------------------------
      0020DD                       1190 _rx1_isr:
      0020DD C0 E0            [24] 1191 	push	acc
      0020DF C0 F0            [24] 1192 	push	b
      0020E1 C0 82            [24] 1193 	push	dpl
      0020E3 C0 83            [24] 1194 	push	dph
      0020E5 C0 07            [24] 1195 	push	ar7
      0020E7 C0 06            [24] 1196 	push	ar6
      0020E9 C0 05            [24] 1197 	push	ar5
      0020EB C0 04            [24] 1198 	push	ar4
      0020ED C0 03            [24] 1199 	push	ar3
      0020EF C0 02            [24] 1200 	push	ar2
      0020F1 C0 01            [24] 1201 	push	ar1
      0020F3 C0 00            [24] 1202 	push	ar0
      0020F5 C0 D0            [24] 1203 	push	psw
      0020F7 75 D0 00         [24] 1204 	mov	psw,#0x00
                                   1205 ;	spi1_alt2/serial.c:114: value = U1DBUF_read;
      0020FA AF F9            [24] 1206 	mov	r7,_U1DBUF
                                   1207 ;	spi1_alt2/serial.c:115: switch(spi_mode)
      0020FC 78 73            [12] 1208 	mov	r0,#_spi_mode
      0020FE E2               [24] 1209 	movx	a,@r0
      0020FF FE               [12] 1210 	mov  r6,a
      002100 24 FC            [12] 1211 	add	a,#0xff - 0x03
      002102 50 03            [24] 1212 	jnc	00168$
      002104 02 22 19         [24] 1213 	ljmp	00126$
      002107                       1214 00168$:
      002107 EE               [12] 1215 	mov	a,r6
      002108 2E               [12] 1216 	add	a,r6
      002109 2E               [12] 1217 	add	a,r6
      00210A 90 21 0E         [24] 1218 	mov	dptr,#00169$
      00210D 73               [24] 1219 	jmp	@a+dptr
      00210E                       1220 00169$:
      00210E 02 21 27         [24] 1221 	ljmp	00104$
      002111 02 21 4D         [24] 1222 	ljmp	00108$
      002114 02 21 9F         [24] 1223 	ljmp	00116$
                                   1224 ;	spi1_alt2/serial.c:117: case SPI_MODE_OUT_OF_SYNC:
                                   1225 ;	spi1_alt2/serial.c:118: if (value == 0x99) {
      002117 BF 99 02         [24] 1226 	cjne	r7,#0x99,00170$
      00211A 80 03            [24] 1227 	sjmp	00171$
      00211C                       1228 00170$:
      00211C 02 22 19         [24] 1229 	ljmp	00126$
      00211F                       1230 00171$:
                                   1231 ;	spi1_alt2/serial.c:119: spi_mode = SPI_MODE_SIZE;
      00211F 78 73            [12] 1232 	mov	r0,#_spi_mode
      002121 74 01            [12] 1233 	mov	a,#0x01
      002123 F2               [24] 1234 	movx	@r0,a
                                   1235 ;	spi1_alt2/serial.c:121: break;
      002124 02 22 19         [24] 1236 	ljmp	00126$
                                   1237 ;	spi1_alt2/serial.c:122: case SPI_MODE_IDLE:
      002127                       1238 00104$:
                                   1239 ;	spi1_alt2/serial.c:123: if (value != 0x99) {
      002127 BF 99 02         [24] 1240 	cjne	r7,#0x99,00172$
      00212A 80 19            [24] 1241 	sjmp	00106$
      00212C                       1242 00172$:
                                   1243 ;	spi1_alt2/serial.c:124: spi_sync_failure_count++;
      00212C 78 6F            [12] 1244 	mov	r0,#_spi_sync_failure_count
      00212E E2               [24] 1245 	movx	a,@r0
      00212F FD               [12] 1246 	mov	r5,a
      002130 08               [12] 1247 	inc	r0
      002131 E2               [24] 1248 	movx	a,@r0
      002132 FE               [12] 1249 	mov	r6,a
      002133 78 6F            [12] 1250 	mov	r0,#_spi_sync_failure_count
      002135 74 01            [12] 1251 	mov	a,#0x01
      002137 2D               [12] 1252 	add	a,r5
      002138 F2               [24] 1253 	movx	@r0,a
      002139 E4               [12] 1254 	clr	a
      00213A 3E               [12] 1255 	addc	a,r6
      00213B 08               [12] 1256 	inc	r0
      00213C F2               [24] 1257 	movx	@r0,a
                                   1258 ;	spi1_alt2/serial.c:125: spi_mode = SPI_MODE_OUT_OF_SYNC;
      00213D 78 73            [12] 1259 	mov	r0,#_spi_mode
      00213F 74 03            [12] 1260 	mov	a,#0x03
      002141 F2               [24] 1261 	movx	@r0,a
      002142 02 22 19         [24] 1262 	ljmp	00126$
      002145                       1263 00106$:
                                   1264 ;	spi1_alt2/serial.c:127: spi_mode = SPI_MODE_SIZE;
      002145 78 73            [12] 1265 	mov	r0,#_spi_mode
      002147 74 01            [12] 1266 	mov	a,#0x01
      002149 F2               [24] 1267 	movx	@r0,a
                                   1268 ;	spi1_alt2/serial.c:129: break;
      00214A 02 22 19         [24] 1269 	ljmp	00126$
                                   1270 ;	spi1_alt2/serial.c:130: case SPI_MODE_SIZE:
      00214D                       1271 00108$:
                                   1272 ;	spi1_alt2/serial.c:131: if (value > SPI_BUF_LEN) {
      00214D EF               [12] 1273 	mov	a,r7
      00214E 24 7F            [12] 1274 	add	a,#0xff - 0x80
      002150 50 19            [24] 1275 	jnc	00110$
                                   1276 ;	spi1_alt2/serial.c:132: spi_sync_failure_count++;
      002152 78 6F            [12] 1277 	mov	r0,#_spi_sync_failure_count
      002154 E2               [24] 1278 	movx	a,@r0
      002155 FD               [12] 1279 	mov	r5,a
      002156 08               [12] 1280 	inc	r0
      002157 E2               [24] 1281 	movx	a,@r0
      002158 FE               [12] 1282 	mov	r6,a
      002159 78 6F            [12] 1283 	mov	r0,#_spi_sync_failure_count
      00215B 74 01            [12] 1284 	mov	a,#0x01
      00215D 2D               [12] 1285 	add	a,r5
      00215E F2               [24] 1286 	movx	@r0,a
      00215F E4               [12] 1287 	clr	a
      002160 3E               [12] 1288 	addc	a,r6
      002161 08               [12] 1289 	inc	r0
      002162 F2               [24] 1290 	movx	@r0,a
                                   1291 ;	spi1_alt2/serial.c:133: spi_mode = SPI_MODE_OUT_OF_SYNC;
      002163 78 73            [12] 1292 	mov	r0,#_spi_mode
      002165 74 03            [12] 1293 	mov	a,#0x03
      002167 F2               [24] 1294 	movx	@r0,a
                                   1295 ;	spi1_alt2/serial.c:134: return;
      002168 02 22 19         [24] 1296 	ljmp	00126$
      00216B                       1297 00110$:
                                   1298 ;	spi1_alt2/serial.c:136: master_send_size = value;
      00216B 78 74            [12] 1299 	mov	r0,#_master_send_size
      00216D EF               [12] 1300 	mov	a,r7
      00216E F2               [24] 1301 	movx	@r0,a
                                   1302 ;	spi1_alt2/serial.c:137: xfer_size = master_send_size;
      00216F 78 74            [12] 1303 	mov	r0,#_master_send_size
      002171 79 76            [12] 1304 	mov	r1,#_xfer_size
      002173 E2               [24] 1305 	movx	a,@r0
      002174 F3               [24] 1306 	movx	@r1,a
                                   1307 ;	spi1_alt2/serial.c:138: if (slave_send_size > xfer_size) {
      002175 78 75            [12] 1308 	mov	r0,#_slave_send_size
      002177 79 76            [12] 1309 	mov	r1,#_xfer_size
      002179 C3               [12] 1310 	clr	c
      00217A E2               [24] 1311 	movx	a,@r0
      00217B F5 F0            [12] 1312 	mov	b,a
      00217D E3               [24] 1313 	movx	a,@r1
      00217E 95 F0            [12] 1314 	subb	a,b
      002180 50 06            [24] 1315 	jnc	00112$
                                   1316 ;	spi1_alt2/serial.c:139: xfer_size = slave_send_size;
      002182 78 75            [12] 1317 	mov	r0,#_slave_send_size
      002184 79 76            [12] 1318 	mov	r1,#_xfer_size
      002186 E2               [24] 1319 	movx	a,@r0
      002187 F3               [24] 1320 	movx	@r1,a
      002188                       1321 00112$:
                                   1322 ;	spi1_alt2/serial.c:141: if (xfer_size > 0) {
      002188 78 76            [12] 1323 	mov	r0,#_xfer_size
      00218A E2               [24] 1324 	movx	a,@r0
      00218B 60 0B            [24] 1325 	jz	00114$
                                   1326 ;	spi1_alt2/serial.c:142: spi_mode = SPI_MODE_XFER;
      00218D 78 73            [12] 1327 	mov	r0,#_spi_mode
      00218F 74 02            [12] 1328 	mov	a,#0x02
      002191 F2               [24] 1329 	movx	@r0,a
                                   1330 ;	spi1_alt2/serial.c:144: CLKCON =  0xA8;		//CLKSPD = 24Mhz, TICKSPD = 750Khz
      002192 75 C6 A8         [24] 1331 	mov	_CLKCON,#0xa8
      002195 02 22 19         [24] 1332 	ljmp	00126$
      002198                       1333 00114$:
                                   1334 ;	spi1_alt2/serial.c:146: spi_mode = SPI_MODE_IDLE;
      002198 78 73            [12] 1335 	mov	r0,#_spi_mode
      00219A E4               [12] 1336 	clr	a
      00219B F2               [24] 1337 	movx	@r0,a
                                   1338 ;	spi1_alt2/serial.c:148: break;
      00219C 02 22 19         [24] 1339 	ljmp	00126$
                                   1340 ;	spi1_alt2/serial.c:149: case SPI_MODE_XFER:
      00219F                       1341 00116$:
                                   1342 ;	spi1_alt2/serial.c:150: if(xfer_size > 0) {	
      00219F 78 76            [12] 1343 	mov	r0,#_xfer_size
      0021A1 E2               [24] 1344 	movx	a,@r0
      0021A2 60 69            [24] 1345 	jz	00122$
                                   1346 ;	spi1_alt2/serial.c:151: if  ((uint8_t)(input_buffer.head - input_buffer.tail) < master_send_size)	{		 				//fifo_count(&input_buffer) < master_send_size
      0021A4 90 F2 0D         [24] 1347 	mov	dptr,#_input_buffer
      0021A7 E0               [24] 1348 	movx	a,@dptr
      0021A8 FE               [12] 1349 	mov	r6,a
      0021A9 90 F2 0E         [24] 1350 	mov	dptr,#(_input_buffer + 0x0001)
      0021AC E0               [24] 1351 	movx	a,@dptr
      0021AD FD               [12] 1352 	mov	r5,a
      0021AE EE               [12] 1353 	mov	a,r6
      0021AF C3               [12] 1354 	clr	c
      0021B0 9D               [12] 1355 	subb	a,r5
      0021B1 FE               [12] 1356 	mov	r6,a
      0021B2 78 74            [12] 1357 	mov	r0,#_master_send_size
      0021B4 C3               [12] 1358 	clr	c
      0021B5 E2               [24] 1359 	movx	a,@r0
      0021B6 F5 F0            [12] 1360 	mov	b,a
      0021B8 EE               [12] 1361 	mov	a,r6
      0021B9 95 F0            [12] 1362 	subb	a,b
      0021BB 50 49            [24] 1363 	jnc	00120$
                                   1364 ;	spi1_alt2/serial.c:152: input_buffer.buffer[input_buffer.head & SPI_BUF_MASK] = value; input_buffer.head++;				//fifo_put(&input_buffer, value)
      0021BD 90 F2 0F         [24] 1365 	mov	dptr,#(_input_buffer + 0x0002)
      0021C0 E0               [24] 1366 	movx	a,@dptr
      0021C1 FC               [12] 1367 	mov	r4,a
      0021C2 A3               [24] 1368 	inc	dptr
      0021C3 E0               [24] 1369 	movx	a,@dptr
      0021C4 FD               [12] 1370 	mov	r5,a
      0021C5 A3               [24] 1371 	inc	dptr
      0021C6 E0               [24] 1372 	movx	a,@dptr
      0021C7 FE               [12] 1373 	mov	r6,a
      0021C8 90 F2 0D         [24] 1374 	mov	dptr,#_input_buffer
      0021CB E0               [24] 1375 	movx	a,@dptr
      0021CC FB               [12] 1376 	mov	r3,a
      0021CD 53 03 7F         [24] 1377 	anl	ar3,#0x7f
      0021D0 7A 00            [12] 1378 	mov	r2,#0x00
      0021D2 EB               [12] 1379 	mov	a,r3
      0021D3 2C               [12] 1380 	add	a,r4
      0021D4 FC               [12] 1381 	mov	r4,a
      0021D5 EA               [12] 1382 	mov	a,r2
      0021D6 3D               [12] 1383 	addc	a,r5
      0021D7 FD               [12] 1384 	mov	r5,a
      0021D8 8C 82            [24] 1385 	mov	dpl,r4
      0021DA 8D 83            [24] 1386 	mov	dph,r5
      0021DC 8E F0            [24] 1387 	mov	b,r6
      0021DE EF               [12] 1388 	mov	a,r7
      0021DF 12 2D 8A         [24] 1389 	lcall	__gptrput
      0021E2 90 F2 0D         [24] 1390 	mov	dptr,#_input_buffer
      0021E5 E0               [24] 1391 	movx	a,@dptr
      0021E6 FF               [12] 1392 	mov	r7,a
      0021E7 0F               [12] 1393 	inc	r7
                                   1394 ;	spi1_alt2/serial.c:153: if  ((uint8_t)(input_buffer.head - input_buffer.tail) == master_send_size) {					//(fifo_count(&input_buffer) == master_send_size)
      0021E8 90 F2 0D         [24] 1395 	mov	dptr,#_input_buffer
      0021EB EF               [12] 1396 	mov	a,r7
      0021EC F0               [24] 1397 	movx	@dptr,a
      0021ED E0               [24] 1398 	movx	a,@dptr
      0021EE FF               [12] 1399 	mov	r7,a
      0021EF 90 F2 0E         [24] 1400 	mov	dptr,#(_input_buffer + 0x0001)
      0021F2 E0               [24] 1401 	movx	a,@dptr
      0021F3 FE               [12] 1402 	mov	r6,a
      0021F4 EF               [12] 1403 	mov	a,r7
      0021F5 C3               [12] 1404 	clr	c
      0021F6 9E               [12] 1405 	subb	a,r6
      0021F7 FF               [12] 1406 	mov	r7,a
      0021F8 78 74            [12] 1407 	mov	r0,#_master_send_size
      0021FA E2               [24] 1408 	movx	a,@r0
      0021FB B5 07 08         [24] 1409 	cjne	a,ar7,00120$
                                   1410 ;	spi1_alt2/serial.c:154: master_send_size = 0;
      0021FE 78 74            [12] 1411 	mov	r0,#_master_send_size
      002200 E4               [12] 1412 	clr	a
      002201 F2               [24] 1413 	movx	@r0,a
                                   1414 ;	spi1_alt2/serial.c:155: serial_data_available = 1;
      002202 78 72            [12] 1415 	mov	r0,#_serial_data_available
      002204 04               [12] 1416 	inc	a
      002205 F2               [24] 1417 	movx	@r0,a
      002206                       1418 00120$:
                                   1419 ;	spi1_alt2/serial.c:158: xfer_size--;
      002206 78 76            [12] 1420 	mov	r0,#_xfer_size
      002208 E2               [24] 1421 	movx	a,@r0
      002209 78 76            [12] 1422 	mov	r0,#_xfer_size
      00220B 14               [12] 1423 	dec	a
      00220C F2               [24] 1424 	movx	@r0,a
      00220D                       1425 00122$:
                                   1426 ;	spi1_alt2/serial.c:160: if (xfer_size == 0) {
      00220D 78 76            [12] 1427 	mov	r0,#_xfer_size
      00220F E2               [24] 1428 	movx	a,@r0
      002210 70 07            [24] 1429 	jnz	00126$
                                   1430 ;	spi1_alt2/serial.c:161: slave_send_size = 0;
      002212 78 75            [12] 1431 	mov	r0,#_slave_send_size
      002214 E4               [12] 1432 	clr	a
      002215 F2               [24] 1433 	movx	@r0,a
                                   1434 ;	spi1_alt2/serial.c:162: spi_mode = SPI_MODE_IDLE;
      002216 78 73            [12] 1435 	mov	r0,#_spi_mode
      002218 F2               [24] 1436 	movx	@r0,a
                                   1437 ;	spi1_alt2/serial.c:165: }
      002219                       1438 00126$:
                                   1439 ;	spi1_alt2/serial.c:166: }
      002219 D0 D0            [24] 1440 	pop	psw
      00221B D0 00            [24] 1441 	pop	ar0
      00221D D0 01            [24] 1442 	pop	ar1
      00221F D0 02            [24] 1443 	pop	ar2
      002221 D0 03            [24] 1444 	pop	ar3
      002223 D0 04            [24] 1445 	pop	ar4
      002225 D0 05            [24] 1446 	pop	ar5
      002227 D0 06            [24] 1447 	pop	ar6
      002229 D0 07            [24] 1448 	pop	ar7
      00222B D0 83            [24] 1449 	pop	dph
      00222D D0 82            [24] 1450 	pop	dpl
      00222F D0 F0            [24] 1451 	pop	b
      002231 D0 E0            [24] 1452 	pop	acc
      002233 32               [24] 1453 	reti
                                   1454 ;------------------------------------------------------------
                                   1455 ;Allocation info for local variables in function 'tx1_isr'
                                   1456 ;------------------------------------------------------------
                                   1457 ;	spi1_alt2/serial.c:168: void tx1_isr(void) __interrupt UTX1_VECTOR
                                   1458 ;	-----------------------------------------
                                   1459 ;	 function tx1_isr
                                   1460 ;	-----------------------------------------
      002234                       1461 _tx1_isr:
      002234 C0 E0            [24] 1462 	push	acc
      002236 C0 F0            [24] 1463 	push	b
      002238 C0 82            [24] 1464 	push	dpl
      00223A C0 83            [24] 1465 	push	dph
      00223C C0 07            [24] 1466 	push	ar7
      00223E C0 06            [24] 1467 	push	ar6
      002240 C0 05            [24] 1468 	push	ar5
      002242 C0 04            [24] 1469 	push	ar4
      002244 C0 03            [24] 1470 	push	ar3
      002246 C0 00            [24] 1471 	push	ar0
      002248 C0 D0            [24] 1472 	push	psw
      00224A 75 D0 00         [24] 1473 	mov	psw,#0x00
                                   1474 ;	spi1_alt2/serial.c:170: IRCON2 &= ~BIT2; // Clear UTX1IF
      00224D 53 E8 FB         [24] 1475 	anl	_IRCON2,#0xfb
                                   1476 ;	spi1_alt2/serial.c:171: if (spi_mode == SPI_MODE_IDLE) {
      002250 78 73            [12] 1477 	mov	r0,#_spi_mode
      002252 E2               [24] 1478 	movx	a,@r0
      002253 70 21            [24] 1479 	jnz	00111$
                                   1480 ;	spi1_alt2/serial.c:172: if (ready_to_send) {
      002255 78 71            [12] 1481 	mov	r0,#_ready_to_send
      002257 E2               [24] 1482 	movx	a,@r0
      002258 60 17            [24] 1483 	jz	00102$
                                   1484 ;	spi1_alt2/serial.c:173: slave_send_size = (output_buffer.head - output_buffer.tail) ; //tell BLE how many bytes you want to send; slave_send_size = fifo_count(&output_buffer);
      00225A 90 F2 93         [24] 1485 	mov	dptr,#_output_buffer
      00225D E0               [24] 1486 	movx	a,@dptr
      00225E FF               [12] 1487 	mov	r7,a
      00225F 90 F2 94         [24] 1488 	mov	dptr,#(_output_buffer + 0x0001)
      002262 E0               [24] 1489 	movx	a,@dptr
      002263 FE               [12] 1490 	mov	r6,a
      002264 EF               [12] 1491 	mov	a,r7
      002265 C3               [12] 1492 	clr	c
      002266 9E               [12] 1493 	subb	a,r6
      002267 78 75            [12] 1494 	mov	r0,#_slave_send_size
      002269 F2               [24] 1495 	movx	@r0,a
                                   1496 ;	spi1_alt2/serial.c:174: U1DBUF_write = slave_send_size;
      00226A 78 75            [12] 1497 	mov	r0,#_slave_send_size
      00226C E2               [24] 1498 	movx	a,@r0
      00226D F5 F9            [12] 1499 	mov	_U1DBUF,a
      00226F 80 55            [24] 1500 	sjmp	00113$
      002271                       1501 00102$:
                                   1502 ;	spi1_alt2/serial.c:176: U1DBUF_write = 0;
      002271 75 F9 00         [24] 1503 	mov	_U1DBUF,#0x00
      002274 80 50            [24] 1504 	sjmp	00113$
      002276                       1505 00111$:
                                   1506 ;	spi1_alt2/serial.c:179: else if (slave_send_size > 0) {
      002276 78 75            [12] 1507 	mov	r0,#_slave_send_size
      002278 E2               [24] 1508 	movx	a,@r0
      002279 60 48            [24] 1509 	jz	00108$
                                   1510 ;	spi1_alt2/serial.c:180: if (output_buffer.head != output_buffer.tail) { 	  //U1DBUF_write = fifo_get(&output_buffer);
      00227B 90 F2 93         [24] 1511 	mov	dptr,#_output_buffer
      00227E E0               [24] 1512 	movx	a,@dptr
      00227F FF               [12] 1513 	mov	r7,a
      002280 90 F2 94         [24] 1514 	mov	dptr,#(_output_buffer + 0x0001)
      002283 E0               [24] 1515 	movx	a,@dptr
      002284 FE               [12] 1516 	mov	r6,a
      002285 EF               [12] 1517 	mov	a,r7
      002286 B5 06 02         [24] 1518 	cjne	a,ar6,00134$
      002289 80 33            [24] 1519 	sjmp	00105$
      00228B                       1520 00134$:
                                   1521 ;	spi1_alt2/serial.c:181: U1DBUF_write = output_buffer.buffer[output_buffer.tail & SPI_BUF_MASK]; output_buffer.tail++;  
      00228B 90 F2 95         [24] 1522 	mov	dptr,#(_output_buffer + 0x0002)
      00228E E0               [24] 1523 	movx	a,@dptr
      00228F FD               [12] 1524 	mov	r5,a
      002290 A3               [24] 1525 	inc	dptr
      002291 E0               [24] 1526 	movx	a,@dptr
      002292 FE               [12] 1527 	mov	r6,a
      002293 A3               [24] 1528 	inc	dptr
      002294 E0               [24] 1529 	movx	a,@dptr
      002295 FF               [12] 1530 	mov	r7,a
      002296 90 F2 94         [24] 1531 	mov	dptr,#(_output_buffer + 0x0001)
      002299 E0               [24] 1532 	movx	a,@dptr
      00229A FC               [12] 1533 	mov	r4,a
      00229B 53 04 7F         [24] 1534 	anl	ar4,#0x7f
      00229E 7B 00            [12] 1535 	mov	r3,#0x00
      0022A0 EC               [12] 1536 	mov	a,r4
      0022A1 2D               [12] 1537 	add	a,r5
      0022A2 FD               [12] 1538 	mov	r5,a
      0022A3 EB               [12] 1539 	mov	a,r3
      0022A4 3E               [12] 1540 	addc	a,r6
      0022A5 FE               [12] 1541 	mov	r6,a
      0022A6 8D 82            [24] 1542 	mov	dpl,r5
      0022A8 8E 83            [24] 1543 	mov	dph,r6
      0022AA 8F F0            [24] 1544 	mov	b,r7
      0022AC 12 2E 55         [24] 1545 	lcall	__gptrget
      0022AF F5 F9            [12] 1546 	mov	_U1DBUF,a
      0022B1 90 F2 94         [24] 1547 	mov	dptr,#(_output_buffer + 0x0001)
      0022B4 E0               [24] 1548 	movx	a,@dptr
      0022B5 FF               [12] 1549 	mov	r7,a
      0022B6 0F               [12] 1550 	inc	r7
      0022B7 90 F2 94         [24] 1551 	mov	dptr,#(_output_buffer + 0x0001)
      0022BA EF               [12] 1552 	mov	a,r7
      0022BB F0               [24] 1553 	movx	@dptr,a
      0022BC 80 08            [24] 1554 	sjmp	00113$
      0022BE                       1555 00105$:
                                   1556 ;	spi1_alt2/serial.c:183: else U1DBUF_write = 0x00;	//nothing in buffer but still should have been something ...
      0022BE 75 F9 00         [24] 1557 	mov	_U1DBUF,#0x00
      0022C1 80 03            [24] 1558 	sjmp	00113$
      0022C3                       1559 00108$:
                                   1560 ;	spi1_alt2/serial.c:188: U1DBUF_write = 0x00;
      0022C3 75 F9 00         [24] 1561 	mov	_U1DBUF,#0x00
      0022C6                       1562 00113$:
                                   1563 ;	spi1_alt2/serial.c:190: }
      0022C6 D0 D0            [24] 1564 	pop	psw
      0022C8 D0 00            [24] 1565 	pop	ar0
      0022CA D0 03            [24] 1566 	pop	ar3
      0022CC D0 04            [24] 1567 	pop	ar4
      0022CE D0 05            [24] 1568 	pop	ar5
      0022D0 D0 06            [24] 1569 	pop	ar6
      0022D2 D0 07            [24] 1570 	pop	ar7
      0022D4 D0 83            [24] 1571 	pop	dph
      0022D6 D0 82            [24] 1572 	pop	dpl
      0022D8 D0 F0            [24] 1573 	pop	b
      0022DA D0 E0            [24] 1574 	pop	acc
      0022DC 32               [24] 1575 	reti
                                   1576 ;	eliminated unneeded push/pop ar1
                                   1577 ;------------------------------------------------------------
                                   1578 ;Allocation info for local variables in function 'serial_rx_avail'
                                   1579 ;------------------------------------------------------------
                                   1580 ;	spi1_alt2/serial.c:192: uint8_t serial_rx_avail()
                                   1581 ;	-----------------------------------------
                                   1582 ;	 function serial_rx_avail
                                   1583 ;	-----------------------------------------
      0022DD                       1584 _serial_rx_avail:
                                   1585 ;	spi1_alt2/serial.c:195: return(input_buffer.head - input_buffer.tail);
      0022DD 90 F2 0D         [24] 1586 	mov	dptr,#_input_buffer
      0022E0 E0               [24] 1587 	movx	a,@dptr
      0022E1 FF               [12] 1588 	mov	r7,a
      0022E2 90 F2 0E         [24] 1589 	mov	dptr,#(_input_buffer + 0x0001)
      0022E5 E0               [24] 1590 	movx	a,@dptr
      0022E6 FE               [12] 1591 	mov	r6,a
      0022E7 EF               [12] 1592 	mov	a,r7
      0022E8 C3               [12] 1593 	clr	c
      0022E9 9E               [12] 1594 	subb	a,r6
      0022EA F5 82            [12] 1595 	mov	dpl,a
                                   1596 ;	spi1_alt2/serial.c:196: }
      0022EC 22               [24] 1597 	ret
                                   1598 ;------------------------------------------------------------
                                   1599 ;Allocation info for local variables in function 'serial_rx_byte'
                                   1600 ;------------------------------------------------------------
                                   1601 ;sloc0                     Allocated with name '_serial_rx_byte_sloc0_1_0'
                                   1602 ;sloc1                     Allocated with name '_serial_rx_byte_sloc1_1_0'
                                   1603 ;sloc2                     Allocated with name '_serial_rx_byte_sloc2_1_0'
                                   1604 ;------------------------------------------------------------
                                   1605 ;	spi1_alt2/serial.c:198: uint8_t serial_rx_byte()
                                   1606 ;	-----------------------------------------
                                   1607 ;	 function serial_rx_byte
                                   1608 ;	-----------------------------------------
      0022ED                       1609 _serial_rx_byte:
                                   1610 ;	spi1_alt2/serial.c:201: if (!serial_data_available) {
      0022ED 78 72            [12] 1611 	mov	r0,#_serial_data_available
      0022EF E2               [24] 1612 	movx	a,@r0
      0022F0 70 0B            [24] 1613 	jnz	00106$
                                   1614 ;	spi1_alt2/serial.c:202: while(!serial_data_available && !subg_rfspy_should_exit) {
      0022F2                       1615 00102$:
      0022F2 78 72            [12] 1616 	mov	r0,#_serial_data_available
      0022F4 E2               [24] 1617 	movx	a,@r0
      0022F5 70 06            [24] 1618 	jnz	00106$
      0022F7 90 F0 B7         [24] 1619 	mov	dptr,#_subg_rfspy_should_exit
      0022FA E0               [24] 1620 	movx	a,@dptr
      0022FB 60 F5            [24] 1621 	jz	00102$
      0022FD                       1622 00106$:
                                   1623 ;	spi1_alt2/serial.c:206: s_data = fifo_get(&input_buffer);
      0022FD 78 78            [12] 1624 	mov	r0,#_serial_rx_byte_b_196608_108
      0022FF 74 0D            [12] 1625 	mov	a,#_input_buffer
      002301 F2               [24] 1626 	movx	@r0,a
      002302 08               [12] 1627 	inc	r0
      002303 74 F2            [12] 1628 	mov	a,#(_input_buffer >> 8)
      002305 F2               [24] 1629 	movx	@r0,a
      002306 08               [12] 1630 	inc	r0
      002307 E4               [12] 1631 	clr	a
      002308 F2               [24] 1632 	movx	@r0,a
                                   1633 ;	./fifo.h:36: uint8_t data_byte = 0;
      002309 7C 00            [12] 1634 	mov	r4,#0x00
                                   1635 ;	./fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
      00230B 74 0D            [12] 1636 	mov	a,#_input_buffer
      00230D 44 F2            [12] 1637 	orl	a,#(_input_buffer >> 8)
      00230F 60 2C            [24] 1638 	jz	00118$
                                   1639 ;	./fifo.h:28: return (b ? (b->head - b->tail) : 0);
      002311 74 0D            [12] 1640 	mov	a,#_input_buffer
      002313 44 F2            [12] 1641 	orl	a,#(_input_buffer >> 8)
      002315 60 17            [24] 1642 	jz	00120$
      002317 90 F2 0D         [24] 1643 	mov	dptr,#_input_buffer
      00231A E0               [24] 1644 	movx	a,@dptr
      00231B FB               [12] 1645 	mov	r3,a
      00231C 90 F2 0E         [24] 1646 	mov	dptr,#(_input_buffer + 0x0001)
      00231F 75 F0 00         [24] 1647 	mov	b,#0x00
      002322 12 2E 55         [24] 1648 	lcall	__gptrget
      002325 FA               [12] 1649 	mov	r2,a
      002326 EB               [12] 1650 	mov	a,r3
      002327 C3               [12] 1651 	clr	c
      002328 9A               [12] 1652 	subb	a,r2
      002329 FA               [12] 1653 	mov	r2,a
      00232A 7B 00            [12] 1654 	mov	r3,#0x00
      00232C 80 04            [24] 1655 	sjmp	00121$
      00232E                       1656 00120$:
      00232E 7A 00            [12] 1657 	mov	r2,#0x00
      002330 7B 00            [12] 1658 	mov	r3,#0x00
      002332                       1659 00121$:
                                   1660 ;	./fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
      002332 78 7B            [12] 1661 	mov	r0,#_serial_rx_byte___1310720012_262144_109
      002334 EA               [12] 1662 	mov	a,r2
      002335 B4 01 00         [24] 1663 	cjne	a,#0x01,00163$
      002338                       1664 00163$:
      002338 E4               [12] 1665 	clr	a
      002339 33               [12] 1666 	rlc	a
      00233A F2               [24] 1667 	movx	@r0,a
      00233B 80 05            [24] 1668 	sjmp	00119$
      00233D                       1669 00118$:
      00233D 78 7B            [12] 1670 	mov	r0,#_serial_rx_byte___1310720012_262144_109
      00233F 74 01            [12] 1671 	mov	a,#0x01
      002341 F2               [24] 1672 	movx	@r0,a
      002342                       1673 00119$:
                                   1674 ;	./fifo.h:38: if (!fifo_empty(b)) {
      002342 78 7B            [12] 1675 	mov	r0,#_serial_rx_byte___1310720012_262144_109
      002344 E2               [24] 1676 	movx	a,@r0
      002345 60 03            [24] 1677 	jz	00164$
      002347 02 23 DB         [24] 1678 	ljmp	00112$
      00234A                       1679 00164$:
                                   1680 ;	./fifo.h:39: data_byte = b->buffer[b->tail % b->buffer_len];
      00234A 78 78            [12] 1681 	mov	r0,#_serial_rx_byte_b_196608_108
      00234C E2               [24] 1682 	movx	a,@r0
      00234D 24 02            [12] 1683 	add	a,#0x02
      00234F FA               [12] 1684 	mov	r2,a
      002350 08               [12] 1685 	inc	r0
      002351 E2               [24] 1686 	movx	a,@r0
      002352 34 00            [12] 1687 	addc	a,#0x00
      002354 FB               [12] 1688 	mov	r3,a
      002355 08               [12] 1689 	inc	r0
      002356 E2               [24] 1690 	movx	a,@r0
      002357 FF               [12] 1691 	mov	r7,a
      002358 8A 82            [24] 1692 	mov	dpl,r2
      00235A 8B 83            [24] 1693 	mov	dph,r3
      00235C 8F F0            [24] 1694 	mov	b,r7
      00235E 12 2E 55         [24] 1695 	lcall	__gptrget
      002361 F5 21            [12] 1696 	mov	_serial_rx_byte_sloc0_1_0,a
      002363 A3               [24] 1697 	inc	dptr
      002364 12 2E 55         [24] 1698 	lcall	__gptrget
      002367 F5 22            [12] 1699 	mov	(_serial_rx_byte_sloc0_1_0 + 1),a
      002369 A3               [24] 1700 	inc	dptr
      00236A 12 2E 55         [24] 1701 	lcall	__gptrget
      00236D F5 23            [12] 1702 	mov	(_serial_rx_byte_sloc0_1_0 + 2),a
      00236F 78 78            [12] 1703 	mov	r0,#_serial_rx_byte_b_196608_108
      002371 E2               [24] 1704 	movx	a,@r0
      002372 24 01            [12] 1705 	add	a,#0x01
      002374 F5 25            [12] 1706 	mov	_serial_rx_byte_sloc2_1_0,a
      002376 08               [12] 1707 	inc	r0
      002377 E2               [24] 1708 	movx	a,@r0
      002378 34 00            [12] 1709 	addc	a,#0x00
      00237A F5 26            [12] 1710 	mov	(_serial_rx_byte_sloc2_1_0 + 1),a
      00237C 08               [12] 1711 	inc	r0
      00237D E2               [24] 1712 	movx	a,@r0
      00237E F5 27            [12] 1713 	mov	(_serial_rx_byte_sloc2_1_0 + 2),a
      002380 85 25 82         [24] 1714 	mov	dpl,_serial_rx_byte_sloc2_1_0
      002383 85 26 83         [24] 1715 	mov	dph,(_serial_rx_byte_sloc2_1_0 + 1)
      002386 85 27 F0         [24] 1716 	mov	b,(_serial_rx_byte_sloc2_1_0 + 2)
      002389 12 2E 55         [24] 1717 	lcall	__gptrget
      00238C F5 24            [12] 1718 	mov	_serial_rx_byte_sloc1_1_0,a
      00238E 78 78            [12] 1719 	mov	r0,#_serial_rx_byte_b_196608_108
      002390 E2               [24] 1720 	movx	a,@r0
      002391 24 05            [12] 1721 	add	a,#0x05
      002393 FA               [12] 1722 	mov	r2,a
      002394 08               [12] 1723 	inc	r0
      002395 E2               [24] 1724 	movx	a,@r0
      002396 34 00            [12] 1725 	addc	a,#0x00
      002398 FB               [12] 1726 	mov	r3,a
      002399 08               [12] 1727 	inc	r0
      00239A E2               [24] 1728 	movx	a,@r0
      00239B FF               [12] 1729 	mov	r7,a
      00239C 8A 82            [24] 1730 	mov	dpl,r2
      00239E 8B 83            [24] 1731 	mov	dph,r3
      0023A0 8F F0            [24] 1732 	mov	b,r7
      0023A2 12 2E 55         [24] 1733 	lcall	__gptrget
      0023A5 FA               [12] 1734 	mov	r2,a
      0023A6 8A F0            [24] 1735 	mov	b,r2
      0023A8 E5 24            [12] 1736 	mov	a,_serial_rx_byte_sloc1_1_0
      0023AA 84               [48] 1737 	div	ab
      0023AB E5 F0            [12] 1738 	mov	a,b
      0023AD 25 21            [12] 1739 	add	a,_serial_rx_byte_sloc0_1_0
      0023AF FA               [12] 1740 	mov	r2,a
      0023B0 E4               [12] 1741 	clr	a
      0023B1 35 22            [12] 1742 	addc	a,(_serial_rx_byte_sloc0_1_0 + 1)
      0023B3 FF               [12] 1743 	mov	r7,a
      0023B4 AE 23            [24] 1744 	mov	r6,(_serial_rx_byte_sloc0_1_0 + 2)
      0023B6 8A 82            [24] 1745 	mov	dpl,r2
      0023B8 8F 83            [24] 1746 	mov	dph,r7
      0023BA 8E F0            [24] 1747 	mov	b,r6
      0023BC 12 2E 55         [24] 1748 	lcall	__gptrget
      0023BF FC               [12] 1749 	mov	r4,a
                                   1750 ;	./fifo.h:40: b->tail++;
      0023C0 85 25 82         [24] 1751 	mov	dpl,_serial_rx_byte_sloc2_1_0
      0023C3 85 26 83         [24] 1752 	mov	dph,(_serial_rx_byte_sloc2_1_0 + 1)
      0023C6 85 27 F0         [24] 1753 	mov	b,(_serial_rx_byte_sloc2_1_0 + 2)
      0023C9 12 2E 55         [24] 1754 	lcall	__gptrget
      0023CC FF               [12] 1755 	mov	r7,a
      0023CD 0F               [12] 1756 	inc	r7
      0023CE 85 25 82         [24] 1757 	mov	dpl,_serial_rx_byte_sloc2_1_0
      0023D1 85 26 83         [24] 1758 	mov	dph,(_serial_rx_byte_sloc2_1_0 + 1)
      0023D4 85 27 F0         [24] 1759 	mov	b,(_serial_rx_byte_sloc2_1_0 + 2)
      0023D7 EF               [12] 1760 	mov	a,r7
      0023D8 12 2D 8A         [24] 1761 	lcall	__gptrput
      0023DB                       1762 00112$:
                                   1763 ;	spi1_alt2/serial.c:206: s_data = fifo_get(&input_buffer);
      0023DB 8C 07            [24] 1764 	mov	ar7,r4
                                   1765 ;	spi1_alt2/serial.c:207: if (fifo_empty(&input_buffer)) {
                                   1766 ;	./fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
      0023DD 74 0D            [12] 1767 	mov	a,#_input_buffer
      0023DF 44 F2            [12] 1768 	orl	a,#(_input_buffer >> 8)
      0023E1 60 2C            [24] 1769 	jz	00122$
                                   1770 ;	./fifo.h:28: return (b ? (b->head - b->tail) : 0);
      0023E3 74 0D            [12] 1771 	mov	a,#_input_buffer
      0023E5 44 F2            [12] 1772 	orl	a,#(_input_buffer >> 8)
      0023E7 60 17            [24] 1773 	jz	00124$
      0023E9 90 F2 0D         [24] 1774 	mov	dptr,#_input_buffer
      0023EC E0               [24] 1775 	movx	a,@dptr
      0023ED FE               [12] 1776 	mov	r6,a
      0023EE 90 F2 0E         [24] 1777 	mov	dptr,#(_input_buffer + 0x0001)
      0023F1 75 F0 00         [24] 1778 	mov	b,#0x00
      0023F4 12 2E 55         [24] 1779 	lcall	__gptrget
      0023F7 FD               [12] 1780 	mov	r5,a
      0023F8 EE               [12] 1781 	mov	a,r6
      0023F9 C3               [12] 1782 	clr	c
      0023FA 9D               [12] 1783 	subb	a,r5
      0023FB FD               [12] 1784 	mov	r5,a
      0023FC 7E 00            [12] 1785 	mov	r6,#0x00
      0023FE 80 04            [24] 1786 	sjmp	00125$
      002400                       1787 00124$:
      002400 7D 00            [12] 1788 	mov	r5,#0x00
      002402 7E 00            [12] 1789 	mov	r6,#0x00
      002404                       1790 00125$:
                                   1791 ;	./fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
      002404 78 77            [12] 1792 	mov	r0,#_serial_rx_byte___1310720032_131072_103
      002406 ED               [12] 1793 	mov	a,r5
      002407 B4 01 00         [24] 1794 	cjne	a,#0x01,00167$
      00240A                       1795 00167$:
      00240A E4               [12] 1796 	clr	a
      00240B 33               [12] 1797 	rlc	a
      00240C F2               [24] 1798 	movx	@r0,a
      00240D 80 05            [24] 1799 	sjmp	00123$
      00240F                       1800 00122$:
      00240F 78 77            [12] 1801 	mov	r0,#_serial_rx_byte___1310720032_131072_103
      002411 74 01            [12] 1802 	mov	a,#0x01
      002413 F2               [24] 1803 	movx	@r0,a
      002414                       1804 00123$:
                                   1805 ;	spi1_alt2/serial.c:207: if (fifo_empty(&input_buffer)) {
      002414 78 77            [12] 1806 	mov	r0,#_serial_rx_byte___1310720032_131072_103
      002416 E2               [24] 1807 	movx	a,@r0
      002417 60 04            [24] 1808 	jz	00108$
                                   1809 ;	spi1_alt2/serial.c:208: serial_data_available = 0;
      002419 78 72            [12] 1810 	mov	r0,#_serial_data_available
      00241B E4               [12] 1811 	clr	a
      00241C F2               [24] 1812 	movx	@r0,a
      00241D                       1813 00108$:
                                   1814 ;	spi1_alt2/serial.c:210: return s_data;
      00241D 8F 82            [24] 1815 	mov	dpl,r7
                                   1816 ;	spi1_alt2/serial.c:211: }
      00241F 22               [24] 1817 	ret
                                   1818 ;------------------------------------------------------------
                                   1819 ;Allocation info for local variables in function 'serial_rx_word'
                                   1820 ;------------------------------------------------------------
                                   1821 ;	spi1_alt2/serial.c:213: uint16_t serial_rx_word()
                                   1822 ;	-----------------------------------------
                                   1823 ;	 function serial_rx_word
                                   1824 ;	-----------------------------------------
      002420                       1825 _serial_rx_word:
                                   1826 ;	spi1_alt2/serial.c:215: return (serial_rx_byte() << 8) + serial_rx_byte();
      002420 12 22 ED         [24] 1827 	lcall	_serial_rx_byte
      002423 AE 82            [24] 1828 	mov	r6,dpl
      002425 7F 00            [12] 1829 	mov	r7,#0x00
      002427 C0 07            [24] 1830 	push	ar7
      002429 C0 06            [24] 1831 	push	ar6
      00242B 12 22 ED         [24] 1832 	lcall	_serial_rx_byte
      00242E AD 82            [24] 1833 	mov	r5,dpl
      002430 D0 06            [24] 1834 	pop	ar6
      002432 D0 07            [24] 1835 	pop	ar7
      002434 7C 00            [12] 1836 	mov	r4,#0x00
      002436 ED               [12] 1837 	mov	a,r5
      002437 2F               [12] 1838 	add	a,r7
      002438 FF               [12] 1839 	mov	r7,a
      002439 EC               [12] 1840 	mov	a,r4
      00243A 3E               [12] 1841 	addc	a,r6
                                   1842 ;	spi1_alt2/serial.c:216: }
      00243B 8F 82            [24] 1843 	mov	dpl,r7
      00243D F5 83            [12] 1844 	mov	dph,a
      00243F 22               [24] 1845 	ret
                                   1846 ;------------------------------------------------------------
                                   1847 ;Allocation info for local variables in function 'serial_rx_long'
                                   1848 ;------------------------------------------------------------
                                   1849 ;	spi1_alt2/serial.c:218: uint32_t serial_rx_long()
                                   1850 ;	-----------------------------------------
                                   1851 ;	 function serial_rx_long
                                   1852 ;	-----------------------------------------
      002440                       1853 _serial_rx_long:
                                   1854 ;	spi1_alt2/serial.c:220: return ((uint32_t)serial_rx_word() << 16) + serial_rx_word();
      002440 12 24 20         [24] 1855 	lcall	_serial_rx_word
      002443 AE 82            [24] 1856 	mov	r6,dpl
      002445 AF 83            [24] 1857 	mov	r7,dph
      002447 8F 04            [24] 1858 	mov	ar4,r7
      002449 8E 05            [24] 1859 	mov	ar5,r6
      00244B 7E 00            [12] 1860 	mov	r6,#0x00
      00244D 7F 00            [12] 1861 	mov	r7,#0x00
      00244F C0 07            [24] 1862 	push	ar7
      002451 C0 06            [24] 1863 	push	ar6
      002453 C0 05            [24] 1864 	push	ar5
      002455 C0 04            [24] 1865 	push	ar4
      002457 12 24 20         [24] 1866 	lcall	_serial_rx_word
      00245A AA 82            [24] 1867 	mov	r2,dpl
      00245C AB 83            [24] 1868 	mov	r3,dph
      00245E D0 04            [24] 1869 	pop	ar4
      002460 D0 05            [24] 1870 	pop	ar5
      002462 D0 06            [24] 1871 	pop	ar6
      002464 D0 07            [24] 1872 	pop	ar7
      002466 8A 00            [24] 1873 	mov	ar0,r2
      002468 8B 01            [24] 1874 	mov	ar1,r3
      00246A E4               [12] 1875 	clr	a
      00246B FA               [12] 1876 	mov	r2,a
      00246C FB               [12] 1877 	mov	r3,a
      00246D E8               [12] 1878 	mov	a,r0
      00246E 2E               [12] 1879 	add	a,r6
      00246F FE               [12] 1880 	mov	r6,a
      002470 E9               [12] 1881 	mov	a,r1
      002471 3F               [12] 1882 	addc	a,r7
      002472 FF               [12] 1883 	mov	r7,a
      002473 EA               [12] 1884 	mov	a,r2
      002474 3D               [12] 1885 	addc	a,r5
      002475 FD               [12] 1886 	mov	r5,a
      002476 EB               [12] 1887 	mov	a,r3
      002477 3C               [12] 1888 	addc	a,r4
      002478 8E 82            [24] 1889 	mov	dpl,r6
      00247A 8F 83            [24] 1890 	mov	dph,r7
      00247C 8D F0            [24] 1891 	mov	b,r5
                                   1892 ;	spi1_alt2/serial.c:221: }
      00247E 22               [24] 1893 	ret
                                   1894 ;------------------------------------------------------------
                                   1895 ;Allocation info for local variables in function 'serial_tx_byte'
                                   1896 ;------------------------------------------------------------
                                   1897 ;sloc0                     Allocated with name '_serial_tx_byte_sloc0_1_0'
                                   1898 ;sloc1                     Allocated with name '_serial_tx_byte_sloc1_1_0'
                                   1899 ;------------------------------------------------------------
                                   1900 ;	spi1_alt2/serial.c:223: void serial_tx_byte(uint8_t tx_byte)
                                   1901 ;	-----------------------------------------
                                   1902 ;	 function serial_tx_byte
                                   1903 ;	-----------------------------------------
      00247F                       1904 _serial_tx_byte:
      00247F E5 82            [12] 1905 	mov	a,dpl
      002481 78 7F            [12] 1906 	mov	r0,#_serial_tx_byte_data_byte_196608_128
      002483 F2               [24] 1907 	movx	@r0,a
                                   1908 ;	spi1_alt2/serial.c:225: fifo_put(&output_buffer, tx_byte);
      002484 78 7C            [12] 1909 	mov	r0,#_serial_tx_byte_b_196608_128
      002486 74 93            [12] 1910 	mov	a,#_output_buffer
      002488 F2               [24] 1911 	movx	@r0,a
      002489 08               [12] 1912 	inc	r0
      00248A 74 F2            [12] 1913 	mov	a,#(_output_buffer >> 8)
      00248C F2               [24] 1914 	movx	@r0,a
      00248D 08               [12] 1915 	inc	r0
      00248E E4               [12] 1916 	clr	a
      00248F F2               [24] 1917 	movx	@r0,a
                                   1918 ;	./fifo.h:59: if (b) {
      002490 74 93            [12] 1919 	mov	a,#_output_buffer
      002492 44 F2            [12] 1920 	orl	a,#(_output_buffer >> 8)
      002494 70 01            [24] 1921 	jnz	00130$
      002496 22               [24] 1922 	ret
      002497                       1923 00130$:
                                   1924 ;	./fifo.h:61: if (!fifo_full(b)) {
      002497 7E 93            [12] 1925 	mov	r6,#_output_buffer
      002499 7D F2            [12] 1926 	mov	r5,#(_output_buffer >> 8)
      00249B 7C 00            [12] 1927 	mov	r4,#0x00
                                   1928 ;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
      00249D 74 93            [12] 1929 	mov	a,#_output_buffer
      00249F 44 F2            [12] 1930 	orl	a,#(_output_buffer >> 8)
      0024A1 60 4F            [24] 1931 	jz	00110$
                                   1932 ;	./fifo.h:28: return (b ? (b->head - b->tail) : 0);
      0024A3 74 93            [12] 1933 	mov	a,#_output_buffer
      0024A5 44 F2            [12] 1934 	orl	a,#(_output_buffer >> 8)
      0024A7 60 1C            [24] 1935 	jz	00112$
      0024A9 90 F2 93         [24] 1936 	mov	dptr,#_output_buffer
      0024AC E0               [24] 1937 	movx	a,@dptr
      0024AD F5 21            [12] 1938 	mov	_serial_tx_byte_sloc0_1_0,a
      0024AF 90 F2 94         [24] 1939 	mov	dptr,#(_output_buffer + 0x0001)
      0024B2 75 F0 00         [24] 1940 	mov	b,#0x00
      0024B5 12 2E 55         [24] 1941 	lcall	__gptrget
      0024B8 FF               [12] 1942 	mov	r7,a
      0024B9 E5 21            [12] 1943 	mov	a,_serial_tx_byte_sloc0_1_0
      0024BB C3               [12] 1944 	clr	c
      0024BC 9F               [12] 1945 	subb	a,r7
      0024BD FF               [12] 1946 	mov	r7,a
      0024BE 8F 22            [24] 1947 	mov	_serial_tx_byte_sloc1_1_0,r7
      0024C0 75 23 00         [24] 1948 	mov	(_serial_tx_byte_sloc1_1_0 + 1),#0x00
      0024C3 80 05            [24] 1949 	sjmp	00113$
      0024C5                       1950 00112$:
      0024C5 E4               [12] 1951 	clr	a
      0024C6 F5 22            [12] 1952 	mov	_serial_tx_byte_sloc1_1_0,a
      0024C8 F5 23            [12] 1953 	mov	(_serial_tx_byte_sloc1_1_0 + 1),a
      0024CA                       1954 00113$:
      0024CA 78 81            [12] 1955 	mov	r0,#_serial_tx_byte___1310720015_524288_133
      0024CC E5 22            [12] 1956 	mov	a,_serial_tx_byte_sloc1_1_0
      0024CE F2               [24] 1957 	movx	@r0,a
                                   1958 ;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
      0024CF 74 05            [12] 1959 	mov	a,#0x05
      0024D1 2E               [12] 1960 	add	a,r6
      0024D2 FA               [12] 1961 	mov	r2,a
      0024D3 E4               [12] 1962 	clr	a
      0024D4 3D               [12] 1963 	addc	a,r5
      0024D5 FB               [12] 1964 	mov	r3,a
      0024D6 8C 07            [24] 1965 	mov	ar7,r4
      0024D8 8A 82            [24] 1966 	mov	dpl,r2
      0024DA 8B 83            [24] 1967 	mov	dph,r3
      0024DC 8F F0            [24] 1968 	mov	b,r7
      0024DE 12 2E 55         [24] 1969 	lcall	__gptrget
      0024E1 FA               [12] 1970 	mov	r2,a
      0024E2 78 81            [12] 1971 	mov	r0,#_serial_tx_byte___1310720015_524288_133
      0024E4 79 80            [12] 1972 	mov	r1,#_serial_tx_byte___1966080018_327680_130
      0024E6 E2               [24] 1973 	movx	a,@r0
      0024E7 B5 02 04         [24] 1974 	cjne	a,ar2,00133$
      0024EA 74 01            [12] 1975 	mov	a,#0x01
      0024EC 80 01            [24] 1976 	sjmp	00134$
      0024EE                       1977 00133$:
      0024EE E4               [12] 1978 	clr	a
      0024EF                       1979 00134$:
      0024EF F3               [24] 1980 	movx	@r1,a
      0024F0 80 05            [24] 1981 	sjmp	00111$
      0024F2                       1982 00110$:
      0024F2 78 80            [12] 1983 	mov	r0,#_serial_tx_byte___1966080018_327680_130
      0024F4 74 01            [12] 1984 	mov	a,#0x01
      0024F6 F2               [24] 1985 	movx	@r0,a
      0024F7                       1986 00111$:
                                   1987 ;	./fifo.h:61: if (!fifo_full(b)) {
      0024F7 78 80            [12] 1988 	mov	r0,#_serial_tx_byte___1966080018_327680_130
      0024F9 E2               [24] 1989 	movx	a,@r0
      0024FA 60 01            [24] 1990 	jz	00135$
      0024FC 22               [24] 1991 	ret
      0024FD                       1992 00135$:
                                   1993 ;	./fifo.h:62: b->buffer[b->head % b->buffer_len] = data_byte;
      0024FD 78 7C            [12] 1994 	mov	r0,#_serial_tx_byte_b_196608_128
      0024FF E2               [24] 1995 	movx	a,@r0
      002500 24 02            [12] 1996 	add	a,#0x02
      002502 FA               [12] 1997 	mov	r2,a
      002503 08               [12] 1998 	inc	r0
      002504 E2               [24] 1999 	movx	a,@r0
      002505 34 00            [12] 2000 	addc	a,#0x00
      002507 FB               [12] 2001 	mov	r3,a
      002508 08               [12] 2002 	inc	r0
      002509 E2               [24] 2003 	movx	a,@r0
      00250A FF               [12] 2004 	mov	r7,a
      00250B 8A 82            [24] 2005 	mov	dpl,r2
      00250D 8B 83            [24] 2006 	mov	dph,r3
      00250F 8F F0            [24] 2007 	mov	b,r7
      002511 12 2E 55         [24] 2008 	lcall	__gptrget
      002514 FA               [12] 2009 	mov	r2,a
      002515 A3               [24] 2010 	inc	dptr
      002516 12 2E 55         [24] 2011 	lcall	__gptrget
      002519 FB               [12] 2012 	mov	r3,a
      00251A A3               [24] 2013 	inc	dptr
      00251B 12 2E 55         [24] 2014 	lcall	__gptrget
      00251E FF               [12] 2015 	mov	r7,a
      00251F 78 7C            [12] 2016 	mov	r0,#_serial_tx_byte_b_196608_128
      002521 E2               [24] 2017 	movx	a,@r0
      002522 F5 82            [12] 2018 	mov	dpl,a
      002524 08               [12] 2019 	inc	r0
      002525 E2               [24] 2020 	movx	a,@r0
      002526 F5 83            [12] 2021 	mov	dph,a
      002528 08               [12] 2022 	inc	r0
      002529 E2               [24] 2023 	movx	a,@r0
      00252A F5 F0            [12] 2024 	mov	b,a
      00252C 12 2E 55         [24] 2025 	lcall	__gptrget
      00252F F5 22            [12] 2026 	mov	_serial_tx_byte_sloc1_1_0,a
      002531 78 7C            [12] 2027 	mov	r0,#_serial_tx_byte_b_196608_128
      002533 E2               [24] 2028 	movx	a,@r0
      002534 24 05            [12] 2029 	add	a,#0x05
      002536 FC               [12] 2030 	mov	r4,a
      002537 08               [12] 2031 	inc	r0
      002538 E2               [24] 2032 	movx	a,@r0
      002539 34 00            [12] 2033 	addc	a,#0x00
      00253B FD               [12] 2034 	mov	r5,a
      00253C 08               [12] 2035 	inc	r0
      00253D E2               [24] 2036 	movx	a,@r0
      00253E FE               [12] 2037 	mov	r6,a
      00253F 8C 82            [24] 2038 	mov	dpl,r4
      002541 8D 83            [24] 2039 	mov	dph,r5
      002543 8E F0            [24] 2040 	mov	b,r6
      002545 12 2E 55         [24] 2041 	lcall	__gptrget
      002548 FC               [12] 2042 	mov	r4,a
      002549 8C F0            [24] 2043 	mov	b,r4
      00254B E5 22            [12] 2044 	mov	a,_serial_tx_byte_sloc1_1_0
      00254D 84               [48] 2045 	div	ab
      00254E E5 F0            [12] 2046 	mov	a,b
      002550 2A               [12] 2047 	add	a,r2
      002551 FA               [12] 2048 	mov	r2,a
      002552 E4               [12] 2049 	clr	a
      002553 3B               [12] 2050 	addc	a,r3
      002554 FB               [12] 2051 	mov	r3,a
      002555 8A 82            [24] 2052 	mov	dpl,r2
      002557 8B 83            [24] 2053 	mov	dph,r3
      002559 8F F0            [24] 2054 	mov	b,r7
      00255B 78 7F            [12] 2055 	mov	r0,#_serial_tx_byte_data_byte_196608_128
      00255D E2               [24] 2056 	movx	a,@r0
      00255E 12 2D 8A         [24] 2057 	lcall	__gptrput
                                   2058 ;	./fifo.h:63: b->head++;
      002561 78 7C            [12] 2059 	mov	r0,#_serial_tx_byte_b_196608_128
      002563 E2               [24] 2060 	movx	a,@r0
      002564 F5 82            [12] 2061 	mov	dpl,a
      002566 08               [12] 2062 	inc	r0
      002567 E2               [24] 2063 	movx	a,@r0
      002568 F5 83            [12] 2064 	mov	dph,a
      00256A 08               [12] 2065 	inc	r0
      00256B E2               [24] 2066 	movx	a,@r0
      00256C F5 F0            [12] 2067 	mov	b,a
      00256E 12 2E 55         [24] 2068 	lcall	__gptrget
      002571 FF               [12] 2069 	mov	r7,a
      002572 0F               [12] 2070 	inc	r7
      002573 78 7C            [12] 2071 	mov	r0,#_serial_tx_byte_b_196608_128
      002575 E2               [24] 2072 	movx	a,@r0
      002576 F5 82            [12] 2073 	mov	dpl,a
      002578 08               [12] 2074 	inc	r0
      002579 E2               [24] 2075 	movx	a,@r0
      00257A F5 83            [12] 2076 	mov	dph,a
      00257C 08               [12] 2077 	inc	r0
      00257D E2               [24] 2078 	movx	a,@r0
      00257E F5 F0            [12] 2079 	mov	b,a
      002580 EF               [12] 2080 	mov	a,r7
                                   2081 ;	spi1_alt2/serial.c:225: fifo_put(&output_buffer, tx_byte);
                                   2082 ;	spi1_alt2/serial.c:226: }
      002581 02 2D 8A         [24] 2083 	ljmp	__gptrput
                                   2084 ;------------------------------------------------------------
                                   2085 ;Allocation info for local variables in function 'serial_tx_word'
                                   2086 ;------------------------------------------------------------
                                   2087 ;sloc0                     Allocated with name '_serial_tx_word_sloc0_1_0'
                                   2088 ;sloc1                     Allocated with name '_serial_tx_word_sloc1_1_0'
                                   2089 ;sloc2                     Allocated with name '_serial_tx_word_sloc2_1_0'
                                   2090 ;------------------------------------------------------------
                                   2091 ;	spi1_alt2/serial.c:228: void serial_tx_word(uint16_t tx_word)
                                   2092 ;	-----------------------------------------
                                   2093 ;	 function serial_tx_word
                                   2094 ;	-----------------------------------------
      002584                       2095 _serial_tx_word:
      002584 AE 82            [24] 2096 	mov	r6,dpl
      002586 AF 83            [24] 2097 	mov	r7,dph
                                   2098 ;	spi1_alt2/serial.c:230: fifo_put(&output_buffer, tx_word >> 8);
      002588 8F 05            [24] 2099 	mov	ar5,r7
      00258A 78 82            [12] 2100 	mov	r0,#_serial_tx_word_b_196608_141
      00258C 74 93            [12] 2101 	mov	a,#_output_buffer
      00258E F2               [24] 2102 	movx	@r0,a
      00258F 08               [12] 2103 	inc	r0
      002590 74 F2            [12] 2104 	mov	a,#(_output_buffer >> 8)
      002592 F2               [24] 2105 	movx	@r0,a
      002593 08               [12] 2106 	inc	r0
      002594 E4               [12] 2107 	clr	a
      002595 F2               [24] 2108 	movx	@r0,a
                                   2109 ;	./fifo.h:59: if (b) {
      002596 74 93            [12] 2110 	mov	a,#_output_buffer
      002598 44 F2            [12] 2111 	orl	a,#(_output_buffer >> 8)
      00259A 70 03            [24] 2112 	jnz	00157$
      00259C 02 26 A9         [24] 2113 	ljmp	00106$
      00259F                       2114 00157$:
                                   2115 ;	./fifo.h:61: if (!fifo_full(b)) {
      00259F 7C 93            [12] 2116 	mov	r4,#_output_buffer
      0025A1 7B F2            [12] 2117 	mov	r3,#(_output_buffer >> 8)
      0025A3 7A 00            [12] 2118 	mov	r2,#0x00
                                   2119 ;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
      0025A5 74 93            [12] 2120 	mov	a,#_output_buffer
      0025A7 44 F2            [12] 2121 	orl	a,#(_output_buffer >> 8)
      0025A9 60 5D            [24] 2122 	jz	00117$
                                   2123 ;	./fifo.h:28: return (b ? (b->head - b->tail) : 0);
      0025AB 74 93            [12] 2124 	mov	a,#_output_buffer
      0025AD 44 F2            [12] 2125 	orl	a,#(_output_buffer >> 8)
      0025AF 60 22            [24] 2126 	jz	00119$
      0025B1 C0 06            [24] 2127 	push	ar6
      0025B3 C0 07            [24] 2128 	push	ar7
      0025B5 90 F2 93         [24] 2129 	mov	dptr,#_output_buffer
      0025B8 E0               [24] 2130 	movx	a,@dptr
      0025B9 FF               [12] 2131 	mov	r7,a
      0025BA 90 F2 94         [24] 2132 	mov	dptr,#(_output_buffer + 0x0001)
      0025BD 75 F0 00         [24] 2133 	mov	b,#0x00
      0025C0 12 2E 55         [24] 2134 	lcall	__gptrget
      0025C3 FE               [12] 2135 	mov	r6,a
      0025C4 EF               [12] 2136 	mov	a,r7
      0025C5 C3               [12] 2137 	clr	c
      0025C6 9E               [12] 2138 	subb	a,r6
      0025C7 FF               [12] 2139 	mov	r7,a
      0025C8 8F 21            [24] 2140 	mov	_serial_tx_word_sloc0_1_0,r7
      0025CA 75 22 00         [24] 2141 	mov	(_serial_tx_word_sloc0_1_0 + 1),#0x00
      0025CD D0 07            [24] 2142 	pop	ar7
      0025CF D0 06            [24] 2143 	pop	ar6
      0025D1 80 05            [24] 2144 	sjmp	00120$
      0025D3                       2145 00119$:
      0025D3 E4               [12] 2146 	clr	a
      0025D4 F5 21            [12] 2147 	mov	_serial_tx_word_sloc0_1_0,a
      0025D6 F5 22            [12] 2148 	mov	(_serial_tx_word_sloc0_1_0 + 1),a
      0025D8                       2149 00120$:
      0025D8 C0 06            [24] 2150 	push	ar6
      0025DA C0 07            [24] 2151 	push	ar7
      0025DC 78 86            [12] 2152 	mov	r0,#_serial_tx_word___1310720015_524288_146
      0025DE E5 21            [12] 2153 	mov	a,_serial_tx_word_sloc0_1_0
      0025E0 F2               [24] 2154 	movx	@r0,a
                                   2155 ;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
      0025E1 74 05            [12] 2156 	mov	a,#0x05
      0025E3 2C               [12] 2157 	add	a,r4
      0025E4 FC               [12] 2158 	mov	r4,a
      0025E5 E4               [12] 2159 	clr	a
      0025E6 3B               [12] 2160 	addc	a,r3
      0025E7 FE               [12] 2161 	mov	r6,a
      0025E8 8A 07            [24] 2162 	mov	ar7,r2
      0025EA 8C 82            [24] 2163 	mov	dpl,r4
      0025EC 8E 83            [24] 2164 	mov	dph,r6
      0025EE 8F F0            [24] 2165 	mov	b,r7
      0025F0 12 2E 55         [24] 2166 	lcall	__gptrget
      0025F3 FC               [12] 2167 	mov	r4,a
      0025F4 78 86            [12] 2168 	mov	r0,#_serial_tx_word___1310720015_524288_146
      0025F6 79 85            [12] 2169 	mov	r1,#_serial_tx_word___1966080018_327680_143
      0025F8 E2               [24] 2170 	movx	a,@r0
      0025F9 B5 04 04         [24] 2171 	cjne	a,ar4,00160$
      0025FC 74 01            [12] 2172 	mov	a,#0x01
      0025FE 80 01            [24] 2173 	sjmp	00161$
      002600                       2174 00160$:
      002600 E4               [12] 2175 	clr	a
      002601                       2176 00161$:
      002601 F3               [24] 2177 	movx	@r1,a
      002602 D0 07            [24] 2178 	pop	ar7
      002604 D0 06            [24] 2179 	pop	ar6
      002606 80 05            [24] 2180 	sjmp	00118$
      002608                       2181 00117$:
      002608 78 85            [12] 2182 	mov	r0,#_serial_tx_word___1966080018_327680_143
      00260A 74 01            [12] 2183 	mov	a,#0x01
      00260C F2               [24] 2184 	movx	@r0,a
      00260D                       2185 00118$:
                                   2186 ;	./fifo.h:61: if (!fifo_full(b)) {
      00260D 78 85            [12] 2187 	mov	r0,#_serial_tx_word___1966080018_327680_143
      00260F E2               [24] 2188 	movx	a,@r0
      002610 60 03            [24] 2189 	jz	00162$
      002612 02 26 A9         [24] 2190 	ljmp	00106$
      002615                       2191 00162$:
                                   2192 ;	./fifo.h:62: b->buffer[b->head % b->buffer_len] = data_byte;
      002615 C0 06            [24] 2193 	push	ar6
      002617 C0 07            [24] 2194 	push	ar7
      002619 78 82            [12] 2195 	mov	r0,#_serial_tx_word_b_196608_141
      00261B E2               [24] 2196 	movx	a,@r0
      00261C 24 02            [12] 2197 	add	a,#0x02
      00261E FA               [12] 2198 	mov	r2,a
      00261F 08               [12] 2199 	inc	r0
      002620 E2               [24] 2200 	movx	a,@r0
      002621 34 00            [12] 2201 	addc	a,#0x00
      002623 FB               [12] 2202 	mov	r3,a
      002624 08               [12] 2203 	inc	r0
      002625 E2               [24] 2204 	movx	a,@r0
      002626 FC               [12] 2205 	mov	r4,a
      002627 8A 82            [24] 2206 	mov	dpl,r2
      002629 8B 83            [24] 2207 	mov	dph,r3
      00262B 8C F0            [24] 2208 	mov	b,r4
      00262D 12 2E 55         [24] 2209 	lcall	__gptrget
      002630 F5 23            [12] 2210 	mov	_serial_tx_word_sloc1_1_0,a
      002632 A3               [24] 2211 	inc	dptr
      002633 12 2E 55         [24] 2212 	lcall	__gptrget
      002636 F5 24            [12] 2213 	mov	(_serial_tx_word_sloc1_1_0 + 1),a
      002638 A3               [24] 2214 	inc	dptr
      002639 12 2E 55         [24] 2215 	lcall	__gptrget
      00263C F5 25            [12] 2216 	mov	(_serial_tx_word_sloc1_1_0 + 2),a
      00263E 78 82            [12] 2217 	mov	r0,#_serial_tx_word_b_196608_141
      002640 E2               [24] 2218 	movx	a,@r0
      002641 F5 82            [12] 2219 	mov	dpl,a
      002643 08               [12] 2220 	inc	r0
      002644 E2               [24] 2221 	movx	a,@r0
      002645 F5 83            [12] 2222 	mov	dph,a
      002647 08               [12] 2223 	inc	r0
      002648 E2               [24] 2224 	movx	a,@r0
      002649 F5 F0            [12] 2225 	mov	b,a
      00264B 12 2E 55         [24] 2226 	lcall	__gptrget
      00264E F5 21            [12] 2227 	mov	_serial_tx_word_sloc0_1_0,a
      002650 78 82            [12] 2228 	mov	r0,#_serial_tx_word_b_196608_141
      002652 E2               [24] 2229 	movx	a,@r0
      002653 24 05            [12] 2230 	add	a,#0x05
      002655 FC               [12] 2231 	mov	r4,a
      002656 08               [12] 2232 	inc	r0
      002657 E2               [24] 2233 	movx	a,@r0
      002658 34 00            [12] 2234 	addc	a,#0x00
      00265A FE               [12] 2235 	mov	r6,a
      00265B 08               [12] 2236 	inc	r0
      00265C E2               [24] 2237 	movx	a,@r0
      00265D FF               [12] 2238 	mov	r7,a
      00265E 8C 82            [24] 2239 	mov	dpl,r4
      002660 8E 83            [24] 2240 	mov	dph,r6
      002662 8F F0            [24] 2241 	mov	b,r7
      002664 12 2E 55         [24] 2242 	lcall	__gptrget
      002667 FC               [12] 2243 	mov	r4,a
      002668 8C F0            [24] 2244 	mov	b,r4
      00266A E5 21            [12] 2245 	mov	a,_serial_tx_word_sloc0_1_0
      00266C 84               [48] 2246 	div	ab
      00266D E5 F0            [12] 2247 	mov	a,b
      00266F 25 23            [12] 2248 	add	a,_serial_tx_word_sloc1_1_0
      002671 FC               [12] 2249 	mov	r4,a
      002672 E4               [12] 2250 	clr	a
      002673 35 24            [12] 2251 	addc	a,(_serial_tx_word_sloc1_1_0 + 1)
      002675 FF               [12] 2252 	mov	r7,a
      002676 AE 25            [24] 2253 	mov	r6,(_serial_tx_word_sloc1_1_0 + 2)
      002678 8C 82            [24] 2254 	mov	dpl,r4
      00267A 8F 83            [24] 2255 	mov	dph,r7
      00267C 8E F0            [24] 2256 	mov	b,r6
      00267E ED               [12] 2257 	mov	a,r5
      00267F 12 2D 8A         [24] 2258 	lcall	__gptrput
                                   2259 ;	./fifo.h:63: b->head++;
      002682 78 82            [12] 2260 	mov	r0,#_serial_tx_word_b_196608_141
      002684 E2               [24] 2261 	movx	a,@r0
      002685 F5 82            [12] 2262 	mov	dpl,a
      002687 08               [12] 2263 	inc	r0
      002688 E2               [24] 2264 	movx	a,@r0
      002689 F5 83            [12] 2265 	mov	dph,a
      00268B 08               [12] 2266 	inc	r0
      00268C E2               [24] 2267 	movx	a,@r0
      00268D F5 F0            [12] 2268 	mov	b,a
      00268F 12 2E 55         [24] 2269 	lcall	__gptrget
      002692 FF               [12] 2270 	mov	r7,a
      002693 0F               [12] 2271 	inc	r7
      002694 78 82            [12] 2272 	mov	r0,#_serial_tx_word_b_196608_141
      002696 E2               [24] 2273 	movx	a,@r0
      002697 F5 82            [12] 2274 	mov	dpl,a
      002699 08               [12] 2275 	inc	r0
      00269A E2               [24] 2276 	movx	a,@r0
      00269B F5 83            [12] 2277 	mov	dph,a
      00269D 08               [12] 2278 	inc	r0
      00269E E2               [24] 2279 	movx	a,@r0
      00269F F5 F0            [12] 2280 	mov	b,a
      0026A1 EF               [12] 2281 	mov	a,r7
      0026A2 12 2D 8A         [24] 2282 	lcall	__gptrput
                                   2283 ;	spi1_alt2/serial.c:231: fifo_put(&output_buffer, tx_word & 0xff);
      0026A5 D0 07            [24] 2284 	pop	ar7
      0026A7 D0 06            [24] 2285 	pop	ar6
                                   2286 ;	./fifo.h:64: status = true;
      0026A9                       2287 00106$:
                                   2288 ;	spi1_alt2/serial.c:231: fifo_put(&output_buffer, tx_word & 0xff);
      0026A9 8E 05            [24] 2289 	mov	ar5,r6
      0026AB 78 87            [12] 2290 	mov	r0,#_serial_tx_word_b_196608_152
      0026AD 74 93            [12] 2291 	mov	a,#_output_buffer
      0026AF F2               [24] 2292 	movx	@r0,a
      0026B0 08               [12] 2293 	inc	r0
      0026B1 74 F2            [12] 2294 	mov	a,#(_output_buffer >> 8)
      0026B3 F2               [24] 2295 	movx	@r0,a
      0026B4 08               [12] 2296 	inc	r0
      0026B5 E4               [12] 2297 	clr	a
      0026B6 F2               [24] 2298 	movx	@r0,a
                                   2299 ;	./fifo.h:59: if (b) {
      0026B7 74 93            [12] 2300 	mov	a,#_output_buffer
      0026B9 44 F2            [12] 2301 	orl	a,#(_output_buffer >> 8)
      0026BB 70 01            [24] 2302 	jnz	00163$
      0026BD 22               [24] 2303 	ret
      0026BE                       2304 00163$:
                                   2305 ;	./fifo.h:61: if (!fifo_full(b)) {
      0026BE 7A 93            [12] 2306 	mov	r2,#_output_buffer
      0026C0 7E F2            [12] 2307 	mov	r6,#(_output_buffer >> 8)
      0026C2 7F 00            [12] 2308 	mov	r7,#0x00
                                   2309 ;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
      0026C4 74 93            [12] 2310 	mov	a,#_output_buffer
      0026C6 44 F2            [12] 2311 	orl	a,#(_output_buffer >> 8)
      0026C8 60 40            [24] 2312 	jz	00121$
                                   2313 ;	./fifo.h:28: return (b ? (b->head - b->tail) : 0);
      0026CA 74 93            [12] 2314 	mov	a,#_output_buffer
      0026CC 44 F2            [12] 2315 	orl	a,#(_output_buffer >> 8)
      0026CE 60 17            [24] 2316 	jz	00123$
      0026D0 90 F2 93         [24] 2317 	mov	dptr,#_output_buffer
      0026D3 E0               [24] 2318 	movx	a,@dptr
      0026D4 FC               [12] 2319 	mov	r4,a
      0026D5 90 F2 94         [24] 2320 	mov	dptr,#(_output_buffer + 0x0001)
      0026D8 75 F0 00         [24] 2321 	mov	b,#0x00
      0026DB 12 2E 55         [24] 2322 	lcall	__gptrget
      0026DE FB               [12] 2323 	mov	r3,a
      0026DF EC               [12] 2324 	mov	a,r4
      0026E0 C3               [12] 2325 	clr	c
      0026E1 9B               [12] 2326 	subb	a,r3
      0026E2 FB               [12] 2327 	mov	r3,a
      0026E3 7C 00            [12] 2328 	mov	r4,#0x00
      0026E5 80 04            [24] 2329 	sjmp	00124$
      0026E7                       2330 00123$:
      0026E7 7B 00            [12] 2331 	mov	r3,#0x00
      0026E9 7C 00            [12] 2332 	mov	r4,#0x00
      0026EB                       2333 00124$:
                                   2334 ;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
      0026EB 74 05            [12] 2335 	mov	a,#0x05
      0026ED 2A               [12] 2336 	add	a,r2
      0026EE FA               [12] 2337 	mov	r2,a
      0026EF E4               [12] 2338 	clr	a
      0026F0 3E               [12] 2339 	addc	a,r6
      0026F1 FE               [12] 2340 	mov	r6,a
      0026F2 8A 82            [24] 2341 	mov	dpl,r2
      0026F4 8E 83            [24] 2342 	mov	dph,r6
      0026F6 8F F0            [24] 2343 	mov	b,r7
      0026F8 12 2E 55         [24] 2344 	lcall	__gptrget
      0026FB FA               [12] 2345 	mov	r2,a
      0026FC 78 8A            [12] 2346 	mov	r0,#_serial_tx_word___1966080018_327680_154
      0026FE EB               [12] 2347 	mov	a,r3
      0026FF B5 02 04         [24] 2348 	cjne	a,ar2,00166$
      002702 74 01            [12] 2349 	mov	a,#0x01
      002704 80 01            [24] 2350 	sjmp	00167$
      002706                       2351 00166$:
      002706 E4               [12] 2352 	clr	a
      002707                       2353 00167$:
      002707 F2               [24] 2354 	movx	@r0,a
      002708 80 05            [24] 2355 	sjmp	00122$
      00270A                       2356 00121$:
      00270A 78 8A            [12] 2357 	mov	r0,#_serial_tx_word___1966080018_327680_154
      00270C 74 01            [12] 2358 	mov	a,#0x01
      00270E F2               [24] 2359 	movx	@r0,a
      00270F                       2360 00122$:
                                   2361 ;	./fifo.h:61: if (!fifo_full(b)) {
      00270F 78 8A            [12] 2362 	mov	r0,#_serial_tx_word___1966080018_327680_154
      002711 E2               [24] 2363 	movx	a,@r0
      002712 60 01            [24] 2364 	jz	00168$
      002714 22               [24] 2365 	ret
      002715                       2366 00168$:
                                   2367 ;	./fifo.h:62: b->buffer[b->head % b->buffer_len] = data_byte;
      002715 78 87            [12] 2368 	mov	r0,#_serial_tx_word_b_196608_152
      002717 E2               [24] 2369 	movx	a,@r0
      002718 24 02            [12] 2370 	add	a,#0x02
      00271A FC               [12] 2371 	mov	r4,a
      00271B 08               [12] 2372 	inc	r0
      00271C E2               [24] 2373 	movx	a,@r0
      00271D 34 00            [12] 2374 	addc	a,#0x00
      00271F FE               [12] 2375 	mov	r6,a
      002720 08               [12] 2376 	inc	r0
      002721 E2               [24] 2377 	movx	a,@r0
      002722 FF               [12] 2378 	mov	r7,a
      002723 8C 82            [24] 2379 	mov	dpl,r4
      002725 8E 83            [24] 2380 	mov	dph,r6
      002727 8F F0            [24] 2381 	mov	b,r7
      002729 12 2E 55         [24] 2382 	lcall	__gptrget
      00272C F5 26            [12] 2383 	mov	_serial_tx_word_sloc2_1_0,a
      00272E A3               [24] 2384 	inc	dptr
      00272F 12 2E 55         [24] 2385 	lcall	__gptrget
      002732 F5 27            [12] 2386 	mov	(_serial_tx_word_sloc2_1_0 + 1),a
      002734 A3               [24] 2387 	inc	dptr
      002735 12 2E 55         [24] 2388 	lcall	__gptrget
      002738 F5 28            [12] 2389 	mov	(_serial_tx_word_sloc2_1_0 + 2),a
      00273A 78 87            [12] 2390 	mov	r0,#_serial_tx_word_b_196608_152
      00273C E2               [24] 2391 	movx	a,@r0
      00273D F5 82            [12] 2392 	mov	dpl,a
      00273F 08               [12] 2393 	inc	r0
      002740 E2               [24] 2394 	movx	a,@r0
      002741 F5 83            [12] 2395 	mov	dph,a
      002743 08               [12] 2396 	inc	r0
      002744 E2               [24] 2397 	movx	a,@r0
      002745 F5 F0            [12] 2398 	mov	b,a
      002747 12 2E 55         [24] 2399 	lcall	__gptrget
      00274A F5 23            [12] 2400 	mov	_serial_tx_word_sloc1_1_0,a
      00274C 78 87            [12] 2401 	mov	r0,#_serial_tx_word_b_196608_152
      00274E E2               [24] 2402 	movx	a,@r0
      00274F 24 05            [12] 2403 	add	a,#0x05
      002751 FA               [12] 2404 	mov	r2,a
      002752 08               [12] 2405 	inc	r0
      002753 E2               [24] 2406 	movx	a,@r0
      002754 34 00            [12] 2407 	addc	a,#0x00
      002756 FB               [12] 2408 	mov	r3,a
      002757 08               [12] 2409 	inc	r0
      002758 E2               [24] 2410 	movx	a,@r0
      002759 FF               [12] 2411 	mov	r7,a
      00275A 8A 82            [24] 2412 	mov	dpl,r2
      00275C 8B 83            [24] 2413 	mov	dph,r3
      00275E 8F F0            [24] 2414 	mov	b,r7
      002760 12 2E 55         [24] 2415 	lcall	__gptrget
      002763 FA               [12] 2416 	mov	r2,a
      002764 8A F0            [24] 2417 	mov	b,r2
      002766 E5 23            [12] 2418 	mov	a,_serial_tx_word_sloc1_1_0
      002768 84               [48] 2419 	div	ab
      002769 E5 F0            [12] 2420 	mov	a,b
      00276B 25 26            [12] 2421 	add	a,_serial_tx_word_sloc2_1_0
      00276D FA               [12] 2422 	mov	r2,a
      00276E E4               [12] 2423 	clr	a
      00276F 35 27            [12] 2424 	addc	a,(_serial_tx_word_sloc2_1_0 + 1)
      002771 FF               [12] 2425 	mov	r7,a
      002772 AE 28            [24] 2426 	mov	r6,(_serial_tx_word_sloc2_1_0 + 2)
      002774 8A 82            [24] 2427 	mov	dpl,r2
      002776 8F 83            [24] 2428 	mov	dph,r7
      002778 8E F0            [24] 2429 	mov	b,r6
      00277A ED               [12] 2430 	mov	a,r5
      00277B 12 2D 8A         [24] 2431 	lcall	__gptrput
                                   2432 ;	./fifo.h:63: b->head++;
      00277E 78 87            [12] 2433 	mov	r0,#_serial_tx_word_b_196608_152
      002780 E2               [24] 2434 	movx	a,@r0
      002781 F5 82            [12] 2435 	mov	dpl,a
      002783 08               [12] 2436 	inc	r0
      002784 E2               [24] 2437 	movx	a,@r0
      002785 F5 83            [12] 2438 	mov	dph,a
      002787 08               [12] 2439 	inc	r0
      002788 E2               [24] 2440 	movx	a,@r0
      002789 F5 F0            [12] 2441 	mov	b,a
      00278B 12 2E 55         [24] 2442 	lcall	__gptrget
      00278E FF               [12] 2443 	mov	r7,a
      00278F 0F               [12] 2444 	inc	r7
      002790 78 87            [12] 2445 	mov	r0,#_serial_tx_word_b_196608_152
      002792 E2               [24] 2446 	movx	a,@r0
      002793 F5 82            [12] 2447 	mov	dpl,a
      002795 08               [12] 2448 	inc	r0
      002796 E2               [24] 2449 	movx	a,@r0
      002797 F5 83            [12] 2450 	mov	dph,a
      002799 08               [12] 2451 	inc	r0
      00279A E2               [24] 2452 	movx	a,@r0
      00279B F5 F0            [12] 2453 	mov	b,a
      00279D EF               [12] 2454 	mov	a,r7
                                   2455 ;	spi1_alt2/serial.c:231: fifo_put(&output_buffer, tx_word & 0xff);
                                   2456 ;	spi1_alt2/serial.c:232: }
      00279E 02 2D 8A         [24] 2457 	ljmp	__gptrput
                                   2458 ;------------------------------------------------------------
                                   2459 ;Allocation info for local variables in function 'serial_tx_long'
                                   2460 ;------------------------------------------------------------
                                   2461 ;sloc0                     Allocated with name '_serial_tx_long_sloc0_1_0'
                                   2462 ;sloc1                     Allocated with name '_serial_tx_long_sloc1_1_0'
                                   2463 ;------------------------------------------------------------
                                   2464 ;	spi1_alt2/serial.c:234: void serial_tx_long(uint32_t tx_long)
                                   2465 ;	-----------------------------------------
                                   2466 ;	 function serial_tx_long
                                   2467 ;	-----------------------------------------
      0027A1                       2468 _serial_tx_long:
      0027A1 AF 82            [24] 2469 	mov	r7,dpl
      0027A3 AE 83            [24] 2470 	mov	r6,dph
      0027A5 AD F0            [24] 2471 	mov	r5,b
      0027A7 FC               [12] 2472 	mov	r4,a
      0027A8 78 8B            [12] 2473 	mov	r0,#_serial_tx_long_tx_long_65536_162
      0027AA EF               [12] 2474 	mov	a,r7
      0027AB F2               [24] 2475 	movx	@r0,a
      0027AC 08               [12] 2476 	inc	r0
      0027AD EE               [12] 2477 	mov	a,r6
      0027AE F2               [24] 2478 	movx	@r0,a
      0027AF 08               [12] 2479 	inc	r0
      0027B0 ED               [12] 2480 	mov	a,r5
      0027B1 F2               [24] 2481 	movx	@r0,a
      0027B2 08               [12] 2482 	inc	r0
      0027B3 EC               [12] 2483 	mov	a,r4
      0027B4 F2               [24] 2484 	movx	@r0,a
                                   2485 ;	spi1_alt2/serial.c:236: fifo_put(&output_buffer, tx_long >> 24);
      0027B5 78 8B            [12] 2486 	mov	r0,#_serial_tx_long_tx_long_65536_162
      0027B7 79 92            [12] 2487 	mov	r1,#_serial_tx_long_data_byte_196608_165
      0027B9 08               [12] 2488 	inc	r0
      0027BA 08               [12] 2489 	inc	r0
      0027BB 08               [12] 2490 	inc	r0
      0027BC E2               [24] 2491 	movx	a,@r0
      0027BD F3               [24] 2492 	movx	@r1,a
      0027BE 78 8F            [12] 2493 	mov	r0,#_serial_tx_long_b_196608_165
      0027C0 74 93            [12] 2494 	mov	a,#_output_buffer
      0027C2 F2               [24] 2495 	movx	@r0,a
      0027C3 08               [12] 2496 	inc	r0
      0027C4 74 F2            [12] 2497 	mov	a,#(_output_buffer >> 8)
      0027C6 F2               [24] 2498 	movx	@r0,a
      0027C7 08               [12] 2499 	inc	r0
      0027C8 E4               [12] 2500 	clr	a
      0027C9 F2               [24] 2501 	movx	@r0,a
                                   2502 ;	./fifo.h:59: if (b) {
      0027CA 74 93            [12] 2503 	mov	a,#_output_buffer
      0027CC 44 F2            [12] 2504 	orl	a,#(_output_buffer >> 8)
      0027CE 70 03            [24] 2505 	jnz	00211$
      0027D0 02 28 B4         [24] 2506 	ljmp	00106$
      0027D3                       2507 00211$:
                                   2508 ;	./fifo.h:61: if (!fifo_full(b)) {
      0027D3 7A 93            [12] 2509 	mov	r2,#_output_buffer
      0027D5 7B F2            [12] 2510 	mov	r3,#(_output_buffer >> 8)
      0027D7 7F 00            [12] 2511 	mov	r7,#0x00
                                   2512 ;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
      0027D9 74 93            [12] 2513 	mov	a,#_output_buffer
      0027DB 44 F2            [12] 2514 	orl	a,#(_output_buffer >> 8)
      0027DD 60 40            [24] 2515 	jz	00131$
                                   2516 ;	./fifo.h:28: return (b ? (b->head - b->tail) : 0);
      0027DF 74 93            [12] 2517 	mov	a,#_output_buffer
      0027E1 44 F2            [12] 2518 	orl	a,#(_output_buffer >> 8)
      0027E3 60 17            [24] 2519 	jz	00133$
      0027E5 90 F2 93         [24] 2520 	mov	dptr,#_output_buffer
      0027E8 E0               [24] 2521 	movx	a,@dptr
      0027E9 FE               [12] 2522 	mov	r6,a
      0027EA 90 F2 94         [24] 2523 	mov	dptr,#(_output_buffer + 0x0001)
      0027ED 75 F0 00         [24] 2524 	mov	b,#0x00
      0027F0 12 2E 55         [24] 2525 	lcall	__gptrget
      0027F3 FD               [12] 2526 	mov	r5,a
      0027F4 EE               [12] 2527 	mov	a,r6
      0027F5 C3               [12] 2528 	clr	c
      0027F6 9D               [12] 2529 	subb	a,r5
      0027F7 FD               [12] 2530 	mov	r5,a
      0027F8 7E 00            [12] 2531 	mov	r6,#0x00
      0027FA 80 04            [24] 2532 	sjmp	00134$
      0027FC                       2533 00133$:
      0027FC 7D 00            [12] 2534 	mov	r5,#0x00
      0027FE 7E 00            [12] 2535 	mov	r6,#0x00
      002800                       2536 00134$:
                                   2537 ;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
      002800 74 05            [12] 2538 	mov	a,#0x05
      002802 2A               [12] 2539 	add	a,r2
      002803 FA               [12] 2540 	mov	r2,a
      002804 E4               [12] 2541 	clr	a
      002805 3B               [12] 2542 	addc	a,r3
      002806 FB               [12] 2543 	mov	r3,a
      002807 8A 82            [24] 2544 	mov	dpl,r2
      002809 8B 83            [24] 2545 	mov	dph,r3
      00280B 8F F0            [24] 2546 	mov	b,r7
      00280D 12 2E 55         [24] 2547 	lcall	__gptrget
      002810 FA               [12] 2548 	mov	r2,a
      002811 78 93            [12] 2549 	mov	r0,#_serial_tx_long___1966080018_327680_167
      002813 ED               [12] 2550 	mov	a,r5
      002814 B5 02 04         [24] 2551 	cjne	a,ar2,00214$
      002817 74 01            [12] 2552 	mov	a,#0x01
      002819 80 01            [24] 2553 	sjmp	00215$
      00281B                       2554 00214$:
      00281B E4               [12] 2555 	clr	a
      00281C                       2556 00215$:
      00281C F2               [24] 2557 	movx	@r0,a
      00281D 80 05            [24] 2558 	sjmp	00132$
      00281F                       2559 00131$:
      00281F 78 93            [12] 2560 	mov	r0,#_serial_tx_long___1966080018_327680_167
      002821 74 01            [12] 2561 	mov	a,#0x01
      002823 F2               [24] 2562 	movx	@r0,a
      002824                       2563 00132$:
                                   2564 ;	./fifo.h:61: if (!fifo_full(b)) {
      002824 78 93            [12] 2565 	mov	r0,#_serial_tx_long___1966080018_327680_167
      002826 E2               [24] 2566 	movx	a,@r0
      002827 60 03            [24] 2567 	jz	00216$
      002829 02 28 B4         [24] 2568 	ljmp	00106$
      00282C                       2569 00216$:
                                   2570 ;	./fifo.h:62: b->buffer[b->head % b->buffer_len] = data_byte;
      00282C 78 8F            [12] 2571 	mov	r0,#_serial_tx_long_b_196608_165
      00282E E2               [24] 2572 	movx	a,@r0
      00282F 24 02            [12] 2573 	add	a,#0x02
      002831 FD               [12] 2574 	mov	r5,a
      002832 08               [12] 2575 	inc	r0
      002833 E2               [24] 2576 	movx	a,@r0
      002834 34 00            [12] 2577 	addc	a,#0x00
      002836 FE               [12] 2578 	mov	r6,a
      002837 08               [12] 2579 	inc	r0
      002838 E2               [24] 2580 	movx	a,@r0
      002839 FF               [12] 2581 	mov	r7,a
      00283A 8D 82            [24] 2582 	mov	dpl,r5
      00283C 8E 83            [24] 2583 	mov	dph,r6
      00283E 8F F0            [24] 2584 	mov	b,r7
      002840 12 2E 55         [24] 2585 	lcall	__gptrget
      002843 FD               [12] 2586 	mov	r5,a
      002844 A3               [24] 2587 	inc	dptr
      002845 12 2E 55         [24] 2588 	lcall	__gptrget
      002848 FE               [12] 2589 	mov	r6,a
      002849 A3               [24] 2590 	inc	dptr
      00284A 12 2E 55         [24] 2591 	lcall	__gptrget
      00284D FF               [12] 2592 	mov	r7,a
      00284E 78 8F            [12] 2593 	mov	r0,#_serial_tx_long_b_196608_165
      002850 E2               [24] 2594 	movx	a,@r0
      002851 F5 82            [12] 2595 	mov	dpl,a
      002853 08               [12] 2596 	inc	r0
      002854 E2               [24] 2597 	movx	a,@r0
      002855 F5 83            [12] 2598 	mov	dph,a
      002857 08               [12] 2599 	inc	r0
      002858 E2               [24] 2600 	movx	a,@r0
      002859 F5 F0            [12] 2601 	mov	b,a
      00285B 12 2E 55         [24] 2602 	lcall	__gptrget
      00285E F5 21            [12] 2603 	mov	_serial_tx_long_sloc0_1_0,a
      002860 78 8F            [12] 2604 	mov	r0,#_serial_tx_long_b_196608_165
      002862 E2               [24] 2605 	movx	a,@r0
      002863 24 05            [12] 2606 	add	a,#0x05
      002865 FA               [12] 2607 	mov	r2,a
      002866 08               [12] 2608 	inc	r0
      002867 E2               [24] 2609 	movx	a,@r0
      002868 34 00            [12] 2610 	addc	a,#0x00
      00286A FB               [12] 2611 	mov	r3,a
      00286B 08               [12] 2612 	inc	r0
      00286C E2               [24] 2613 	movx	a,@r0
      00286D FC               [12] 2614 	mov	r4,a
      00286E 8A 82            [24] 2615 	mov	dpl,r2
      002870 8B 83            [24] 2616 	mov	dph,r3
      002872 8C F0            [24] 2617 	mov	b,r4
      002874 12 2E 55         [24] 2618 	lcall	__gptrget
      002877 FA               [12] 2619 	mov	r2,a
      002878 8A F0            [24] 2620 	mov	b,r2
      00287A E5 21            [12] 2621 	mov	a,_serial_tx_long_sloc0_1_0
      00287C 84               [48] 2622 	div	ab
      00287D E5 F0            [12] 2623 	mov	a,b
      00287F FA               [12] 2624 	mov	r2,a
      002880 2D               [12] 2625 	add	a,r5
      002881 FD               [12] 2626 	mov	r5,a
      002882 E4               [12] 2627 	clr	a
      002883 3E               [12] 2628 	addc	a,r6
      002884 FE               [12] 2629 	mov	r6,a
      002885 8D 82            [24] 2630 	mov	dpl,r5
      002887 8E 83            [24] 2631 	mov	dph,r6
      002889 8F F0            [24] 2632 	mov	b,r7
      00288B 78 92            [12] 2633 	mov	r0,#_serial_tx_long_data_byte_196608_165
      00288D E2               [24] 2634 	movx	a,@r0
      00288E 12 2D 8A         [24] 2635 	lcall	__gptrput
                                   2636 ;	./fifo.h:63: b->head++;
      002891 78 8F            [12] 2637 	mov	r0,#_serial_tx_long_b_196608_165
      002893 E2               [24] 2638 	movx	a,@r0
      002894 F5 82            [12] 2639 	mov	dpl,a
      002896 08               [12] 2640 	inc	r0
      002897 E2               [24] 2641 	movx	a,@r0
      002898 F5 83            [12] 2642 	mov	dph,a
      00289A 08               [12] 2643 	inc	r0
      00289B E2               [24] 2644 	movx	a,@r0
      00289C F5 F0            [12] 2645 	mov	b,a
      00289E 12 2E 55         [24] 2646 	lcall	__gptrget
      0028A1 FF               [12] 2647 	mov	r7,a
      0028A2 0F               [12] 2648 	inc	r7
      0028A3 78 8F            [12] 2649 	mov	r0,#_serial_tx_long_b_196608_165
      0028A5 E2               [24] 2650 	movx	a,@r0
      0028A6 F5 82            [12] 2651 	mov	dpl,a
      0028A8 08               [12] 2652 	inc	r0
      0028A9 E2               [24] 2653 	movx	a,@r0
      0028AA F5 83            [12] 2654 	mov	dph,a
      0028AC 08               [12] 2655 	inc	r0
      0028AD E2               [24] 2656 	movx	a,@r0
      0028AE F5 F0            [12] 2657 	mov	b,a
      0028B0 EF               [12] 2658 	mov	a,r7
      0028B1 12 2D 8A         [24] 2659 	lcall	__gptrput
                                   2660 ;	./fifo.h:64: status = true;
      0028B4                       2661 00106$:
                                   2662 ;	spi1_alt2/serial.c:237: fifo_put(&output_buffer, (tx_long >> 16) & 0xff);
      0028B4 78 8B            [12] 2663 	mov	r0,#_serial_tx_long_tx_long_65536_162
      0028B6 79 97            [12] 2664 	mov	r1,#_serial_tx_long_data_byte_196608_176
      0028B8 08               [12] 2665 	inc	r0
      0028B9 08               [12] 2666 	inc	r0
      0028BA E2               [24] 2667 	movx	a,@r0
      0028BB F3               [24] 2668 	movx	@r1,a
      0028BC 78 94            [12] 2669 	mov	r0,#_serial_tx_long_b_196608_176
      0028BE 74 93            [12] 2670 	mov	a,#_output_buffer
      0028C0 F2               [24] 2671 	movx	@r0,a
      0028C1 08               [12] 2672 	inc	r0
      0028C2 74 F2            [12] 2673 	mov	a,#(_output_buffer >> 8)
      0028C4 F2               [24] 2674 	movx	@r0,a
      0028C5 08               [12] 2675 	inc	r0
      0028C6 E4               [12] 2676 	clr	a
      0028C7 F2               [24] 2677 	movx	@r0,a
                                   2678 ;	./fifo.h:59: if (b) {
      0028C8 74 93            [12] 2679 	mov	a,#_output_buffer
      0028CA 44 F2            [12] 2680 	orl	a,#(_output_buffer >> 8)
      0028CC 70 03            [24] 2681 	jnz	00217$
      0028CE 02 29 C4         [24] 2682 	ljmp	00113$
      0028D1                       2683 00217$:
                                   2684 ;	./fifo.h:61: if (!fifo_full(b)) {
      0028D1 7A 93            [12] 2685 	mov	r2,#_output_buffer
      0028D3 7B F2            [12] 2686 	mov	r3,#(_output_buffer >> 8)
      0028D5 7F 00            [12] 2687 	mov	r7,#0x00
                                   2688 ;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
      0028D7 74 93            [12] 2689 	mov	a,#_output_buffer
      0028D9 44 F2            [12] 2690 	orl	a,#(_output_buffer >> 8)
      0028DB 60 52            [24] 2691 	jz	00135$
                                   2692 ;	./fifo.h:28: return (b ? (b->head - b->tail) : 0);
      0028DD 74 93            [12] 2693 	mov	a,#_output_buffer
      0028DF 44 F2            [12] 2694 	orl	a,#(_output_buffer >> 8)
      0028E1 60 26            [24] 2695 	jz	00137$
      0028E3 C0 02            [24] 2696 	push	ar2
      0028E5 C0 03            [24] 2697 	push	ar3
      0028E7 C0 07            [24] 2698 	push	ar7
      0028E9 90 F2 93         [24] 2699 	mov	dptr,#_output_buffer
      0028EC E0               [24] 2700 	movx	a,@dptr
      0028ED FF               [12] 2701 	mov	r7,a
      0028EE 90 F2 94         [24] 2702 	mov	dptr,#(_output_buffer + 0x0001)
      0028F1 75 F0 00         [24] 2703 	mov	b,#0x00
      0028F4 12 2E 55         [24] 2704 	lcall	__gptrget
      0028F7 FB               [12] 2705 	mov	r3,a
      0028F8 EF               [12] 2706 	mov	a,r7
      0028F9 C3               [12] 2707 	clr	c
      0028FA 9B               [12] 2708 	subb	a,r3
      0028FB FF               [12] 2709 	mov	r7,a
      0028FC 8F 22            [24] 2710 	mov	_serial_tx_long_sloc1_1_0,r7
      0028FE 75 23 00         [24] 2711 	mov	(_serial_tx_long_sloc1_1_0 + 1),#0x00
      002901 D0 07            [24] 2712 	pop	ar7
      002903 D0 03            [24] 2713 	pop	ar3
      002905 D0 02            [24] 2714 	pop	ar2
      002907 80 05            [24] 2715 	sjmp	00138$
      002909                       2716 00137$:
      002909 E4               [12] 2717 	clr	a
      00290A F5 22            [12] 2718 	mov	_serial_tx_long_sloc1_1_0,a
      00290C F5 23            [12] 2719 	mov	(_serial_tx_long_sloc1_1_0 + 1),a
      00290E                       2720 00138$:
      00290E AE 22            [24] 2721 	mov	r6,_serial_tx_long_sloc1_1_0
                                   2722 ;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
      002910 74 05            [12] 2723 	mov	a,#0x05
      002912 2A               [12] 2724 	add	a,r2
      002913 FA               [12] 2725 	mov	r2,a
      002914 E4               [12] 2726 	clr	a
      002915 3B               [12] 2727 	addc	a,r3
      002916 FB               [12] 2728 	mov	r3,a
      002917 8A 82            [24] 2729 	mov	dpl,r2
      002919 8B 83            [24] 2730 	mov	dph,r3
      00291B 8F F0            [24] 2731 	mov	b,r7
      00291D 12 2E 55         [24] 2732 	lcall	__gptrget
      002920 FA               [12] 2733 	mov	r2,a
      002921 78 98            [12] 2734 	mov	r0,#_serial_tx_long___1966080018_327680_178
      002923 EE               [12] 2735 	mov	a,r6
      002924 B5 02 04         [24] 2736 	cjne	a,ar2,00220$
      002927 74 01            [12] 2737 	mov	a,#0x01
      002929 80 01            [24] 2738 	sjmp	00221$
      00292B                       2739 00220$:
      00292B E4               [12] 2740 	clr	a
      00292C                       2741 00221$:
      00292C F2               [24] 2742 	movx	@r0,a
      00292D 80 05            [24] 2743 	sjmp	00136$
      00292F                       2744 00135$:
      00292F 78 98            [12] 2745 	mov	r0,#_serial_tx_long___1966080018_327680_178
      002931 74 01            [12] 2746 	mov	a,#0x01
      002933 F2               [24] 2747 	movx	@r0,a
      002934                       2748 00136$:
                                   2749 ;	./fifo.h:61: if (!fifo_full(b)) {
      002934 78 98            [12] 2750 	mov	r0,#_serial_tx_long___1966080018_327680_178
      002936 E2               [24] 2751 	movx	a,@r0
      002937 60 03            [24] 2752 	jz	00222$
      002939 02 29 C4         [24] 2753 	ljmp	00113$
      00293C                       2754 00222$:
                                   2755 ;	./fifo.h:62: b->buffer[b->head % b->buffer_len] = data_byte;
      00293C 78 94            [12] 2756 	mov	r0,#_serial_tx_long_b_196608_176
      00293E E2               [24] 2757 	movx	a,@r0
      00293F 24 02            [12] 2758 	add	a,#0x02
      002941 FA               [12] 2759 	mov	r2,a
      002942 08               [12] 2760 	inc	r0
      002943 E2               [24] 2761 	movx	a,@r0
      002944 34 00            [12] 2762 	addc	a,#0x00
      002946 FB               [12] 2763 	mov	r3,a
      002947 08               [12] 2764 	inc	r0
      002948 E2               [24] 2765 	movx	a,@r0
      002949 FF               [12] 2766 	mov	r7,a
      00294A 8A 82            [24] 2767 	mov	dpl,r2
      00294C 8B 83            [24] 2768 	mov	dph,r3
      00294E 8F F0            [24] 2769 	mov	b,r7
      002950 12 2E 55         [24] 2770 	lcall	__gptrget
      002953 FA               [12] 2771 	mov	r2,a
      002954 A3               [24] 2772 	inc	dptr
      002955 12 2E 55         [24] 2773 	lcall	__gptrget
      002958 FB               [12] 2774 	mov	r3,a
      002959 A3               [24] 2775 	inc	dptr
      00295A 12 2E 55         [24] 2776 	lcall	__gptrget
      00295D FF               [12] 2777 	mov	r7,a
      00295E 78 94            [12] 2778 	mov	r0,#_serial_tx_long_b_196608_176
      002960 E2               [24] 2779 	movx	a,@r0
      002961 F5 82            [12] 2780 	mov	dpl,a
      002963 08               [12] 2781 	inc	r0
      002964 E2               [24] 2782 	movx	a,@r0
      002965 F5 83            [12] 2783 	mov	dph,a
      002967 08               [12] 2784 	inc	r0
      002968 E2               [24] 2785 	movx	a,@r0
      002969 F5 F0            [12] 2786 	mov	b,a
      00296B 12 2E 55         [24] 2787 	lcall	__gptrget
      00296E F5 22            [12] 2788 	mov	_serial_tx_long_sloc1_1_0,a
      002970 78 94            [12] 2789 	mov	r0,#_serial_tx_long_b_196608_176
      002972 E2               [24] 2790 	movx	a,@r0
      002973 24 05            [12] 2791 	add	a,#0x05
      002975 FC               [12] 2792 	mov	r4,a
      002976 08               [12] 2793 	inc	r0
      002977 E2               [24] 2794 	movx	a,@r0
      002978 34 00            [12] 2795 	addc	a,#0x00
      00297A FD               [12] 2796 	mov	r5,a
      00297B 08               [12] 2797 	inc	r0
      00297C E2               [24] 2798 	movx	a,@r0
      00297D FE               [12] 2799 	mov	r6,a
      00297E 8C 82            [24] 2800 	mov	dpl,r4
      002980 8D 83            [24] 2801 	mov	dph,r5
      002982 8E F0            [24] 2802 	mov	b,r6
      002984 12 2E 55         [24] 2803 	lcall	__gptrget
      002987 FC               [12] 2804 	mov	r4,a
      002988 8C F0            [24] 2805 	mov	b,r4
      00298A E5 22            [12] 2806 	mov	a,_serial_tx_long_sloc1_1_0
      00298C 84               [48] 2807 	div	ab
      00298D E5 F0            [12] 2808 	mov	a,b
      00298F FC               [12] 2809 	mov	r4,a
      002990 2A               [12] 2810 	add	a,r2
      002991 FA               [12] 2811 	mov	r2,a
      002992 E4               [12] 2812 	clr	a
      002993 3B               [12] 2813 	addc	a,r3
      002994 FB               [12] 2814 	mov	r3,a
      002995 8A 82            [24] 2815 	mov	dpl,r2
      002997 8B 83            [24] 2816 	mov	dph,r3
      002999 8F F0            [24] 2817 	mov	b,r7
      00299B 78 97            [12] 2818 	mov	r0,#_serial_tx_long_data_byte_196608_176
      00299D E2               [24] 2819 	movx	a,@r0
      00299E 12 2D 8A         [24] 2820 	lcall	__gptrput
                                   2821 ;	./fifo.h:63: b->head++;
      0029A1 78 94            [12] 2822 	mov	r0,#_serial_tx_long_b_196608_176
      0029A3 E2               [24] 2823 	movx	a,@r0
      0029A4 F5 82            [12] 2824 	mov	dpl,a
      0029A6 08               [12] 2825 	inc	r0
      0029A7 E2               [24] 2826 	movx	a,@r0
      0029A8 F5 83            [12] 2827 	mov	dph,a
      0029AA 08               [12] 2828 	inc	r0
      0029AB E2               [24] 2829 	movx	a,@r0
      0029AC F5 F0            [12] 2830 	mov	b,a
      0029AE 12 2E 55         [24] 2831 	lcall	__gptrget
      0029B1 FF               [12] 2832 	mov	r7,a
      0029B2 0F               [12] 2833 	inc	r7
      0029B3 78 94            [12] 2834 	mov	r0,#_serial_tx_long_b_196608_176
      0029B5 E2               [24] 2835 	movx	a,@r0
      0029B6 F5 82            [12] 2836 	mov	dpl,a
      0029B8 08               [12] 2837 	inc	r0
      0029B9 E2               [24] 2838 	movx	a,@r0
      0029BA F5 83            [12] 2839 	mov	dph,a
      0029BC 08               [12] 2840 	inc	r0
      0029BD E2               [24] 2841 	movx	a,@r0
      0029BE F5 F0            [12] 2842 	mov	b,a
      0029C0 EF               [12] 2843 	mov	a,r7
      0029C1 12 2D 8A         [24] 2844 	lcall	__gptrput
                                   2845 ;	./fifo.h:64: status = true;
      0029C4                       2846 00113$:
                                   2847 ;	spi1_alt2/serial.c:238: fifo_put(&output_buffer, (tx_long >> 8) & 0xff);
      0029C4 78 8B            [12] 2848 	mov	r0,#_serial_tx_long_tx_long_65536_162
      0029C6 79 9C            [12] 2849 	mov	r1,#_serial_tx_long_data_byte_196608_187
      0029C8 08               [12] 2850 	inc	r0
      0029C9 E2               [24] 2851 	movx	a,@r0
      0029CA F3               [24] 2852 	movx	@r1,a
      0029CB 78 99            [12] 2853 	mov	r0,#_serial_tx_long_b_196608_187
      0029CD 74 93            [12] 2854 	mov	a,#_output_buffer
      0029CF F2               [24] 2855 	movx	@r0,a
      0029D0 08               [12] 2856 	inc	r0
      0029D1 74 F2            [12] 2857 	mov	a,#(_output_buffer >> 8)
      0029D3 F2               [24] 2858 	movx	@r0,a
      0029D4 08               [12] 2859 	inc	r0
      0029D5 E4               [12] 2860 	clr	a
      0029D6 F2               [24] 2861 	movx	@r0,a
                                   2862 ;	./fifo.h:59: if (b) {
      0029D7 74 93            [12] 2863 	mov	a,#_output_buffer
      0029D9 44 F2            [12] 2864 	orl	a,#(_output_buffer >> 8)
      0029DB 70 03            [24] 2865 	jnz	00223$
      0029DD 02 2A D3         [24] 2866 	ljmp	00120$
      0029E0                       2867 00223$:
                                   2868 ;	./fifo.h:61: if (!fifo_full(b)) {
      0029E0 7A 93            [12] 2869 	mov	r2,#_output_buffer
      0029E2 7B F2            [12] 2870 	mov	r3,#(_output_buffer >> 8)
      0029E4 7F 00            [12] 2871 	mov	r7,#0x00
                                   2872 ;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
      0029E6 74 93            [12] 2873 	mov	a,#_output_buffer
      0029E8 44 F2            [12] 2874 	orl	a,#(_output_buffer >> 8)
      0029EA 60 52            [24] 2875 	jz	00139$
                                   2876 ;	./fifo.h:28: return (b ? (b->head - b->tail) : 0);
      0029EC 74 93            [12] 2877 	mov	a,#_output_buffer
      0029EE 44 F2            [12] 2878 	orl	a,#(_output_buffer >> 8)
      0029F0 60 26            [24] 2879 	jz	00141$
      0029F2 C0 02            [24] 2880 	push	ar2
      0029F4 C0 03            [24] 2881 	push	ar3
      0029F6 C0 07            [24] 2882 	push	ar7
      0029F8 90 F2 93         [24] 2883 	mov	dptr,#_output_buffer
      0029FB E0               [24] 2884 	movx	a,@dptr
      0029FC FF               [12] 2885 	mov	r7,a
      0029FD 90 F2 94         [24] 2886 	mov	dptr,#(_output_buffer + 0x0001)
      002A00 75 F0 00         [24] 2887 	mov	b,#0x00
      002A03 12 2E 55         [24] 2888 	lcall	__gptrget
      002A06 FB               [12] 2889 	mov	r3,a
      002A07 EF               [12] 2890 	mov	a,r7
      002A08 C3               [12] 2891 	clr	c
      002A09 9B               [12] 2892 	subb	a,r3
      002A0A FF               [12] 2893 	mov	r7,a
      002A0B 8F 22            [24] 2894 	mov	_serial_tx_long_sloc1_1_0,r7
      002A0D 75 23 00         [24] 2895 	mov	(_serial_tx_long_sloc1_1_0 + 1),#0x00
      002A10 D0 07            [24] 2896 	pop	ar7
      002A12 D0 03            [24] 2897 	pop	ar3
      002A14 D0 02            [24] 2898 	pop	ar2
      002A16 80 05            [24] 2899 	sjmp	00142$
      002A18                       2900 00141$:
      002A18 E4               [12] 2901 	clr	a
      002A19 F5 22            [12] 2902 	mov	_serial_tx_long_sloc1_1_0,a
      002A1B F5 23            [12] 2903 	mov	(_serial_tx_long_sloc1_1_0 + 1),a
      002A1D                       2904 00142$:
      002A1D AE 22            [24] 2905 	mov	r6,_serial_tx_long_sloc1_1_0
                                   2906 ;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
      002A1F 74 05            [12] 2907 	mov	a,#0x05
      002A21 2A               [12] 2908 	add	a,r2
      002A22 FA               [12] 2909 	mov	r2,a
      002A23 E4               [12] 2910 	clr	a
      002A24 3B               [12] 2911 	addc	a,r3
      002A25 FB               [12] 2912 	mov	r3,a
      002A26 8A 82            [24] 2913 	mov	dpl,r2
      002A28 8B 83            [24] 2914 	mov	dph,r3
      002A2A 8F F0            [24] 2915 	mov	b,r7
      002A2C 12 2E 55         [24] 2916 	lcall	__gptrget
      002A2F FA               [12] 2917 	mov	r2,a
      002A30 78 9D            [12] 2918 	mov	r0,#_serial_tx_long___1966080018_327680_189
      002A32 EE               [12] 2919 	mov	a,r6
      002A33 B5 02 04         [24] 2920 	cjne	a,ar2,00226$
      002A36 74 01            [12] 2921 	mov	a,#0x01
      002A38 80 01            [24] 2922 	sjmp	00227$
      002A3A                       2923 00226$:
      002A3A E4               [12] 2924 	clr	a
      002A3B                       2925 00227$:
      002A3B F2               [24] 2926 	movx	@r0,a
      002A3C 80 05            [24] 2927 	sjmp	00140$
      002A3E                       2928 00139$:
      002A3E 78 9D            [12] 2929 	mov	r0,#_serial_tx_long___1966080018_327680_189
      002A40 74 01            [12] 2930 	mov	a,#0x01
      002A42 F2               [24] 2931 	movx	@r0,a
      002A43                       2932 00140$:
                                   2933 ;	./fifo.h:61: if (!fifo_full(b)) {
      002A43 78 9D            [12] 2934 	mov	r0,#_serial_tx_long___1966080018_327680_189
      002A45 E2               [24] 2935 	movx	a,@r0
      002A46 60 03            [24] 2936 	jz	00228$
      002A48 02 2A D3         [24] 2937 	ljmp	00120$
      002A4B                       2938 00228$:
                                   2939 ;	./fifo.h:62: b->buffer[b->head % b->buffer_len] = data_byte;
      002A4B 78 99            [12] 2940 	mov	r0,#_serial_tx_long_b_196608_187
      002A4D E2               [24] 2941 	movx	a,@r0
      002A4E 24 02            [12] 2942 	add	a,#0x02
      002A50 FA               [12] 2943 	mov	r2,a
      002A51 08               [12] 2944 	inc	r0
      002A52 E2               [24] 2945 	movx	a,@r0
      002A53 34 00            [12] 2946 	addc	a,#0x00
      002A55 FB               [12] 2947 	mov	r3,a
      002A56 08               [12] 2948 	inc	r0
      002A57 E2               [24] 2949 	movx	a,@r0
      002A58 FF               [12] 2950 	mov	r7,a
      002A59 8A 82            [24] 2951 	mov	dpl,r2
      002A5B 8B 83            [24] 2952 	mov	dph,r3
      002A5D 8F F0            [24] 2953 	mov	b,r7
      002A5F 12 2E 55         [24] 2954 	lcall	__gptrget
      002A62 FA               [12] 2955 	mov	r2,a
      002A63 A3               [24] 2956 	inc	dptr
      002A64 12 2E 55         [24] 2957 	lcall	__gptrget
      002A67 FB               [12] 2958 	mov	r3,a
      002A68 A3               [24] 2959 	inc	dptr
      002A69 12 2E 55         [24] 2960 	lcall	__gptrget
      002A6C FF               [12] 2961 	mov	r7,a
      002A6D 78 99            [12] 2962 	mov	r0,#_serial_tx_long_b_196608_187
      002A6F E2               [24] 2963 	movx	a,@r0
      002A70 F5 82            [12] 2964 	mov	dpl,a
      002A72 08               [12] 2965 	inc	r0
      002A73 E2               [24] 2966 	movx	a,@r0
      002A74 F5 83            [12] 2967 	mov	dph,a
      002A76 08               [12] 2968 	inc	r0
      002A77 E2               [24] 2969 	movx	a,@r0
      002A78 F5 F0            [12] 2970 	mov	b,a
      002A7A 12 2E 55         [24] 2971 	lcall	__gptrget
      002A7D F5 22            [12] 2972 	mov	_serial_tx_long_sloc1_1_0,a
      002A7F 78 99            [12] 2973 	mov	r0,#_serial_tx_long_b_196608_187
      002A81 E2               [24] 2974 	movx	a,@r0
      002A82 24 05            [12] 2975 	add	a,#0x05
      002A84 FC               [12] 2976 	mov	r4,a
      002A85 08               [12] 2977 	inc	r0
      002A86 E2               [24] 2978 	movx	a,@r0
      002A87 34 00            [12] 2979 	addc	a,#0x00
      002A89 FD               [12] 2980 	mov	r5,a
      002A8A 08               [12] 2981 	inc	r0
      002A8B E2               [24] 2982 	movx	a,@r0
      002A8C FE               [12] 2983 	mov	r6,a
      002A8D 8C 82            [24] 2984 	mov	dpl,r4
      002A8F 8D 83            [24] 2985 	mov	dph,r5
      002A91 8E F0            [24] 2986 	mov	b,r6
      002A93 12 2E 55         [24] 2987 	lcall	__gptrget
      002A96 FC               [12] 2988 	mov	r4,a
      002A97 8C F0            [24] 2989 	mov	b,r4
      002A99 E5 22            [12] 2990 	mov	a,_serial_tx_long_sloc1_1_0
      002A9B 84               [48] 2991 	div	ab
      002A9C E5 F0            [12] 2992 	mov	a,b
      002A9E FC               [12] 2993 	mov	r4,a
      002A9F 2A               [12] 2994 	add	a,r2
      002AA0 FA               [12] 2995 	mov	r2,a
      002AA1 E4               [12] 2996 	clr	a
      002AA2 3B               [12] 2997 	addc	a,r3
      002AA3 FB               [12] 2998 	mov	r3,a
      002AA4 8A 82            [24] 2999 	mov	dpl,r2
      002AA6 8B 83            [24] 3000 	mov	dph,r3
      002AA8 8F F0            [24] 3001 	mov	b,r7
      002AAA 78 9C            [12] 3002 	mov	r0,#_serial_tx_long_data_byte_196608_187
      002AAC E2               [24] 3003 	movx	a,@r0
      002AAD 12 2D 8A         [24] 3004 	lcall	__gptrput
                                   3005 ;	./fifo.h:63: b->head++;
      002AB0 78 99            [12] 3006 	mov	r0,#_serial_tx_long_b_196608_187
      002AB2 E2               [24] 3007 	movx	a,@r0
      002AB3 F5 82            [12] 3008 	mov	dpl,a
      002AB5 08               [12] 3009 	inc	r0
      002AB6 E2               [24] 3010 	movx	a,@r0
      002AB7 F5 83            [12] 3011 	mov	dph,a
      002AB9 08               [12] 3012 	inc	r0
      002ABA E2               [24] 3013 	movx	a,@r0
      002ABB F5 F0            [12] 3014 	mov	b,a
      002ABD 12 2E 55         [24] 3015 	lcall	__gptrget
      002AC0 FF               [12] 3016 	mov	r7,a
      002AC1 0F               [12] 3017 	inc	r7
      002AC2 78 99            [12] 3018 	mov	r0,#_serial_tx_long_b_196608_187
      002AC4 E2               [24] 3019 	movx	a,@r0
      002AC5 F5 82            [12] 3020 	mov	dpl,a
      002AC7 08               [12] 3021 	inc	r0
      002AC8 E2               [24] 3022 	movx	a,@r0
      002AC9 F5 83            [12] 3023 	mov	dph,a
      002ACB 08               [12] 3024 	inc	r0
      002ACC E2               [24] 3025 	movx	a,@r0
      002ACD F5 F0            [12] 3026 	mov	b,a
      002ACF EF               [12] 3027 	mov	a,r7
      002AD0 12 2D 8A         [24] 3028 	lcall	__gptrput
                                   3029 ;	./fifo.h:64: status = true;
      002AD3                       3030 00120$:
                                   3031 ;	spi1_alt2/serial.c:239: fifo_put(&output_buffer, tx_long & 0xff);
      002AD3 78 8B            [12] 3032 	mov	r0,#_serial_tx_long_tx_long_65536_162
      002AD5 79 A1            [12] 3033 	mov	r1,#_serial_tx_long_data_byte_196608_198
      002AD7 E2               [24] 3034 	movx	a,@r0
      002AD8 F3               [24] 3035 	movx	@r1,a
      002AD9 78 9E            [12] 3036 	mov	r0,#_serial_tx_long_b_196608_198
      002ADB 74 93            [12] 3037 	mov	a,#_output_buffer
      002ADD F2               [24] 3038 	movx	@r0,a
      002ADE 08               [12] 3039 	inc	r0
      002ADF 74 F2            [12] 3040 	mov	a,#(_output_buffer >> 8)
      002AE1 F2               [24] 3041 	movx	@r0,a
      002AE2 08               [12] 3042 	inc	r0
      002AE3 E4               [12] 3043 	clr	a
      002AE4 F2               [24] 3044 	movx	@r0,a
                                   3045 ;	./fifo.h:59: if (b) {
      002AE5 74 93            [12] 3046 	mov	a,#_output_buffer
      002AE7 44 F2            [12] 3047 	orl	a,#(_output_buffer >> 8)
      002AE9 70 01            [24] 3048 	jnz	00229$
      002AEB 22               [24] 3049 	ret
      002AEC                       3050 00229$:
                                   3051 ;	./fifo.h:61: if (!fifo_full(b)) {
      002AEC 7A 93            [12] 3052 	mov	r2,#_output_buffer
      002AEE 7B F2            [12] 3053 	mov	r3,#(_output_buffer >> 8)
      002AF0 7C 00            [12] 3054 	mov	r4,#0x00
                                   3055 ;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
      002AF2 74 93            [12] 3056 	mov	a,#_output_buffer
      002AF4 44 F2            [12] 3057 	orl	a,#(_output_buffer >> 8)
      002AF6 60 52            [24] 3058 	jz	00143$
                                   3059 ;	./fifo.h:28: return (b ? (b->head - b->tail) : 0);
      002AF8 74 93            [12] 3060 	mov	a,#_output_buffer
      002AFA 44 F2            [12] 3061 	orl	a,#(_output_buffer >> 8)
      002AFC 60 26            [24] 3062 	jz	00145$
      002AFE C0 02            [24] 3063 	push	ar2
      002B00 C0 03            [24] 3064 	push	ar3
      002B02 C0 04            [24] 3065 	push	ar4
      002B04 90 F2 93         [24] 3066 	mov	dptr,#_output_buffer
      002B07 E0               [24] 3067 	movx	a,@dptr
      002B08 FC               [12] 3068 	mov	r4,a
      002B09 90 F2 94         [24] 3069 	mov	dptr,#(_output_buffer + 0x0001)
      002B0C 75 F0 00         [24] 3070 	mov	b,#0x00
      002B0F 12 2E 55         [24] 3071 	lcall	__gptrget
      002B12 FB               [12] 3072 	mov	r3,a
      002B13 EC               [12] 3073 	mov	a,r4
      002B14 C3               [12] 3074 	clr	c
      002B15 9B               [12] 3075 	subb	a,r3
      002B16 FC               [12] 3076 	mov	r4,a
      002B17 8C 22            [24] 3077 	mov	_serial_tx_long_sloc1_1_0,r4
      002B19 75 23 00         [24] 3078 	mov	(_serial_tx_long_sloc1_1_0 + 1),#0x00
      002B1C D0 04            [24] 3079 	pop	ar4
      002B1E D0 03            [24] 3080 	pop	ar3
      002B20 D0 02            [24] 3081 	pop	ar2
      002B22 80 05            [24] 3082 	sjmp	00146$
      002B24                       3083 00145$:
      002B24 E4               [12] 3084 	clr	a
      002B25 F5 22            [12] 3085 	mov	_serial_tx_long_sloc1_1_0,a
      002B27 F5 23            [12] 3086 	mov	(_serial_tx_long_sloc1_1_0 + 1),a
      002B29                       3087 00146$:
      002B29 AF 22            [24] 3088 	mov	r7,_serial_tx_long_sloc1_1_0
                                   3089 ;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
      002B2B 74 05            [12] 3090 	mov	a,#0x05
      002B2D 2A               [12] 3091 	add	a,r2
      002B2E FA               [12] 3092 	mov	r2,a
      002B2F E4               [12] 3093 	clr	a
      002B30 3B               [12] 3094 	addc	a,r3
      002B31 FB               [12] 3095 	mov	r3,a
      002B32 8A 82            [24] 3096 	mov	dpl,r2
      002B34 8B 83            [24] 3097 	mov	dph,r3
      002B36 8C F0            [24] 3098 	mov	b,r4
      002B38 12 2E 55         [24] 3099 	lcall	__gptrget
      002B3B FA               [12] 3100 	mov	r2,a
      002B3C 78 A2            [12] 3101 	mov	r0,#_serial_tx_long___1966080018_327680_200
      002B3E EF               [12] 3102 	mov	a,r7
      002B3F B5 02 04         [24] 3103 	cjne	a,ar2,00232$
      002B42 74 01            [12] 3104 	mov	a,#0x01
      002B44 80 01            [24] 3105 	sjmp	00233$
      002B46                       3106 00232$:
      002B46 E4               [12] 3107 	clr	a
      002B47                       3108 00233$:
      002B47 F2               [24] 3109 	movx	@r0,a
      002B48 80 05            [24] 3110 	sjmp	00144$
      002B4A                       3111 00143$:
      002B4A 78 A2            [12] 3112 	mov	r0,#_serial_tx_long___1966080018_327680_200
      002B4C 74 01            [12] 3113 	mov	a,#0x01
      002B4E F2               [24] 3114 	movx	@r0,a
      002B4F                       3115 00144$:
                                   3116 ;	./fifo.h:61: if (!fifo_full(b)) {
      002B4F 78 A2            [12] 3117 	mov	r0,#_serial_tx_long___1966080018_327680_200
      002B51 E2               [24] 3118 	movx	a,@r0
      002B52 60 01            [24] 3119 	jz	00234$
      002B54 22               [24] 3120 	ret
      002B55                       3121 00234$:
                                   3122 ;	./fifo.h:62: b->buffer[b->head % b->buffer_len] = data_byte;
      002B55 78 9E            [12] 3123 	mov	r0,#_serial_tx_long_b_196608_198
      002B57 E2               [24] 3124 	movx	a,@r0
      002B58 24 02            [12] 3125 	add	a,#0x02
      002B5A FA               [12] 3126 	mov	r2,a
      002B5B 08               [12] 3127 	inc	r0
      002B5C E2               [24] 3128 	movx	a,@r0
      002B5D 34 00            [12] 3129 	addc	a,#0x00
      002B5F FB               [12] 3130 	mov	r3,a
      002B60 08               [12] 3131 	inc	r0
      002B61 E2               [24] 3132 	movx	a,@r0
      002B62 FC               [12] 3133 	mov	r4,a
      002B63 8A 82            [24] 3134 	mov	dpl,r2
      002B65 8B 83            [24] 3135 	mov	dph,r3
      002B67 8C F0            [24] 3136 	mov	b,r4
      002B69 12 2E 55         [24] 3137 	lcall	__gptrget
      002B6C FA               [12] 3138 	mov	r2,a
      002B6D A3               [24] 3139 	inc	dptr
      002B6E 12 2E 55         [24] 3140 	lcall	__gptrget
      002B71 FB               [12] 3141 	mov	r3,a
      002B72 A3               [24] 3142 	inc	dptr
      002B73 12 2E 55         [24] 3143 	lcall	__gptrget
      002B76 FC               [12] 3144 	mov	r4,a
      002B77 78 9E            [12] 3145 	mov	r0,#_serial_tx_long_b_196608_198
      002B79 E2               [24] 3146 	movx	a,@r0
      002B7A F5 82            [12] 3147 	mov	dpl,a
      002B7C 08               [12] 3148 	inc	r0
      002B7D E2               [24] 3149 	movx	a,@r0
      002B7E F5 83            [12] 3150 	mov	dph,a
      002B80 08               [12] 3151 	inc	r0
      002B81 E2               [24] 3152 	movx	a,@r0
      002B82 F5 F0            [12] 3153 	mov	b,a
      002B84 12 2E 55         [24] 3154 	lcall	__gptrget
      002B87 F5 22            [12] 3155 	mov	_serial_tx_long_sloc1_1_0,a
      002B89 78 9E            [12] 3156 	mov	r0,#_serial_tx_long_b_196608_198
      002B8B E2               [24] 3157 	movx	a,@r0
      002B8C 24 05            [12] 3158 	add	a,#0x05
      002B8E FD               [12] 3159 	mov	r5,a
      002B8F 08               [12] 3160 	inc	r0
      002B90 E2               [24] 3161 	movx	a,@r0
      002B91 34 00            [12] 3162 	addc	a,#0x00
      002B93 FE               [12] 3163 	mov	r6,a
      002B94 08               [12] 3164 	inc	r0
      002B95 E2               [24] 3165 	movx	a,@r0
      002B96 FF               [12] 3166 	mov	r7,a
      002B97 8D 82            [24] 3167 	mov	dpl,r5
      002B99 8E 83            [24] 3168 	mov	dph,r6
      002B9B 8F F0            [24] 3169 	mov	b,r7
      002B9D 12 2E 55         [24] 3170 	lcall	__gptrget
      002BA0 FD               [12] 3171 	mov	r5,a
      002BA1 8D F0            [24] 3172 	mov	b,r5
      002BA3 E5 22            [12] 3173 	mov	a,_serial_tx_long_sloc1_1_0
      002BA5 84               [48] 3174 	div	ab
      002BA6 E5 F0            [12] 3175 	mov	a,b
      002BA8 2A               [12] 3176 	add	a,r2
      002BA9 FA               [12] 3177 	mov	r2,a
      002BAA E4               [12] 3178 	clr	a
      002BAB 3B               [12] 3179 	addc	a,r3
      002BAC FB               [12] 3180 	mov	r3,a
      002BAD 8A 82            [24] 3181 	mov	dpl,r2
      002BAF 8B 83            [24] 3182 	mov	dph,r3
      002BB1 8C F0            [24] 3183 	mov	b,r4
      002BB3 78 A1            [12] 3184 	mov	r0,#_serial_tx_long_data_byte_196608_198
      002BB5 E2               [24] 3185 	movx	a,@r0
      002BB6 12 2D 8A         [24] 3186 	lcall	__gptrput
                                   3187 ;	./fifo.h:63: b->head++;
      002BB9 78 9E            [12] 3188 	mov	r0,#_serial_tx_long_b_196608_198
      002BBB E2               [24] 3189 	movx	a,@r0
      002BBC F5 82            [12] 3190 	mov	dpl,a
      002BBE 08               [12] 3191 	inc	r0
      002BBF E2               [24] 3192 	movx	a,@r0
      002BC0 F5 83            [12] 3193 	mov	dph,a
      002BC2 08               [12] 3194 	inc	r0
      002BC3 E2               [24] 3195 	movx	a,@r0
      002BC4 F5 F0            [12] 3196 	mov	b,a
      002BC6 12 2E 55         [24] 3197 	lcall	__gptrget
      002BC9 FF               [12] 3198 	mov	r7,a
      002BCA 0F               [12] 3199 	inc	r7
      002BCB 78 9E            [12] 3200 	mov	r0,#_serial_tx_long_b_196608_198
      002BCD E2               [24] 3201 	movx	a,@r0
      002BCE F5 82            [12] 3202 	mov	dpl,a
      002BD0 08               [12] 3203 	inc	r0
      002BD1 E2               [24] 3204 	movx	a,@r0
      002BD2 F5 83            [12] 3205 	mov	dph,a
      002BD4 08               [12] 3206 	inc	r0
      002BD5 E2               [24] 3207 	movx	a,@r0
      002BD6 F5 F0            [12] 3208 	mov	b,a
      002BD8 EF               [12] 3209 	mov	a,r7
                                   3210 ;	spi1_alt2/serial.c:239: fifo_put(&output_buffer, tx_long & 0xff);
                                   3211 ;	spi1_alt2/serial.c:240: }
      002BD9 02 2D 8A         [24] 3212 	ljmp	__gptrput
                                   3213 ;------------------------------------------------------------
                                   3214 ;Allocation info for local variables in function 'serial_flush'
                                   3215 ;------------------------------------------------------------
                                   3216 ;	spi1_alt2/serial.c:242: void serial_flush()
                                   3217 ;	-----------------------------------------
                                   3218 ;	 function serial_flush
                                   3219 ;	-----------------------------------------
      002BDC                       3220 _serial_flush:
                                   3221 ;	spi1_alt2/serial.c:246: if (fifo_empty(&output_buffer)) {
                                   3222 ;	./fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
      002BDC 74 93            [12] 3223 	mov	a,#_output_buffer
      002BDE 44 F2            [12] 3224 	orl	a,#(_output_buffer >> 8)
      002BE0 60 2C            [24] 3225 	jz	00124$
                                   3226 ;	./fifo.h:28: return (b ? (b->head - b->tail) : 0);
      002BE2 74 93            [12] 3227 	mov	a,#_output_buffer
      002BE4 44 F2            [12] 3228 	orl	a,#(_output_buffer >> 8)
      002BE6 60 17            [24] 3229 	jz	00126$
      002BE8 90 F2 93         [24] 3230 	mov	dptr,#_output_buffer
      002BEB E0               [24] 3231 	movx	a,@dptr
      002BEC FF               [12] 3232 	mov	r7,a
      002BED 90 F2 94         [24] 3233 	mov	dptr,#(_output_buffer + 0x0001)
      002BF0 75 F0 00         [24] 3234 	mov	b,#0x00
      002BF3 12 2E 55         [24] 3235 	lcall	__gptrget
      002BF6 FE               [12] 3236 	mov	r6,a
      002BF7 EF               [12] 3237 	mov	a,r7
      002BF8 C3               [12] 3238 	clr	c
      002BF9 9E               [12] 3239 	subb	a,r6
      002BFA FE               [12] 3240 	mov	r6,a
      002BFB 7F 00            [12] 3241 	mov	r7,#0x00
      002BFD 80 04            [24] 3242 	sjmp	00127$
      002BFF                       3243 00126$:
      002BFF 7E 00            [12] 3244 	mov	r6,#0x00
      002C01 7F 00            [12] 3245 	mov	r7,#0x00
      002C03                       3246 00127$:
                                   3247 ;	./fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
      002C03 78 A4            [12] 3248 	mov	r0,#_serial_flush___1310720063_131072_208
      002C05 EE               [12] 3249 	mov	a,r6
      002C06 B4 01 00         [24] 3250 	cjne	a,#0x01,00178$
      002C09                       3251 00178$:
      002C09 E4               [12] 3252 	clr	a
      002C0A 33               [12] 3253 	rlc	a
      002C0B F2               [24] 3254 	movx	@r0,a
      002C0C 80 05            [24] 3255 	sjmp	00125$
      002C0E                       3256 00124$:
      002C0E 78 A4            [12] 3257 	mov	r0,#_serial_flush___1310720063_131072_208
      002C10 74 01            [12] 3258 	mov	a,#0x01
      002C12 F2               [24] 3259 	movx	@r0,a
      002C13                       3260 00125$:
                                   3261 ;	spi1_alt2/serial.c:246: if (fifo_empty(&output_buffer)) {
      002C13 78 A4            [12] 3262 	mov	r0,#_serial_flush___1310720063_131072_208
      002C15 E2               [24] 3263 	movx	a,@r0
      002C16 60 01            [24] 3264 	jz	00102$
                                   3265 ;	spi1_alt2/serial.c:247: return;
      002C18 22               [24] 3266 	ret
      002C19                       3267 00102$:
                                   3268 ;	spi1_alt2/serial.c:251: read_timer(&start_time);
                                   3269 ;	./timer.h:14: EA = 0;
                                   3270 ;	assignBit
      002C19 C2 AF            [12] 3271 	clr	_EA
                                   3272 ;	./timer.h:15: *result = __timerCounter;
      002C1B 78 A5            [12] 3273 	mov	r0,#_serial_flush_start_time_65536_208
      002C1D 79 2E            [12] 3274 	mov	r1,#___timerCounter
      002C1F E3               [24] 3275 	movx	a,@r1
      002C20 F2               [24] 3276 	movx	@r0,a
      002C21 08               [12] 3277 	inc	r0
      002C22 09               [12] 3278 	inc	r1
      002C23 E3               [24] 3279 	movx	a,@r1
      002C24 F2               [24] 3280 	movx	@r0,a
      002C25 08               [12] 3281 	inc	r0
      002C26 09               [12] 3282 	inc	r1
      002C27 E3               [24] 3283 	movx	a,@r1
      002C28 F2               [24] 3284 	movx	@r0,a
      002C29 08               [12] 3285 	inc	r0
      002C2A 09               [12] 3286 	inc	r1
      002C2B E3               [24] 3287 	movx	a,@r1
      002C2C F2               [24] 3288 	movx	@r0,a
                                   3289 ;	./timer.h:16: EA = 1;
                                   3290 ;	assignBit
      002C2D D2 AF            [12] 3291 	setb	_EA
                                   3292 ;	spi1_alt2/serial.c:252: ready_to_send = 1;
      002C2F 78 71            [12] 3293 	mov	r0,#_ready_to_send
      002C31 74 01            [12] 3294 	mov	a,#0x01
      002C33 F2               [24] 3295 	movx	@r0,a
                                   3296 ;	spi1_alt2/serial.c:253: while(!fifo_empty(&output_buffer) && !subg_rfspy_should_exit) {
      002C34                       3297 00106$:
                                   3298 ;	./fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
      002C34 74 93            [12] 3299 	mov	a,#_output_buffer
      002C36 44 F2            [12] 3300 	orl	a,#(_output_buffer >> 8)
      002C38 60 2C            [24] 3301 	jz	00128$
                                   3302 ;	./fifo.h:28: return (b ? (b->head - b->tail) : 0);
      002C3A 74 93            [12] 3303 	mov	a,#_output_buffer
      002C3C 44 F2            [12] 3304 	orl	a,#(_output_buffer >> 8)
      002C3E 60 17            [24] 3305 	jz	00130$
      002C40 90 F2 93         [24] 3306 	mov	dptr,#_output_buffer
      002C43 E0               [24] 3307 	movx	a,@dptr
      002C44 FF               [12] 3308 	mov	r7,a
      002C45 90 F2 94         [24] 3309 	mov	dptr,#(_output_buffer + 0x0001)
      002C48 75 F0 00         [24] 3310 	mov	b,#0x00
      002C4B 12 2E 55         [24] 3311 	lcall	__gptrget
      002C4E FE               [12] 3312 	mov	r6,a
      002C4F EF               [12] 3313 	mov	a,r7
      002C50 C3               [12] 3314 	clr	c
      002C51 9E               [12] 3315 	subb	a,r6
      002C52 FE               [12] 3316 	mov	r6,a
      002C53 7F 00            [12] 3317 	mov	r7,#0x00
      002C55 80 04            [24] 3318 	sjmp	00131$
      002C57                       3319 00130$:
      002C57 7E 00            [12] 3320 	mov	r6,#0x00
      002C59 7F 00            [12] 3321 	mov	r7,#0x00
      002C5B                       3322 00131$:
                                   3323 ;	./fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
      002C5B 78 A3            [12] 3324 	mov	r0,#_serial_flush___1310720068_131072_208
      002C5D EE               [12] 3325 	mov	a,r6
      002C5E B4 01 00         [24] 3326 	cjne	a,#0x01,00182$
      002C61                       3327 00182$:
      002C61 E4               [12] 3328 	clr	a
      002C62 33               [12] 3329 	rlc	a
      002C63 F2               [24] 3330 	movx	@r0,a
      002C64 80 05            [24] 3331 	sjmp	00129$
      002C66                       3332 00128$:
      002C66 78 A3            [12] 3333 	mov	r0,#_serial_flush___1310720068_131072_208
      002C68 74 01            [12] 3334 	mov	a,#0x01
      002C6A F2               [24] 3335 	movx	@r0,a
      002C6B                       3336 00129$:
                                   3337 ;	spi1_alt2/serial.c:253: while(!fifo_empty(&output_buffer) && !subg_rfspy_should_exit) {
      002C6B 78 A3            [12] 3338 	mov	r0,#_serial_flush___1310720068_131072_208
      002C6D E2               [24] 3339 	movx	a,@r0
      002C6E 70 49            [24] 3340 	jnz	00112$
      002C70 90 F0 B7         [24] 3341 	mov	dptr,#_subg_rfspy_should_exit
      002C73 E0               [24] 3342 	movx	a,@dptr
      002C74 70 43            [24] 3343 	jnz	00112$
                                   3344 ;	./timer.h:22: EA = 0;
                                   3345 ;	assignBit
      002C76 C2 AF            [12] 3346 	clr	_EA
                                   3347 ;	./timer.h:23: rval = (__timerCounter - start_time) > duration;
      002C78 78 2E            [12] 3348 	mov	r0,#___timerCounter
      002C7A 79 A5            [12] 3349 	mov	r1,#_serial_flush_start_time_65536_208
      002C7C E3               [24] 3350 	movx	a,@r1
      002C7D F5 F0            [12] 3351 	mov	b,a
      002C7F C3               [12] 3352 	clr	c
      002C80 E2               [24] 3353 	movx	a,@r0
      002C81 95 F0            [12] 3354 	subb	a,b
      002C83 FC               [12] 3355 	mov	r4,a
      002C84 09               [12] 3356 	inc	r1
      002C85 E3               [24] 3357 	movx	a,@r1
      002C86 F5 F0            [12] 3358 	mov	b,a
      002C88 08               [12] 3359 	inc	r0
      002C89 E2               [24] 3360 	movx	a,@r0
      002C8A 95 F0            [12] 3361 	subb	a,b
      002C8C FD               [12] 3362 	mov	r5,a
      002C8D 09               [12] 3363 	inc	r1
      002C8E E3               [24] 3364 	movx	a,@r1
      002C8F F5 F0            [12] 3365 	mov	b,a
      002C91 08               [12] 3366 	inc	r0
      002C92 E2               [24] 3367 	movx	a,@r0
      002C93 95 F0            [12] 3368 	subb	a,b
      002C95 FE               [12] 3369 	mov	r6,a
      002C96 09               [12] 3370 	inc	r1
      002C97 E3               [24] 3371 	movx	a,@r1
      002C98 F5 F0            [12] 3372 	mov	b,a
      002C9A 08               [12] 3373 	inc	r0
      002C9B E2               [24] 3374 	movx	a,@r0
      002C9C 95 F0            [12] 3375 	subb	a,b
      002C9E FF               [12] 3376 	mov	r7,a
      002C9F 78 A9            [12] 3377 	mov	r0,#_serial_flush_rval_327680_231
      002CA1 C3               [12] 3378 	clr	c
      002CA2 74 88            [12] 3379 	mov	a,#0x88
      002CA4 9C               [12] 3380 	subb	a,r4
      002CA5 74 13            [12] 3381 	mov	a,#0x13
      002CA7 9D               [12] 3382 	subb	a,r5
      002CA8 E4               [12] 3383 	clr	a
      002CA9 9E               [12] 3384 	subb	a,r6
      002CAA E4               [12] 3385 	clr	a
      002CAB 9F               [12] 3386 	subb	a,r7
      002CAC E4               [12] 3387 	clr	a
      002CAD 33               [12] 3388 	rlc	a
      002CAE F2               [24] 3389 	movx	@r0,a
                                   3390 ;	./timer.h:24: EA = 1;
                                   3391 ;	assignBit
      002CAF D2 AF            [12] 3392 	setb	_EA
                                   3393 ;	spi1_alt2/serial.c:255: if (check_elapsed(start_time, FLUSH_TIMEOUT_MS)) {
      002CB1 78 A9            [12] 3394 	mov	r0,#_serial_flush_rval_327680_231
      002CB3 E2               [24] 3395 	movx	a,@r0
      002CB4 70 03            [24] 3396 	jnz	00185$
      002CB6 02 2C 34         [24] 3397 	ljmp	00106$
      002CB9                       3398 00185$:
                                   3399 ;	spi1_alt2/serial.c:261: while(slave_send_size != 0 && !subg_rfspy_should_exit) {
      002CB9                       3400 00112$:
      002CB9 78 75            [12] 3401 	mov	r0,#_slave_send_size
      002CBB E2               [24] 3402 	movx	a,@r0
      002CBC 60 46            [24] 3403 	jz	00114$
      002CBE 90 F0 B7         [24] 3404 	mov	dptr,#_subg_rfspy_should_exit
      002CC1 E0               [24] 3405 	movx	a,@dptr
      002CC2 70 40            [24] 3406 	jnz	00114$
                                   3407 ;	./timer.h:22: EA = 0;
                                   3408 ;	assignBit
      002CC4 C2 AF            [12] 3409 	clr	_EA
                                   3410 ;	./timer.h:23: rval = (__timerCounter - start_time) > duration;
      002CC6 78 2E            [12] 3411 	mov	r0,#___timerCounter
      002CC8 79 A5            [12] 3412 	mov	r1,#_serial_flush_start_time_65536_208
      002CCA E3               [24] 3413 	movx	a,@r1
      002CCB F5 F0            [12] 3414 	mov	b,a
      002CCD C3               [12] 3415 	clr	c
      002CCE E2               [24] 3416 	movx	a,@r0
      002CCF 95 F0            [12] 3417 	subb	a,b
      002CD1 FC               [12] 3418 	mov	r4,a
      002CD2 09               [12] 3419 	inc	r1
      002CD3 E3               [24] 3420 	movx	a,@r1
      002CD4 F5 F0            [12] 3421 	mov	b,a
      002CD6 08               [12] 3422 	inc	r0
      002CD7 E2               [24] 3423 	movx	a,@r0
      002CD8 95 F0            [12] 3424 	subb	a,b
      002CDA FD               [12] 3425 	mov	r5,a
      002CDB 09               [12] 3426 	inc	r1
      002CDC E3               [24] 3427 	movx	a,@r1
      002CDD F5 F0            [12] 3428 	mov	b,a
      002CDF 08               [12] 3429 	inc	r0
      002CE0 E2               [24] 3430 	movx	a,@r0
      002CE1 95 F0            [12] 3431 	subb	a,b
      002CE3 FE               [12] 3432 	mov	r6,a
      002CE4 09               [12] 3433 	inc	r1
      002CE5 E3               [24] 3434 	movx	a,@r1
      002CE6 F5 F0            [12] 3435 	mov	b,a
      002CE8 08               [12] 3436 	inc	r0
      002CE9 E2               [24] 3437 	movx	a,@r0
      002CEA 95 F0            [12] 3438 	subb	a,b
      002CEC FF               [12] 3439 	mov	r7,a
      002CED 78 AA            [12] 3440 	mov	r0,#_serial_flush_rval_327680_234
      002CEF C3               [12] 3441 	clr	c
      002CF0 74 88            [12] 3442 	mov	a,#0x88
      002CF2 9C               [12] 3443 	subb	a,r4
      002CF3 74 13            [12] 3444 	mov	a,#0x13
      002CF5 9D               [12] 3445 	subb	a,r5
      002CF6 E4               [12] 3446 	clr	a
      002CF7 9E               [12] 3447 	subb	a,r6
      002CF8 E4               [12] 3448 	clr	a
      002CF9 9F               [12] 3449 	subb	a,r7
      002CFA E4               [12] 3450 	clr	a
      002CFB 33               [12] 3451 	rlc	a
      002CFC F2               [24] 3452 	movx	@r0,a
                                   3453 ;	./timer.h:24: EA = 1;
                                   3454 ;	assignBit
      002CFD D2 AF            [12] 3455 	setb	_EA
                                   3456 ;	spi1_alt2/serial.c:263: if (check_elapsed(start_time, FLUSH_TIMEOUT_MS)) {
      002CFF 78 AA            [12] 3457 	mov	r0,#_serial_flush_rval_327680_234
      002D01 E2               [24] 3458 	movx	a,@r0
      002D02 60 B5            [24] 3459 	jz	00112$
                                   3460 ;	spi1_alt2/serial.c:264: break;
      002D04                       3461 00114$:
                                   3462 ;	spi1_alt2/serial.c:267: ready_to_send = 0;
      002D04 78 71            [12] 3463 	mov	r0,#_ready_to_send
      002D06 E4               [12] 3464 	clr	a
      002D07 F2               [24] 3465 	movx	@r0,a
                                   3466 ;	spi1_alt2/serial.c:268: }
      002D08 22               [24] 3467 	ret
                                   3468 ;------------------------------------------------------------
                                   3469 ;Allocation info for local variables in function 'serial_tx_str'
                                   3470 ;------------------------------------------------------------
                                   3471 ;	spi1_alt2/serial.c:270: void serial_tx_str(const char *str) {
                                   3472 ;	-----------------------------------------
                                   3473 ;	 function serial_tx_str
                                   3474 ;	-----------------------------------------
      002D09                       3475 _serial_tx_str:
      002D09 AD 82            [24] 3476 	mov	r5,dpl
      002D0B AE 83            [24] 3477 	mov	r6,dph
      002D0D AF F0            [24] 3478 	mov	r7,b
                                   3479 ;	spi1_alt2/serial.c:271: while(*str != 0) {
      002D0F                       3480 00101$:
      002D0F 8D 82            [24] 3481 	mov	dpl,r5
      002D11 8E 83            [24] 3482 	mov	dph,r6
      002D13 8F F0            [24] 3483 	mov	b,r7
      002D15 12 2E 55         [24] 3484 	lcall	__gptrget
      002D18 FC               [12] 3485 	mov	r4,a
      002D19 60 18            [24] 3486 	jz	00103$
                                   3487 ;	spi1_alt2/serial.c:272: serial_tx_byte(*str);
      002D1B 8C 82            [24] 3488 	mov	dpl,r4
      002D1D C0 07            [24] 3489 	push	ar7
      002D1F C0 06            [24] 3490 	push	ar6
      002D21 C0 05            [24] 3491 	push	ar5
      002D23 12 24 7F         [24] 3492 	lcall	_serial_tx_byte
      002D26 D0 05            [24] 3493 	pop	ar5
      002D28 D0 06            [24] 3494 	pop	ar6
      002D2A D0 07            [24] 3495 	pop	ar7
                                   3496 ;	spi1_alt2/serial.c:273: str++;
      002D2C 0D               [12] 3497 	inc	r5
      002D2D BD 00 DF         [24] 3498 	cjne	r5,#0x00,00101$
      002D30 0E               [12] 3499 	inc	r6
      002D31 80 DC            [24] 3500 	sjmp	00101$
      002D33                       3501 00103$:
                                   3502 ;	spi1_alt2/serial.c:275: serial_flush();
                                   3503 ;	spi1_alt2/serial.c:276: }
      002D33 02 2B DC         [24] 3504 	ljmp	_serial_flush
                                   3505 	.area CSEG    (CODE)
                                   3506 	.area CONST   (CODE)
                                   3507 	.area XINIT   (CODE)
                                   3508 	.area CABS    (ABS,CODE)
