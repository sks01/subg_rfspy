                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.0.2 #11662 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module encoding
                                      6 	.optsdcc -mmcs51 --model-medium
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _fourbsixb_next_decoded_byte
                                     12 	.globl _fourbsixb_add_encoded_byte
                                     13 	.globl _fourbsixb_init_decoder
                                     14 	.globl _fourbsixb_next_encoded_byte
                                     15 	.globl _fourbsixb_add_raw_byte
                                     16 	.globl _fourbsixb_init_encoder
                                     17 	.globl _manchester_next_decoded_byte
                                     18 	.globl _manchester_add_encoded_byte
                                     19 	.globl _manchester_init_decoder
                                     20 	.globl _manchester_next_encoded_byte
                                     21 	.globl _manchester_add_raw_byte
                                     22 	.globl _manchester_init_encoder
                                     23 	.globl _MODE
                                     24 	.globl _RE
                                     25 	.globl _SLAVE
                                     26 	.globl _FE
                                     27 	.globl _ERR
                                     28 	.globl _RX_BYTE
                                     29 	.globl _TX_BYTE
                                     30 	.globl _ACTIVE
                                     31 	.globl _B_7
                                     32 	.globl _B_6
                                     33 	.globl _B_5
                                     34 	.globl _B_4
                                     35 	.globl _B_3
                                     36 	.globl _B_2
                                     37 	.globl _B_1
                                     38 	.globl _B_0
                                     39 	.globl _WDTIF
                                     40 	.globl _P1IF
                                     41 	.globl _UTX1IF
                                     42 	.globl _UTX0IF
                                     43 	.globl _P2IF
                                     44 	.globl _ACC_7
                                     45 	.globl _ACC_6
                                     46 	.globl _ACC_5
                                     47 	.globl _ACC_4
                                     48 	.globl _ACC_3
                                     49 	.globl _ACC_2
                                     50 	.globl _ACC_1
                                     51 	.globl _ACC_0
                                     52 	.globl _OVFIM
                                     53 	.globl _T4CH1IF
                                     54 	.globl _T4CH0IF
                                     55 	.globl _T4OVFIF
                                     56 	.globl _T3CH1IF
                                     57 	.globl _T3CH0IF
                                     58 	.globl _T3OVFIF
                                     59 	.globl _CY
                                     60 	.globl _AC
                                     61 	.globl _F0
                                     62 	.globl _RS1
                                     63 	.globl _RS0
                                     64 	.globl _OV
                                     65 	.globl _F1
                                     66 	.globl _P
                                     67 	.globl _STIF
                                     68 	.globl _P0IF
                                     69 	.globl _T4IF
                                     70 	.globl _T3IF
                                     71 	.globl _T2IF
                                     72 	.globl _T1IF
                                     73 	.globl _DMAIF
                                     74 	.globl _P0IE
                                     75 	.globl _T4IE
                                     76 	.globl _T3IE
                                     77 	.globl _T2IE
                                     78 	.globl _T1IE
                                     79 	.globl _DMAIE
                                     80 	.globl _EA
                                     81 	.globl _STIE
                                     82 	.globl _ENCIE
                                     83 	.globl _URX1IE
                                     84 	.globl _URX0IE
                                     85 	.globl _ADCIE
                                     86 	.globl _RFTXRXIE
                                     87 	.globl _P2_7
                                     88 	.globl _P2_6
                                     89 	.globl _P2_5
                                     90 	.globl _P2_4
                                     91 	.globl _P2_3
                                     92 	.globl _P2_2
                                     93 	.globl _P2_1
                                     94 	.globl _P2_0
                                     95 	.globl _ENCIF_1
                                     96 	.globl _ENCIF_0
                                     97 	.globl _P1_7
                                     98 	.globl _P1_6
                                     99 	.globl _P1_5
                                    100 	.globl _P1_4
                                    101 	.globl _P1_3
                                    102 	.globl _P1_2
                                    103 	.globl _P1_1
                                    104 	.globl _P1_0
                                    105 	.globl _URX1IF
                                    106 	.globl _ADCIF
                                    107 	.globl _URX0IF
                                    108 	.globl _IT1
                                    109 	.globl _RFTXRXIF
                                    110 	.globl _IT0
                                    111 	.globl _P0_7
                                    112 	.globl _P0_6
                                    113 	.globl _P0_5
                                    114 	.globl _P0_4
                                    115 	.globl _P0_3
                                    116 	.globl _P0_2
                                    117 	.globl _P0_1
                                    118 	.globl _P0_0
                                    119 	.globl _P2DIR
                                    120 	.globl _P1DIR
                                    121 	.globl _P0DIR
                                    122 	.globl _U1GCR
                                    123 	.globl _U1UCR
                                    124 	.globl _U1BAUD
                                    125 	.globl _U1DBUF
                                    126 	.globl _U1CSR
                                    127 	.globl _P2INP
                                    128 	.globl _P1INP
                                    129 	.globl _P2SEL
                                    130 	.globl _P1SEL
                                    131 	.globl _P0SEL
                                    132 	.globl _ADCCFG
                                    133 	.globl _PERCFG
                                    134 	.globl _B
                                    135 	.globl _T4CC1
                                    136 	.globl _T4CCTL1
                                    137 	.globl _T4CC0
                                    138 	.globl _T4CCTL0
                                    139 	.globl _T4CTL
                                    140 	.globl _T4CNT
                                    141 	.globl _RFIF
                                    142 	.globl _IRCON2
                                    143 	.globl _T1CCTL2
                                    144 	.globl _T1CCTL1
                                    145 	.globl _T1CCTL0
                                    146 	.globl _T1CTL
                                    147 	.globl _T1CNTH
                                    148 	.globl _T1CNTL
                                    149 	.globl _RFST
                                    150 	.globl _ACC
                                    151 	.globl _T1CC2H
                                    152 	.globl _T1CC2L
                                    153 	.globl _T1CC1H
                                    154 	.globl _T1CC1L
                                    155 	.globl _T1CC0H
                                    156 	.globl _T1CC0L
                                    157 	.globl _RFD
                                    158 	.globl _TIMIF
                                    159 	.globl _DMAREQ
                                    160 	.globl _DMAARM
                                    161 	.globl _DMA0CFGH
                                    162 	.globl _DMA0CFGL
                                    163 	.globl _DMA1CFGH
                                    164 	.globl _DMA1CFGL
                                    165 	.globl _DMAIRQ
                                    166 	.globl _PSW
                                    167 	.globl _T3CC1
                                    168 	.globl _T3CCTL1
                                    169 	.globl _T3CC0
                                    170 	.globl _T3CCTL0
                                    171 	.globl _T3CTL
                                    172 	.globl _T3CNT
                                    173 	.globl _WDCTL
                                    174 	.globl __SFRC8
                                    175 	.globl _MEMCTR
                                    176 	.globl _CLKCON
                                    177 	.globl _U0GCR
                                    178 	.globl _U0UCR
                                    179 	.globl __SFRC3
                                    180 	.globl _U0BAUD
                                    181 	.globl _U0DBUF
                                    182 	.globl _IRCON
                                    183 	.globl __SFRBF
                                    184 	.globl _SLEEP
                                    185 	.globl _RNDH
                                    186 	.globl _RNDL
                                    187 	.globl _ADCH
                                    188 	.globl _ADCL
                                    189 	.globl _IP1
                                    190 	.globl _IEN1
                                    191 	.globl __SFRB7
                                    192 	.globl _ADCCON3
                                    193 	.globl _ADCCON2
                                    194 	.globl _ADCCON1
                                    195 	.globl _ENCCS
                                    196 	.globl _ENCDO
                                    197 	.globl _ENCDI
                                    198 	.globl __SFRB0
                                    199 	.globl _FWDATA
                                    200 	.globl _FCTL
                                    201 	.globl _FADDRH
                                    202 	.globl _FADDRL
                                    203 	.globl _FWT
                                    204 	.globl __SFRAA
                                    205 	.globl _IP0
                                    206 	.globl _IEN0
                                    207 	.globl __SFRA7
                                    208 	.globl _WORTIME1
                                    209 	.globl _WORTIME0
                                    210 	.globl _WOREVT1
                                    211 	.globl _WOREVT0
                                    212 	.globl _WORCTRL
                                    213 	.globl _WORIRQ
                                    214 	.globl _P2
                                    215 	.globl __SFR9F
                                    216 	.globl _T2CTL
                                    217 	.globl _T2PR
                                    218 	.globl _T2CT
                                    219 	.globl _S1CON
                                    220 	.globl _IEN2
                                    221 	.globl __SFR99
                                    222 	.globl _S0CON
                                    223 	.globl __SFR97
                                    224 	.globl __SFR96
                                    225 	.globl __SFR95
                                    226 	.globl __SFR94
                                    227 	.globl __XPAGE
                                    228 	.globl _MPAGE
                                    229 	.globl _DPS
                                    230 	.globl _RFIM
                                    231 	.globl _P1
                                    232 	.globl _P0INP
                                    233 	.globl __SFR8E
                                    234 	.globl _P1IEN
                                    235 	.globl _PICTL
                                    236 	.globl _P2IFG
                                    237 	.globl _P1IFG
                                    238 	.globl _P0IFG
                                    239 	.globl _TCON
                                    240 	.globl _PCON
                                    241 	.globl _U0CSR
                                    242 	.globl _DPH1
                                    243 	.globl _DPL1
                                    244 	.globl _DPH0
                                    245 	.globl _DPL0
                                    246 	.globl _SP
                                    247 	.globl _P0
                                    248 	.globl _X_P2DIR
                                    249 	.globl _X_P1DIR
                                    250 	.globl _X_P0DIR
                                    251 	.globl _X_U1GCR
                                    252 	.globl _X_U1UCR
                                    253 	.globl _X_U1BAUD
                                    254 	.globl _X_U1DBUF
                                    255 	.globl _X_U1CSR
                                    256 	.globl _X_P2INP
                                    257 	.globl _X_P1INP
                                    258 	.globl _X_P2SEL
                                    259 	.globl _X_P1SEL
                                    260 	.globl _X_P0SEL
                                    261 	.globl _X_ADCCFG
                                    262 	.globl _X_PERCFG
                                    263 	.globl __NA_B
                                    264 	.globl _X_T4CC1
                                    265 	.globl _X_T4CCTL1
                                    266 	.globl _X_T4CC0
                                    267 	.globl _X_T4CCTL0
                                    268 	.globl _X_T4CTL
                                    269 	.globl _X_T4CNT
                                    270 	.globl _X_RFIF
                                    271 	.globl __NA_IRCON2
                                    272 	.globl _X_T1CCTL2
                                    273 	.globl _X_T1CCTL1
                                    274 	.globl _X_T1CCTL0
                                    275 	.globl _X_T1CTL
                                    276 	.globl _X_T1CNTH
                                    277 	.globl _X_T1CNTL
                                    278 	.globl _X_RFST
                                    279 	.globl __NA_ACC
                                    280 	.globl _X_T1CC2H
                                    281 	.globl _X_T1CC2L
                                    282 	.globl _X_T1CC1H
                                    283 	.globl _X_T1CC1L
                                    284 	.globl _X_T1CC0H
                                    285 	.globl _X_T1CC0L
                                    286 	.globl _X_RFD
                                    287 	.globl _X_TIMIF
                                    288 	.globl _X_DMAREQ
                                    289 	.globl _X_DMAARM
                                    290 	.globl _X_DMA0CFGH
                                    291 	.globl _X_DMA0CFGL
                                    292 	.globl _X_DMA1CFGH
                                    293 	.globl _X_DMA1CFGL
                                    294 	.globl _X_DMAIRQ
                                    295 	.globl __NA_PSW
                                    296 	.globl _X_T3CC1
                                    297 	.globl _X_T3CCTL1
                                    298 	.globl _X_T3CC0
                                    299 	.globl _X_T3CCTL0
                                    300 	.globl _X_T3CTL
                                    301 	.globl _X_T3CNT
                                    302 	.globl _X_WDCTL
                                    303 	.globl __X_SFRC8
                                    304 	.globl _X_MEMCTR
                                    305 	.globl _X_CLKCON
                                    306 	.globl _X_U0GCR
                                    307 	.globl _X_U0UCR
                                    308 	.globl __X_SFRC3
                                    309 	.globl _X_U0BAUD
                                    310 	.globl _X_U0DBUF
                                    311 	.globl __NA_IRCON
                                    312 	.globl __X_SFRBF
                                    313 	.globl _X_SLEEP
                                    314 	.globl _X_RNDH
                                    315 	.globl _X_RNDL
                                    316 	.globl _X_ADCH
                                    317 	.globl _X_ADCL
                                    318 	.globl __NA_IP1
                                    319 	.globl __NA_IEN1
                                    320 	.globl __X_SFRB7
                                    321 	.globl _X_ADCCON3
                                    322 	.globl _X_ADCCON2
                                    323 	.globl _X_ADCCON1
                                    324 	.globl _X_ENCCS
                                    325 	.globl _X_ENCDO
                                    326 	.globl _X_ENCDI
                                    327 	.globl __X_SFRB0
                                    328 	.globl _X_FWDATA
                                    329 	.globl _X_FCTL
                                    330 	.globl _X_FADDRH
                                    331 	.globl _X_FADDRL
                                    332 	.globl _X_FWT
                                    333 	.globl __X_SFRAA
                                    334 	.globl __NA_IP0
                                    335 	.globl __NA_IEN0
                                    336 	.globl __X_SFRA7
                                    337 	.globl _X_WORTIME1
                                    338 	.globl _X_WORTIME0
                                    339 	.globl _X_WOREVT1
                                    340 	.globl _X_WOREVT0
                                    341 	.globl _X_WORCTRL
                                    342 	.globl _X_WORIRQ
                                    343 	.globl __NA_P2
                                    344 	.globl __X_SFR9F
                                    345 	.globl _X_T2CTL
                                    346 	.globl _X_T2PR
                                    347 	.globl _X_T2CT
                                    348 	.globl __NA_S1CON
                                    349 	.globl __NA_IEN2
                                    350 	.globl __X_SFR99
                                    351 	.globl __NA_S0CON
                                    352 	.globl __X_SFR97
                                    353 	.globl __X_SFR96
                                    354 	.globl __X_SFR95
                                    355 	.globl __X_SFR94
                                    356 	.globl _X_MPAGE
                                    357 	.globl __NA_DPS
                                    358 	.globl _X_RFIM
                                    359 	.globl __NA_P1
                                    360 	.globl _X_P0INP
                                    361 	.globl __X_SFR8E
                                    362 	.globl _X_P1IEN
                                    363 	.globl _X_PICTL
                                    364 	.globl _X_P2IFG
                                    365 	.globl _X_P1IFG
                                    366 	.globl _X_P0IFG
                                    367 	.globl __NA_TCON
                                    368 	.globl __NA_PCON
                                    369 	.globl _X_U0CSR
                                    370 	.globl __NA_DPH1
                                    371 	.globl __NA_DPL1
                                    372 	.globl __NA_DPH0
                                    373 	.globl __NA_DPL0
                                    374 	.globl __NA_SP
                                    375 	.globl __NA_P0
                                    376 	.globl _I2SCLKF2
                                    377 	.globl _I2SCLKF1
                                    378 	.globl _I2SCLKF0
                                    379 	.globl _I2SSTAT
                                    380 	.globl _I2SWCNT
                                    381 	.globl _I2SDATH
                                    382 	.globl _I2SDATL
                                    383 	.globl _I2SCFG1
                                    384 	.globl _I2SCFG0
                                    385 	.globl _VCO_VC_DAC
                                    386 	.globl _PKTSTATUS
                                    387 	.globl _MARCSTATE
                                    388 	.globl _RSSI
                                    389 	.globl _LQI
                                    390 	.globl _FREQEST
                                    391 	.globl _VERSION
                                    392 	.globl _PARTNUM
                                    393 	.globl __XREGDF35
                                    394 	.globl __XREGDF34
                                    395 	.globl __XREGDF33
                                    396 	.globl __XREGDF32
                                    397 	.globl _IOCFG0
                                    398 	.globl _IOCFG1
                                    399 	.globl _IOCFG2
                                    400 	.globl _PA_TABLE0
                                    401 	.globl _PA_TABLE1
                                    402 	.globl _PA_TABLE2
                                    403 	.globl _PA_TABLE3
                                    404 	.globl _PA_TABLE4
                                    405 	.globl _PA_TABLE5
                                    406 	.globl _PA_TABLE6
                                    407 	.globl _PA_TABLE7
                                    408 	.globl __XREGDF26
                                    409 	.globl _TEST0
                                    410 	.globl _TEST1
                                    411 	.globl _TEST2
                                    412 	.globl __XREGDF22
                                    413 	.globl __XREGDF21
                                    414 	.globl __XREGDF20
                                    415 	.globl _FSCAL0
                                    416 	.globl _FSCAL1
                                    417 	.globl _FSCAL2
                                    418 	.globl _FSCAL3
                                    419 	.globl _FREND0
                                    420 	.globl _FREND1
                                    421 	.globl _AGCCTRL0
                                    422 	.globl _AGCCTRL1
                                    423 	.globl _AGCCTRL2
                                    424 	.globl _BSCFG
                                    425 	.globl _FOCCFG
                                    426 	.globl _MCSM0
                                    427 	.globl _MCSM1
                                    428 	.globl _MCSM2
                                    429 	.globl _DEVIATN
                                    430 	.globl _MDMCFG0
                                    431 	.globl _MDMCFG1
                                    432 	.globl _MDMCFG2
                                    433 	.globl _MDMCFG3
                                    434 	.globl _MDMCFG4
                                    435 	.globl _FREQ0
                                    436 	.globl _FREQ1
                                    437 	.globl _FREQ2
                                    438 	.globl _FSCTRL0
                                    439 	.globl _FSCTRL1
                                    440 	.globl _CHANNR
                                    441 	.globl _ADDR
                                    442 	.globl _PKTCTRL0
                                    443 	.globl _PKTCTRL1
                                    444 	.globl _PKTLEN
                                    445 	.globl _SYNC0
                                    446 	.globl _SYNC1
                                    447 	.globl _MDMCTRL0H
                                    448 	.globl _init_decoder_PARM_3
                                    449 	.globl _init_decoder_PARM_2
                                    450 	.globl _init_encoder_PARM_3
                                    451 	.globl _init_encoder_PARM_2
                                    452 	.globl _init_encoder
                                    453 	.globl _init_decoder
                                    454 ;--------------------------------------------------------
                                    455 ; special function registers
                                    456 ;--------------------------------------------------------
                                    457 	.area RSEG    (ABS,DATA)
      000000                        458 	.org 0x0000
                           000080   459 _P0	=	0x0080
                           000081   460 _SP	=	0x0081
                           000082   461 _DPL0	=	0x0082
                           000083   462 _DPH0	=	0x0083
                           000084   463 _DPL1	=	0x0084
                           000085   464 _DPH1	=	0x0085
                           000086   465 _U0CSR	=	0x0086
                           000087   466 _PCON	=	0x0087
                           000088   467 _TCON	=	0x0088
                           000089   468 _P0IFG	=	0x0089
                           00008A   469 _P1IFG	=	0x008a
                           00008B   470 _P2IFG	=	0x008b
                           00008C   471 _PICTL	=	0x008c
                           00008D   472 _P1IEN	=	0x008d
                           00008E   473 __SFR8E	=	0x008e
                           00008F   474 _P0INP	=	0x008f
                           000090   475 _P1	=	0x0090
                           000091   476 _RFIM	=	0x0091
                           000092   477 _DPS	=	0x0092
                           000093   478 _MPAGE	=	0x0093
                           000093   479 __XPAGE	=	0x0093
                           000094   480 __SFR94	=	0x0094
                           000095   481 __SFR95	=	0x0095
                           000096   482 __SFR96	=	0x0096
                           000097   483 __SFR97	=	0x0097
                           000098   484 _S0CON	=	0x0098
                           000099   485 __SFR99	=	0x0099
                           00009A   486 _IEN2	=	0x009a
                           00009B   487 _S1CON	=	0x009b
                           00009C   488 _T2CT	=	0x009c
                           00009D   489 _T2PR	=	0x009d
                           00009E   490 _T2CTL	=	0x009e
                           00009F   491 __SFR9F	=	0x009f
                           0000A0   492 _P2	=	0x00a0
                           0000A1   493 _WORIRQ	=	0x00a1
                           0000A2   494 _WORCTRL	=	0x00a2
                           0000A3   495 _WOREVT0	=	0x00a3
                           0000A4   496 _WOREVT1	=	0x00a4
                           0000A5   497 _WORTIME0	=	0x00a5
                           0000A6   498 _WORTIME1	=	0x00a6
                           0000A7   499 __SFRA7	=	0x00a7
                           0000A8   500 _IEN0	=	0x00a8
                           0000A9   501 _IP0	=	0x00a9
                           0000AA   502 __SFRAA	=	0x00aa
                           0000AB   503 _FWT	=	0x00ab
                           0000AC   504 _FADDRL	=	0x00ac
                           0000AD   505 _FADDRH	=	0x00ad
                           0000AE   506 _FCTL	=	0x00ae
                           0000AF   507 _FWDATA	=	0x00af
                           0000B0   508 __SFRB0	=	0x00b0
                           0000B1   509 _ENCDI	=	0x00b1
                           0000B2   510 _ENCDO	=	0x00b2
                           0000B3   511 _ENCCS	=	0x00b3
                           0000B4   512 _ADCCON1	=	0x00b4
                           0000B5   513 _ADCCON2	=	0x00b5
                           0000B6   514 _ADCCON3	=	0x00b6
                           0000B7   515 __SFRB7	=	0x00b7
                           0000B8   516 _IEN1	=	0x00b8
                           0000B9   517 _IP1	=	0x00b9
                           0000BA   518 _ADCL	=	0x00ba
                           0000BB   519 _ADCH	=	0x00bb
                           0000BC   520 _RNDL	=	0x00bc
                           0000BD   521 _RNDH	=	0x00bd
                           0000BE   522 _SLEEP	=	0x00be
                           0000BF   523 __SFRBF	=	0x00bf
                           0000C0   524 _IRCON	=	0x00c0
                           0000C1   525 _U0DBUF	=	0x00c1
                           0000C2   526 _U0BAUD	=	0x00c2
                           0000C3   527 __SFRC3	=	0x00c3
                           0000C4   528 _U0UCR	=	0x00c4
                           0000C5   529 _U0GCR	=	0x00c5
                           0000C6   530 _CLKCON	=	0x00c6
                           0000C7   531 _MEMCTR	=	0x00c7
                           0000C8   532 __SFRC8	=	0x00c8
                           0000C9   533 _WDCTL	=	0x00c9
                           0000CA   534 _T3CNT	=	0x00ca
                           0000CB   535 _T3CTL	=	0x00cb
                           0000CC   536 _T3CCTL0	=	0x00cc
                           0000CD   537 _T3CC0	=	0x00cd
                           0000CE   538 _T3CCTL1	=	0x00ce
                           0000CF   539 _T3CC1	=	0x00cf
                           0000D0   540 _PSW	=	0x00d0
                           0000D1   541 _DMAIRQ	=	0x00d1
                           0000D2   542 _DMA1CFGL	=	0x00d2
                           0000D3   543 _DMA1CFGH	=	0x00d3
                           0000D4   544 _DMA0CFGL	=	0x00d4
                           0000D5   545 _DMA0CFGH	=	0x00d5
                           0000D6   546 _DMAARM	=	0x00d6
                           0000D7   547 _DMAREQ	=	0x00d7
                           0000D8   548 _TIMIF	=	0x00d8
                           0000D9   549 _RFD	=	0x00d9
                           0000DA   550 _T1CC0L	=	0x00da
                           0000DB   551 _T1CC0H	=	0x00db
                           0000DC   552 _T1CC1L	=	0x00dc
                           0000DD   553 _T1CC1H	=	0x00dd
                           0000DE   554 _T1CC2L	=	0x00de
                           0000DF   555 _T1CC2H	=	0x00df
                           0000E0   556 _ACC	=	0x00e0
                           0000E1   557 _RFST	=	0x00e1
                           0000E2   558 _T1CNTL	=	0x00e2
                           0000E3   559 _T1CNTH	=	0x00e3
                           0000E4   560 _T1CTL	=	0x00e4
                           0000E5   561 _T1CCTL0	=	0x00e5
                           0000E6   562 _T1CCTL1	=	0x00e6
                           0000E7   563 _T1CCTL2	=	0x00e7
                           0000E8   564 _IRCON2	=	0x00e8
                           0000E9   565 _RFIF	=	0x00e9
                           0000EA   566 _T4CNT	=	0x00ea
                           0000EB   567 _T4CTL	=	0x00eb
                           0000EC   568 _T4CCTL0	=	0x00ec
                           0000ED   569 _T4CC0	=	0x00ed
                           0000EE   570 _T4CCTL1	=	0x00ee
                           0000EF   571 _T4CC1	=	0x00ef
                           0000F0   572 _B	=	0x00f0
                           0000F1   573 _PERCFG	=	0x00f1
                           0000F2   574 _ADCCFG	=	0x00f2
                           0000F3   575 _P0SEL	=	0x00f3
                           0000F4   576 _P1SEL	=	0x00f4
                           0000F5   577 _P2SEL	=	0x00f5
                           0000F6   578 _P1INP	=	0x00f6
                           0000F7   579 _P2INP	=	0x00f7
                           0000F8   580 _U1CSR	=	0x00f8
                           0000F9   581 _U1DBUF	=	0x00f9
                           0000FA   582 _U1BAUD	=	0x00fa
                           0000FB   583 _U1UCR	=	0x00fb
                           0000FC   584 _U1GCR	=	0x00fc
                           0000FD   585 _P0DIR	=	0x00fd
                           0000FE   586 _P1DIR	=	0x00fe
                           0000FF   587 _P2DIR	=	0x00ff
                                    588 ;--------------------------------------------------------
                                    589 ; special function bits
                                    590 ;--------------------------------------------------------
                                    591 	.area RSEG    (ABS,DATA)
      000000                        592 	.org 0x0000
                           000080   593 _P0_0	=	0x0080
                           000081   594 _P0_1	=	0x0081
                           000082   595 _P0_2	=	0x0082
                           000083   596 _P0_3	=	0x0083
                           000084   597 _P0_4	=	0x0084
                           000085   598 _P0_5	=	0x0085
                           000086   599 _P0_6	=	0x0086
                           000087   600 _P0_7	=	0x0087
                           000088   601 _IT0	=	0x0088
                           000089   602 _RFTXRXIF	=	0x0089
                           00008A   603 _IT1	=	0x008a
                           00008B   604 _URX0IF	=	0x008b
                           00008D   605 _ADCIF	=	0x008d
                           00008F   606 _URX1IF	=	0x008f
                           000090   607 _P1_0	=	0x0090
                           000091   608 _P1_1	=	0x0091
                           000092   609 _P1_2	=	0x0092
                           000093   610 _P1_3	=	0x0093
                           000094   611 _P1_4	=	0x0094
                           000095   612 _P1_5	=	0x0095
                           000096   613 _P1_6	=	0x0096
                           000097   614 _P1_7	=	0x0097
                           000098   615 _ENCIF_0	=	0x0098
                           000099   616 _ENCIF_1	=	0x0099
                           0000A0   617 _P2_0	=	0x00a0
                           0000A1   618 _P2_1	=	0x00a1
                           0000A2   619 _P2_2	=	0x00a2
                           0000A3   620 _P2_3	=	0x00a3
                           0000A4   621 _P2_4	=	0x00a4
                           0000A5   622 _P2_5	=	0x00a5
                           0000A6   623 _P2_6	=	0x00a6
                           0000A7   624 _P2_7	=	0x00a7
                           0000A8   625 _RFTXRXIE	=	0x00a8
                           0000A9   626 _ADCIE	=	0x00a9
                           0000AA   627 _URX0IE	=	0x00aa
                           0000AB   628 _URX1IE	=	0x00ab
                           0000AC   629 _ENCIE	=	0x00ac
                           0000AD   630 _STIE	=	0x00ad
                           0000AF   631 _EA	=	0x00af
                           0000B8   632 _DMAIE	=	0x00b8
                           0000B9   633 _T1IE	=	0x00b9
                           0000BA   634 _T2IE	=	0x00ba
                           0000BB   635 _T3IE	=	0x00bb
                           0000BC   636 _T4IE	=	0x00bc
                           0000BD   637 _P0IE	=	0x00bd
                           0000C0   638 _DMAIF	=	0x00c0
                           0000C1   639 _T1IF	=	0x00c1
                           0000C2   640 _T2IF	=	0x00c2
                           0000C3   641 _T3IF	=	0x00c3
                           0000C4   642 _T4IF	=	0x00c4
                           0000C5   643 _P0IF	=	0x00c5
                           0000C7   644 _STIF	=	0x00c7
                           0000D0   645 _P	=	0x00d0
                           0000D1   646 _F1	=	0x00d1
                           0000D2   647 _OV	=	0x00d2
                           0000D3   648 _RS0	=	0x00d3
                           0000D4   649 _RS1	=	0x00d4
                           0000D5   650 _F0	=	0x00d5
                           0000D6   651 _AC	=	0x00d6
                           0000D7   652 _CY	=	0x00d7
                           0000D8   653 _T3OVFIF	=	0x00d8
                           0000D9   654 _T3CH0IF	=	0x00d9
                           0000DA   655 _T3CH1IF	=	0x00da
                           0000DB   656 _T4OVFIF	=	0x00db
                           0000DC   657 _T4CH0IF	=	0x00dc
                           0000DD   658 _T4CH1IF	=	0x00dd
                           0000DE   659 _OVFIM	=	0x00de
                           0000E0   660 _ACC_0	=	0x00e0
                           0000E1   661 _ACC_1	=	0x00e1
                           0000E2   662 _ACC_2	=	0x00e2
                           0000E3   663 _ACC_3	=	0x00e3
                           0000E4   664 _ACC_4	=	0x00e4
                           0000E5   665 _ACC_5	=	0x00e5
                           0000E6   666 _ACC_6	=	0x00e6
                           0000E7   667 _ACC_7	=	0x00e7
                           0000E8   668 _P2IF	=	0x00e8
                           0000E9   669 _UTX0IF	=	0x00e9
                           0000EA   670 _UTX1IF	=	0x00ea
                           0000EB   671 _P1IF	=	0x00eb
                           0000EC   672 _WDTIF	=	0x00ec
                           0000F0   673 _B_0	=	0x00f0
                           0000F1   674 _B_1	=	0x00f1
                           0000F2   675 _B_2	=	0x00f2
                           0000F3   676 _B_3	=	0x00f3
                           0000F4   677 _B_4	=	0x00f4
                           0000F5   678 _B_5	=	0x00f5
                           0000F6   679 _B_6	=	0x00f6
                           0000F7   680 _B_7	=	0x00f7
                           0000F8   681 _ACTIVE	=	0x00f8
                           0000F9   682 _TX_BYTE	=	0x00f9
                           0000FA   683 _RX_BYTE	=	0x00fa
                           0000FB   684 _ERR	=	0x00fb
                           0000FC   685 _FE	=	0x00fc
                           0000FD   686 _SLAVE	=	0x00fd
                           0000FE   687 _RE	=	0x00fe
                           0000FF   688 _MODE	=	0x00ff
                                    689 ;--------------------------------------------------------
                                    690 ; overlayable register banks
                                    691 ;--------------------------------------------------------
                                    692 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        693 	.ds 8
                                    694 ;--------------------------------------------------------
                                    695 ; internal ram data
                                    696 ;--------------------------------------------------------
                                    697 	.area DSEG    (DATA)
                                    698 ;--------------------------------------------------------
                                    699 ; overlayable items in internal ram 
                                    700 ;--------------------------------------------------------
                                    701 ;--------------------------------------------------------
                                    702 ; indirectly addressable internal ram data
                                    703 ;--------------------------------------------------------
                                    704 	.area ISEG    (DATA)
                                    705 ;--------------------------------------------------------
                                    706 ; absolute internal ram data
                                    707 ;--------------------------------------------------------
                                    708 	.area IABS    (ABS,DATA)
                                    709 	.area IABS    (ABS,DATA)
                                    710 ;--------------------------------------------------------
                                    711 ; bit data
                                    712 ;--------------------------------------------------------
                                    713 	.area BSEG    (BIT)
                                    714 ;--------------------------------------------------------
                                    715 ; paged external ram data
                                    716 ;--------------------------------------------------------
                                    717 	.area PSEG    (PAG,XDATA)
      00F03D                        718 _init_encoder_PARM_2:
      00F03D                        719 	.ds 3
      00F040                        720 _init_encoder_PARM_3:
      00F040                        721 	.ds 3
      00F043                        722 _init_decoder_PARM_2:
      00F043                        723 	.ds 3
      00F046                        724 _init_decoder_PARM_3:
      00F046                        725 	.ds 3
                                    726 ;--------------------------------------------------------
                                    727 ; external ram data
                                    728 ;--------------------------------------------------------
                                    729 	.area XSEG    (XDATA)
                           00DF02   730 _MDMCTRL0H	=	0xdf02
                           00DF00   731 _SYNC1	=	0xdf00
                           00DF01   732 _SYNC0	=	0xdf01
                           00DF02   733 _PKTLEN	=	0xdf02
                           00DF03   734 _PKTCTRL1	=	0xdf03
                           00DF04   735 _PKTCTRL0	=	0xdf04
                           00DF05   736 _ADDR	=	0xdf05
                           00DF06   737 _CHANNR	=	0xdf06
                           00DF07   738 _FSCTRL1	=	0xdf07
                           00DF08   739 _FSCTRL0	=	0xdf08
                           00DF09   740 _FREQ2	=	0xdf09
                           00DF0A   741 _FREQ1	=	0xdf0a
                           00DF0B   742 _FREQ0	=	0xdf0b
                           00DF0C   743 _MDMCFG4	=	0xdf0c
                           00DF0D   744 _MDMCFG3	=	0xdf0d
                           00DF0E   745 _MDMCFG2	=	0xdf0e
                           00DF0F   746 _MDMCFG1	=	0xdf0f
                           00DF10   747 _MDMCFG0	=	0xdf10
                           00DF11   748 _DEVIATN	=	0xdf11
                           00DF12   749 _MCSM2	=	0xdf12
                           00DF13   750 _MCSM1	=	0xdf13
                           00DF14   751 _MCSM0	=	0xdf14
                           00DF15   752 _FOCCFG	=	0xdf15
                           00DF16   753 _BSCFG	=	0xdf16
                           00DF17   754 _AGCCTRL2	=	0xdf17
                           00DF18   755 _AGCCTRL1	=	0xdf18
                           00DF19   756 _AGCCTRL0	=	0xdf19
                           00DF1A   757 _FREND1	=	0xdf1a
                           00DF1B   758 _FREND0	=	0xdf1b
                           00DF1C   759 _FSCAL3	=	0xdf1c
                           00DF1D   760 _FSCAL2	=	0xdf1d
                           00DF1E   761 _FSCAL1	=	0xdf1e
                           00DF1F   762 _FSCAL0	=	0xdf1f
                           00DF20   763 __XREGDF20	=	0xdf20
                           00DF21   764 __XREGDF21	=	0xdf21
                           00DF22   765 __XREGDF22	=	0xdf22
                           00DF23   766 _TEST2	=	0xdf23
                           00DF24   767 _TEST1	=	0xdf24
                           00DF25   768 _TEST0	=	0xdf25
                           00DF26   769 __XREGDF26	=	0xdf26
                           00DF27   770 _PA_TABLE7	=	0xdf27
                           00DF28   771 _PA_TABLE6	=	0xdf28
                           00DF29   772 _PA_TABLE5	=	0xdf29
                           00DF2A   773 _PA_TABLE4	=	0xdf2a
                           00DF2B   774 _PA_TABLE3	=	0xdf2b
                           00DF2C   775 _PA_TABLE2	=	0xdf2c
                           00DF2D   776 _PA_TABLE1	=	0xdf2d
                           00DF2E   777 _PA_TABLE0	=	0xdf2e
                           00DF2F   778 _IOCFG2	=	0xdf2f
                           00DF30   779 _IOCFG1	=	0xdf30
                           00DF31   780 _IOCFG0	=	0xdf31
                           00DF32   781 __XREGDF32	=	0xdf32
                           00DF33   782 __XREGDF33	=	0xdf33
                           00DF34   783 __XREGDF34	=	0xdf34
                           00DF35   784 __XREGDF35	=	0xdf35
                           00DF36   785 _PARTNUM	=	0xdf36
                           00DF37   786 _VERSION	=	0xdf37
                           00DF38   787 _FREQEST	=	0xdf38
                           00DF39   788 _LQI	=	0xdf39
                           00DF3A   789 _RSSI	=	0xdf3a
                           00DF3B   790 _MARCSTATE	=	0xdf3b
                           00DF3C   791 _PKTSTATUS	=	0xdf3c
                           00DF3D   792 _VCO_VC_DAC	=	0xdf3d
                           00DF40   793 _I2SCFG0	=	0xdf40
                           00DF41   794 _I2SCFG1	=	0xdf41
                           00DF42   795 _I2SDATL	=	0xdf42
                           00DF43   796 _I2SDATH	=	0xdf43
                           00DF44   797 _I2SWCNT	=	0xdf44
                           00DF45   798 _I2SSTAT	=	0xdf45
                           00DF46   799 _I2SCLKF0	=	0xdf46
                           00DF47   800 _I2SCLKF1	=	0xdf47
                           00DF48   801 _I2SCLKF2	=	0xdf48
                           00DF80   802 __NA_P0	=	0xdf80
                           00DF81   803 __NA_SP	=	0xdf81
                           00DF82   804 __NA_DPL0	=	0xdf82
                           00DF83   805 __NA_DPH0	=	0xdf83
                           00DF84   806 __NA_DPL1	=	0xdf84
                           00DF85   807 __NA_DPH1	=	0xdf85
                           00DF86   808 _X_U0CSR	=	0xdf86
                           00DF87   809 __NA_PCON	=	0xdf87
                           00DF88   810 __NA_TCON	=	0xdf88
                           00DF89   811 _X_P0IFG	=	0xdf89
                           00DF8A   812 _X_P1IFG	=	0xdf8a
                           00DF8B   813 _X_P2IFG	=	0xdf8b
                           00DF8C   814 _X_PICTL	=	0xdf8c
                           00DF8D   815 _X_P1IEN	=	0xdf8d
                           00DF8E   816 __X_SFR8E	=	0xdf8e
                           00DF8F   817 _X_P0INP	=	0xdf8f
                           00DF90   818 __NA_P1	=	0xdf90
                           00DF91   819 _X_RFIM	=	0xdf91
                           00DF92   820 __NA_DPS	=	0xdf92
                           00DF93   821 _X_MPAGE	=	0xdf93
                           00DF94   822 __X_SFR94	=	0xdf94
                           00DF95   823 __X_SFR95	=	0xdf95
                           00DF96   824 __X_SFR96	=	0xdf96
                           00DF97   825 __X_SFR97	=	0xdf97
                           00DF98   826 __NA_S0CON	=	0xdf98
                           00DF99   827 __X_SFR99	=	0xdf99
                           00DF9A   828 __NA_IEN2	=	0xdf9a
                           00DF9B   829 __NA_S1CON	=	0xdf9b
                           00DF9C   830 _X_T2CT	=	0xdf9c
                           00DF9D   831 _X_T2PR	=	0xdf9d
                           00DF9E   832 _X_T2CTL	=	0xdf9e
                           00DF9F   833 __X_SFR9F	=	0xdf9f
                           00DFA0   834 __NA_P2	=	0xdfa0
                           00DFA1   835 _X_WORIRQ	=	0xdfa1
                           00DFA2   836 _X_WORCTRL	=	0xdfa2
                           00DFA3   837 _X_WOREVT0	=	0xdfa3
                           00DFA4   838 _X_WOREVT1	=	0xdfa4
                           00DFA5   839 _X_WORTIME0	=	0xdfa5
                           00DFA6   840 _X_WORTIME1	=	0xdfa6
                           00DFA7   841 __X_SFRA7	=	0xdfa7
                           00DFA8   842 __NA_IEN0	=	0xdfa8
                           00DFA9   843 __NA_IP0	=	0xdfa9
                           00DFAA   844 __X_SFRAA	=	0xdfaa
                           00DFAB   845 _X_FWT	=	0xdfab
                           00DFAC   846 _X_FADDRL	=	0xdfac
                           00DFAD   847 _X_FADDRH	=	0xdfad
                           00DFAE   848 _X_FCTL	=	0xdfae
                           00DFAF   849 _X_FWDATA	=	0xdfaf
                           00DFB0   850 __X_SFRB0	=	0xdfb0
                           00DFB1   851 _X_ENCDI	=	0xdfb1
                           00DFB2   852 _X_ENCDO	=	0xdfb2
                           00DFB3   853 _X_ENCCS	=	0xdfb3
                           00DFB4   854 _X_ADCCON1	=	0xdfb4
                           00DFB5   855 _X_ADCCON2	=	0xdfb5
                           00DFB6   856 _X_ADCCON3	=	0xdfb6
                           00DFB7   857 __X_SFRB7	=	0xdfb7
                           00DFB8   858 __NA_IEN1	=	0xdfb8
                           00DFB9   859 __NA_IP1	=	0xdfb9
                           00DFBA   860 _X_ADCL	=	0xdfba
                           00DFBB   861 _X_ADCH	=	0xdfbb
                           00DFBC   862 _X_RNDL	=	0xdfbc
                           00DFBD   863 _X_RNDH	=	0xdfbd
                           00DFBE   864 _X_SLEEP	=	0xdfbe
                           00DFBF   865 __X_SFRBF	=	0xdfbf
                           00DFC0   866 __NA_IRCON	=	0xdfc0
                           00DFC1   867 _X_U0DBUF	=	0xdfc1
                           00DFC2   868 _X_U0BAUD	=	0xdfc2
                           00DFC3   869 __X_SFRC3	=	0xdfc3
                           00DFC4   870 _X_U0UCR	=	0xdfc4
                           00DFC5   871 _X_U0GCR	=	0xdfc5
                           00DFC6   872 _X_CLKCON	=	0xdfc6
                           00DFC7   873 _X_MEMCTR	=	0xdfc7
                           00DFC8   874 __X_SFRC8	=	0xdfc8
                           00DFC9   875 _X_WDCTL	=	0xdfc9
                           00DFCA   876 _X_T3CNT	=	0xdfca
                           00DFCB   877 _X_T3CTL	=	0xdfcb
                           00DFCC   878 _X_T3CCTL0	=	0xdfcc
                           00DFCD   879 _X_T3CC0	=	0xdfcd
                           00DFCE   880 _X_T3CCTL1	=	0xdfce
                           00DFCF   881 _X_T3CC1	=	0xdfcf
                           00DFD0   882 __NA_PSW	=	0xdfd0
                           00DFD1   883 _X_DMAIRQ	=	0xdfd1
                           00DFD2   884 _X_DMA1CFGL	=	0xdfd2
                           00DFD3   885 _X_DMA1CFGH	=	0xdfd3
                           00DFD4   886 _X_DMA0CFGL	=	0xdfd4
                           00DFD5   887 _X_DMA0CFGH	=	0xdfd5
                           00DFD6   888 _X_DMAARM	=	0xdfd6
                           00DFD7   889 _X_DMAREQ	=	0xdfd7
                           00DFD8   890 _X_TIMIF	=	0xdfd8
                           00DFD9   891 _X_RFD	=	0xdfd9
                           00DFDA   892 _X_T1CC0L	=	0xdfda
                           00DFDB   893 _X_T1CC0H	=	0xdfdb
                           00DFDC   894 _X_T1CC1L	=	0xdfdc
                           00DFDD   895 _X_T1CC1H	=	0xdfdd
                           00DFDE   896 _X_T1CC2L	=	0xdfde
                           00DFDF   897 _X_T1CC2H	=	0xdfdf
                           00DFE0   898 __NA_ACC	=	0xdfe0
                           00DFE1   899 _X_RFST	=	0xdfe1
                           00DFE2   900 _X_T1CNTL	=	0xdfe2
                           00DFE3   901 _X_T1CNTH	=	0xdfe3
                           00DFE4   902 _X_T1CTL	=	0xdfe4
                           00DFE5   903 _X_T1CCTL0	=	0xdfe5
                           00DFE6   904 _X_T1CCTL1	=	0xdfe6
                           00DFE7   905 _X_T1CCTL2	=	0xdfe7
                           00DFE8   906 __NA_IRCON2	=	0xdfe8
                           00DFE9   907 _X_RFIF	=	0xdfe9
                           00DFEA   908 _X_T4CNT	=	0xdfea
                           00DFEB   909 _X_T4CTL	=	0xdfeb
                           00DFEC   910 _X_T4CCTL0	=	0xdfec
                           00DFED   911 _X_T4CC0	=	0xdfed
                           00DFEE   912 _X_T4CCTL1	=	0xdfee
                           00DFEF   913 _X_T4CC1	=	0xdfef
                           00DFF0   914 __NA_B	=	0xdff0
                           00DFF1   915 _X_PERCFG	=	0xdff1
                           00DFF2   916 _X_ADCCFG	=	0xdff2
                           00DFF3   917 _X_P0SEL	=	0xdff3
                           00DFF4   918 _X_P1SEL	=	0xdff4
                           00DFF5   919 _X_P2SEL	=	0xdff5
                           00DFF6   920 _X_P1INP	=	0xdff6
                           00DFF7   921 _X_P2INP	=	0xdff7
                           00DFF8   922 _X_U1CSR	=	0xdff8
                           00DFF9   923 _X_U1DBUF	=	0xdff9
                           00DFFA   924 _X_U1BAUD	=	0xdffa
                           00DFFB   925 _X_U1UCR	=	0xdffb
                           00DFFC   926 _X_U1GCR	=	0xdffc
                           00DFFD   927 _X_P0DIR	=	0xdffd
                           00DFFE   928 _X_P1DIR	=	0xdffe
                           00DFFF   929 _X_P2DIR	=	0xdfff
                                    930 ;--------------------------------------------------------
                                    931 ; absolute external ram data
                                    932 ;--------------------------------------------------------
                                    933 	.area XABS    (ABS,XDATA)
                                    934 ;--------------------------------------------------------
                                    935 ; external initialized ram data
                                    936 ;--------------------------------------------------------
                                    937 	.area XISEG   (XDATA)
                                    938 	.area HOME    (CODE)
                                    939 	.area GSINIT0 (CODE)
                                    940 	.area GSINIT1 (CODE)
                                    941 	.area GSINIT2 (CODE)
                                    942 	.area GSINIT3 (CODE)
                                    943 	.area GSINIT4 (CODE)
                                    944 	.area GSINIT5 (CODE)
                                    945 	.area GSINIT  (CODE)
                                    946 	.area GSFINAL (CODE)
                                    947 	.area CSEG    (CODE)
                                    948 ;--------------------------------------------------------
                                    949 ; global & static initialisations
                                    950 ;--------------------------------------------------------
                                    951 	.area HOME    (CODE)
                                    952 	.area GSINIT  (CODE)
                                    953 	.area GSFINAL (CODE)
                                    954 	.area GSINIT  (CODE)
                                    955 ;--------------------------------------------------------
                                    956 ; Home
                                    957 ;--------------------------------------------------------
                                    958 	.area HOME    (CODE)
                                    959 	.area HOME    (CODE)
                                    960 ;--------------------------------------------------------
                                    961 ; code
                                    962 ;--------------------------------------------------------
                                    963 	.area CSEG    (CODE)
                                    964 ;------------------------------------------------------------
                                    965 ;Allocation info for local variables in function 'passthrough_init_encoder'
                                    966 ;------------------------------------------------------------
                                    967 ;	encoding.c:7: static void passthrough_init_encoder(EncoderState *state) {
                                    968 ;	-----------------------------------------
                                    969 ;	 function passthrough_init_encoder
                                    970 ;	-----------------------------------------
      000CE1                        971 _passthrough_init_encoder:
                           000007   972 	ar7 = 0x07
                           000006   973 	ar6 = 0x06
                           000005   974 	ar5 = 0x05
                           000004   975 	ar4 = 0x04
                           000003   976 	ar3 = 0x03
                           000002   977 	ar2 = 0x02
                           000001   978 	ar1 = 0x01
                           000000   979 	ar0 = 0x00
      000CE1 AD 82            [24]  980 	mov	r5,dpl
      000CE3 AE 83            [24]  981 	mov	r6,dph
      000CE5 AF F0            [24]  982 	mov	r7,b
                                    983 ;	encoding.c:8: state->passthrough.count = 0;
      000CE7 0D               [12]  984 	inc	r5
      000CE8 BD 00 01         [24]  985 	cjne	r5,#0x00,00103$
      000CEB 0E               [12]  986 	inc	r6
      000CEC                        987 00103$:
      000CEC 8D 82            [24]  988 	mov	dpl,r5
      000CEE 8E 83            [24]  989 	mov	dph,r6
      000CF0 8F F0            [24]  990 	mov	b,r7
      000CF2 E4               [12]  991 	clr	a
                                    992 ;	encoding.c:9: }
      000CF3 02 2D 8A         [24]  993 	ljmp	__gptrput
                                    994 ;------------------------------------------------------------
                                    995 ;Allocation info for local variables in function 'passthrough_add_raw_byte'
                                    996 ;------------------------------------------------------------
                                    997 ;raw                       Allocated to stack - _bp -3
                                    998 ;state                     Allocated to registers r5 r6 r7 
                                    999 ;------------------------------------------------------------
                                   1000 ;	encoding.c:11: static void passthrough_add_raw_byte(EncoderState *state, uint8_t raw) __reentrant {
                                   1001 ;	-----------------------------------------
                                   1002 ;	 function passthrough_add_raw_byte
                                   1003 ;	-----------------------------------------
      000CF6                       1004 _passthrough_add_raw_byte:
      000CF6 C0 18            [24] 1005 	push	_bp
      000CF8 85 81 18         [24] 1006 	mov	_bp,sp
      000CFB AD 82            [24] 1007 	mov	r5,dpl
      000CFD AE 83            [24] 1008 	mov	r6,dph
      000CFF AF F0            [24] 1009 	mov	r7,b
                                   1010 ;	encoding.c:12: state->passthrough.count = 1;
      000D01 74 01            [12] 1011 	mov	a,#0x01
      000D03 2D               [12] 1012 	add	a,r5
      000D04 FA               [12] 1013 	mov	r2,a
      000D05 E4               [12] 1014 	clr	a
      000D06 3E               [12] 1015 	addc	a,r6
      000D07 FB               [12] 1016 	mov	r3,a
      000D08 8F 04            [24] 1017 	mov	ar4,r7
      000D0A 8A 82            [24] 1018 	mov	dpl,r2
      000D0C 8B 83            [24] 1019 	mov	dph,r3
      000D0E 8C F0            [24] 1020 	mov	b,r4
      000D10 74 01            [12] 1021 	mov	a,#0x01
      000D12 12 2D 8A         [24] 1022 	lcall	__gptrput
                                   1023 ;	encoding.c:13: state->passthrough.data = raw;
      000D15 8D 82            [24] 1024 	mov	dpl,r5
      000D17 8E 83            [24] 1025 	mov	dph,r6
      000D19 8F F0            [24] 1026 	mov	b,r7
      000D1B E5 18            [12] 1027 	mov	a,_bp
      000D1D 24 FD            [12] 1028 	add	a,#0xfd
      000D1F F8               [12] 1029 	mov	r0,a
      000D20 E6               [12] 1030 	mov	a,@r0
      000D21 12 2D 8A         [24] 1031 	lcall	__gptrput
                                   1032 ;	encoding.c:14: }
      000D24 D0 18            [24] 1033 	pop	_bp
      000D26 22               [24] 1034 	ret
                                   1035 ;------------------------------------------------------------
                                   1036 ;Allocation info for local variables in function 'passthrough_next_encoded_byte'
                                   1037 ;------------------------------------------------------------
                                   1038 ;encoded                   Allocated to stack - _bp -5
                                   1039 ;flush                     Allocated to stack - _bp -6
                                   1040 ;state                     Allocated to stack - _bp +1
                                   1041 ;sloc0                     Allocated to stack - _bp +4
                                   1042 ;------------------------------------------------------------
                                   1043 ;	encoding.c:16: static uint8_t passthrough_next_encoded_byte(EncoderState *state, uint8_t *encoded, bool flush) __reentrant {
                                   1044 ;	-----------------------------------------
                                   1045 ;	 function passthrough_next_encoded_byte
                                   1046 ;	-----------------------------------------
      000D27                       1047 _passthrough_next_encoded_byte:
      000D27 C0 18            [24] 1048 	push	_bp
      000D29 85 81 18         [24] 1049 	mov	_bp,sp
      000D2C C0 82            [24] 1050 	push	dpl
      000D2E C0 83            [24] 1051 	push	dph
      000D30 C0 F0            [24] 1052 	push	b
      000D32 05 81            [12] 1053 	inc	sp
      000D34 05 81            [12] 1054 	inc	sp
      000D36 05 81            [12] 1055 	inc	sp
                                   1056 ;	encoding.c:17: if (state->passthrough.count < 1) {
      000D38 A8 18            [24] 1057 	mov	r0,_bp
      000D3A 08               [12] 1058 	inc	r0
      000D3B 74 01            [12] 1059 	mov	a,#0x01
      000D3D 26               [12] 1060 	add	a,@r0
      000D3E FA               [12] 1061 	mov	r2,a
      000D3F E4               [12] 1062 	clr	a
      000D40 08               [12] 1063 	inc	r0
      000D41 36               [12] 1064 	addc	a,@r0
      000D42 FB               [12] 1065 	mov	r3,a
      000D43 08               [12] 1066 	inc	r0
      000D44 86 04            [24] 1067 	mov	ar4,@r0
      000D46 8A 82            [24] 1068 	mov	dpl,r2
      000D48 8B 83            [24] 1069 	mov	dph,r3
      000D4A 8C F0            [24] 1070 	mov	b,r4
      000D4C 12 2E 55         [24] 1071 	lcall	__gptrget
      000D4F FF               [12] 1072 	mov	r7,a
      000D50 BF 01 00         [24] 1073 	cjne	r7,#0x01,00109$
      000D53                       1074 00109$:
      000D53 50 05            [24] 1075 	jnc	00102$
                                   1076 ;	encoding.c:18: return 0;
      000D55 75 82 00         [24] 1077 	mov	dpl,#0x00
      000D58 80 4C            [24] 1078 	sjmp	00103$
      000D5A                       1079 00102$:
                                   1080 ;	encoding.c:20: *encoded = state->passthrough.data;
      000D5A E5 18            [12] 1081 	mov	a,_bp
      000D5C 24 FB            [12] 1082 	add	a,#0xfb
      000D5E F8               [12] 1083 	mov	r0,a
      000D5F E5 18            [12] 1084 	mov	a,_bp
      000D61 24 04            [12] 1085 	add	a,#0x04
      000D63 F9               [12] 1086 	mov	r1,a
      000D64 E6               [12] 1087 	mov	a,@r0
      000D65 F7               [12] 1088 	mov	@r1,a
      000D66 08               [12] 1089 	inc	r0
      000D67 09               [12] 1090 	inc	r1
      000D68 E6               [12] 1091 	mov	a,@r0
      000D69 F7               [12] 1092 	mov	@r1,a
      000D6A 08               [12] 1093 	inc	r0
      000D6B 09               [12] 1094 	inc	r1
      000D6C E6               [12] 1095 	mov	a,@r0
      000D6D F7               [12] 1096 	mov	@r1,a
      000D6E A8 18            [24] 1097 	mov	r0,_bp
      000D70 08               [12] 1098 	inc	r0
      000D71 86 82            [24] 1099 	mov	dpl,@r0
      000D73 08               [12] 1100 	inc	r0
      000D74 86 83            [24] 1101 	mov	dph,@r0
      000D76 08               [12] 1102 	inc	r0
      000D77 86 F0            [24] 1103 	mov	b,@r0
      000D79 12 2E 55         [24] 1104 	lcall	__gptrget
      000D7C FF               [12] 1105 	mov	r7,a
      000D7D E5 18            [12] 1106 	mov	a,_bp
      000D7F 24 04            [12] 1107 	add	a,#0x04
      000D81 F8               [12] 1108 	mov	r0,a
      000D82 86 82            [24] 1109 	mov	dpl,@r0
      000D84 08               [12] 1110 	inc	r0
      000D85 86 83            [24] 1111 	mov	dph,@r0
      000D87 08               [12] 1112 	inc	r0
      000D88 86 F0            [24] 1113 	mov	b,@r0
      000D8A EF               [12] 1114 	mov	a,r7
      000D8B 12 2D 8A         [24] 1115 	lcall	__gptrput
                                   1116 ;	encoding.c:21: state->passthrough.count--;
      000D8E 8A 82            [24] 1117 	mov	dpl,r2
      000D90 8B 83            [24] 1118 	mov	dph,r3
      000D92 8C F0            [24] 1119 	mov	b,r4
      000D94 12 2E 55         [24] 1120 	lcall	__gptrget
      000D97 FF               [12] 1121 	mov	r7,a
      000D98 1F               [12] 1122 	dec	r7
      000D99 8A 82            [24] 1123 	mov	dpl,r2
      000D9B 8B 83            [24] 1124 	mov	dph,r3
      000D9D 8C F0            [24] 1125 	mov	b,r4
      000D9F EF               [12] 1126 	mov	a,r7
      000DA0 12 2D 8A         [24] 1127 	lcall	__gptrput
                                   1128 ;	encoding.c:22: return 1;
      000DA3 75 82 01         [24] 1129 	mov	dpl,#0x01
      000DA6                       1130 00103$:
                                   1131 ;	encoding.c:23: }
      000DA6 85 18 81         [24] 1132 	mov	sp,_bp
      000DA9 D0 18            [24] 1133 	pop	_bp
      000DAB 22               [24] 1134 	ret
                                   1135 ;------------------------------------------------------------
                                   1136 ;Allocation info for local variables in function 'passthrough_init_decoder'
                                   1137 ;------------------------------------------------------------
                                   1138 ;	encoding.c:26: static void passthrough_init_decoder(DecoderState *state) {
                                   1139 ;	-----------------------------------------
                                   1140 ;	 function passthrough_init_decoder
                                   1141 ;	-----------------------------------------
      000DAC                       1142 _passthrough_init_decoder:
      000DAC AD 82            [24] 1143 	mov	r5,dpl
      000DAE AE 83            [24] 1144 	mov	r6,dph
      000DB0 AF F0            [24] 1145 	mov	r7,b
                                   1146 ;	encoding.c:27: state->passthrough.count = 0;
      000DB2 0D               [12] 1147 	inc	r5
      000DB3 BD 00 01         [24] 1148 	cjne	r5,#0x00,00103$
      000DB6 0E               [12] 1149 	inc	r6
      000DB7                       1150 00103$:
      000DB7 8D 82            [24] 1151 	mov	dpl,r5
      000DB9 8E 83            [24] 1152 	mov	dph,r6
      000DBB 8F F0            [24] 1153 	mov	b,r7
      000DBD E4               [12] 1154 	clr	a
                                   1155 ;	encoding.c:28: }
      000DBE 02 2D 8A         [24] 1156 	ljmp	__gptrput
                                   1157 ;------------------------------------------------------------
                                   1158 ;Allocation info for local variables in function 'passthrough_add_encoded_byte'
                                   1159 ;------------------------------------------------------------
                                   1160 ;encoded                   Allocated to stack - _bp -3
                                   1161 ;state                     Allocated to registers r5 r6 r7 
                                   1162 ;------------------------------------------------------------
                                   1163 ;	encoding.c:30: static uint8_t passthrough_add_encoded_byte(DecoderState *state, uint8_t encoded) __reentrant {
                                   1164 ;	-----------------------------------------
                                   1165 ;	 function passthrough_add_encoded_byte
                                   1166 ;	-----------------------------------------
      000DC1                       1167 _passthrough_add_encoded_byte:
      000DC1 C0 18            [24] 1168 	push	_bp
      000DC3 85 81 18         [24] 1169 	mov	_bp,sp
                                   1170 ;	encoding.c:31: state->passthrough.data = encoded;
      000DC6 AD 82            [24] 1171 	mov	r5,dpl
      000DC8 AE 83            [24] 1172 	mov	r6,dph
      000DCA AF F0            [24] 1173 	mov	r7,b
      000DCC E5 18            [12] 1174 	mov	a,_bp
      000DCE 24 FD            [12] 1175 	add	a,#0xfd
      000DD0 F8               [12] 1176 	mov	r0,a
      000DD1 E6               [12] 1177 	mov	a,@r0
      000DD2 12 2D 8A         [24] 1178 	lcall	__gptrput
                                   1179 ;	encoding.c:32: state->passthrough.count = 1;
      000DD5 0D               [12] 1180 	inc	r5
      000DD6 BD 00 01         [24] 1181 	cjne	r5,#0x00,00109$
      000DD9 0E               [12] 1182 	inc	r6
      000DDA                       1183 00109$:
      000DDA 8D 82            [24] 1184 	mov	dpl,r5
      000DDC 8E 83            [24] 1185 	mov	dph,r6
      000DDE 8F F0            [24] 1186 	mov	b,r7
      000DE0 74 01            [12] 1187 	mov	a,#0x01
      000DE2 12 2D 8A         [24] 1188 	lcall	__gptrput
                                   1189 ;	encoding.c:33: if (encoded == 0) {
      000DE5 E5 18            [12] 1190 	mov	a,_bp
      000DE7 24 FD            [12] 1191 	add	a,#0xfd
      000DE9 F8               [12] 1192 	mov	r0,a
      000DEA E6               [12] 1193 	mov	a,@r0
      000DEB 70 05            [24] 1194 	jnz	00102$
                                   1195 ;	encoding.c:34: return 1;
      000DED 75 82 01         [24] 1196 	mov	dpl,#0x01
      000DF0 80 03            [24] 1197 	sjmp	00103$
      000DF2                       1198 00102$:
                                   1199 ;	encoding.c:36: return 0;
      000DF2 75 82 00         [24] 1200 	mov	dpl,#0x00
      000DF5                       1201 00103$:
                                   1202 ;	encoding.c:37: }
      000DF5 D0 18            [24] 1203 	pop	_bp
      000DF7 22               [24] 1204 	ret
                                   1205 ;------------------------------------------------------------
                                   1206 ;Allocation info for local variables in function 'passthrough_next_decoded_byte'
                                   1207 ;------------------------------------------------------------
                                   1208 ;decoded                   Allocated to stack - _bp -5
                                   1209 ;state                     Allocated to stack - _bp +4
                                   1210 ;sloc0                     Allocated to stack - _bp +1
                                   1211 ;------------------------------------------------------------
                                   1212 ;	encoding.c:39: static uint8_t passthrough_next_decoded_byte(DecoderState *state, uint8_t *decoded) __reentrant {
                                   1213 ;	-----------------------------------------
                                   1214 ;	 function passthrough_next_decoded_byte
                                   1215 ;	-----------------------------------------
      000DF8                       1216 _passthrough_next_decoded_byte:
      000DF8 C0 18            [24] 1217 	push	_bp
      000DFA E5 81            [12] 1218 	mov	a,sp
      000DFC F5 18            [12] 1219 	mov	_bp,a
      000DFE 24 06            [12] 1220 	add	a,#0x06
      000E00 F5 81            [12] 1221 	mov	sp,a
      000E02 C8               [12] 1222 	xch	a,r0
      000E03 E5 18            [12] 1223 	mov	a,_bp
      000E05 24 04            [12] 1224 	add	a,#0x04
      000E07 C8               [12] 1225 	xch	a,r0
      000E08 A6 82            [24] 1226 	mov	@r0,dpl
      000E0A 08               [12] 1227 	inc	r0
      000E0B A6 83            [24] 1228 	mov	@r0,dph
      000E0D 08               [12] 1229 	inc	r0
      000E0E A6 F0            [24] 1230 	mov	@r0,b
                                   1231 ;	encoding.c:40: if (state->passthrough.count < 1) {
      000E10 E5 18            [12] 1232 	mov	a,_bp
      000E12 24 04            [12] 1233 	add	a,#0x04
      000E14 F8               [12] 1234 	mov	r0,a
      000E15 74 01            [12] 1235 	mov	a,#0x01
      000E17 26               [12] 1236 	add	a,@r0
      000E18 FA               [12] 1237 	mov	r2,a
      000E19 E4               [12] 1238 	clr	a
      000E1A 08               [12] 1239 	inc	r0
      000E1B 36               [12] 1240 	addc	a,@r0
      000E1C FB               [12] 1241 	mov	r3,a
      000E1D 08               [12] 1242 	inc	r0
      000E1E 86 04            [24] 1243 	mov	ar4,@r0
      000E20 8A 82            [24] 1244 	mov	dpl,r2
      000E22 8B 83            [24] 1245 	mov	dph,r3
      000E24 8C F0            [24] 1246 	mov	b,r4
      000E26 12 2E 55         [24] 1247 	lcall	__gptrget
      000E29 FF               [12] 1248 	mov	r7,a
      000E2A BF 01 00         [24] 1249 	cjne	r7,#0x01,00109$
      000E2D                       1250 00109$:
      000E2D 50 05            [24] 1251 	jnc	00102$
                                   1252 ;	encoding.c:41: return 0;
      000E2F 75 82 00         [24] 1253 	mov	dpl,#0x00
      000E32 80 3F            [24] 1254 	sjmp	00103$
      000E34                       1255 00102$:
                                   1256 ;	encoding.c:43: *decoded = state->passthrough.data;
      000E34 E5 18            [12] 1257 	mov	a,_bp
      000E36 24 FB            [12] 1258 	add	a,#0xfb
      000E38 F8               [12] 1259 	mov	r0,a
      000E39 A9 18            [24] 1260 	mov	r1,_bp
      000E3B 09               [12] 1261 	inc	r1
      000E3C E6               [12] 1262 	mov	a,@r0
      000E3D F7               [12] 1263 	mov	@r1,a
      000E3E 08               [12] 1264 	inc	r0
      000E3F 09               [12] 1265 	inc	r1
      000E40 E6               [12] 1266 	mov	a,@r0
      000E41 F7               [12] 1267 	mov	@r1,a
      000E42 08               [12] 1268 	inc	r0
      000E43 09               [12] 1269 	inc	r1
      000E44 E6               [12] 1270 	mov	a,@r0
      000E45 F7               [12] 1271 	mov	@r1,a
      000E46 E5 18            [12] 1272 	mov	a,_bp
      000E48 24 04            [12] 1273 	add	a,#0x04
      000E4A F8               [12] 1274 	mov	r0,a
      000E4B 86 82            [24] 1275 	mov	dpl,@r0
      000E4D 08               [12] 1276 	inc	r0
      000E4E 86 83            [24] 1277 	mov	dph,@r0
      000E50 08               [12] 1278 	inc	r0
      000E51 86 F0            [24] 1279 	mov	b,@r0
      000E53 12 2E 55         [24] 1280 	lcall	__gptrget
      000E56 FF               [12] 1281 	mov	r7,a
      000E57 A8 18            [24] 1282 	mov	r0,_bp
      000E59 08               [12] 1283 	inc	r0
      000E5A 86 82            [24] 1284 	mov	dpl,@r0
      000E5C 08               [12] 1285 	inc	r0
      000E5D 86 83            [24] 1286 	mov	dph,@r0
      000E5F 08               [12] 1287 	inc	r0
      000E60 86 F0            [24] 1288 	mov	b,@r0
      000E62 EF               [12] 1289 	mov	a,r7
      000E63 12 2D 8A         [24] 1290 	lcall	__gptrput
                                   1291 ;	encoding.c:44: state->passthrough.count = 0;
      000E66 8A 82            [24] 1292 	mov	dpl,r2
      000E68 8B 83            [24] 1293 	mov	dph,r3
      000E6A 8C F0            [24] 1294 	mov	b,r4
      000E6C E4               [12] 1295 	clr	a
      000E6D 12 2D 8A         [24] 1296 	lcall	__gptrput
                                   1297 ;	encoding.c:45: return 1;
      000E70 75 82 01         [24] 1298 	mov	dpl,#0x01
      000E73                       1299 00103$:
                                   1300 ;	encoding.c:46: }
      000E73 85 18 81         [24] 1301 	mov	sp,_bp
      000E76 D0 18            [24] 1302 	pop	_bp
      000E78 22               [24] 1303 	ret
                                   1304 ;------------------------------------------------------------
                                   1305 ;Allocation info for local variables in function 'init_encoder'
                                   1306 ;------------------------------------------------------------
                                   1307 ;	encoding.c:50: void init_encoder(EncodingType encoding_type, Encoder *encoder, EncoderState *state) {
                                   1308 ;	-----------------------------------------
                                   1309 ;	 function init_encoder
                                   1310 ;	-----------------------------------------
      000E79                       1311 _init_encoder:
      000E79 AF 82            [24] 1312 	mov	r7,dpl
                                   1313 ;	encoding.c:51: switch (encoding_type) {
      000E7B BF 00 02         [24] 1314 	cjne	r7,#0x00,00119$
      000E7E 80 0C            [24] 1315 	sjmp	00101$
      000E80                       1316 00119$:
      000E80 BF 01 02         [24] 1317 	cjne	r7,#0x01,00120$
      000E83 80 4A            [24] 1318 	sjmp	00102$
      000E85                       1319 00120$:
      000E85 BF 02 03         [24] 1320 	cjne	r7,#0x02,00121$
      000E88 02 0F 12         [24] 1321 	ljmp	00103$
      000E8B                       1322 00121$:
      000E8B 22               [24] 1323 	ret
                                   1324 ;	encoding.c:52: case EncodingTypeNone:
      000E8C                       1325 00101$:
                                   1326 ;	encoding.c:53: encoder->add_raw_byte = passthrough_add_raw_byte;
      000E8C 78 3D            [12] 1327 	mov	r0,#_init_encoder_PARM_2
      000E8E E2               [24] 1328 	movx	a,@r0
      000E8F FD               [12] 1329 	mov	r5,a
      000E90 08               [12] 1330 	inc	r0
      000E91 E2               [24] 1331 	movx	a,@r0
      000E92 FE               [12] 1332 	mov	r6,a
      000E93 08               [12] 1333 	inc	r0
      000E94 E2               [24] 1334 	movx	a,@r0
      000E95 FF               [12] 1335 	mov	r7,a
      000E96 8D 82            [24] 1336 	mov	dpl,r5
      000E98 8E 83            [24] 1337 	mov	dph,r6
      000E9A 8F F0            [24] 1338 	mov	b,r7
      000E9C 74 F6            [12] 1339 	mov	a,#_passthrough_add_raw_byte
      000E9E 12 2D 8A         [24] 1340 	lcall	__gptrput
      000EA1 A3               [24] 1341 	inc	dptr
      000EA2 74 0C            [12] 1342 	mov	a,#(_passthrough_add_raw_byte >> 8)
      000EA4 12 2D 8A         [24] 1343 	lcall	__gptrput
                                   1344 ;	encoding.c:54: encoder->next_encoded_byte = passthrough_next_encoded_byte;
      000EA7 74 02            [12] 1345 	mov	a,#0x02
      000EA9 2D               [12] 1346 	add	a,r5
      000EAA FD               [12] 1347 	mov	r5,a
      000EAB E4               [12] 1348 	clr	a
      000EAC 3E               [12] 1349 	addc	a,r6
      000EAD FE               [12] 1350 	mov	r6,a
      000EAE 8D 82            [24] 1351 	mov	dpl,r5
      000EB0 8E 83            [24] 1352 	mov	dph,r6
      000EB2 8F F0            [24] 1353 	mov	b,r7
      000EB4 74 27            [12] 1354 	mov	a,#_passthrough_next_encoded_byte
      000EB6 12 2D 8A         [24] 1355 	lcall	__gptrput
      000EB9 A3               [24] 1356 	inc	dptr
      000EBA 74 0D            [12] 1357 	mov	a,#(_passthrough_next_encoded_byte >> 8)
      000EBC 12 2D 8A         [24] 1358 	lcall	__gptrput
                                   1359 ;	encoding.c:55: passthrough_init_encoder(state);
      000EBF 78 40            [12] 1360 	mov	r0,#_init_encoder_PARM_3
      000EC1 E2               [24] 1361 	movx	a,@r0
      000EC2 F5 82            [12] 1362 	mov	dpl,a
      000EC4 08               [12] 1363 	inc	r0
      000EC5 E2               [24] 1364 	movx	a,@r0
      000EC6 F5 83            [12] 1365 	mov	dph,a
      000EC8 08               [12] 1366 	inc	r0
      000EC9 E2               [24] 1367 	movx	a,@r0
      000ECA F5 F0            [12] 1368 	mov	b,a
                                   1369 ;	encoding.c:56: break;
      000ECC 02 0C E1         [24] 1370 	ljmp	_passthrough_init_encoder
                                   1371 ;	encoding.c:57: case EncodingTypeManchester:
      000ECF                       1372 00102$:
                                   1373 ;	encoding.c:58: encoder->add_raw_byte = manchester_add_raw_byte;
      000ECF 78 3D            [12] 1374 	mov	r0,#_init_encoder_PARM_2
      000ED1 E2               [24] 1375 	movx	a,@r0
      000ED2 FD               [12] 1376 	mov	r5,a
      000ED3 08               [12] 1377 	inc	r0
      000ED4 E2               [24] 1378 	movx	a,@r0
      000ED5 FE               [12] 1379 	mov	r6,a
      000ED6 08               [12] 1380 	inc	r0
      000ED7 E2               [24] 1381 	movx	a,@r0
      000ED8 FF               [12] 1382 	mov	r7,a
      000ED9 8D 82            [24] 1383 	mov	dpl,r5
      000EDB 8E 83            [24] 1384 	mov	dph,r6
      000EDD 8F F0            [24] 1385 	mov	b,r7
      000EDF 74 49            [12] 1386 	mov	a,#_manchester_add_raw_byte
      000EE1 12 2D 8A         [24] 1387 	lcall	__gptrput
      000EE4 A3               [24] 1388 	inc	dptr
      000EE5 74 10            [12] 1389 	mov	a,#(_manchester_add_raw_byte >> 8)
      000EE7 12 2D 8A         [24] 1390 	lcall	__gptrput
                                   1391 ;	encoding.c:59: encoder->next_encoded_byte = manchester_next_encoded_byte;
      000EEA 74 02            [12] 1392 	mov	a,#0x02
      000EEC 2D               [12] 1393 	add	a,r5
      000EED FD               [12] 1394 	mov	r5,a
      000EEE E4               [12] 1395 	clr	a
      000EEF 3E               [12] 1396 	addc	a,r6
      000EF0 FE               [12] 1397 	mov	r6,a
      000EF1 8D 82            [24] 1398 	mov	dpl,r5
      000EF3 8E 83            [24] 1399 	mov	dph,r6
      000EF5 8F F0            [24] 1400 	mov	b,r7
      000EF7 74 E7            [12] 1401 	mov	a,#_manchester_next_encoded_byte
      000EF9 12 2D 8A         [24] 1402 	lcall	__gptrput
      000EFC A3               [24] 1403 	inc	dptr
      000EFD 74 10            [12] 1404 	mov	a,#(_manchester_next_encoded_byte >> 8)
      000EFF 12 2D 8A         [24] 1405 	lcall	__gptrput
                                   1406 ;	encoding.c:60: manchester_init_encoder(state);
      000F02 78 40            [12] 1407 	mov	r0,#_init_encoder_PARM_3
      000F04 E2               [24] 1408 	movx	a,@r0
      000F05 F5 82            [12] 1409 	mov	dpl,a
      000F07 08               [12] 1410 	inc	r0
      000F08 E2               [24] 1411 	movx	a,@r0
      000F09 F5 83            [12] 1412 	mov	dph,a
      000F0B 08               [12] 1413 	inc	r0
      000F0C E2               [24] 1414 	movx	a,@r0
      000F0D F5 F0            [12] 1415 	mov	b,a
                                   1416 ;	encoding.c:61: break;
                                   1417 ;	encoding.c:62: case EncodingTypeFourbSixb:
      000F0F 02 10 31         [24] 1418 	ljmp	_manchester_init_encoder
      000F12                       1419 00103$:
                                   1420 ;	encoding.c:63: encoder->add_raw_byte = fourbsixb_add_raw_byte;
      000F12 78 3D            [12] 1421 	mov	r0,#_init_encoder_PARM_2
      000F14 E2               [24] 1422 	movx	a,@r0
      000F15 FD               [12] 1423 	mov	r5,a
      000F16 08               [12] 1424 	inc	r0
      000F17 E2               [24] 1425 	movx	a,@r0
      000F18 FE               [12] 1426 	mov	r6,a
      000F19 08               [12] 1427 	inc	r0
      000F1A E2               [24] 1428 	movx	a,@r0
      000F1B FF               [12] 1429 	mov	r7,a
      000F1C 8D 82            [24] 1430 	mov	dpl,r5
      000F1E 8E 83            [24] 1431 	mov	dph,r6
      000F20 8F F0            [24] 1432 	mov	b,r7
      000F22 74 E0            [12] 1433 	mov	a,#_fourbsixb_add_raw_byte
      000F24 12 2D 8A         [24] 1434 	lcall	__gptrput
      000F27 A3               [24] 1435 	inc	dptr
      000F28 74 12            [12] 1436 	mov	a,#(_fourbsixb_add_raw_byte >> 8)
      000F2A 12 2D 8A         [24] 1437 	lcall	__gptrput
                                   1438 ;	encoding.c:64: encoder->next_encoded_byte = fourbsixb_next_encoded_byte;
      000F2D 74 02            [12] 1439 	mov	a,#0x02
      000F2F 2D               [12] 1440 	add	a,r5
      000F30 FD               [12] 1441 	mov	r5,a
      000F31 E4               [12] 1442 	clr	a
      000F32 3E               [12] 1443 	addc	a,r6
      000F33 FE               [12] 1444 	mov	r6,a
      000F34 8D 82            [24] 1445 	mov	dpl,r5
      000F36 8E 83            [24] 1446 	mov	dph,r6
      000F38 8F F0            [24] 1447 	mov	b,r7
      000F3A 74 85            [12] 1448 	mov	a,#_fourbsixb_next_encoded_byte
      000F3C 12 2D 8A         [24] 1449 	lcall	__gptrput
      000F3F A3               [24] 1450 	inc	dptr
      000F40 74 13            [12] 1451 	mov	a,#(_fourbsixb_next_encoded_byte >> 8)
      000F42 12 2D 8A         [24] 1452 	lcall	__gptrput
                                   1453 ;	encoding.c:65: fourbsixb_init_encoder(state);
      000F45 78 40            [12] 1454 	mov	r0,#_init_encoder_PARM_3
      000F47 E2               [24] 1455 	movx	a,@r0
      000F48 F5 82            [12] 1456 	mov	dpl,a
      000F4A 08               [12] 1457 	inc	r0
      000F4B E2               [24] 1458 	movx	a,@r0
      000F4C F5 83            [12] 1459 	mov	dph,a
      000F4E 08               [12] 1460 	inc	r0
      000F4F E2               [24] 1461 	movx	a,@r0
      000F50 F5 F0            [12] 1462 	mov	b,a
                                   1463 ;	encoding.c:67: }
                                   1464 ;	encoding.c:68: }
      000F52 02 12 C1         [24] 1465 	ljmp	_fourbsixb_init_encoder
                                   1466 ;------------------------------------------------------------
                                   1467 ;Allocation info for local variables in function 'init_decoder'
                                   1468 ;------------------------------------------------------------
                                   1469 ;	encoding.c:71: void init_decoder(EncodingType encoding_type, Decoder *decoder, DecoderState *state) {
                                   1470 ;	-----------------------------------------
                                   1471 ;	 function init_decoder
                                   1472 ;	-----------------------------------------
      000F55                       1473 _init_decoder:
      000F55 AF 82            [24] 1474 	mov	r7,dpl
                                   1475 ;	encoding.c:72: switch (encoding_type) {
      000F57 BF 00 02         [24] 1476 	cjne	r7,#0x00,00119$
      000F5A 80 0C            [24] 1477 	sjmp	00101$
      000F5C                       1478 00119$:
      000F5C BF 01 02         [24] 1479 	cjne	r7,#0x01,00120$
      000F5F 80 4A            [24] 1480 	sjmp	00102$
      000F61                       1481 00120$:
      000F61 BF 02 03         [24] 1482 	cjne	r7,#0x02,00121$
      000F64 02 0F EE         [24] 1483 	ljmp	00103$
      000F67                       1484 00121$:
      000F67 22               [24] 1485 	ret
                                   1486 ;	encoding.c:73: case EncodingTypeNone:
      000F68                       1487 00101$:
                                   1488 ;	encoding.c:74: decoder->add_encoded_byte = passthrough_add_encoded_byte;
      000F68 78 43            [12] 1489 	mov	r0,#_init_decoder_PARM_2
      000F6A E2               [24] 1490 	movx	a,@r0
      000F6B FD               [12] 1491 	mov	r5,a
      000F6C 08               [12] 1492 	inc	r0
      000F6D E2               [24] 1493 	movx	a,@r0
      000F6E FE               [12] 1494 	mov	r6,a
      000F6F 08               [12] 1495 	inc	r0
      000F70 E2               [24] 1496 	movx	a,@r0
      000F71 FF               [12] 1497 	mov	r7,a
      000F72 8D 82            [24] 1498 	mov	dpl,r5
      000F74 8E 83            [24] 1499 	mov	dph,r6
      000F76 8F F0            [24] 1500 	mov	b,r7
      000F78 74 C1            [12] 1501 	mov	a,#_passthrough_add_encoded_byte
      000F7A 12 2D 8A         [24] 1502 	lcall	__gptrput
      000F7D A3               [24] 1503 	inc	dptr
      000F7E 74 0D            [12] 1504 	mov	a,#(_passthrough_add_encoded_byte >> 8)
      000F80 12 2D 8A         [24] 1505 	lcall	__gptrput
                                   1506 ;	encoding.c:75: decoder->next_decoded_byte = passthrough_next_decoded_byte;
      000F83 74 02            [12] 1507 	mov	a,#0x02
      000F85 2D               [12] 1508 	add	a,r5
      000F86 FD               [12] 1509 	mov	r5,a
      000F87 E4               [12] 1510 	clr	a
      000F88 3E               [12] 1511 	addc	a,r6
      000F89 FE               [12] 1512 	mov	r6,a
      000F8A 8D 82            [24] 1513 	mov	dpl,r5
      000F8C 8E 83            [24] 1514 	mov	dph,r6
      000F8E 8F F0            [24] 1515 	mov	b,r7
      000F90 74 F8            [12] 1516 	mov	a,#_passthrough_next_decoded_byte
      000F92 12 2D 8A         [24] 1517 	lcall	__gptrput
      000F95 A3               [24] 1518 	inc	dptr
      000F96 74 0D            [12] 1519 	mov	a,#(_passthrough_next_decoded_byte >> 8)
      000F98 12 2D 8A         [24] 1520 	lcall	__gptrput
                                   1521 ;	encoding.c:76: passthrough_init_decoder(state);
      000F9B 78 46            [12] 1522 	mov	r0,#_init_decoder_PARM_3
      000F9D E2               [24] 1523 	movx	a,@r0
      000F9E F5 82            [12] 1524 	mov	dpl,a
      000FA0 08               [12] 1525 	inc	r0
      000FA1 E2               [24] 1526 	movx	a,@r0
      000FA2 F5 83            [12] 1527 	mov	dph,a
      000FA4 08               [12] 1528 	inc	r0
      000FA5 E2               [24] 1529 	movx	a,@r0
      000FA6 F5 F0            [12] 1530 	mov	b,a
                                   1531 ;	encoding.c:77: break;
      000FA8 02 0D AC         [24] 1532 	ljmp	_passthrough_init_decoder
                                   1533 ;	encoding.c:78: case EncodingTypeManchester:
      000FAB                       1534 00102$:
                                   1535 ;	encoding.c:79: decoder->add_encoded_byte = manchester_add_encoded_byte;
      000FAB 78 43            [12] 1536 	mov	r0,#_init_decoder_PARM_2
      000FAD E2               [24] 1537 	movx	a,@r0
      000FAE FD               [12] 1538 	mov	r5,a
      000FAF 08               [12] 1539 	inc	r0
      000FB0 E2               [24] 1540 	movx	a,@r0
      000FB1 FE               [12] 1541 	mov	r6,a
      000FB2 08               [12] 1542 	inc	r0
      000FB3 E2               [24] 1543 	movx	a,@r0
      000FB4 FF               [12] 1544 	mov	r7,a
      000FB5 8D 82            [24] 1545 	mov	dpl,r5
      000FB7 8E 83            [24] 1546 	mov	dph,r6
      000FB9 8F F0            [24] 1547 	mov	b,r7
      000FBB 74 8B            [12] 1548 	mov	a,#_manchester_add_encoded_byte
      000FBD 12 2D 8A         [24] 1549 	lcall	__gptrput
      000FC0 A3               [24] 1550 	inc	dptr
      000FC1 74 11            [12] 1551 	mov	a,#(_manchester_add_encoded_byte >> 8)
      000FC3 12 2D 8A         [24] 1552 	lcall	__gptrput
                                   1553 ;	encoding.c:80: decoder->next_decoded_byte = manchester_next_decoded_byte;
      000FC6 74 02            [12] 1554 	mov	a,#0x02
      000FC8 2D               [12] 1555 	add	a,r5
      000FC9 FD               [12] 1556 	mov	r5,a
      000FCA E4               [12] 1557 	clr	a
      000FCB 3E               [12] 1558 	addc	a,r6
      000FCC FE               [12] 1559 	mov	r6,a
      000FCD 8D 82            [24] 1560 	mov	dpl,r5
      000FCF 8E 83            [24] 1561 	mov	dph,r6
      000FD1 8F F0            [24] 1562 	mov	b,r7
      000FD3 74 40            [12] 1563 	mov	a,#_manchester_next_decoded_byte
      000FD5 12 2D 8A         [24] 1564 	lcall	__gptrput
      000FD8 A3               [24] 1565 	inc	dptr
      000FD9 74 12            [12] 1566 	mov	a,#(_manchester_next_decoded_byte >> 8)
      000FDB 12 2D 8A         [24] 1567 	lcall	__gptrput
                                   1568 ;	encoding.c:81: manchester_init_decoder(state);
      000FDE 78 46            [12] 1569 	mov	r0,#_init_decoder_PARM_3
      000FE0 E2               [24] 1570 	movx	a,@r0
      000FE1 F5 82            [12] 1571 	mov	dpl,a
      000FE3 08               [12] 1572 	inc	r0
      000FE4 E2               [24] 1573 	movx	a,@r0
      000FE5 F5 83            [12] 1574 	mov	dph,a
      000FE7 08               [12] 1575 	inc	r0
      000FE8 E2               [24] 1576 	movx	a,@r0
      000FE9 F5 F0            [12] 1577 	mov	b,a
                                   1578 ;	encoding.c:82: break;
                                   1579 ;	encoding.c:83: case EncodingTypeFourbSixb:
      000FEB 02 11 72         [24] 1580 	ljmp	_manchester_init_decoder
      000FEE                       1581 00103$:
                                   1582 ;	encoding.c:84: decoder->add_encoded_byte = fourbsixb_add_encoded_byte;
      000FEE 78 43            [12] 1583 	mov	r0,#_init_decoder_PARM_2
      000FF0 E2               [24] 1584 	movx	a,@r0
      000FF1 FD               [12] 1585 	mov	r5,a
      000FF2 08               [12] 1586 	inc	r0
      000FF3 E2               [24] 1587 	movx	a,@r0
      000FF4 FE               [12] 1588 	mov	r6,a
      000FF5 08               [12] 1589 	inc	r0
      000FF6 E2               [24] 1590 	movx	a,@r0
      000FF7 FF               [12] 1591 	mov	r7,a
      000FF8 8D 82            [24] 1592 	mov	dpl,r5
      000FFA 8E 83            [24] 1593 	mov	dph,r6
      000FFC 8F F0            [24] 1594 	mov	b,r7
      000FFE 74 DE            [12] 1595 	mov	a,#_fourbsixb_add_encoded_byte
      001000 12 2D 8A         [24] 1596 	lcall	__gptrput
      001003 A3               [24] 1597 	inc	dptr
      001004 74 14            [12] 1598 	mov	a,#(_fourbsixb_add_encoded_byte >> 8)
      001006 12 2D 8A         [24] 1599 	lcall	__gptrput
                                   1600 ;	encoding.c:85: decoder->next_decoded_byte = fourbsixb_next_decoded_byte;
      001009 74 02            [12] 1601 	mov	a,#0x02
      00100B 2D               [12] 1602 	add	a,r5
      00100C FD               [12] 1603 	mov	r5,a
      00100D E4               [12] 1604 	clr	a
      00100E 3E               [12] 1605 	addc	a,r6
      00100F FE               [12] 1606 	mov	r6,a
      001010 8D 82            [24] 1607 	mov	dpl,r5
      001012 8E 83            [24] 1608 	mov	dph,r6
      001014 8F F0            [24] 1609 	mov	b,r7
      001016 74 51            [12] 1610 	mov	a,#_fourbsixb_next_decoded_byte
      001018 12 2D 8A         [24] 1611 	lcall	__gptrput
      00101B A3               [24] 1612 	inc	dptr
      00101C 74 16            [12] 1613 	mov	a,#(_fourbsixb_next_decoded_byte >> 8)
      00101E 12 2D 8A         [24] 1614 	lcall	__gptrput
                                   1615 ;	encoding.c:86: fourbsixb_init_decoder(state);
      001021 78 46            [12] 1616 	mov	r0,#_init_decoder_PARM_3
      001023 E2               [24] 1617 	movx	a,@r0
      001024 F5 82            [12] 1618 	mov	dpl,a
      001026 08               [12] 1619 	inc	r0
      001027 E2               [24] 1620 	movx	a,@r0
      001028 F5 83            [12] 1621 	mov	dph,a
      00102A 08               [12] 1622 	inc	r0
      00102B E2               [24] 1623 	movx	a,@r0
      00102C F5 F0            [12] 1624 	mov	b,a
                                   1625 ;	encoding.c:88: }
                                   1626 ;	encoding.c:89: }
      00102E 02 14 95         [24] 1627 	ljmp	_fourbsixb_init_decoder
                                   1628 	.area CSEG    (CODE)
                                   1629 	.area CONST   (CODE)
                                   1630 	.area XINIT   (CODE)
                                   1631 	.area CABS    (ABS,CODE)
