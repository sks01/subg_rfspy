                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.0.2 #11662 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module manchester
                                      6 	.optsdcc -mmcs51 --model-medium
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _MODE
                                     12 	.globl _RE
                                     13 	.globl _SLAVE
                                     14 	.globl _FE
                                     15 	.globl _ERR
                                     16 	.globl _RX_BYTE
                                     17 	.globl _TX_BYTE
                                     18 	.globl _ACTIVE
                                     19 	.globl _B_7
                                     20 	.globl _B_6
                                     21 	.globl _B_5
                                     22 	.globl _B_4
                                     23 	.globl _B_3
                                     24 	.globl _B_2
                                     25 	.globl _B_1
                                     26 	.globl _B_0
                                     27 	.globl _WDTIF
                                     28 	.globl _P1IF
                                     29 	.globl _UTX1IF
                                     30 	.globl _UTX0IF
                                     31 	.globl _P2IF
                                     32 	.globl _ACC_7
                                     33 	.globl _ACC_6
                                     34 	.globl _ACC_5
                                     35 	.globl _ACC_4
                                     36 	.globl _ACC_3
                                     37 	.globl _ACC_2
                                     38 	.globl _ACC_1
                                     39 	.globl _ACC_0
                                     40 	.globl _OVFIM
                                     41 	.globl _T4CH1IF
                                     42 	.globl _T4CH0IF
                                     43 	.globl _T4OVFIF
                                     44 	.globl _T3CH1IF
                                     45 	.globl _T3CH0IF
                                     46 	.globl _T3OVFIF
                                     47 	.globl _CY
                                     48 	.globl _AC
                                     49 	.globl _F0
                                     50 	.globl _RS1
                                     51 	.globl _RS0
                                     52 	.globl _OV
                                     53 	.globl _F1
                                     54 	.globl _P
                                     55 	.globl _STIF
                                     56 	.globl _P0IF
                                     57 	.globl _T4IF
                                     58 	.globl _T3IF
                                     59 	.globl _T2IF
                                     60 	.globl _T1IF
                                     61 	.globl _DMAIF
                                     62 	.globl _P0IE
                                     63 	.globl _T4IE
                                     64 	.globl _T3IE
                                     65 	.globl _T2IE
                                     66 	.globl _T1IE
                                     67 	.globl _DMAIE
                                     68 	.globl _EA
                                     69 	.globl _STIE
                                     70 	.globl _ENCIE
                                     71 	.globl _URX1IE
                                     72 	.globl _URX0IE
                                     73 	.globl _ADCIE
                                     74 	.globl _RFTXRXIE
                                     75 	.globl _P2_7
                                     76 	.globl _P2_6
                                     77 	.globl _P2_5
                                     78 	.globl _P2_4
                                     79 	.globl _P2_3
                                     80 	.globl _P2_2
                                     81 	.globl _P2_1
                                     82 	.globl _P2_0
                                     83 	.globl _ENCIF_1
                                     84 	.globl _ENCIF_0
                                     85 	.globl _P1_7
                                     86 	.globl _P1_6
                                     87 	.globl _P1_5
                                     88 	.globl _P1_4
                                     89 	.globl _P1_3
                                     90 	.globl _P1_2
                                     91 	.globl _P1_1
                                     92 	.globl _P1_0
                                     93 	.globl _URX1IF
                                     94 	.globl _ADCIF
                                     95 	.globl _URX0IF
                                     96 	.globl _IT1
                                     97 	.globl _RFTXRXIF
                                     98 	.globl _IT0
                                     99 	.globl _P0_7
                                    100 	.globl _P0_6
                                    101 	.globl _P0_5
                                    102 	.globl _P0_4
                                    103 	.globl _P0_3
                                    104 	.globl _P0_2
                                    105 	.globl _P0_1
                                    106 	.globl _P0_0
                                    107 	.globl _P2DIR
                                    108 	.globl _P1DIR
                                    109 	.globl _P0DIR
                                    110 	.globl _U1GCR
                                    111 	.globl _U1UCR
                                    112 	.globl _U1BAUD
                                    113 	.globl _U1DBUF
                                    114 	.globl _U1CSR
                                    115 	.globl _P2INP
                                    116 	.globl _P1INP
                                    117 	.globl _P2SEL
                                    118 	.globl _P1SEL
                                    119 	.globl _P0SEL
                                    120 	.globl _ADCCFG
                                    121 	.globl _PERCFG
                                    122 	.globl _B
                                    123 	.globl _T4CC1
                                    124 	.globl _T4CCTL1
                                    125 	.globl _T4CC0
                                    126 	.globl _T4CCTL0
                                    127 	.globl _T4CTL
                                    128 	.globl _T4CNT
                                    129 	.globl _RFIF
                                    130 	.globl _IRCON2
                                    131 	.globl _T1CCTL2
                                    132 	.globl _T1CCTL1
                                    133 	.globl _T1CCTL0
                                    134 	.globl _T1CTL
                                    135 	.globl _T1CNTH
                                    136 	.globl _T1CNTL
                                    137 	.globl _RFST
                                    138 	.globl _ACC
                                    139 	.globl _T1CC2H
                                    140 	.globl _T1CC2L
                                    141 	.globl _T1CC1H
                                    142 	.globl _T1CC1L
                                    143 	.globl _T1CC0H
                                    144 	.globl _T1CC0L
                                    145 	.globl _RFD
                                    146 	.globl _TIMIF
                                    147 	.globl _DMAREQ
                                    148 	.globl _DMAARM
                                    149 	.globl _DMA0CFGH
                                    150 	.globl _DMA0CFGL
                                    151 	.globl _DMA1CFGH
                                    152 	.globl _DMA1CFGL
                                    153 	.globl _DMAIRQ
                                    154 	.globl _PSW
                                    155 	.globl _T3CC1
                                    156 	.globl _T3CCTL1
                                    157 	.globl _T3CC0
                                    158 	.globl _T3CCTL0
                                    159 	.globl _T3CTL
                                    160 	.globl _T3CNT
                                    161 	.globl _WDCTL
                                    162 	.globl __SFRC8
                                    163 	.globl _MEMCTR
                                    164 	.globl _CLKCON
                                    165 	.globl _U0GCR
                                    166 	.globl _U0UCR
                                    167 	.globl __SFRC3
                                    168 	.globl _U0BAUD
                                    169 	.globl _U0DBUF
                                    170 	.globl _IRCON
                                    171 	.globl __SFRBF
                                    172 	.globl _SLEEP
                                    173 	.globl _RNDH
                                    174 	.globl _RNDL
                                    175 	.globl _ADCH
                                    176 	.globl _ADCL
                                    177 	.globl _IP1
                                    178 	.globl _IEN1
                                    179 	.globl __SFRB7
                                    180 	.globl _ADCCON3
                                    181 	.globl _ADCCON2
                                    182 	.globl _ADCCON1
                                    183 	.globl _ENCCS
                                    184 	.globl _ENCDO
                                    185 	.globl _ENCDI
                                    186 	.globl __SFRB0
                                    187 	.globl _FWDATA
                                    188 	.globl _FCTL
                                    189 	.globl _FADDRH
                                    190 	.globl _FADDRL
                                    191 	.globl _FWT
                                    192 	.globl __SFRAA
                                    193 	.globl _IP0
                                    194 	.globl _IEN0
                                    195 	.globl __SFRA7
                                    196 	.globl _WORTIME1
                                    197 	.globl _WORTIME0
                                    198 	.globl _WOREVT1
                                    199 	.globl _WOREVT0
                                    200 	.globl _WORCTRL
                                    201 	.globl _WORIRQ
                                    202 	.globl _P2
                                    203 	.globl __SFR9F
                                    204 	.globl _T2CTL
                                    205 	.globl _T2PR
                                    206 	.globl _T2CT
                                    207 	.globl _S1CON
                                    208 	.globl _IEN2
                                    209 	.globl __SFR99
                                    210 	.globl _S0CON
                                    211 	.globl __SFR97
                                    212 	.globl __SFR96
                                    213 	.globl __SFR95
                                    214 	.globl __SFR94
                                    215 	.globl __XPAGE
                                    216 	.globl _MPAGE
                                    217 	.globl _DPS
                                    218 	.globl _RFIM
                                    219 	.globl _P1
                                    220 	.globl _P0INP
                                    221 	.globl __SFR8E
                                    222 	.globl _P1IEN
                                    223 	.globl _PICTL
                                    224 	.globl _P2IFG
                                    225 	.globl _P1IFG
                                    226 	.globl _P0IFG
                                    227 	.globl _TCON
                                    228 	.globl _PCON
                                    229 	.globl _U0CSR
                                    230 	.globl _DPH1
                                    231 	.globl _DPL1
                                    232 	.globl _DPH0
                                    233 	.globl _DPL0
                                    234 	.globl _SP
                                    235 	.globl _P0
                                    236 	.globl _X_P2DIR
                                    237 	.globl _X_P1DIR
                                    238 	.globl _X_P0DIR
                                    239 	.globl _X_U1GCR
                                    240 	.globl _X_U1UCR
                                    241 	.globl _X_U1BAUD
                                    242 	.globl _X_U1DBUF
                                    243 	.globl _X_U1CSR
                                    244 	.globl _X_P2INP
                                    245 	.globl _X_P1INP
                                    246 	.globl _X_P2SEL
                                    247 	.globl _X_P1SEL
                                    248 	.globl _X_P0SEL
                                    249 	.globl _X_ADCCFG
                                    250 	.globl _X_PERCFG
                                    251 	.globl __NA_B
                                    252 	.globl _X_T4CC1
                                    253 	.globl _X_T4CCTL1
                                    254 	.globl _X_T4CC0
                                    255 	.globl _X_T4CCTL0
                                    256 	.globl _X_T4CTL
                                    257 	.globl _X_T4CNT
                                    258 	.globl _X_RFIF
                                    259 	.globl __NA_IRCON2
                                    260 	.globl _X_T1CCTL2
                                    261 	.globl _X_T1CCTL1
                                    262 	.globl _X_T1CCTL0
                                    263 	.globl _X_T1CTL
                                    264 	.globl _X_T1CNTH
                                    265 	.globl _X_T1CNTL
                                    266 	.globl _X_RFST
                                    267 	.globl __NA_ACC
                                    268 	.globl _X_T1CC2H
                                    269 	.globl _X_T1CC2L
                                    270 	.globl _X_T1CC1H
                                    271 	.globl _X_T1CC1L
                                    272 	.globl _X_T1CC0H
                                    273 	.globl _X_T1CC0L
                                    274 	.globl _X_RFD
                                    275 	.globl _X_TIMIF
                                    276 	.globl _X_DMAREQ
                                    277 	.globl _X_DMAARM
                                    278 	.globl _X_DMA0CFGH
                                    279 	.globl _X_DMA0CFGL
                                    280 	.globl _X_DMA1CFGH
                                    281 	.globl _X_DMA1CFGL
                                    282 	.globl _X_DMAIRQ
                                    283 	.globl __NA_PSW
                                    284 	.globl _X_T3CC1
                                    285 	.globl _X_T3CCTL1
                                    286 	.globl _X_T3CC0
                                    287 	.globl _X_T3CCTL0
                                    288 	.globl _X_T3CTL
                                    289 	.globl _X_T3CNT
                                    290 	.globl _X_WDCTL
                                    291 	.globl __X_SFRC8
                                    292 	.globl _X_MEMCTR
                                    293 	.globl _X_CLKCON
                                    294 	.globl _X_U0GCR
                                    295 	.globl _X_U0UCR
                                    296 	.globl __X_SFRC3
                                    297 	.globl _X_U0BAUD
                                    298 	.globl _X_U0DBUF
                                    299 	.globl __NA_IRCON
                                    300 	.globl __X_SFRBF
                                    301 	.globl _X_SLEEP
                                    302 	.globl _X_RNDH
                                    303 	.globl _X_RNDL
                                    304 	.globl _X_ADCH
                                    305 	.globl _X_ADCL
                                    306 	.globl __NA_IP1
                                    307 	.globl __NA_IEN1
                                    308 	.globl __X_SFRB7
                                    309 	.globl _X_ADCCON3
                                    310 	.globl _X_ADCCON2
                                    311 	.globl _X_ADCCON1
                                    312 	.globl _X_ENCCS
                                    313 	.globl _X_ENCDO
                                    314 	.globl _X_ENCDI
                                    315 	.globl __X_SFRB0
                                    316 	.globl _X_FWDATA
                                    317 	.globl _X_FCTL
                                    318 	.globl _X_FADDRH
                                    319 	.globl _X_FADDRL
                                    320 	.globl _X_FWT
                                    321 	.globl __X_SFRAA
                                    322 	.globl __NA_IP0
                                    323 	.globl __NA_IEN0
                                    324 	.globl __X_SFRA7
                                    325 	.globl _X_WORTIME1
                                    326 	.globl _X_WORTIME0
                                    327 	.globl _X_WOREVT1
                                    328 	.globl _X_WOREVT0
                                    329 	.globl _X_WORCTRL
                                    330 	.globl _X_WORIRQ
                                    331 	.globl __NA_P2
                                    332 	.globl __X_SFR9F
                                    333 	.globl _X_T2CTL
                                    334 	.globl _X_T2PR
                                    335 	.globl _X_T2CT
                                    336 	.globl __NA_S1CON
                                    337 	.globl __NA_IEN2
                                    338 	.globl __X_SFR99
                                    339 	.globl __NA_S0CON
                                    340 	.globl __X_SFR97
                                    341 	.globl __X_SFR96
                                    342 	.globl __X_SFR95
                                    343 	.globl __X_SFR94
                                    344 	.globl _X_MPAGE
                                    345 	.globl __NA_DPS
                                    346 	.globl _X_RFIM
                                    347 	.globl __NA_P1
                                    348 	.globl _X_P0INP
                                    349 	.globl __X_SFR8E
                                    350 	.globl _X_P1IEN
                                    351 	.globl _X_PICTL
                                    352 	.globl _X_P2IFG
                                    353 	.globl _X_P1IFG
                                    354 	.globl _X_P0IFG
                                    355 	.globl __NA_TCON
                                    356 	.globl __NA_PCON
                                    357 	.globl _X_U0CSR
                                    358 	.globl __NA_DPH1
                                    359 	.globl __NA_DPL1
                                    360 	.globl __NA_DPH0
                                    361 	.globl __NA_DPL0
                                    362 	.globl __NA_SP
                                    363 	.globl __NA_P0
                                    364 	.globl _I2SCLKF2
                                    365 	.globl _I2SCLKF1
                                    366 	.globl _I2SCLKF0
                                    367 	.globl _I2SSTAT
                                    368 	.globl _I2SWCNT
                                    369 	.globl _I2SDATH
                                    370 	.globl _I2SDATL
                                    371 	.globl _I2SCFG1
                                    372 	.globl _I2SCFG0
                                    373 	.globl _VCO_VC_DAC
                                    374 	.globl _PKTSTATUS
                                    375 	.globl _MARCSTATE
                                    376 	.globl _RSSI
                                    377 	.globl _LQI
                                    378 	.globl _FREQEST
                                    379 	.globl _VERSION
                                    380 	.globl _PARTNUM
                                    381 	.globl __XREGDF35
                                    382 	.globl __XREGDF34
                                    383 	.globl __XREGDF33
                                    384 	.globl __XREGDF32
                                    385 	.globl _IOCFG0
                                    386 	.globl _IOCFG1
                                    387 	.globl _IOCFG2
                                    388 	.globl _PA_TABLE0
                                    389 	.globl _PA_TABLE1
                                    390 	.globl _PA_TABLE2
                                    391 	.globl _PA_TABLE3
                                    392 	.globl _PA_TABLE4
                                    393 	.globl _PA_TABLE5
                                    394 	.globl _PA_TABLE6
                                    395 	.globl _PA_TABLE7
                                    396 	.globl __XREGDF26
                                    397 	.globl _TEST0
                                    398 	.globl _TEST1
                                    399 	.globl _TEST2
                                    400 	.globl __XREGDF22
                                    401 	.globl __XREGDF21
                                    402 	.globl __XREGDF20
                                    403 	.globl _FSCAL0
                                    404 	.globl _FSCAL1
                                    405 	.globl _FSCAL2
                                    406 	.globl _FSCAL3
                                    407 	.globl _FREND0
                                    408 	.globl _FREND1
                                    409 	.globl _AGCCTRL0
                                    410 	.globl _AGCCTRL1
                                    411 	.globl _AGCCTRL2
                                    412 	.globl _BSCFG
                                    413 	.globl _FOCCFG
                                    414 	.globl _MCSM0
                                    415 	.globl _MCSM1
                                    416 	.globl _MCSM2
                                    417 	.globl _DEVIATN
                                    418 	.globl _MDMCFG0
                                    419 	.globl _MDMCFG1
                                    420 	.globl _MDMCFG2
                                    421 	.globl _MDMCFG3
                                    422 	.globl _MDMCFG4
                                    423 	.globl _FREQ0
                                    424 	.globl _FREQ1
                                    425 	.globl _FREQ2
                                    426 	.globl _FSCTRL0
                                    427 	.globl _FSCTRL1
                                    428 	.globl _CHANNR
                                    429 	.globl _ADDR
                                    430 	.globl _PKTCTRL0
                                    431 	.globl _PKTCTRL1
                                    432 	.globl _PKTLEN
                                    433 	.globl _SYNC0
                                    434 	.globl _SYNC1
                                    435 	.globl _MDMCTRL0H
                                    436 	.globl _manchester_init_encoder
                                    437 	.globl _manchester_add_raw_byte
                                    438 	.globl _manchester_next_encoded_byte
                                    439 	.globl _manchester_init_decoder
                                    440 	.globl _manchester_add_encoded_byte
                                    441 	.globl _manchester_next_decoded_byte
                                    442 ;--------------------------------------------------------
                                    443 ; special function registers
                                    444 ;--------------------------------------------------------
                                    445 	.area RSEG    (ABS,DATA)
      000000                        446 	.org 0x0000
                           000080   447 _P0	=	0x0080
                           000081   448 _SP	=	0x0081
                           000082   449 _DPL0	=	0x0082
                           000083   450 _DPH0	=	0x0083
                           000084   451 _DPL1	=	0x0084
                           000085   452 _DPH1	=	0x0085
                           000086   453 _U0CSR	=	0x0086
                           000087   454 _PCON	=	0x0087
                           000088   455 _TCON	=	0x0088
                           000089   456 _P0IFG	=	0x0089
                           00008A   457 _P1IFG	=	0x008a
                           00008B   458 _P2IFG	=	0x008b
                           00008C   459 _PICTL	=	0x008c
                           00008D   460 _P1IEN	=	0x008d
                           00008E   461 __SFR8E	=	0x008e
                           00008F   462 _P0INP	=	0x008f
                           000090   463 _P1	=	0x0090
                           000091   464 _RFIM	=	0x0091
                           000092   465 _DPS	=	0x0092
                           000093   466 _MPAGE	=	0x0093
                           000093   467 __XPAGE	=	0x0093
                           000094   468 __SFR94	=	0x0094
                           000095   469 __SFR95	=	0x0095
                           000096   470 __SFR96	=	0x0096
                           000097   471 __SFR97	=	0x0097
                           000098   472 _S0CON	=	0x0098
                           000099   473 __SFR99	=	0x0099
                           00009A   474 _IEN2	=	0x009a
                           00009B   475 _S1CON	=	0x009b
                           00009C   476 _T2CT	=	0x009c
                           00009D   477 _T2PR	=	0x009d
                           00009E   478 _T2CTL	=	0x009e
                           00009F   479 __SFR9F	=	0x009f
                           0000A0   480 _P2	=	0x00a0
                           0000A1   481 _WORIRQ	=	0x00a1
                           0000A2   482 _WORCTRL	=	0x00a2
                           0000A3   483 _WOREVT0	=	0x00a3
                           0000A4   484 _WOREVT1	=	0x00a4
                           0000A5   485 _WORTIME0	=	0x00a5
                           0000A6   486 _WORTIME1	=	0x00a6
                           0000A7   487 __SFRA7	=	0x00a7
                           0000A8   488 _IEN0	=	0x00a8
                           0000A9   489 _IP0	=	0x00a9
                           0000AA   490 __SFRAA	=	0x00aa
                           0000AB   491 _FWT	=	0x00ab
                           0000AC   492 _FADDRL	=	0x00ac
                           0000AD   493 _FADDRH	=	0x00ad
                           0000AE   494 _FCTL	=	0x00ae
                           0000AF   495 _FWDATA	=	0x00af
                           0000B0   496 __SFRB0	=	0x00b0
                           0000B1   497 _ENCDI	=	0x00b1
                           0000B2   498 _ENCDO	=	0x00b2
                           0000B3   499 _ENCCS	=	0x00b3
                           0000B4   500 _ADCCON1	=	0x00b4
                           0000B5   501 _ADCCON2	=	0x00b5
                           0000B6   502 _ADCCON3	=	0x00b6
                           0000B7   503 __SFRB7	=	0x00b7
                           0000B8   504 _IEN1	=	0x00b8
                           0000B9   505 _IP1	=	0x00b9
                           0000BA   506 _ADCL	=	0x00ba
                           0000BB   507 _ADCH	=	0x00bb
                           0000BC   508 _RNDL	=	0x00bc
                           0000BD   509 _RNDH	=	0x00bd
                           0000BE   510 _SLEEP	=	0x00be
                           0000BF   511 __SFRBF	=	0x00bf
                           0000C0   512 _IRCON	=	0x00c0
                           0000C1   513 _U0DBUF	=	0x00c1
                           0000C2   514 _U0BAUD	=	0x00c2
                           0000C3   515 __SFRC3	=	0x00c3
                           0000C4   516 _U0UCR	=	0x00c4
                           0000C5   517 _U0GCR	=	0x00c5
                           0000C6   518 _CLKCON	=	0x00c6
                           0000C7   519 _MEMCTR	=	0x00c7
                           0000C8   520 __SFRC8	=	0x00c8
                           0000C9   521 _WDCTL	=	0x00c9
                           0000CA   522 _T3CNT	=	0x00ca
                           0000CB   523 _T3CTL	=	0x00cb
                           0000CC   524 _T3CCTL0	=	0x00cc
                           0000CD   525 _T3CC0	=	0x00cd
                           0000CE   526 _T3CCTL1	=	0x00ce
                           0000CF   527 _T3CC1	=	0x00cf
                           0000D0   528 _PSW	=	0x00d0
                           0000D1   529 _DMAIRQ	=	0x00d1
                           0000D2   530 _DMA1CFGL	=	0x00d2
                           0000D3   531 _DMA1CFGH	=	0x00d3
                           0000D4   532 _DMA0CFGL	=	0x00d4
                           0000D5   533 _DMA0CFGH	=	0x00d5
                           0000D6   534 _DMAARM	=	0x00d6
                           0000D7   535 _DMAREQ	=	0x00d7
                           0000D8   536 _TIMIF	=	0x00d8
                           0000D9   537 _RFD	=	0x00d9
                           0000DA   538 _T1CC0L	=	0x00da
                           0000DB   539 _T1CC0H	=	0x00db
                           0000DC   540 _T1CC1L	=	0x00dc
                           0000DD   541 _T1CC1H	=	0x00dd
                           0000DE   542 _T1CC2L	=	0x00de
                           0000DF   543 _T1CC2H	=	0x00df
                           0000E0   544 _ACC	=	0x00e0
                           0000E1   545 _RFST	=	0x00e1
                           0000E2   546 _T1CNTL	=	0x00e2
                           0000E3   547 _T1CNTH	=	0x00e3
                           0000E4   548 _T1CTL	=	0x00e4
                           0000E5   549 _T1CCTL0	=	0x00e5
                           0000E6   550 _T1CCTL1	=	0x00e6
                           0000E7   551 _T1CCTL2	=	0x00e7
                           0000E8   552 _IRCON2	=	0x00e8
                           0000E9   553 _RFIF	=	0x00e9
                           0000EA   554 _T4CNT	=	0x00ea
                           0000EB   555 _T4CTL	=	0x00eb
                           0000EC   556 _T4CCTL0	=	0x00ec
                           0000ED   557 _T4CC0	=	0x00ed
                           0000EE   558 _T4CCTL1	=	0x00ee
                           0000EF   559 _T4CC1	=	0x00ef
                           0000F0   560 _B	=	0x00f0
                           0000F1   561 _PERCFG	=	0x00f1
                           0000F2   562 _ADCCFG	=	0x00f2
                           0000F3   563 _P0SEL	=	0x00f3
                           0000F4   564 _P1SEL	=	0x00f4
                           0000F5   565 _P2SEL	=	0x00f5
                           0000F6   566 _P1INP	=	0x00f6
                           0000F7   567 _P2INP	=	0x00f7
                           0000F8   568 _U1CSR	=	0x00f8
                           0000F9   569 _U1DBUF	=	0x00f9
                           0000FA   570 _U1BAUD	=	0x00fa
                           0000FB   571 _U1UCR	=	0x00fb
                           0000FC   572 _U1GCR	=	0x00fc
                           0000FD   573 _P0DIR	=	0x00fd
                           0000FE   574 _P1DIR	=	0x00fe
                           0000FF   575 _P2DIR	=	0x00ff
                                    576 ;--------------------------------------------------------
                                    577 ; special function bits
                                    578 ;--------------------------------------------------------
                                    579 	.area RSEG    (ABS,DATA)
      000000                        580 	.org 0x0000
                           000080   581 _P0_0	=	0x0080
                           000081   582 _P0_1	=	0x0081
                           000082   583 _P0_2	=	0x0082
                           000083   584 _P0_3	=	0x0083
                           000084   585 _P0_4	=	0x0084
                           000085   586 _P0_5	=	0x0085
                           000086   587 _P0_6	=	0x0086
                           000087   588 _P0_7	=	0x0087
                           000088   589 _IT0	=	0x0088
                           000089   590 _RFTXRXIF	=	0x0089
                           00008A   591 _IT1	=	0x008a
                           00008B   592 _URX0IF	=	0x008b
                           00008D   593 _ADCIF	=	0x008d
                           00008F   594 _URX1IF	=	0x008f
                           000090   595 _P1_0	=	0x0090
                           000091   596 _P1_1	=	0x0091
                           000092   597 _P1_2	=	0x0092
                           000093   598 _P1_3	=	0x0093
                           000094   599 _P1_4	=	0x0094
                           000095   600 _P1_5	=	0x0095
                           000096   601 _P1_6	=	0x0096
                           000097   602 _P1_7	=	0x0097
                           000098   603 _ENCIF_0	=	0x0098
                           000099   604 _ENCIF_1	=	0x0099
                           0000A0   605 _P2_0	=	0x00a0
                           0000A1   606 _P2_1	=	0x00a1
                           0000A2   607 _P2_2	=	0x00a2
                           0000A3   608 _P2_3	=	0x00a3
                           0000A4   609 _P2_4	=	0x00a4
                           0000A5   610 _P2_5	=	0x00a5
                           0000A6   611 _P2_6	=	0x00a6
                           0000A7   612 _P2_7	=	0x00a7
                           0000A8   613 _RFTXRXIE	=	0x00a8
                           0000A9   614 _ADCIE	=	0x00a9
                           0000AA   615 _URX0IE	=	0x00aa
                           0000AB   616 _URX1IE	=	0x00ab
                           0000AC   617 _ENCIE	=	0x00ac
                           0000AD   618 _STIE	=	0x00ad
                           0000AF   619 _EA	=	0x00af
                           0000B8   620 _DMAIE	=	0x00b8
                           0000B9   621 _T1IE	=	0x00b9
                           0000BA   622 _T2IE	=	0x00ba
                           0000BB   623 _T3IE	=	0x00bb
                           0000BC   624 _T4IE	=	0x00bc
                           0000BD   625 _P0IE	=	0x00bd
                           0000C0   626 _DMAIF	=	0x00c0
                           0000C1   627 _T1IF	=	0x00c1
                           0000C2   628 _T2IF	=	0x00c2
                           0000C3   629 _T3IF	=	0x00c3
                           0000C4   630 _T4IF	=	0x00c4
                           0000C5   631 _P0IF	=	0x00c5
                           0000C7   632 _STIF	=	0x00c7
                           0000D0   633 _P	=	0x00d0
                           0000D1   634 _F1	=	0x00d1
                           0000D2   635 _OV	=	0x00d2
                           0000D3   636 _RS0	=	0x00d3
                           0000D4   637 _RS1	=	0x00d4
                           0000D5   638 _F0	=	0x00d5
                           0000D6   639 _AC	=	0x00d6
                           0000D7   640 _CY	=	0x00d7
                           0000D8   641 _T3OVFIF	=	0x00d8
                           0000D9   642 _T3CH0IF	=	0x00d9
                           0000DA   643 _T3CH1IF	=	0x00da
                           0000DB   644 _T4OVFIF	=	0x00db
                           0000DC   645 _T4CH0IF	=	0x00dc
                           0000DD   646 _T4CH1IF	=	0x00dd
                           0000DE   647 _OVFIM	=	0x00de
                           0000E0   648 _ACC_0	=	0x00e0
                           0000E1   649 _ACC_1	=	0x00e1
                           0000E2   650 _ACC_2	=	0x00e2
                           0000E3   651 _ACC_3	=	0x00e3
                           0000E4   652 _ACC_4	=	0x00e4
                           0000E5   653 _ACC_5	=	0x00e5
                           0000E6   654 _ACC_6	=	0x00e6
                           0000E7   655 _ACC_7	=	0x00e7
                           0000E8   656 _P2IF	=	0x00e8
                           0000E9   657 _UTX0IF	=	0x00e9
                           0000EA   658 _UTX1IF	=	0x00ea
                           0000EB   659 _P1IF	=	0x00eb
                           0000EC   660 _WDTIF	=	0x00ec
                           0000F0   661 _B_0	=	0x00f0
                           0000F1   662 _B_1	=	0x00f1
                           0000F2   663 _B_2	=	0x00f2
                           0000F3   664 _B_3	=	0x00f3
                           0000F4   665 _B_4	=	0x00f4
                           0000F5   666 _B_5	=	0x00f5
                           0000F6   667 _B_6	=	0x00f6
                           0000F7   668 _B_7	=	0x00f7
                           0000F8   669 _ACTIVE	=	0x00f8
                           0000F9   670 _TX_BYTE	=	0x00f9
                           0000FA   671 _RX_BYTE	=	0x00fa
                           0000FB   672 _ERR	=	0x00fb
                           0000FC   673 _FE	=	0x00fc
                           0000FD   674 _SLAVE	=	0x00fd
                           0000FE   675 _RE	=	0x00fe
                           0000FF   676 _MODE	=	0x00ff
                                    677 ;--------------------------------------------------------
                                    678 ; overlayable register banks
                                    679 ;--------------------------------------------------------
                                    680 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        681 	.ds 8
                                    682 ;--------------------------------------------------------
                                    683 ; internal ram data
                                    684 ;--------------------------------------------------------
                                    685 	.area DSEG    (DATA)
                                    686 ;--------------------------------------------------------
                                    687 ; overlayable items in internal ram 
                                    688 ;--------------------------------------------------------
                                    689 ;--------------------------------------------------------
                                    690 ; indirectly addressable internal ram data
                                    691 ;--------------------------------------------------------
                                    692 	.area ISEG    (DATA)
                                    693 ;--------------------------------------------------------
                                    694 ; absolute internal ram data
                                    695 ;--------------------------------------------------------
                                    696 	.area IABS    (ABS,DATA)
                                    697 	.area IABS    (ABS,DATA)
                                    698 ;--------------------------------------------------------
                                    699 ; bit data
                                    700 ;--------------------------------------------------------
                                    701 	.area BSEG    (BIT)
                                    702 ;--------------------------------------------------------
                                    703 ; paged external ram data
                                    704 ;--------------------------------------------------------
                                    705 	.area PSEG    (PAG,XDATA)
                                    706 ;--------------------------------------------------------
                                    707 ; external ram data
                                    708 ;--------------------------------------------------------
                                    709 	.area XSEG    (XDATA)
                           00DF02   710 _MDMCTRL0H	=	0xdf02
                           00DF00   711 _SYNC1	=	0xdf00
                           00DF01   712 _SYNC0	=	0xdf01
                           00DF02   713 _PKTLEN	=	0xdf02
                           00DF03   714 _PKTCTRL1	=	0xdf03
                           00DF04   715 _PKTCTRL0	=	0xdf04
                           00DF05   716 _ADDR	=	0xdf05
                           00DF06   717 _CHANNR	=	0xdf06
                           00DF07   718 _FSCTRL1	=	0xdf07
                           00DF08   719 _FSCTRL0	=	0xdf08
                           00DF09   720 _FREQ2	=	0xdf09
                           00DF0A   721 _FREQ1	=	0xdf0a
                           00DF0B   722 _FREQ0	=	0xdf0b
                           00DF0C   723 _MDMCFG4	=	0xdf0c
                           00DF0D   724 _MDMCFG3	=	0xdf0d
                           00DF0E   725 _MDMCFG2	=	0xdf0e
                           00DF0F   726 _MDMCFG1	=	0xdf0f
                           00DF10   727 _MDMCFG0	=	0xdf10
                           00DF11   728 _DEVIATN	=	0xdf11
                           00DF12   729 _MCSM2	=	0xdf12
                           00DF13   730 _MCSM1	=	0xdf13
                           00DF14   731 _MCSM0	=	0xdf14
                           00DF15   732 _FOCCFG	=	0xdf15
                           00DF16   733 _BSCFG	=	0xdf16
                           00DF17   734 _AGCCTRL2	=	0xdf17
                           00DF18   735 _AGCCTRL1	=	0xdf18
                           00DF19   736 _AGCCTRL0	=	0xdf19
                           00DF1A   737 _FREND1	=	0xdf1a
                           00DF1B   738 _FREND0	=	0xdf1b
                           00DF1C   739 _FSCAL3	=	0xdf1c
                           00DF1D   740 _FSCAL2	=	0xdf1d
                           00DF1E   741 _FSCAL1	=	0xdf1e
                           00DF1F   742 _FSCAL0	=	0xdf1f
                           00DF20   743 __XREGDF20	=	0xdf20
                           00DF21   744 __XREGDF21	=	0xdf21
                           00DF22   745 __XREGDF22	=	0xdf22
                           00DF23   746 _TEST2	=	0xdf23
                           00DF24   747 _TEST1	=	0xdf24
                           00DF25   748 _TEST0	=	0xdf25
                           00DF26   749 __XREGDF26	=	0xdf26
                           00DF27   750 _PA_TABLE7	=	0xdf27
                           00DF28   751 _PA_TABLE6	=	0xdf28
                           00DF29   752 _PA_TABLE5	=	0xdf29
                           00DF2A   753 _PA_TABLE4	=	0xdf2a
                           00DF2B   754 _PA_TABLE3	=	0xdf2b
                           00DF2C   755 _PA_TABLE2	=	0xdf2c
                           00DF2D   756 _PA_TABLE1	=	0xdf2d
                           00DF2E   757 _PA_TABLE0	=	0xdf2e
                           00DF2F   758 _IOCFG2	=	0xdf2f
                           00DF30   759 _IOCFG1	=	0xdf30
                           00DF31   760 _IOCFG0	=	0xdf31
                           00DF32   761 __XREGDF32	=	0xdf32
                           00DF33   762 __XREGDF33	=	0xdf33
                           00DF34   763 __XREGDF34	=	0xdf34
                           00DF35   764 __XREGDF35	=	0xdf35
                           00DF36   765 _PARTNUM	=	0xdf36
                           00DF37   766 _VERSION	=	0xdf37
                           00DF38   767 _FREQEST	=	0xdf38
                           00DF39   768 _LQI	=	0xdf39
                           00DF3A   769 _RSSI	=	0xdf3a
                           00DF3B   770 _MARCSTATE	=	0xdf3b
                           00DF3C   771 _PKTSTATUS	=	0xdf3c
                           00DF3D   772 _VCO_VC_DAC	=	0xdf3d
                           00DF40   773 _I2SCFG0	=	0xdf40
                           00DF41   774 _I2SCFG1	=	0xdf41
                           00DF42   775 _I2SDATL	=	0xdf42
                           00DF43   776 _I2SDATH	=	0xdf43
                           00DF44   777 _I2SWCNT	=	0xdf44
                           00DF45   778 _I2SSTAT	=	0xdf45
                           00DF46   779 _I2SCLKF0	=	0xdf46
                           00DF47   780 _I2SCLKF1	=	0xdf47
                           00DF48   781 _I2SCLKF2	=	0xdf48
                           00DF80   782 __NA_P0	=	0xdf80
                           00DF81   783 __NA_SP	=	0xdf81
                           00DF82   784 __NA_DPL0	=	0xdf82
                           00DF83   785 __NA_DPH0	=	0xdf83
                           00DF84   786 __NA_DPL1	=	0xdf84
                           00DF85   787 __NA_DPH1	=	0xdf85
                           00DF86   788 _X_U0CSR	=	0xdf86
                           00DF87   789 __NA_PCON	=	0xdf87
                           00DF88   790 __NA_TCON	=	0xdf88
                           00DF89   791 _X_P0IFG	=	0xdf89
                           00DF8A   792 _X_P1IFG	=	0xdf8a
                           00DF8B   793 _X_P2IFG	=	0xdf8b
                           00DF8C   794 _X_PICTL	=	0xdf8c
                           00DF8D   795 _X_P1IEN	=	0xdf8d
                           00DF8E   796 __X_SFR8E	=	0xdf8e
                           00DF8F   797 _X_P0INP	=	0xdf8f
                           00DF90   798 __NA_P1	=	0xdf90
                           00DF91   799 _X_RFIM	=	0xdf91
                           00DF92   800 __NA_DPS	=	0xdf92
                           00DF93   801 _X_MPAGE	=	0xdf93
                           00DF94   802 __X_SFR94	=	0xdf94
                           00DF95   803 __X_SFR95	=	0xdf95
                           00DF96   804 __X_SFR96	=	0xdf96
                           00DF97   805 __X_SFR97	=	0xdf97
                           00DF98   806 __NA_S0CON	=	0xdf98
                           00DF99   807 __X_SFR99	=	0xdf99
                           00DF9A   808 __NA_IEN2	=	0xdf9a
                           00DF9B   809 __NA_S1CON	=	0xdf9b
                           00DF9C   810 _X_T2CT	=	0xdf9c
                           00DF9D   811 _X_T2PR	=	0xdf9d
                           00DF9E   812 _X_T2CTL	=	0xdf9e
                           00DF9F   813 __X_SFR9F	=	0xdf9f
                           00DFA0   814 __NA_P2	=	0xdfa0
                           00DFA1   815 _X_WORIRQ	=	0xdfa1
                           00DFA2   816 _X_WORCTRL	=	0xdfa2
                           00DFA3   817 _X_WOREVT0	=	0xdfa3
                           00DFA4   818 _X_WOREVT1	=	0xdfa4
                           00DFA5   819 _X_WORTIME0	=	0xdfa5
                           00DFA6   820 _X_WORTIME1	=	0xdfa6
                           00DFA7   821 __X_SFRA7	=	0xdfa7
                           00DFA8   822 __NA_IEN0	=	0xdfa8
                           00DFA9   823 __NA_IP0	=	0xdfa9
                           00DFAA   824 __X_SFRAA	=	0xdfaa
                           00DFAB   825 _X_FWT	=	0xdfab
                           00DFAC   826 _X_FADDRL	=	0xdfac
                           00DFAD   827 _X_FADDRH	=	0xdfad
                           00DFAE   828 _X_FCTL	=	0xdfae
                           00DFAF   829 _X_FWDATA	=	0xdfaf
                           00DFB0   830 __X_SFRB0	=	0xdfb0
                           00DFB1   831 _X_ENCDI	=	0xdfb1
                           00DFB2   832 _X_ENCDO	=	0xdfb2
                           00DFB3   833 _X_ENCCS	=	0xdfb3
                           00DFB4   834 _X_ADCCON1	=	0xdfb4
                           00DFB5   835 _X_ADCCON2	=	0xdfb5
                           00DFB6   836 _X_ADCCON3	=	0xdfb6
                           00DFB7   837 __X_SFRB7	=	0xdfb7
                           00DFB8   838 __NA_IEN1	=	0xdfb8
                           00DFB9   839 __NA_IP1	=	0xdfb9
                           00DFBA   840 _X_ADCL	=	0xdfba
                           00DFBB   841 _X_ADCH	=	0xdfbb
                           00DFBC   842 _X_RNDL	=	0xdfbc
                           00DFBD   843 _X_RNDH	=	0xdfbd
                           00DFBE   844 _X_SLEEP	=	0xdfbe
                           00DFBF   845 __X_SFRBF	=	0xdfbf
                           00DFC0   846 __NA_IRCON	=	0xdfc0
                           00DFC1   847 _X_U0DBUF	=	0xdfc1
                           00DFC2   848 _X_U0BAUD	=	0xdfc2
                           00DFC3   849 __X_SFRC3	=	0xdfc3
                           00DFC4   850 _X_U0UCR	=	0xdfc4
                           00DFC5   851 _X_U0GCR	=	0xdfc5
                           00DFC6   852 _X_CLKCON	=	0xdfc6
                           00DFC7   853 _X_MEMCTR	=	0xdfc7
                           00DFC8   854 __X_SFRC8	=	0xdfc8
                           00DFC9   855 _X_WDCTL	=	0xdfc9
                           00DFCA   856 _X_T3CNT	=	0xdfca
                           00DFCB   857 _X_T3CTL	=	0xdfcb
                           00DFCC   858 _X_T3CCTL0	=	0xdfcc
                           00DFCD   859 _X_T3CC0	=	0xdfcd
                           00DFCE   860 _X_T3CCTL1	=	0xdfce
                           00DFCF   861 _X_T3CC1	=	0xdfcf
                           00DFD0   862 __NA_PSW	=	0xdfd0
                           00DFD1   863 _X_DMAIRQ	=	0xdfd1
                           00DFD2   864 _X_DMA1CFGL	=	0xdfd2
                           00DFD3   865 _X_DMA1CFGH	=	0xdfd3
                           00DFD4   866 _X_DMA0CFGL	=	0xdfd4
                           00DFD5   867 _X_DMA0CFGH	=	0xdfd5
                           00DFD6   868 _X_DMAARM	=	0xdfd6
                           00DFD7   869 _X_DMAREQ	=	0xdfd7
                           00DFD8   870 _X_TIMIF	=	0xdfd8
                           00DFD9   871 _X_RFD	=	0xdfd9
                           00DFDA   872 _X_T1CC0L	=	0xdfda
                           00DFDB   873 _X_T1CC0H	=	0xdfdb
                           00DFDC   874 _X_T1CC1L	=	0xdfdc
                           00DFDD   875 _X_T1CC1H	=	0xdfdd
                           00DFDE   876 _X_T1CC2L	=	0xdfde
                           00DFDF   877 _X_T1CC2H	=	0xdfdf
                           00DFE0   878 __NA_ACC	=	0xdfe0
                           00DFE1   879 _X_RFST	=	0xdfe1
                           00DFE2   880 _X_T1CNTL	=	0xdfe2
                           00DFE3   881 _X_T1CNTH	=	0xdfe3
                           00DFE4   882 _X_T1CTL	=	0xdfe4
                           00DFE5   883 _X_T1CCTL0	=	0xdfe5
                           00DFE6   884 _X_T1CCTL1	=	0xdfe6
                           00DFE7   885 _X_T1CCTL2	=	0xdfe7
                           00DFE8   886 __NA_IRCON2	=	0xdfe8
                           00DFE9   887 _X_RFIF	=	0xdfe9
                           00DFEA   888 _X_T4CNT	=	0xdfea
                           00DFEB   889 _X_T4CTL	=	0xdfeb
                           00DFEC   890 _X_T4CCTL0	=	0xdfec
                           00DFED   891 _X_T4CC0	=	0xdfed
                           00DFEE   892 _X_T4CCTL1	=	0xdfee
                           00DFEF   893 _X_T4CC1	=	0xdfef
                           00DFF0   894 __NA_B	=	0xdff0
                           00DFF1   895 _X_PERCFG	=	0xdff1
                           00DFF2   896 _X_ADCCFG	=	0xdff2
                           00DFF3   897 _X_P0SEL	=	0xdff3
                           00DFF4   898 _X_P1SEL	=	0xdff4
                           00DFF5   899 _X_P2SEL	=	0xdff5
                           00DFF6   900 _X_P1INP	=	0xdff6
                           00DFF7   901 _X_P2INP	=	0xdff7
                           00DFF8   902 _X_U1CSR	=	0xdff8
                           00DFF9   903 _X_U1DBUF	=	0xdff9
                           00DFFA   904 _X_U1BAUD	=	0xdffa
                           00DFFB   905 _X_U1UCR	=	0xdffb
                           00DFFC   906 _X_U1GCR	=	0xdffc
                           00DFFD   907 _X_P0DIR	=	0xdffd
                           00DFFE   908 _X_P1DIR	=	0xdffe
                           00DFFF   909 _X_P2DIR	=	0xdfff
                                    910 ;--------------------------------------------------------
                                    911 ; absolute external ram data
                                    912 ;--------------------------------------------------------
                                    913 	.area XABS    (ABS,XDATA)
                                    914 ;--------------------------------------------------------
                                    915 ; external initialized ram data
                                    916 ;--------------------------------------------------------
                                    917 	.area XISEG   (XDATA)
                                    918 	.area HOME    (CODE)
                                    919 	.area GSINIT0 (CODE)
                                    920 	.area GSINIT1 (CODE)
                                    921 	.area GSINIT2 (CODE)
                                    922 	.area GSINIT3 (CODE)
                                    923 	.area GSINIT4 (CODE)
                                    924 	.area GSINIT5 (CODE)
                                    925 	.area GSINIT  (CODE)
                                    926 	.area GSFINAL (CODE)
                                    927 	.area CSEG    (CODE)
                                    928 ;--------------------------------------------------------
                                    929 ; global & static initialisations
                                    930 ;--------------------------------------------------------
                                    931 	.area HOME    (CODE)
                                    932 	.area GSINIT  (CODE)
                                    933 	.area GSFINAL (CODE)
                                    934 	.area GSINIT  (CODE)
                                    935 ;--------------------------------------------------------
                                    936 ; Home
                                    937 ;--------------------------------------------------------
                                    938 	.area HOME    (CODE)
                                    939 	.area HOME    (CODE)
                                    940 ;--------------------------------------------------------
                                    941 ; code
                                    942 ;--------------------------------------------------------
                                    943 	.area CSEG    (CODE)
                                    944 ;------------------------------------------------------------
                                    945 ;Allocation info for local variables in function 'manchester_init_encoder'
                                    946 ;------------------------------------------------------------
                                    947 ;	manchester.c:4: void manchester_init_encoder(EncoderState *state) {
                                    948 ;	-----------------------------------------
                                    949 ;	 function manchester_init_encoder
                                    950 ;	-----------------------------------------
      001031                        951 _manchester_init_encoder:
                           000007   952 	ar7 = 0x07
                           000006   953 	ar6 = 0x06
                           000005   954 	ar5 = 0x05
                           000004   955 	ar4 = 0x04
                           000003   956 	ar3 = 0x03
                           000002   957 	ar2 = 0x02
                           000001   958 	ar1 = 0x01
                           000000   959 	ar0 = 0x00
      001031 AD 82            [24]  960 	mov	r5,dpl
      001033 AE 83            [24]  961 	mov	r6,dph
      001035 AF F0            [24]  962 	mov	r7,b
                                    963 ;	manchester.c:5: state->manchester.offset = 2;
      001037 74 02            [12]  964 	mov	a,#0x02
      001039 2D               [12]  965 	add	a,r5
      00103A FD               [12]  966 	mov	r5,a
      00103B E4               [12]  967 	clr	a
      00103C 3E               [12]  968 	addc	a,r6
      00103D FE               [12]  969 	mov	r6,a
      00103E 8D 82            [24]  970 	mov	dpl,r5
      001040 8E 83            [24]  971 	mov	dph,r6
      001042 8F F0            [24]  972 	mov	b,r7
      001044 74 02            [12]  973 	mov	a,#0x02
                                    974 ;	manchester.c:6: }
      001046 02 2D 8A         [24]  975 	ljmp	__gptrput
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'manchester_add_raw_byte'
                                    978 ;------------------------------------------------------------
                                    979 ;raw                       Allocated to stack - _bp -3
                                    980 ;state                     Allocated to stack - _bp +1
                                    981 ;acc                       Allocated to registers r6 r5 
                                    982 ;i                         Allocated to registers r2 r4 
                                    983 ;------------------------------------------------------------
                                    984 ;	manchester.c:8: void manchester_add_raw_byte(EncoderState *state, uint8_t raw) __reentrant {
                                    985 ;	-----------------------------------------
                                    986 ;	 function manchester_add_raw_byte
                                    987 ;	-----------------------------------------
      001049                        988 _manchester_add_raw_byte:
      001049 C0 18            [24]  989 	push	_bp
      00104B 85 81 18         [24]  990 	mov	_bp,sp
      00104E C0 82            [24]  991 	push	dpl
      001050 C0 83            [24]  992 	push	dph
      001052 C0 F0            [24]  993 	push	b
                                    994 ;	manchester.c:9: uint16_t acc = 0;
      001054 7E 00            [12]  995 	mov	r6,#0x00
      001056 7D 00            [12]  996 	mov	r5,#0x00
                                    997 ;	manchester.c:11: for (i=0; i<8; i++) {
      001058 7A 08            [12]  998 	mov	r2,#0x08
      00105A 7C 00            [12]  999 	mov	r4,#0x00
      00105C                       1000 00104$:
                                   1001 ;	manchester.c:12: acc = (acc << 2) + 2 - (raw >> 7);
      00105C EE               [12] 1002 	mov	a,r6
      00105D 2E               [12] 1003 	add	a,r6
      00105E FB               [12] 1004 	mov	r3,a
      00105F ED               [12] 1005 	mov	a,r5
      001060 33               [12] 1006 	rlc	a
      001061 FF               [12] 1007 	mov	r7,a
      001062 EB               [12] 1008 	mov	a,r3
      001063 2B               [12] 1009 	add	a,r3
      001064 FB               [12] 1010 	mov	r3,a
      001065 EF               [12] 1011 	mov	a,r7
      001066 33               [12] 1012 	rlc	a
      001067 FF               [12] 1013 	mov	r7,a
      001068 74 02            [12] 1014 	mov	a,#0x02
      00106A 2B               [12] 1015 	add	a,r3
      00106B FB               [12] 1016 	mov	r3,a
      00106C E4               [12] 1017 	clr	a
      00106D 3F               [12] 1018 	addc	a,r7
      00106E FF               [12] 1019 	mov	r7,a
      00106F E5 18            [12] 1020 	mov	a,_bp
      001071 24 FD            [12] 1021 	add	a,#0xfd
      001073 F8               [12] 1022 	mov	r0,a
      001074 E6               [12] 1023 	mov	a,@r0
      001075 23               [12] 1024 	rl	a
      001076 54 01            [12] 1025 	anl	a,#0x01
      001078 FE               [12] 1026 	mov	r6,a
      001079 7D 00            [12] 1027 	mov	r5,#0x00
      00107B EB               [12] 1028 	mov	a,r3
      00107C C3               [12] 1029 	clr	c
      00107D 9E               [12] 1030 	subb	a,r6
      00107E FB               [12] 1031 	mov	r3,a
      00107F EF               [12] 1032 	mov	a,r7
      001080 9D               [12] 1033 	subb	a,r5
      001081 FF               [12] 1034 	mov	r7,a
      001082 8B 06            [24] 1035 	mov	ar6,r3
      001084 8F 05            [24] 1036 	mov	ar5,r7
                                   1037 ;	manchester.c:13: raw = raw << 1;
      001086 E5 18            [12] 1038 	mov	a,_bp
      001088 24 FD            [12] 1039 	add	a,#0xfd
      00108A F8               [12] 1040 	mov	r0,a
      00108B 86 07            [24] 1041 	mov	ar7,@r0
      00108D E5 18            [12] 1042 	mov	a,_bp
      00108F 24 FD            [12] 1043 	add	a,#0xfd
      001091 F8               [12] 1044 	mov	r0,a
      001092 EF               [12] 1045 	mov	a,r7
      001093 2F               [12] 1046 	add	a,r7
      001094 F6               [12] 1047 	mov	@r0,a
      001095 1A               [12] 1048 	dec	r2
      001096 BA FF 01         [24] 1049 	cjne	r2,#0xff,00116$
      001099 1C               [12] 1050 	dec	r4
      00109A                       1051 00116$:
                                   1052 ;	manchester.c:11: for (i=0; i<8; i++) {
      00109A EA               [12] 1053 	mov	a,r2
      00109B 4C               [12] 1054 	orl	a,r4
      00109C 70 BE            [24] 1055 	jnz	00104$
                                   1056 ;	manchester.c:15: state->manchester.output[0] = acc >> 8;
      00109E 8D 04            [24] 1057 	mov	ar4,r5
      0010A0 A8 18            [24] 1058 	mov	r0,_bp
      0010A2 08               [12] 1059 	inc	r0
      0010A3 86 82            [24] 1060 	mov	dpl,@r0
      0010A5 08               [12] 1061 	inc	r0
      0010A6 86 83            [24] 1062 	mov	dph,@r0
      0010A8 08               [12] 1063 	inc	r0
      0010A9 86 F0            [24] 1064 	mov	b,@r0
      0010AB EC               [12] 1065 	mov	a,r4
      0010AC 12 2D 8A         [24] 1066 	lcall	__gptrput
                                   1067 ;	manchester.c:16: state->manchester.output[1] = acc & 0xff;
      0010AF A8 18            [24] 1068 	mov	r0,_bp
      0010B1 08               [12] 1069 	inc	r0
      0010B2 74 01            [12] 1070 	mov	a,#0x01
      0010B4 26               [12] 1071 	add	a,@r0
      0010B5 FA               [12] 1072 	mov	r2,a
      0010B6 E4               [12] 1073 	clr	a
      0010B7 08               [12] 1074 	inc	r0
      0010B8 36               [12] 1075 	addc	a,@r0
      0010B9 FB               [12] 1076 	mov	r3,a
      0010BA 08               [12] 1077 	inc	r0
      0010BB 86 04            [24] 1078 	mov	ar4,@r0
      0010BD 8E 07            [24] 1079 	mov	ar7,r6
      0010BF 8A 82            [24] 1080 	mov	dpl,r2
      0010C1 8B 83            [24] 1081 	mov	dph,r3
      0010C3 8C F0            [24] 1082 	mov	b,r4
      0010C5 EF               [12] 1083 	mov	a,r7
      0010C6 12 2D 8A         [24] 1084 	lcall	__gptrput
                                   1085 ;	manchester.c:17: state->manchester.offset = 0;
      0010C9 A8 18            [24] 1086 	mov	r0,_bp
      0010CB 08               [12] 1087 	inc	r0
      0010CC 74 02            [12] 1088 	mov	a,#0x02
      0010CE 26               [12] 1089 	add	a,@r0
      0010CF FD               [12] 1090 	mov	r5,a
      0010D0 E4               [12] 1091 	clr	a
      0010D1 08               [12] 1092 	inc	r0
      0010D2 36               [12] 1093 	addc	a,@r0
      0010D3 FE               [12] 1094 	mov	r6,a
      0010D4 08               [12] 1095 	inc	r0
      0010D5 86 07            [24] 1096 	mov	ar7,@r0
      0010D7 8D 82            [24] 1097 	mov	dpl,r5
      0010D9 8E 83            [24] 1098 	mov	dph,r6
      0010DB 8F F0            [24] 1099 	mov	b,r7
      0010DD E4               [12] 1100 	clr	a
      0010DE 12 2D 8A         [24] 1101 	lcall	__gptrput
                                   1102 ;	manchester.c:18: }
      0010E1 85 18 81         [24] 1103 	mov	sp,_bp
      0010E4 D0 18            [24] 1104 	pop	_bp
      0010E6 22               [24] 1105 	ret
                                   1106 ;------------------------------------------------------------
                                   1107 ;Allocation info for local variables in function 'manchester_next_encoded_byte'
                                   1108 ;------------------------------------------------------------
                                   1109 ;encoded                   Allocated to stack - _bp -5
                                   1110 ;flush                     Allocated to stack - _bp -6
                                   1111 ;state                     Allocated to registers r5 r6 r7 
                                   1112 ;sloc0                     Allocated to stack - _bp +4
                                   1113 ;sloc1                     Allocated to stack - _bp +1
                                   1114 ;------------------------------------------------------------
                                   1115 ;	manchester.c:20: uint8_t manchester_next_encoded_byte(EncoderState *state, uint8_t *encoded, bool flush) __reentrant {
                                   1116 ;	-----------------------------------------
                                   1117 ;	 function manchester_next_encoded_byte
                                   1118 ;	-----------------------------------------
      0010E7                       1119 _manchester_next_encoded_byte:
      0010E7 C0 18            [24] 1120 	push	_bp
      0010E9 E5 81            [12] 1121 	mov	a,sp
      0010EB F5 18            [12] 1122 	mov	_bp,a
      0010ED 24 04            [12] 1123 	add	a,#0x04
      0010EF F5 81            [12] 1124 	mov	sp,a
      0010F1 AD 82            [24] 1125 	mov	r5,dpl
      0010F3 AE 83            [24] 1126 	mov	r6,dph
      0010F5 AF F0            [24] 1127 	mov	r7,b
                                   1128 ;	manchester.c:21: if (state->manchester.offset > 1) {
      0010F7 74 02            [12] 1129 	mov	a,#0x02
      0010F9 2D               [12] 1130 	add	a,r5
      0010FA FA               [12] 1131 	mov	r2,a
      0010FB E4               [12] 1132 	clr	a
      0010FC 3E               [12] 1133 	addc	a,r6
      0010FD FB               [12] 1134 	mov	r3,a
      0010FE 8F 04            [24] 1135 	mov	ar4,r7
      001100 8A 82            [24] 1136 	mov	dpl,r2
      001102 8B 83            [24] 1137 	mov	dph,r3
      001104 8C F0            [24] 1138 	mov	b,r4
      001106 E5 18            [12] 1139 	mov	a,_bp
      001108 24 04            [12] 1140 	add	a,#0x04
      00110A F8               [12] 1141 	mov	r0,a
      00110B 12 2E 55         [24] 1142 	lcall	__gptrget
      00110E F6               [12] 1143 	mov	@r0,a
      00110F E5 18            [12] 1144 	mov	a,_bp
      001111 24 04            [12] 1145 	add	a,#0x04
      001113 F8               [12] 1146 	mov	r0,a
      001114 E6               [12] 1147 	mov	a,@r0
      001115 24 FE            [12] 1148 	add	a,#0xff - 0x01
      001117 50 05            [24] 1149 	jnc	00102$
                                   1150 ;	manchester.c:22: return 0;
      001119 75 82 00         [24] 1151 	mov	dpl,#0x00
      00111C 80 4E            [24] 1152 	sjmp	00103$
      00111E                       1153 00102$:
                                   1154 ;	manchester.c:24: *encoded = state->manchester.output[state->manchester.offset];
      00111E E5 18            [12] 1155 	mov	a,_bp
      001120 24 FB            [12] 1156 	add	a,#0xfb
      001122 F8               [12] 1157 	mov	r0,a
      001123 A9 18            [24] 1158 	mov	r1,_bp
      001125 09               [12] 1159 	inc	r1
      001126 E6               [12] 1160 	mov	a,@r0
      001127 F7               [12] 1161 	mov	@r1,a
      001128 08               [12] 1162 	inc	r0
      001129 09               [12] 1163 	inc	r1
      00112A E6               [12] 1164 	mov	a,@r0
      00112B F7               [12] 1165 	mov	@r1,a
      00112C 08               [12] 1166 	inc	r0
      00112D 09               [12] 1167 	inc	r1
      00112E E6               [12] 1168 	mov	a,@r0
      00112F F7               [12] 1169 	mov	@r1,a
      001130 E5 18            [12] 1170 	mov	a,_bp
      001132 24 04            [12] 1171 	add	a,#0x04
      001134 F8               [12] 1172 	mov	r0,a
      001135 E6               [12] 1173 	mov	a,@r0
      001136 2D               [12] 1174 	add	a,r5
      001137 FD               [12] 1175 	mov	r5,a
      001138 E4               [12] 1176 	clr	a
      001139 3E               [12] 1177 	addc	a,r6
      00113A FE               [12] 1178 	mov	r6,a
      00113B 8D 82            [24] 1179 	mov	dpl,r5
      00113D 8E 83            [24] 1180 	mov	dph,r6
      00113F 8F F0            [24] 1181 	mov	b,r7
      001141 12 2E 55         [24] 1182 	lcall	__gptrget
      001144 FD               [12] 1183 	mov	r5,a
      001145 A8 18            [24] 1184 	mov	r0,_bp
      001147 08               [12] 1185 	inc	r0
      001148 86 82            [24] 1186 	mov	dpl,@r0
      00114A 08               [12] 1187 	inc	r0
      00114B 86 83            [24] 1188 	mov	dph,@r0
      00114D 08               [12] 1189 	inc	r0
      00114E 86 F0            [24] 1190 	mov	b,@r0
      001150 ED               [12] 1191 	mov	a,r5
      001151 12 2D 8A         [24] 1192 	lcall	__gptrput
                                   1193 ;	manchester.c:25: state->manchester.offset++;
      001154 8A 82            [24] 1194 	mov	dpl,r2
      001156 8B 83            [24] 1195 	mov	dph,r3
      001158 8C F0            [24] 1196 	mov	b,r4
      00115A 12 2E 55         [24] 1197 	lcall	__gptrget
      00115D FF               [12] 1198 	mov	r7,a
      00115E 0F               [12] 1199 	inc	r7
      00115F 8A 82            [24] 1200 	mov	dpl,r2
      001161 8B 83            [24] 1201 	mov	dph,r3
      001163 8C F0            [24] 1202 	mov	b,r4
      001165 EF               [12] 1203 	mov	a,r7
      001166 12 2D 8A         [24] 1204 	lcall	__gptrput
                                   1205 ;	manchester.c:26: return 1;
      001169 75 82 01         [24] 1206 	mov	dpl,#0x01
      00116C                       1207 00103$:
                                   1208 ;	manchester.c:27: }
      00116C 85 18 81         [24] 1209 	mov	sp,_bp
      00116F D0 18            [24] 1210 	pop	_bp
      001171 22               [24] 1211 	ret
                                   1212 ;------------------------------------------------------------
                                   1213 ;Allocation info for local variables in function 'manchester_init_decoder'
                                   1214 ;------------------------------------------------------------
                                   1215 ;	manchester.c:31: void manchester_init_decoder(DecoderState *state) {
                                   1216 ;	-----------------------------------------
                                   1217 ;	 function manchester_init_decoder
                                   1218 ;	-----------------------------------------
      001172                       1219 _manchester_init_decoder:
                                   1220 ;	manchester.c:32: state->manchester.output = 0;
      001172 AD 82            [24] 1221 	mov	r5,dpl
      001174 AE 83            [24] 1222 	mov	r6,dph
      001176 AF F0            [24] 1223 	mov	r7,b
      001178 E4               [12] 1224 	clr	a
      001179 12 2D 8A         [24] 1225 	lcall	__gptrput
                                   1226 ;	manchester.c:33: state->manchester.bits_avail = 0;
      00117C 0D               [12] 1227 	inc	r5
      00117D BD 00 01         [24] 1228 	cjne	r5,#0x00,00103$
      001180 0E               [12] 1229 	inc	r6
      001181                       1230 00103$:
      001181 8D 82            [24] 1231 	mov	dpl,r5
      001183 8E 83            [24] 1232 	mov	dph,r6
      001185 8F F0            [24] 1233 	mov	b,r7
      001187 E4               [12] 1234 	clr	a
                                   1235 ;	manchester.c:34: }
      001188 02 2D 8A         [24] 1236 	ljmp	__gptrput
                                   1237 ;------------------------------------------------------------
                                   1238 ;Allocation info for local variables in function 'manchester_add_encoded_byte'
                                   1239 ;------------------------------------------------------------
                                   1240 ;encoded                   Allocated to stack - _bp -3
                                   1241 ;state                     Allocated to registers r5 r6 r7 
                                   1242 ;acc                       Allocated to registers r4 
                                   1243 ;i                         Allocated to registers r2 r3 
                                   1244 ;sloc0                     Allocated to stack - _bp +1
                                   1245 ;------------------------------------------------------------
                                   1246 ;	manchester.c:36: uint8_t manchester_add_encoded_byte(DecoderState *state, uint8_t encoded) __reentrant {
                                   1247 ;	-----------------------------------------
                                   1248 ;	 function manchester_add_encoded_byte
                                   1249 ;	-----------------------------------------
      00118B                       1250 _manchester_add_encoded_byte:
      00118B C0 18            [24] 1251 	push	_bp
      00118D 85 81 18         [24] 1252 	mov	_bp,sp
      001190 05 81            [12] 1253 	inc	sp
      001192 05 81            [12] 1254 	inc	sp
      001194 AD 82            [24] 1255 	mov	r5,dpl
      001196 AE 83            [24] 1256 	mov	r6,dph
      001198 AF F0            [24] 1257 	mov	r7,b
                                   1258 ;	manchester.c:37: uint8_t acc = 0;
      00119A 7C 00            [12] 1259 	mov	r4,#0x00
                                   1260 ;	manchester.c:39: for (i=6; i>=0; i-=2) {
      00119C 7A 06            [12] 1261 	mov	r2,#0x06
      00119E 7B 00            [12] 1262 	mov	r3,#0x00
      0011A0                       1263 00106$:
                                   1264 ;	manchester.c:40: acc = (acc << 1);
      0011A0 C0 05            [24] 1265 	push	ar5
      0011A2 C0 06            [24] 1266 	push	ar6
      0011A4 C0 07            [24] 1267 	push	ar7
      0011A6 8C 07            [24] 1268 	mov	ar7,r4
      0011A8 EF               [12] 1269 	mov	a,r7
      0011A9 2F               [12] 1270 	add	a,r7
      0011AA FC               [12] 1271 	mov	r4,a
                                   1272 ;	manchester.c:41: switch((encoded >> i) & 0b11) {
      0011AB 8A F0            [24] 1273 	mov	b,r2
      0011AD 05 F0            [12] 1274 	inc	b
      0011AF E5 18            [12] 1275 	mov	a,_bp
      0011B1 24 FD            [12] 1276 	add	a,#0xfd
      0011B3 F8               [12] 1277 	mov	r0,a
      0011B4 E6               [12] 1278 	mov	a,@r0
      0011B5 80 02            [24] 1279 	sjmp	00127$
      0011B7                       1280 00126$:
      0011B7 C3               [12] 1281 	clr	c
      0011B8 13               [12] 1282 	rrc	a
      0011B9                       1283 00127$:
      0011B9 D5 F0 FB         [24] 1284 	djnz	b,00126$
      0011BC FF               [12] 1285 	mov	r7,a
      0011BD A8 18            [24] 1286 	mov	r0,_bp
      0011BF 08               [12] 1287 	inc	r0
      0011C0 74 03            [12] 1288 	mov	a,#0x03
      0011C2 5F               [12] 1289 	anl	a,r7
      0011C3 F6               [12] 1290 	mov	@r0,a
      0011C4 08               [12] 1291 	inc	r0
      0011C5 76 00            [12] 1292 	mov	@r0,#0x00
      0011C7 A8 18            [24] 1293 	mov	r0,_bp
      0011C9 08               [12] 1294 	inc	r0
      0011CA B6 00 0C         [24] 1295 	cjne	@r0,#0x00,00128$
      0011CD 08               [12] 1296 	inc	r0
      0011CE B6 00 08         [24] 1297 	cjne	@r0,#0x00,00128$
      0011D1 D0 07            [24] 1298 	pop	ar7
      0011D3 D0 06            [24] 1299 	pop	ar6
      0011D5 D0 05            [24] 1300 	pop	ar5
      0011D7 80 1C            [24] 1301 	sjmp	00102$
      0011D9                       1302 00128$:
      0011D9 D0 07            [24] 1303 	pop	ar7
      0011DB D0 06            [24] 1304 	pop	ar6
      0011DD D0 05            [24] 1305 	pop	ar5
      0011DF A8 18            [24] 1306 	mov	r0,_bp
      0011E1 08               [12] 1307 	inc	r0
      0011E2 B6 01 06         [24] 1308 	cjne	@r0,#0x01,00129$
      0011E5 08               [12] 1309 	inc	r0
      0011E6 B6 00 02         [24] 1310 	cjne	@r0,#0x00,00129$
      0011E9 80 0F            [24] 1311 	sjmp	00103$
      0011EB                       1312 00129$:
      0011EB A8 18            [24] 1313 	mov	r0,_bp
      0011ED 08               [12] 1314 	inc	r0
      0011EE B6 03 0A         [24] 1315 	cjne	@r0,#0x03,00107$
      0011F1 08               [12] 1316 	inc	r0
      0011F2 B6 00 06         [24] 1317 	cjne	@r0,#0x00,00107$
                                   1318 ;	manchester.c:43: case 0b11:
      0011F5                       1319 00102$:
                                   1320 ;	manchester.c:44: return 1;  // Encoding error
      0011F5 75 82 01         [24] 1321 	mov	dpl,#0x01
                                   1322 ;	manchester.c:45: case 0b01:
      0011F8 80 40            [24] 1323 	sjmp	00108$
      0011FA                       1324 00103$:
                                   1325 ;	manchester.c:46: acc++;
      0011FA 0C               [12] 1326 	inc	r4
                                   1327 ;	manchester.c:47: }
      0011FB                       1328 00107$:
                                   1329 ;	manchester.c:39: for (i=6; i>=0; i-=2) {
      0011FB EA               [12] 1330 	mov	a,r2
      0011FC 24 FE            [12] 1331 	add	a,#0xfe
      0011FE FA               [12] 1332 	mov	r2,a
      0011FF EB               [12] 1333 	mov	a,r3
      001200 34 FF            [12] 1334 	addc	a,#0xff
      001202 FB               [12] 1335 	mov	r3,a
      001203 30 E7 9A         [24] 1336 	jnb	acc.7,00106$
                                   1337 ;	manchester.c:49: state->manchester.output = (state->manchester.output << 4) + acc;
      001206 8D 82            [24] 1338 	mov	dpl,r5
      001208 8E 83            [24] 1339 	mov	dph,r6
      00120A 8F F0            [24] 1340 	mov	b,r7
      00120C 12 2E 55         [24] 1341 	lcall	__gptrget
      00120F C4               [12] 1342 	swap	a
      001210 54 F0            [12] 1343 	anl	a,#0xf0
      001212 2C               [12] 1344 	add	a,r4
      001213 FB               [12] 1345 	mov	r3,a
      001214 8D 82            [24] 1346 	mov	dpl,r5
      001216 8E 83            [24] 1347 	mov	dph,r6
      001218 8F F0            [24] 1348 	mov	b,r7
      00121A 12 2D 8A         [24] 1349 	lcall	__gptrput
                                   1350 ;	manchester.c:50: state->manchester.bits_avail += 4;
      00121D 0D               [12] 1351 	inc	r5
      00121E BD 00 01         [24] 1352 	cjne	r5,#0x00,00133$
      001221 0E               [12] 1353 	inc	r6
      001222                       1354 00133$:
      001222 8D 82            [24] 1355 	mov	dpl,r5
      001224 8E 83            [24] 1356 	mov	dph,r6
      001226 8F F0            [24] 1357 	mov	b,r7
      001228 12 2E 55         [24] 1358 	lcall	__gptrget
      00122B 24 04            [12] 1359 	add	a,#0x04
      00122D FC               [12] 1360 	mov	r4,a
      00122E 8D 82            [24] 1361 	mov	dpl,r5
      001230 8E 83            [24] 1362 	mov	dph,r6
      001232 8F F0            [24] 1363 	mov	b,r7
      001234 12 2D 8A         [24] 1364 	lcall	__gptrput
                                   1365 ;	manchester.c:51: return 0;
      001237 75 82 00         [24] 1366 	mov	dpl,#0x00
      00123A                       1367 00108$:
                                   1368 ;	manchester.c:52: }
      00123A 85 18 81         [24] 1369 	mov	sp,_bp
      00123D D0 18            [24] 1370 	pop	_bp
      00123F 22               [24] 1371 	ret
                                   1372 ;------------------------------------------------------------
                                   1373 ;Allocation info for local variables in function 'manchester_next_decoded_byte'
                                   1374 ;------------------------------------------------------------
                                   1375 ;decoded                   Allocated to stack - _bp -5
                                   1376 ;state                     Allocated to stack - _bp +4
                                   1377 ;sloc0                     Allocated to stack - _bp +1
                                   1378 ;------------------------------------------------------------
                                   1379 ;	manchester.c:54: uint8_t manchester_next_decoded_byte(DecoderState *state, uint8_t *decoded) __reentrant {
                                   1380 ;	-----------------------------------------
                                   1381 ;	 function manchester_next_decoded_byte
                                   1382 ;	-----------------------------------------
      001240                       1383 _manchester_next_decoded_byte:
      001240 C0 18            [24] 1384 	push	_bp
      001242 E5 81            [12] 1385 	mov	a,sp
      001244 F5 18            [12] 1386 	mov	_bp,a
      001246 24 06            [12] 1387 	add	a,#0x06
      001248 F5 81            [12] 1388 	mov	sp,a
      00124A C8               [12] 1389 	xch	a,r0
      00124B E5 18            [12] 1390 	mov	a,_bp
      00124D 24 04            [12] 1391 	add	a,#0x04
      00124F C8               [12] 1392 	xch	a,r0
      001250 A6 82            [24] 1393 	mov	@r0,dpl
      001252 08               [12] 1394 	inc	r0
      001253 A6 83            [24] 1395 	mov	@r0,dph
      001255 08               [12] 1396 	inc	r0
      001256 A6 F0            [24] 1397 	mov	@r0,b
                                   1398 ;	manchester.c:55: if (state->manchester.bits_avail < 8) {
      001258 E5 18            [12] 1399 	mov	a,_bp
      00125A 24 04            [12] 1400 	add	a,#0x04
      00125C F8               [12] 1401 	mov	r0,a
      00125D 74 01            [12] 1402 	mov	a,#0x01
      00125F 26               [12] 1403 	add	a,@r0
      001260 FA               [12] 1404 	mov	r2,a
      001261 E4               [12] 1405 	clr	a
      001262 08               [12] 1406 	inc	r0
      001263 36               [12] 1407 	addc	a,@r0
      001264 FB               [12] 1408 	mov	r3,a
      001265 08               [12] 1409 	inc	r0
      001266 86 04            [24] 1410 	mov	ar4,@r0
      001268 8A 82            [24] 1411 	mov	dpl,r2
      00126A 8B 83            [24] 1412 	mov	dph,r3
      00126C 8C F0            [24] 1413 	mov	b,r4
      00126E 12 2E 55         [24] 1414 	lcall	__gptrget
      001271 FF               [12] 1415 	mov	r7,a
      001272 BF 08 00         [24] 1416 	cjne	r7,#0x08,00109$
      001275                       1417 00109$:
      001275 50 05            [24] 1418 	jnc	00102$
                                   1419 ;	manchester.c:56: return 0;
      001277 75 82 00         [24] 1420 	mov	dpl,#0x00
      00127A 80 3F            [24] 1421 	sjmp	00103$
      00127C                       1422 00102$:
                                   1423 ;	manchester.c:58: *decoded = state->manchester.output;
      00127C E5 18            [12] 1424 	mov	a,_bp
      00127E 24 FB            [12] 1425 	add	a,#0xfb
      001280 F8               [12] 1426 	mov	r0,a
      001281 A9 18            [24] 1427 	mov	r1,_bp
      001283 09               [12] 1428 	inc	r1
      001284 E6               [12] 1429 	mov	a,@r0
      001285 F7               [12] 1430 	mov	@r1,a
      001286 08               [12] 1431 	inc	r0
      001287 09               [12] 1432 	inc	r1
      001288 E6               [12] 1433 	mov	a,@r0
      001289 F7               [12] 1434 	mov	@r1,a
      00128A 08               [12] 1435 	inc	r0
      00128B 09               [12] 1436 	inc	r1
      00128C E6               [12] 1437 	mov	a,@r0
      00128D F7               [12] 1438 	mov	@r1,a
      00128E E5 18            [12] 1439 	mov	a,_bp
      001290 24 04            [12] 1440 	add	a,#0x04
      001292 F8               [12] 1441 	mov	r0,a
      001293 86 82            [24] 1442 	mov	dpl,@r0
      001295 08               [12] 1443 	inc	r0
      001296 86 83            [24] 1444 	mov	dph,@r0
      001298 08               [12] 1445 	inc	r0
      001299 86 F0            [24] 1446 	mov	b,@r0
      00129B 12 2E 55         [24] 1447 	lcall	__gptrget
      00129E FF               [12] 1448 	mov	r7,a
      00129F A8 18            [24] 1449 	mov	r0,_bp
      0012A1 08               [12] 1450 	inc	r0
      0012A2 86 82            [24] 1451 	mov	dpl,@r0
      0012A4 08               [12] 1452 	inc	r0
      0012A5 86 83            [24] 1453 	mov	dph,@r0
      0012A7 08               [12] 1454 	inc	r0
      0012A8 86 F0            [24] 1455 	mov	b,@r0
      0012AA EF               [12] 1456 	mov	a,r7
      0012AB 12 2D 8A         [24] 1457 	lcall	__gptrput
                                   1458 ;	manchester.c:59: state->manchester.bits_avail = 0;
      0012AE 8A 82            [24] 1459 	mov	dpl,r2
      0012B0 8B 83            [24] 1460 	mov	dph,r3
      0012B2 8C F0            [24] 1461 	mov	b,r4
      0012B4 E4               [12] 1462 	clr	a
      0012B5 12 2D 8A         [24] 1463 	lcall	__gptrput
                                   1464 ;	manchester.c:60: return 1;
      0012B8 75 82 01         [24] 1465 	mov	dpl,#0x01
      0012BB                       1466 00103$:
                                   1467 ;	manchester.c:61: }
      0012BB 85 18 81         [24] 1468 	mov	sp,_bp
      0012BE D0 18            [24] 1469 	pop	_bp
      0012C0 22               [24] 1470 	ret
                                   1471 	.area CSEG    (CODE)
                                   1472 	.area CONST   (CODE)
                                   1473 	.area XINIT   (CODE)
                                   1474 	.area CABS    (ABS,CODE)
