                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.0.2 #11662 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module hardware
                                      6 	.optsdcc -mmcs51 --model-medium
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _serial_rx_byte
                                     12 	.globl _MODE
                                     13 	.globl _RE
                                     14 	.globl _SLAVE
                                     15 	.globl _FE
                                     16 	.globl _ERR
                                     17 	.globl _RX_BYTE
                                     18 	.globl _TX_BYTE
                                     19 	.globl _ACTIVE
                                     20 	.globl _B_7
                                     21 	.globl _B_6
                                     22 	.globl _B_5
                                     23 	.globl _B_4
                                     24 	.globl _B_3
                                     25 	.globl _B_2
                                     26 	.globl _B_1
                                     27 	.globl _B_0
                                     28 	.globl _WDTIF
                                     29 	.globl _P1IF
                                     30 	.globl _UTX1IF
                                     31 	.globl _UTX0IF
                                     32 	.globl _P2IF
                                     33 	.globl _ACC_7
                                     34 	.globl _ACC_6
                                     35 	.globl _ACC_5
                                     36 	.globl _ACC_4
                                     37 	.globl _ACC_3
                                     38 	.globl _ACC_2
                                     39 	.globl _ACC_1
                                     40 	.globl _ACC_0
                                     41 	.globl _OVFIM
                                     42 	.globl _T4CH1IF
                                     43 	.globl _T4CH0IF
                                     44 	.globl _T4OVFIF
                                     45 	.globl _T3CH1IF
                                     46 	.globl _T3CH0IF
                                     47 	.globl _T3OVFIF
                                     48 	.globl _CY
                                     49 	.globl _AC
                                     50 	.globl _F0
                                     51 	.globl _RS1
                                     52 	.globl _RS0
                                     53 	.globl _OV
                                     54 	.globl _F1
                                     55 	.globl _P
                                     56 	.globl _STIF
                                     57 	.globl _P0IF
                                     58 	.globl _T4IF
                                     59 	.globl _T3IF
                                     60 	.globl _T2IF
                                     61 	.globl _T1IF
                                     62 	.globl _DMAIF
                                     63 	.globl _P0IE
                                     64 	.globl _T4IE
                                     65 	.globl _T3IE
                                     66 	.globl _T2IE
                                     67 	.globl _T1IE
                                     68 	.globl _DMAIE
                                     69 	.globl _EA
                                     70 	.globl _STIE
                                     71 	.globl _ENCIE
                                     72 	.globl _URX1IE
                                     73 	.globl _URX0IE
                                     74 	.globl _ADCIE
                                     75 	.globl _RFTXRXIE
                                     76 	.globl _P2_7
                                     77 	.globl _P2_6
                                     78 	.globl _P2_5
                                     79 	.globl _P2_4
                                     80 	.globl _P2_3
                                     81 	.globl _P2_2
                                     82 	.globl _P2_1
                                     83 	.globl _P2_0
                                     84 	.globl _ENCIF_1
                                     85 	.globl _ENCIF_0
                                     86 	.globl _P1_7
                                     87 	.globl _P1_6
                                     88 	.globl _P1_5
                                     89 	.globl _P1_4
                                     90 	.globl _P1_3
                                     91 	.globl _P1_2
                                     92 	.globl _P1_1
                                     93 	.globl _P1_0
                                     94 	.globl _URX1IF
                                     95 	.globl _ADCIF
                                     96 	.globl _URX0IF
                                     97 	.globl _IT1
                                     98 	.globl _RFTXRXIF
                                     99 	.globl _IT0
                                    100 	.globl _P0_7
                                    101 	.globl _P0_6
                                    102 	.globl _P0_5
                                    103 	.globl _P0_4
                                    104 	.globl _P0_3
                                    105 	.globl _P0_2
                                    106 	.globl _P0_1
                                    107 	.globl _P0_0
                                    108 	.globl _P2DIR
                                    109 	.globl _P1DIR
                                    110 	.globl _P0DIR
                                    111 	.globl _U1GCR
                                    112 	.globl _U1UCR
                                    113 	.globl _U1BAUD
                                    114 	.globl _U1DBUF
                                    115 	.globl _U1CSR
                                    116 	.globl _P2INP
                                    117 	.globl _P1INP
                                    118 	.globl _P2SEL
                                    119 	.globl _P1SEL
                                    120 	.globl _P0SEL
                                    121 	.globl _ADCCFG
                                    122 	.globl _PERCFG
                                    123 	.globl _B
                                    124 	.globl _T4CC1
                                    125 	.globl _T4CCTL1
                                    126 	.globl _T4CC0
                                    127 	.globl _T4CCTL0
                                    128 	.globl _T4CTL
                                    129 	.globl _T4CNT
                                    130 	.globl _RFIF
                                    131 	.globl _IRCON2
                                    132 	.globl _T1CCTL2
                                    133 	.globl _T1CCTL1
                                    134 	.globl _T1CCTL0
                                    135 	.globl _T1CTL
                                    136 	.globl _T1CNTH
                                    137 	.globl _T1CNTL
                                    138 	.globl _RFST
                                    139 	.globl _ACC
                                    140 	.globl _T1CC2H
                                    141 	.globl _T1CC2L
                                    142 	.globl _T1CC1H
                                    143 	.globl _T1CC1L
                                    144 	.globl _T1CC0H
                                    145 	.globl _T1CC0L
                                    146 	.globl _RFD
                                    147 	.globl _TIMIF
                                    148 	.globl _DMAREQ
                                    149 	.globl _DMAARM
                                    150 	.globl _DMA0CFGH
                                    151 	.globl _DMA0CFGL
                                    152 	.globl _DMA1CFGH
                                    153 	.globl _DMA1CFGL
                                    154 	.globl _DMAIRQ
                                    155 	.globl _PSW
                                    156 	.globl _T3CC1
                                    157 	.globl _T3CCTL1
                                    158 	.globl _T3CC0
                                    159 	.globl _T3CCTL0
                                    160 	.globl _T3CTL
                                    161 	.globl _T3CNT
                                    162 	.globl _WDCTL
                                    163 	.globl __SFRC8
                                    164 	.globl _MEMCTR
                                    165 	.globl _CLKCON
                                    166 	.globl _U0GCR
                                    167 	.globl _U0UCR
                                    168 	.globl __SFRC3
                                    169 	.globl _U0BAUD
                                    170 	.globl _U0DBUF
                                    171 	.globl _IRCON
                                    172 	.globl __SFRBF
                                    173 	.globl _SLEEP
                                    174 	.globl _RNDH
                                    175 	.globl _RNDL
                                    176 	.globl _ADCH
                                    177 	.globl _ADCL
                                    178 	.globl _IP1
                                    179 	.globl _IEN1
                                    180 	.globl __SFRB7
                                    181 	.globl _ADCCON3
                                    182 	.globl _ADCCON2
                                    183 	.globl _ADCCON1
                                    184 	.globl _ENCCS
                                    185 	.globl _ENCDO
                                    186 	.globl _ENCDI
                                    187 	.globl __SFRB0
                                    188 	.globl _FWDATA
                                    189 	.globl _FCTL
                                    190 	.globl _FADDRH
                                    191 	.globl _FADDRL
                                    192 	.globl _FWT
                                    193 	.globl __SFRAA
                                    194 	.globl _IP0
                                    195 	.globl _IEN0
                                    196 	.globl __SFRA7
                                    197 	.globl _WORTIME1
                                    198 	.globl _WORTIME0
                                    199 	.globl _WOREVT1
                                    200 	.globl _WOREVT0
                                    201 	.globl _WORCTRL
                                    202 	.globl _WORIRQ
                                    203 	.globl _P2
                                    204 	.globl __SFR9F
                                    205 	.globl _T2CTL
                                    206 	.globl _T2PR
                                    207 	.globl _T2CT
                                    208 	.globl _S1CON
                                    209 	.globl _IEN2
                                    210 	.globl __SFR99
                                    211 	.globl _S0CON
                                    212 	.globl __SFR97
                                    213 	.globl __SFR96
                                    214 	.globl __SFR95
                                    215 	.globl __SFR94
                                    216 	.globl __XPAGE
                                    217 	.globl _MPAGE
                                    218 	.globl _DPS
                                    219 	.globl _RFIM
                                    220 	.globl _P1
                                    221 	.globl _P0INP
                                    222 	.globl __SFR8E
                                    223 	.globl _P1IEN
                                    224 	.globl _PICTL
                                    225 	.globl _P2IFG
                                    226 	.globl _P1IFG
                                    227 	.globl _P0IFG
                                    228 	.globl _TCON
                                    229 	.globl _PCON
                                    230 	.globl _U0CSR
                                    231 	.globl _DPH1
                                    232 	.globl _DPL1
                                    233 	.globl _DPH0
                                    234 	.globl _DPL0
                                    235 	.globl _SP
                                    236 	.globl _P0
                                    237 	.globl _rx_registers
                                    238 	.globl _tx_registers
                                    239 	.globl _X_P2DIR
                                    240 	.globl _X_P1DIR
                                    241 	.globl _X_P0DIR
                                    242 	.globl _X_U1GCR
                                    243 	.globl _X_U1UCR
                                    244 	.globl _X_U1BAUD
                                    245 	.globl _X_U1DBUF
                                    246 	.globl _X_U1CSR
                                    247 	.globl _X_P2INP
                                    248 	.globl _X_P1INP
                                    249 	.globl _X_P2SEL
                                    250 	.globl _X_P1SEL
                                    251 	.globl _X_P0SEL
                                    252 	.globl _X_ADCCFG
                                    253 	.globl _X_PERCFG
                                    254 	.globl __NA_B
                                    255 	.globl _X_T4CC1
                                    256 	.globl _X_T4CCTL1
                                    257 	.globl _X_T4CC0
                                    258 	.globl _X_T4CCTL0
                                    259 	.globl _X_T4CTL
                                    260 	.globl _X_T4CNT
                                    261 	.globl _X_RFIF
                                    262 	.globl __NA_IRCON2
                                    263 	.globl _X_T1CCTL2
                                    264 	.globl _X_T1CCTL1
                                    265 	.globl _X_T1CCTL0
                                    266 	.globl _X_T1CTL
                                    267 	.globl _X_T1CNTH
                                    268 	.globl _X_T1CNTL
                                    269 	.globl _X_RFST
                                    270 	.globl __NA_ACC
                                    271 	.globl _X_T1CC2H
                                    272 	.globl _X_T1CC2L
                                    273 	.globl _X_T1CC1H
                                    274 	.globl _X_T1CC1L
                                    275 	.globl _X_T1CC0H
                                    276 	.globl _X_T1CC0L
                                    277 	.globl _X_RFD
                                    278 	.globl _X_TIMIF
                                    279 	.globl _X_DMAREQ
                                    280 	.globl _X_DMAARM
                                    281 	.globl _X_DMA0CFGH
                                    282 	.globl _X_DMA0CFGL
                                    283 	.globl _X_DMA1CFGH
                                    284 	.globl _X_DMA1CFGL
                                    285 	.globl _X_DMAIRQ
                                    286 	.globl __NA_PSW
                                    287 	.globl _X_T3CC1
                                    288 	.globl _X_T3CCTL1
                                    289 	.globl _X_T3CC0
                                    290 	.globl _X_T3CCTL0
                                    291 	.globl _X_T3CTL
                                    292 	.globl _X_T3CNT
                                    293 	.globl _X_WDCTL
                                    294 	.globl __X_SFRC8
                                    295 	.globl _X_MEMCTR
                                    296 	.globl _X_CLKCON
                                    297 	.globl _X_U0GCR
                                    298 	.globl _X_U0UCR
                                    299 	.globl __X_SFRC3
                                    300 	.globl _X_U0BAUD
                                    301 	.globl _X_U0DBUF
                                    302 	.globl __NA_IRCON
                                    303 	.globl __X_SFRBF
                                    304 	.globl _X_SLEEP
                                    305 	.globl _X_RNDH
                                    306 	.globl _X_RNDL
                                    307 	.globl _X_ADCH
                                    308 	.globl _X_ADCL
                                    309 	.globl __NA_IP1
                                    310 	.globl __NA_IEN1
                                    311 	.globl __X_SFRB7
                                    312 	.globl _X_ADCCON3
                                    313 	.globl _X_ADCCON2
                                    314 	.globl _X_ADCCON1
                                    315 	.globl _X_ENCCS
                                    316 	.globl _X_ENCDO
                                    317 	.globl _X_ENCDI
                                    318 	.globl __X_SFRB0
                                    319 	.globl _X_FWDATA
                                    320 	.globl _X_FCTL
                                    321 	.globl _X_FADDRH
                                    322 	.globl _X_FADDRL
                                    323 	.globl _X_FWT
                                    324 	.globl __X_SFRAA
                                    325 	.globl __NA_IP0
                                    326 	.globl __NA_IEN0
                                    327 	.globl __X_SFRA7
                                    328 	.globl _X_WORTIME1
                                    329 	.globl _X_WORTIME0
                                    330 	.globl _X_WOREVT1
                                    331 	.globl _X_WOREVT0
                                    332 	.globl _X_WORCTRL
                                    333 	.globl _X_WORIRQ
                                    334 	.globl __NA_P2
                                    335 	.globl __X_SFR9F
                                    336 	.globl _X_T2CTL
                                    337 	.globl _X_T2PR
                                    338 	.globl _X_T2CT
                                    339 	.globl __NA_S1CON
                                    340 	.globl __NA_IEN2
                                    341 	.globl __X_SFR99
                                    342 	.globl __NA_S0CON
                                    343 	.globl __X_SFR97
                                    344 	.globl __X_SFR96
                                    345 	.globl __X_SFR95
                                    346 	.globl __X_SFR94
                                    347 	.globl _X_MPAGE
                                    348 	.globl __NA_DPS
                                    349 	.globl _X_RFIM
                                    350 	.globl __NA_P1
                                    351 	.globl _X_P0INP
                                    352 	.globl __X_SFR8E
                                    353 	.globl _X_P1IEN
                                    354 	.globl _X_PICTL
                                    355 	.globl _X_P2IFG
                                    356 	.globl _X_P1IFG
                                    357 	.globl _X_P0IFG
                                    358 	.globl __NA_TCON
                                    359 	.globl __NA_PCON
                                    360 	.globl _X_U0CSR
                                    361 	.globl __NA_DPH1
                                    362 	.globl __NA_DPL1
                                    363 	.globl __NA_DPH0
                                    364 	.globl __NA_DPL0
                                    365 	.globl __NA_SP
                                    366 	.globl __NA_P0
                                    367 	.globl _I2SCLKF2
                                    368 	.globl _I2SCLKF1
                                    369 	.globl _I2SCLKF0
                                    370 	.globl _I2SSTAT
                                    371 	.globl _I2SWCNT
                                    372 	.globl _I2SDATH
                                    373 	.globl _I2SDATL
                                    374 	.globl _I2SCFG1
                                    375 	.globl _I2SCFG0
                                    376 	.globl _VCO_VC_DAC
                                    377 	.globl _PKTSTATUS
                                    378 	.globl _MARCSTATE
                                    379 	.globl _RSSI
                                    380 	.globl _LQI
                                    381 	.globl _FREQEST
                                    382 	.globl _VERSION
                                    383 	.globl _PARTNUM
                                    384 	.globl __XREGDF35
                                    385 	.globl __XREGDF34
                                    386 	.globl __XREGDF33
                                    387 	.globl __XREGDF32
                                    388 	.globl _IOCFG0
                                    389 	.globl _IOCFG1
                                    390 	.globl _IOCFG2
                                    391 	.globl _PA_TABLE0
                                    392 	.globl _PA_TABLE1
                                    393 	.globl _PA_TABLE2
                                    394 	.globl _PA_TABLE3
                                    395 	.globl _PA_TABLE4
                                    396 	.globl _PA_TABLE5
                                    397 	.globl _PA_TABLE6
                                    398 	.globl _PA_TABLE7
                                    399 	.globl __XREGDF26
                                    400 	.globl _TEST0
                                    401 	.globl _TEST1
                                    402 	.globl _TEST2
                                    403 	.globl __XREGDF22
                                    404 	.globl __XREGDF21
                                    405 	.globl __XREGDF20
                                    406 	.globl _FSCAL0
                                    407 	.globl _FSCAL1
                                    408 	.globl _FSCAL2
                                    409 	.globl _FSCAL3
                                    410 	.globl _FREND0
                                    411 	.globl _FREND1
                                    412 	.globl _AGCCTRL0
                                    413 	.globl _AGCCTRL1
                                    414 	.globl _AGCCTRL2
                                    415 	.globl _BSCFG
                                    416 	.globl _FOCCFG
                                    417 	.globl _MCSM0
                                    418 	.globl _MCSM1
                                    419 	.globl _MCSM2
                                    420 	.globl _DEVIATN
                                    421 	.globl _MDMCFG0
                                    422 	.globl _MDMCFG1
                                    423 	.globl _MDMCFG2
                                    424 	.globl _MDMCFG3
                                    425 	.globl _MDMCFG4
                                    426 	.globl _FREQ0
                                    427 	.globl _FREQ1
                                    428 	.globl _FREQ2
                                    429 	.globl _FSCTRL0
                                    430 	.globl _FSCTRL1
                                    431 	.globl _CHANNR
                                    432 	.globl _ADDR
                                    433 	.globl _PKTCTRL0
                                    434 	.globl _PKTCTRL1
                                    435 	.globl _PKTLEN
                                    436 	.globl _SYNC0
                                    437 	.globl _SYNC1
                                    438 	.globl _MDMCTRL0H
                                    439 	.globl _mode_registers_add_PARM_3
                                    440 	.globl _mode_registers_add_PARM_2
                                    441 	.globl _set_register_PARM_2
                                    442 	.globl _debug_putc
                                    443 	.globl _get_register
                                    444 	.globl _set_register
                                    445 	.globl _mode_registers_clear
                                    446 	.globl _mode_registers_add
                                    447 	.globl _mode_registers_enact
                                    448 ;--------------------------------------------------------
                                    449 ; special function registers
                                    450 ;--------------------------------------------------------
                                    451 	.area RSEG    (ABS,DATA)
      000000                        452 	.org 0x0000
                           000080   453 _P0	=	0x0080
                           000081   454 _SP	=	0x0081
                           000082   455 _DPL0	=	0x0082
                           000083   456 _DPH0	=	0x0083
                           000084   457 _DPL1	=	0x0084
                           000085   458 _DPH1	=	0x0085
                           000086   459 _U0CSR	=	0x0086
                           000087   460 _PCON	=	0x0087
                           000088   461 _TCON	=	0x0088
                           000089   462 _P0IFG	=	0x0089
                           00008A   463 _P1IFG	=	0x008a
                           00008B   464 _P2IFG	=	0x008b
                           00008C   465 _PICTL	=	0x008c
                           00008D   466 _P1IEN	=	0x008d
                           00008E   467 __SFR8E	=	0x008e
                           00008F   468 _P0INP	=	0x008f
                           000090   469 _P1	=	0x0090
                           000091   470 _RFIM	=	0x0091
                           000092   471 _DPS	=	0x0092
                           000093   472 _MPAGE	=	0x0093
                           000093   473 __XPAGE	=	0x0093
                           000094   474 __SFR94	=	0x0094
                           000095   475 __SFR95	=	0x0095
                           000096   476 __SFR96	=	0x0096
                           000097   477 __SFR97	=	0x0097
                           000098   478 _S0CON	=	0x0098
                           000099   479 __SFR99	=	0x0099
                           00009A   480 _IEN2	=	0x009a
                           00009B   481 _S1CON	=	0x009b
                           00009C   482 _T2CT	=	0x009c
                           00009D   483 _T2PR	=	0x009d
                           00009E   484 _T2CTL	=	0x009e
                           00009F   485 __SFR9F	=	0x009f
                           0000A0   486 _P2	=	0x00a0
                           0000A1   487 _WORIRQ	=	0x00a1
                           0000A2   488 _WORCTRL	=	0x00a2
                           0000A3   489 _WOREVT0	=	0x00a3
                           0000A4   490 _WOREVT1	=	0x00a4
                           0000A5   491 _WORTIME0	=	0x00a5
                           0000A6   492 _WORTIME1	=	0x00a6
                           0000A7   493 __SFRA7	=	0x00a7
                           0000A8   494 _IEN0	=	0x00a8
                           0000A9   495 _IP0	=	0x00a9
                           0000AA   496 __SFRAA	=	0x00aa
                           0000AB   497 _FWT	=	0x00ab
                           0000AC   498 _FADDRL	=	0x00ac
                           0000AD   499 _FADDRH	=	0x00ad
                           0000AE   500 _FCTL	=	0x00ae
                           0000AF   501 _FWDATA	=	0x00af
                           0000B0   502 __SFRB0	=	0x00b0
                           0000B1   503 _ENCDI	=	0x00b1
                           0000B2   504 _ENCDO	=	0x00b2
                           0000B3   505 _ENCCS	=	0x00b3
                           0000B4   506 _ADCCON1	=	0x00b4
                           0000B5   507 _ADCCON2	=	0x00b5
                           0000B6   508 _ADCCON3	=	0x00b6
                           0000B7   509 __SFRB7	=	0x00b7
                           0000B8   510 _IEN1	=	0x00b8
                           0000B9   511 _IP1	=	0x00b9
                           0000BA   512 _ADCL	=	0x00ba
                           0000BB   513 _ADCH	=	0x00bb
                           0000BC   514 _RNDL	=	0x00bc
                           0000BD   515 _RNDH	=	0x00bd
                           0000BE   516 _SLEEP	=	0x00be
                           0000BF   517 __SFRBF	=	0x00bf
                           0000C0   518 _IRCON	=	0x00c0
                           0000C1   519 _U0DBUF	=	0x00c1
                           0000C2   520 _U0BAUD	=	0x00c2
                           0000C3   521 __SFRC3	=	0x00c3
                           0000C4   522 _U0UCR	=	0x00c4
                           0000C5   523 _U0GCR	=	0x00c5
                           0000C6   524 _CLKCON	=	0x00c6
                           0000C7   525 _MEMCTR	=	0x00c7
                           0000C8   526 __SFRC8	=	0x00c8
                           0000C9   527 _WDCTL	=	0x00c9
                           0000CA   528 _T3CNT	=	0x00ca
                           0000CB   529 _T3CTL	=	0x00cb
                           0000CC   530 _T3CCTL0	=	0x00cc
                           0000CD   531 _T3CC0	=	0x00cd
                           0000CE   532 _T3CCTL1	=	0x00ce
                           0000CF   533 _T3CC1	=	0x00cf
                           0000D0   534 _PSW	=	0x00d0
                           0000D1   535 _DMAIRQ	=	0x00d1
                           0000D2   536 _DMA1CFGL	=	0x00d2
                           0000D3   537 _DMA1CFGH	=	0x00d3
                           0000D4   538 _DMA0CFGL	=	0x00d4
                           0000D5   539 _DMA0CFGH	=	0x00d5
                           0000D6   540 _DMAARM	=	0x00d6
                           0000D7   541 _DMAREQ	=	0x00d7
                           0000D8   542 _TIMIF	=	0x00d8
                           0000D9   543 _RFD	=	0x00d9
                           0000DA   544 _T1CC0L	=	0x00da
                           0000DB   545 _T1CC0H	=	0x00db
                           0000DC   546 _T1CC1L	=	0x00dc
                           0000DD   547 _T1CC1H	=	0x00dd
                           0000DE   548 _T1CC2L	=	0x00de
                           0000DF   549 _T1CC2H	=	0x00df
                           0000E0   550 _ACC	=	0x00e0
                           0000E1   551 _RFST	=	0x00e1
                           0000E2   552 _T1CNTL	=	0x00e2
                           0000E3   553 _T1CNTH	=	0x00e3
                           0000E4   554 _T1CTL	=	0x00e4
                           0000E5   555 _T1CCTL0	=	0x00e5
                           0000E6   556 _T1CCTL1	=	0x00e6
                           0000E7   557 _T1CCTL2	=	0x00e7
                           0000E8   558 _IRCON2	=	0x00e8
                           0000E9   559 _RFIF	=	0x00e9
                           0000EA   560 _T4CNT	=	0x00ea
                           0000EB   561 _T4CTL	=	0x00eb
                           0000EC   562 _T4CCTL0	=	0x00ec
                           0000ED   563 _T4CC0	=	0x00ed
                           0000EE   564 _T4CCTL1	=	0x00ee
                           0000EF   565 _T4CC1	=	0x00ef
                           0000F0   566 _B	=	0x00f0
                           0000F1   567 _PERCFG	=	0x00f1
                           0000F2   568 _ADCCFG	=	0x00f2
                           0000F3   569 _P0SEL	=	0x00f3
                           0000F4   570 _P1SEL	=	0x00f4
                           0000F5   571 _P2SEL	=	0x00f5
                           0000F6   572 _P1INP	=	0x00f6
                           0000F7   573 _P2INP	=	0x00f7
                           0000F8   574 _U1CSR	=	0x00f8
                           0000F9   575 _U1DBUF	=	0x00f9
                           0000FA   576 _U1BAUD	=	0x00fa
                           0000FB   577 _U1UCR	=	0x00fb
                           0000FC   578 _U1GCR	=	0x00fc
                           0000FD   579 _P0DIR	=	0x00fd
                           0000FE   580 _P1DIR	=	0x00fe
                           0000FF   581 _P2DIR	=	0x00ff
                                    582 ;--------------------------------------------------------
                                    583 ; special function bits
                                    584 ;--------------------------------------------------------
                                    585 	.area RSEG    (ABS,DATA)
      000000                        586 	.org 0x0000
                           000080   587 _P0_0	=	0x0080
                           000081   588 _P0_1	=	0x0081
                           000082   589 _P0_2	=	0x0082
                           000083   590 _P0_3	=	0x0083
                           000084   591 _P0_4	=	0x0084
                           000085   592 _P0_5	=	0x0085
                           000086   593 _P0_6	=	0x0086
                           000087   594 _P0_7	=	0x0087
                           000088   595 _IT0	=	0x0088
                           000089   596 _RFTXRXIF	=	0x0089
                           00008A   597 _IT1	=	0x008a
                           00008B   598 _URX0IF	=	0x008b
                           00008D   599 _ADCIF	=	0x008d
                           00008F   600 _URX1IF	=	0x008f
                           000090   601 _P1_0	=	0x0090
                           000091   602 _P1_1	=	0x0091
                           000092   603 _P1_2	=	0x0092
                           000093   604 _P1_3	=	0x0093
                           000094   605 _P1_4	=	0x0094
                           000095   606 _P1_5	=	0x0095
                           000096   607 _P1_6	=	0x0096
                           000097   608 _P1_7	=	0x0097
                           000098   609 _ENCIF_0	=	0x0098
                           000099   610 _ENCIF_1	=	0x0099
                           0000A0   611 _P2_0	=	0x00a0
                           0000A1   612 _P2_1	=	0x00a1
                           0000A2   613 _P2_2	=	0x00a2
                           0000A3   614 _P2_3	=	0x00a3
                           0000A4   615 _P2_4	=	0x00a4
                           0000A5   616 _P2_5	=	0x00a5
                           0000A6   617 _P2_6	=	0x00a6
                           0000A7   618 _P2_7	=	0x00a7
                           0000A8   619 _RFTXRXIE	=	0x00a8
                           0000A9   620 _ADCIE	=	0x00a9
                           0000AA   621 _URX0IE	=	0x00aa
                           0000AB   622 _URX1IE	=	0x00ab
                           0000AC   623 _ENCIE	=	0x00ac
                           0000AD   624 _STIE	=	0x00ad
                           0000AF   625 _EA	=	0x00af
                           0000B8   626 _DMAIE	=	0x00b8
                           0000B9   627 _T1IE	=	0x00b9
                           0000BA   628 _T2IE	=	0x00ba
                           0000BB   629 _T3IE	=	0x00bb
                           0000BC   630 _T4IE	=	0x00bc
                           0000BD   631 _P0IE	=	0x00bd
                           0000C0   632 _DMAIF	=	0x00c0
                           0000C1   633 _T1IF	=	0x00c1
                           0000C2   634 _T2IF	=	0x00c2
                           0000C3   635 _T3IF	=	0x00c3
                           0000C4   636 _T4IF	=	0x00c4
                           0000C5   637 _P0IF	=	0x00c5
                           0000C7   638 _STIF	=	0x00c7
                           0000D0   639 _P	=	0x00d0
                           0000D1   640 _F1	=	0x00d1
                           0000D2   641 _OV	=	0x00d2
                           0000D3   642 _RS0	=	0x00d3
                           0000D4   643 _RS1	=	0x00d4
                           0000D5   644 _F0	=	0x00d5
                           0000D6   645 _AC	=	0x00d6
                           0000D7   646 _CY	=	0x00d7
                           0000D8   647 _T3OVFIF	=	0x00d8
                           0000D9   648 _T3CH0IF	=	0x00d9
                           0000DA   649 _T3CH1IF	=	0x00da
                           0000DB   650 _T4OVFIF	=	0x00db
                           0000DC   651 _T4CH0IF	=	0x00dc
                           0000DD   652 _T4CH1IF	=	0x00dd
                           0000DE   653 _OVFIM	=	0x00de
                           0000E0   654 _ACC_0	=	0x00e0
                           0000E1   655 _ACC_1	=	0x00e1
                           0000E2   656 _ACC_2	=	0x00e2
                           0000E3   657 _ACC_3	=	0x00e3
                           0000E4   658 _ACC_4	=	0x00e4
                           0000E5   659 _ACC_5	=	0x00e5
                           0000E6   660 _ACC_6	=	0x00e6
                           0000E7   661 _ACC_7	=	0x00e7
                           0000E8   662 _P2IF	=	0x00e8
                           0000E9   663 _UTX0IF	=	0x00e9
                           0000EA   664 _UTX1IF	=	0x00ea
                           0000EB   665 _P1IF	=	0x00eb
                           0000EC   666 _WDTIF	=	0x00ec
                           0000F0   667 _B_0	=	0x00f0
                           0000F1   668 _B_1	=	0x00f1
                           0000F2   669 _B_2	=	0x00f2
                           0000F3   670 _B_3	=	0x00f3
                           0000F4   671 _B_4	=	0x00f4
                           0000F5   672 _B_5	=	0x00f5
                           0000F6   673 _B_6	=	0x00f6
                           0000F7   674 _B_7	=	0x00f7
                           0000F8   675 _ACTIVE	=	0x00f8
                           0000F9   676 _TX_BYTE	=	0x00f9
                           0000FA   677 _RX_BYTE	=	0x00fa
                           0000FB   678 _ERR	=	0x00fb
                           0000FC   679 _FE	=	0x00fc
                           0000FD   680 _SLAVE	=	0x00fd
                           0000FE   681 _RE	=	0x00fe
                           0000FF   682 _MODE	=	0x00ff
                                    683 ;--------------------------------------------------------
                                    684 ; overlayable register banks
                                    685 ;--------------------------------------------------------
                                    686 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        687 	.ds 8
                                    688 ;--------------------------------------------------------
                                    689 ; internal ram data
                                    690 ;--------------------------------------------------------
                                    691 	.area DSEG    (DATA)
      000015                        692 _mode_registers_enact_sloc0_1_0:
      000015                        693 	.ds 2
      000017                        694 _mode_registers_enact_sloc1_1_0:
      000017                        695 	.ds 1
                                    696 ;--------------------------------------------------------
                                    697 ; overlayable items in internal ram 
                                    698 ;--------------------------------------------------------
                                    699 ;--------------------------------------------------------
                                    700 ; indirectly addressable internal ram data
                                    701 ;--------------------------------------------------------
                                    702 	.area ISEG    (DATA)
                                    703 ;--------------------------------------------------------
                                    704 ; absolute internal ram data
                                    705 ;--------------------------------------------------------
                                    706 	.area IABS    (ABS,DATA)
                                    707 	.area IABS    (ABS,DATA)
                                    708 ;--------------------------------------------------------
                                    709 ; bit data
                                    710 ;--------------------------------------------------------
                                    711 	.area BSEG    (BIT)
      000001                        712 _debug_putc_sloc0_1_0:
      000001                        713 	.ds 1
                                    714 ;--------------------------------------------------------
                                    715 ; paged external ram data
                                    716 ;--------------------------------------------------------
                                    717 	.area PSEG    (PAG,XDATA)
      00F05A                        718 _set_register_PARM_2:
      00F05A                        719 	.ds 1
      00F05B                        720 _mode_registers_add_PARM_2:
      00F05B                        721 	.ds 1
      00F05C                        722 _mode_registers_add_PARM_3:
      00F05C                        723 	.ds 1
      00F05D                        724 _mode_registers_add_mode_65536_39:
      00F05D                        725 	.ds 3
      00F060                        726 _mode_registers_enact_mode_65536_42:
      00F060                        727 	.ds 3
      00F063                        728 _mode_registers_enact_i_65536_43:
      00F063                        729 	.ds 2
                                    730 ;--------------------------------------------------------
                                    731 ; external ram data
                                    732 ;--------------------------------------------------------
                                    733 	.area XSEG    (XDATA)
                           00DF02   734 _MDMCTRL0H	=	0xdf02
                           00DF00   735 _SYNC1	=	0xdf00
                           00DF01   736 _SYNC0	=	0xdf01
                           00DF02   737 _PKTLEN	=	0xdf02
                           00DF03   738 _PKTCTRL1	=	0xdf03
                           00DF04   739 _PKTCTRL0	=	0xdf04
                           00DF05   740 _ADDR	=	0xdf05
                           00DF06   741 _CHANNR	=	0xdf06
                           00DF07   742 _FSCTRL1	=	0xdf07
                           00DF08   743 _FSCTRL0	=	0xdf08
                           00DF09   744 _FREQ2	=	0xdf09
                           00DF0A   745 _FREQ1	=	0xdf0a
                           00DF0B   746 _FREQ0	=	0xdf0b
                           00DF0C   747 _MDMCFG4	=	0xdf0c
                           00DF0D   748 _MDMCFG3	=	0xdf0d
                           00DF0E   749 _MDMCFG2	=	0xdf0e
                           00DF0F   750 _MDMCFG1	=	0xdf0f
                           00DF10   751 _MDMCFG0	=	0xdf10
                           00DF11   752 _DEVIATN	=	0xdf11
                           00DF12   753 _MCSM2	=	0xdf12
                           00DF13   754 _MCSM1	=	0xdf13
                           00DF14   755 _MCSM0	=	0xdf14
                           00DF15   756 _FOCCFG	=	0xdf15
                           00DF16   757 _BSCFG	=	0xdf16
                           00DF17   758 _AGCCTRL2	=	0xdf17
                           00DF18   759 _AGCCTRL1	=	0xdf18
                           00DF19   760 _AGCCTRL0	=	0xdf19
                           00DF1A   761 _FREND1	=	0xdf1a
                           00DF1B   762 _FREND0	=	0xdf1b
                           00DF1C   763 _FSCAL3	=	0xdf1c
                           00DF1D   764 _FSCAL2	=	0xdf1d
                           00DF1E   765 _FSCAL1	=	0xdf1e
                           00DF1F   766 _FSCAL0	=	0xdf1f
                           00DF20   767 __XREGDF20	=	0xdf20
                           00DF21   768 __XREGDF21	=	0xdf21
                           00DF22   769 __XREGDF22	=	0xdf22
                           00DF23   770 _TEST2	=	0xdf23
                           00DF24   771 _TEST1	=	0xdf24
                           00DF25   772 _TEST0	=	0xdf25
                           00DF26   773 __XREGDF26	=	0xdf26
                           00DF27   774 _PA_TABLE7	=	0xdf27
                           00DF28   775 _PA_TABLE6	=	0xdf28
                           00DF29   776 _PA_TABLE5	=	0xdf29
                           00DF2A   777 _PA_TABLE4	=	0xdf2a
                           00DF2B   778 _PA_TABLE3	=	0xdf2b
                           00DF2C   779 _PA_TABLE2	=	0xdf2c
                           00DF2D   780 _PA_TABLE1	=	0xdf2d
                           00DF2E   781 _PA_TABLE0	=	0xdf2e
                           00DF2F   782 _IOCFG2	=	0xdf2f
                           00DF30   783 _IOCFG1	=	0xdf30
                           00DF31   784 _IOCFG0	=	0xdf31
                           00DF32   785 __XREGDF32	=	0xdf32
                           00DF33   786 __XREGDF33	=	0xdf33
                           00DF34   787 __XREGDF34	=	0xdf34
                           00DF35   788 __XREGDF35	=	0xdf35
                           00DF36   789 _PARTNUM	=	0xdf36
                           00DF37   790 _VERSION	=	0xdf37
                           00DF38   791 _FREQEST	=	0xdf38
                           00DF39   792 _LQI	=	0xdf39
                           00DF3A   793 _RSSI	=	0xdf3a
                           00DF3B   794 _MARCSTATE	=	0xdf3b
                           00DF3C   795 _PKTSTATUS	=	0xdf3c
                           00DF3D   796 _VCO_VC_DAC	=	0xdf3d
                           00DF40   797 _I2SCFG0	=	0xdf40
                           00DF41   798 _I2SCFG1	=	0xdf41
                           00DF42   799 _I2SDATL	=	0xdf42
                           00DF43   800 _I2SDATH	=	0xdf43
                           00DF44   801 _I2SWCNT	=	0xdf44
                           00DF45   802 _I2SSTAT	=	0xdf45
                           00DF46   803 _I2SCLKF0	=	0xdf46
                           00DF47   804 _I2SCLKF1	=	0xdf47
                           00DF48   805 _I2SCLKF2	=	0xdf48
                           00DF80   806 __NA_P0	=	0xdf80
                           00DF81   807 __NA_SP	=	0xdf81
                           00DF82   808 __NA_DPL0	=	0xdf82
                           00DF83   809 __NA_DPH0	=	0xdf83
                           00DF84   810 __NA_DPL1	=	0xdf84
                           00DF85   811 __NA_DPH1	=	0xdf85
                           00DF86   812 _X_U0CSR	=	0xdf86
                           00DF87   813 __NA_PCON	=	0xdf87
                           00DF88   814 __NA_TCON	=	0xdf88
                           00DF89   815 _X_P0IFG	=	0xdf89
                           00DF8A   816 _X_P1IFG	=	0xdf8a
                           00DF8B   817 _X_P2IFG	=	0xdf8b
                           00DF8C   818 _X_PICTL	=	0xdf8c
                           00DF8D   819 _X_P1IEN	=	0xdf8d
                           00DF8E   820 __X_SFR8E	=	0xdf8e
                           00DF8F   821 _X_P0INP	=	0xdf8f
                           00DF90   822 __NA_P1	=	0xdf90
                           00DF91   823 _X_RFIM	=	0xdf91
                           00DF92   824 __NA_DPS	=	0xdf92
                           00DF93   825 _X_MPAGE	=	0xdf93
                           00DF94   826 __X_SFR94	=	0xdf94
                           00DF95   827 __X_SFR95	=	0xdf95
                           00DF96   828 __X_SFR96	=	0xdf96
                           00DF97   829 __X_SFR97	=	0xdf97
                           00DF98   830 __NA_S0CON	=	0xdf98
                           00DF99   831 __X_SFR99	=	0xdf99
                           00DF9A   832 __NA_IEN2	=	0xdf9a
                           00DF9B   833 __NA_S1CON	=	0xdf9b
                           00DF9C   834 _X_T2CT	=	0xdf9c
                           00DF9D   835 _X_T2PR	=	0xdf9d
                           00DF9E   836 _X_T2CTL	=	0xdf9e
                           00DF9F   837 __X_SFR9F	=	0xdf9f
                           00DFA0   838 __NA_P2	=	0xdfa0
                           00DFA1   839 _X_WORIRQ	=	0xdfa1
                           00DFA2   840 _X_WORCTRL	=	0xdfa2
                           00DFA3   841 _X_WOREVT0	=	0xdfa3
                           00DFA4   842 _X_WOREVT1	=	0xdfa4
                           00DFA5   843 _X_WORTIME0	=	0xdfa5
                           00DFA6   844 _X_WORTIME1	=	0xdfa6
                           00DFA7   845 __X_SFRA7	=	0xdfa7
                           00DFA8   846 __NA_IEN0	=	0xdfa8
                           00DFA9   847 __NA_IP0	=	0xdfa9
                           00DFAA   848 __X_SFRAA	=	0xdfaa
                           00DFAB   849 _X_FWT	=	0xdfab
                           00DFAC   850 _X_FADDRL	=	0xdfac
                           00DFAD   851 _X_FADDRH	=	0xdfad
                           00DFAE   852 _X_FCTL	=	0xdfae
                           00DFAF   853 _X_FWDATA	=	0xdfaf
                           00DFB0   854 __X_SFRB0	=	0xdfb0
                           00DFB1   855 _X_ENCDI	=	0xdfb1
                           00DFB2   856 _X_ENCDO	=	0xdfb2
                           00DFB3   857 _X_ENCCS	=	0xdfb3
                           00DFB4   858 _X_ADCCON1	=	0xdfb4
                           00DFB5   859 _X_ADCCON2	=	0xdfb5
                           00DFB6   860 _X_ADCCON3	=	0xdfb6
                           00DFB7   861 __X_SFRB7	=	0xdfb7
                           00DFB8   862 __NA_IEN1	=	0xdfb8
                           00DFB9   863 __NA_IP1	=	0xdfb9
                           00DFBA   864 _X_ADCL	=	0xdfba
                           00DFBB   865 _X_ADCH	=	0xdfbb
                           00DFBC   866 _X_RNDL	=	0xdfbc
                           00DFBD   867 _X_RNDH	=	0xdfbd
                           00DFBE   868 _X_SLEEP	=	0xdfbe
                           00DFBF   869 __X_SFRBF	=	0xdfbf
                           00DFC0   870 __NA_IRCON	=	0xdfc0
                           00DFC1   871 _X_U0DBUF	=	0xdfc1
                           00DFC2   872 _X_U0BAUD	=	0xdfc2
                           00DFC3   873 __X_SFRC3	=	0xdfc3
                           00DFC4   874 _X_U0UCR	=	0xdfc4
                           00DFC5   875 _X_U0GCR	=	0xdfc5
                           00DFC6   876 _X_CLKCON	=	0xdfc6
                           00DFC7   877 _X_MEMCTR	=	0xdfc7
                           00DFC8   878 __X_SFRC8	=	0xdfc8
                           00DFC9   879 _X_WDCTL	=	0xdfc9
                           00DFCA   880 _X_T3CNT	=	0xdfca
                           00DFCB   881 _X_T3CTL	=	0xdfcb
                           00DFCC   882 _X_T3CCTL0	=	0xdfcc
                           00DFCD   883 _X_T3CC0	=	0xdfcd
                           00DFCE   884 _X_T3CCTL1	=	0xdfce
                           00DFCF   885 _X_T3CC1	=	0xdfcf
                           00DFD0   886 __NA_PSW	=	0xdfd0
                           00DFD1   887 _X_DMAIRQ	=	0xdfd1
                           00DFD2   888 _X_DMA1CFGL	=	0xdfd2
                           00DFD3   889 _X_DMA1CFGH	=	0xdfd3
                           00DFD4   890 _X_DMA0CFGL	=	0xdfd4
                           00DFD5   891 _X_DMA0CFGH	=	0xdfd5
                           00DFD6   892 _X_DMAARM	=	0xdfd6
                           00DFD7   893 _X_DMAREQ	=	0xdfd7
                           00DFD8   894 _X_TIMIF	=	0xdfd8
                           00DFD9   895 _X_RFD	=	0xdfd9
                           00DFDA   896 _X_T1CC0L	=	0xdfda
                           00DFDB   897 _X_T1CC0H	=	0xdfdb
                           00DFDC   898 _X_T1CC1L	=	0xdfdc
                           00DFDD   899 _X_T1CC1H	=	0xdfdd
                           00DFDE   900 _X_T1CC2L	=	0xdfde
                           00DFDF   901 _X_T1CC2H	=	0xdfdf
                           00DFE0   902 __NA_ACC	=	0xdfe0
                           00DFE1   903 _X_RFST	=	0xdfe1
                           00DFE2   904 _X_T1CNTL	=	0xdfe2
                           00DFE3   905 _X_T1CNTH	=	0xdfe3
                           00DFE4   906 _X_T1CTL	=	0xdfe4
                           00DFE5   907 _X_T1CCTL0	=	0xdfe5
                           00DFE6   908 _X_T1CCTL1	=	0xdfe6
                           00DFE7   909 _X_T1CCTL2	=	0xdfe7
                           00DFE8   910 __NA_IRCON2	=	0xdfe8
                           00DFE9   911 _X_RFIF	=	0xdfe9
                           00DFEA   912 _X_T4CNT	=	0xdfea
                           00DFEB   913 _X_T4CTL	=	0xdfeb
                           00DFEC   914 _X_T4CCTL0	=	0xdfec
                           00DFED   915 _X_T4CC0	=	0xdfed
                           00DFEE   916 _X_T4CCTL1	=	0xdfee
                           00DFEF   917 _X_T4CC1	=	0xdfef
                           00DFF0   918 __NA_B	=	0xdff0
                           00DFF1   919 _X_PERCFG	=	0xdff1
                           00DFF2   920 _X_ADCCFG	=	0xdff2
                           00DFF3   921 _X_P0SEL	=	0xdff3
                           00DFF4   922 _X_P1SEL	=	0xdff4
                           00DFF5   923 _X_P2SEL	=	0xdff5
                           00DFF6   924 _X_P1INP	=	0xdff6
                           00DFF7   925 _X_P2INP	=	0xdff7
                           00DFF8   926 _X_U1CSR	=	0xdff8
                           00DFF9   927 _X_U1DBUF	=	0xdff9
                           00DFFA   928 _X_U1BAUD	=	0xdffa
                           00DFFB   929 _X_U1UCR	=	0xdffb
                           00DFFC   930 _X_U1GCR	=	0xdffc
                           00DFFD   931 _X_P0DIR	=	0xdffd
                           00DFFE   932 _X_P1DIR	=	0xdffe
                           00DFFF   933 _X_P2DIR	=	0xdfff
      00F1EB                        934 _tx_registers::
      00F1EB                        935 	.ds 17
      00F1FC                        936 _rx_registers::
      00F1FC                        937 	.ds 17
                                    938 ;--------------------------------------------------------
                                    939 ; absolute external ram data
                                    940 ;--------------------------------------------------------
                                    941 	.area XABS    (ABS,XDATA)
                                    942 ;--------------------------------------------------------
                                    943 ; external initialized ram data
                                    944 ;--------------------------------------------------------
                                    945 	.area XISEG   (XDATA)
                                    946 	.area HOME    (CODE)
                                    947 	.area GSINIT0 (CODE)
                                    948 	.area GSINIT1 (CODE)
                                    949 	.area GSINIT2 (CODE)
                                    950 	.area GSINIT3 (CODE)
                                    951 	.area GSINIT4 (CODE)
                                    952 	.area GSINIT5 (CODE)
                                    953 	.area GSINIT  (CODE)
                                    954 	.area GSFINAL (CODE)
                                    955 	.area CSEG    (CODE)
                                    956 ;--------------------------------------------------------
                                    957 ; global & static initialisations
                                    958 ;--------------------------------------------------------
                                    959 	.area HOME    (CODE)
                                    960 	.area GSINIT  (CODE)
                                    961 	.area GSFINAL (CODE)
                                    962 	.area GSINIT  (CODE)
                                    963 ;--------------------------------------------------------
                                    964 ; Home
                                    965 ;--------------------------------------------------------
                                    966 	.area HOME    (CODE)
                                    967 	.area HOME    (CODE)
                                    968 ;--------------------------------------------------------
                                    969 ; code
                                    970 ;--------------------------------------------------------
                                    971 	.area CSEG    (CODE)
                                    972 ;------------------------------------------------------------
                                    973 ;Allocation info for local variables in function 'debug_putc'
                                    974 ;------------------------------------------------------------
                                    975 ;	hardware.c:20: void debug_putc(uint8_t data)
                                    976 ;	-----------------------------------------
                                    977 ;	 function debug_putc
                                    978 ;	-----------------------------------------
      001B57                        979 _debug_putc:
                           000007   980 	ar7 = 0x07
                           000006   981 	ar6 = 0x06
                           000005   982 	ar5 = 0x05
                           000004   983 	ar4 = 0x04
                           000003   984 	ar3 = 0x03
                           000002   985 	ar2 = 0x02
                           000001   986 	ar1 = 0x01
                           000000   987 	ar0 = 0x00
      001B57 AF 82            [24]  988 	mov	r7,dpl
                                    989 ;	hardware.c:24: P2_1 = 1;
                                    990 ;	assignBit
      001B59 D2 A1            [12]  991 	setb	_P2_1
                                    992 ;	hardware.c:25: i = debug_bit_t*2; while (i--);	//pause between bytes
      001B5B 7E 04            [12]  993 	mov	r6,#0x04
      001B5D                        994 00101$:
      001B5D 8E 05            [24]  995 	mov	ar5,r6
      001B5F 1E               [12]  996 	dec	r6
      001B60 ED               [12]  997 	mov	a,r5
      001B61 70 FA            [24]  998 	jnz	00101$
                                    999 ;	hardware.c:26: EA=0; 	//do not allow interrupts 
                                   1000 ;	assignBit
      001B63 C2 AF            [12] 1001 	clr	_EA
                                   1002 ;	hardware.c:27: P2_1 = 0;
                                   1003 ;	assignBit
      001B65 C2 A1            [12] 1004 	clr	_P2_1
                                   1005 ;	hardware.c:29: j=1;
      001B67 7E 01            [12] 1006 	mov	r6,#0x01
                                   1007 ;	hardware.c:30: while (j != 0)
      001B69                       1008 00107$:
      001B69 EE               [12] 1009 	mov	a,r6
      001B6A 60 1D            [24] 1010 	jz	00109$
                                   1011 ;	hardware.c:32: P2_1 = !!(data & j);
      001B6C EE               [12] 1012 	mov	a,r6
      001B6D 5F               [12] 1013 	anl	a,r7
      001B6E B4 01 00         [24] 1014 	cjne	a,#0x01,00147$
      001B71                       1015 00147$:
      001B71 B3               [12] 1016 	cpl	c
      001B72 92 01            [24] 1017 	mov	_debug_putc_sloc0_1_0,c
      001B74 E4               [12] 1018 	clr	a
      001B75 33               [12] 1019 	rlc	a
      001B76 24 FF            [12] 1020 	add	a,#0xff
      001B78 92 A1            [24] 1021 	mov	_P2_1,c
                                   1022 ;	hardware.c:33: j = j << 1;
      001B7A 8E 05            [24] 1023 	mov	ar5,r6
      001B7C ED               [12] 1024 	mov	a,r5
      001B7D 2D               [12] 1025 	add	a,r5
      001B7E FE               [12] 1026 	mov	r6,a
                                   1027 ;	hardware.c:34: i = debug_bit_t-2; while (i--);
      001B7F 7D 00            [12] 1028 	mov	r5,#0x00
      001B81                       1029 00104$:
      001B81 8D 04            [24] 1030 	mov	ar4,r5
      001B83 1D               [12] 1031 	dec	r5
      001B84 EC               [12] 1032 	mov	a,r4
      001B85 60 E2            [24] 1033 	jz	00107$
      001B87 80 F8            [24] 1034 	sjmp	00104$
      001B89                       1035 00109$:
                                   1036 ;	hardware.c:37: P2_1 = 1;
                                   1037 ;	assignBit
      001B89 D2 A1            [12] 1038 	setb	_P2_1
                                   1039 ;	hardware.c:38: EA=1; 	//resume interrupts 
                                   1040 ;	assignBit
      001B8B D2 AF            [12] 1041 	setb	_EA
                                   1042 ;	hardware.c:39: i = debug_bit_t; while (i--);  //stop bit
      001B8D 7F 02            [12] 1043 	mov	r7,#0x02
      001B8F                       1044 00110$:
      001B8F 8F 06            [24] 1045 	mov	ar6,r7
      001B91 1F               [12] 1046 	dec	r7
      001B92 EE               [12] 1047 	mov	a,r6
      001B93 70 FA            [24] 1048 	jnz	00110$
                                   1049 ;	hardware.c:40: }
      001B95 22               [24] 1050 	ret
                                   1051 ;------------------------------------------------------------
                                   1052 ;Allocation info for local variables in function 'get_register'
                                   1053 ;------------------------------------------------------------
                                   1054 ;	hardware.c:42: uint8_t get_register(uint8_t addr) {
                                   1055 ;	-----------------------------------------
                                   1056 ;	 function get_register
                                   1057 ;	-----------------------------------------
      001B96                       1058 _get_register:
                                   1059 ;	hardware.c:44: addr = serial_rx_byte();
      001B96 12 22 ED         [24] 1060 	lcall	_serial_rx_byte
                                   1061 ;	hardware.c:45: switch(addr) {
      001B99 E5 82            [12] 1062 	mov	a,dpl
      001B9B FF               [12] 1063 	mov	r7,a
      001B9C 24 D1            [12] 1064 	add	a,#0xff - 0x2e
      001B9E 50 03            [24] 1065 	jnc	00145$
      001BA0 02 1D 1F         [24] 1066 	ljmp	00137$
      001BA3                       1067 00145$:
      001BA3 EF               [12] 1068 	mov	a,r7
      001BA4 24 0A            [12] 1069 	add	a,#(00146$-3-.)
      001BA6 83               [24] 1070 	movc	a,@a+pc
      001BA7 F5 82            [12] 1071 	mov	dpl,a
      001BA9 EF               [12] 1072 	mov	a,r7
      001BAA 24 33            [12] 1073 	add	a,#(00147$-3-.)
      001BAC 83               [24] 1074 	movc	a,@a+pc
      001BAD F5 83            [12] 1075 	mov	dph,a
      001BAF E4               [12] 1076 	clr	a
      001BB0 73               [24] 1077 	jmp	@a+dptr
      001BB1                       1078 00146$:
      001BB1 0F                    1079 	.db	00101$
      001BB2 17                    1080 	.db	00102$
      001BB3 1F                    1081 	.db	00103$
      001BB4 27                    1082 	.db	00104$
      001BB5 2F                    1083 	.db	00105$
      001BB6 37                    1084 	.db	00106$
      001BB7 3F                    1085 	.db	00107$
      001BB8 47                    1086 	.db	00108$
      001BB9 4F                    1087 	.db	00109$
      001BBA 57                    1088 	.db	00110$
      001BBB 5F                    1089 	.db	00111$
      001BBC 67                    1090 	.db	00112$
      001BBD 6F                    1091 	.db	00113$
      001BBE 77                    1092 	.db	00114$
      001BBF 7F                    1093 	.db	00115$
      001BC0 87                    1094 	.db	00116$
      001BC1 8F                    1095 	.db	00117$
      001BC2 97                    1096 	.db	00118$
      001BC3 9F                    1097 	.db	00119$
      001BC4 A7                    1098 	.db	00120$
      001BC5 AF                    1099 	.db	00121$
      001BC6 B6                    1100 	.db	00122$
      001BC7 BD                    1101 	.db	00123$
      001BC8 C4                    1102 	.db	00124$
      001BC9 CB                    1103 	.db	00125$
      001BCA D2                    1104 	.db	00126$
      001BCB D9                    1105 	.db	00127$
      001BCC E0                    1106 	.db	00128$
      001BCD E7                    1107 	.db	00129$
      001BCE EE                    1108 	.db	00130$
      001BCF F5                    1109 	.db	00131$
      001BD0 FC                    1110 	.db	00132$
      001BD1 1F                    1111 	.db	00137$
      001BD2 1F                    1112 	.db	00137$
      001BD3 1F                    1113 	.db	00137$
      001BD4 1F                    1114 	.db	00137$
      001BD5 03                    1115 	.db	00133$
      001BD6 0A                    1116 	.db	00134$
      001BD7 1F                    1117 	.db	00137$
      001BD8 1F                    1118 	.db	00137$
      001BD9 1F                    1119 	.db	00137$
      001BDA 1F                    1120 	.db	00137$
      001BDB 1F                    1121 	.db	00137$
      001BDC 1F                    1122 	.db	00137$
      001BDD 1F                    1123 	.db	00137$
      001BDE 11                    1124 	.db	00135$
      001BDF 18                    1125 	.db	00136$
      001BE0                       1126 00147$:
      001BE0 1C                    1127 	.db	00101$>>8
      001BE1 1C                    1128 	.db	00102$>>8
      001BE2 1C                    1129 	.db	00103$>>8
      001BE3 1C                    1130 	.db	00104$>>8
      001BE4 1C                    1131 	.db	00105$>>8
      001BE5 1C                    1132 	.db	00106$>>8
      001BE6 1C                    1133 	.db	00107$>>8
      001BE7 1C                    1134 	.db	00108$>>8
      001BE8 1C                    1135 	.db	00109$>>8
      001BE9 1C                    1136 	.db	00110$>>8
      001BEA 1C                    1137 	.db	00111$>>8
      001BEB 1C                    1138 	.db	00112$>>8
      001BEC 1C                    1139 	.db	00113$>>8
      001BED 1C                    1140 	.db	00114$>>8
      001BEE 1C                    1141 	.db	00115$>>8
      001BEF 1C                    1142 	.db	00116$>>8
      001BF0 1C                    1143 	.db	00117$>>8
      001BF1 1C                    1144 	.db	00118$>>8
      001BF2 1C                    1145 	.db	00119$>>8
      001BF3 1C                    1146 	.db	00120$>>8
      001BF4 1C                    1147 	.db	00121$>>8
      001BF5 1C                    1148 	.db	00122$>>8
      001BF6 1C                    1149 	.db	00123$>>8
      001BF7 1C                    1150 	.db	00124$>>8
      001BF8 1C                    1151 	.db	00125$>>8
      001BF9 1C                    1152 	.db	00126$>>8
      001BFA 1C                    1153 	.db	00127$>>8
      001BFB 1C                    1154 	.db	00128$>>8
      001BFC 1C                    1155 	.db	00129$>>8
      001BFD 1C                    1156 	.db	00130$>>8
      001BFE 1C                    1157 	.db	00131$>>8
      001BFF 1C                    1158 	.db	00132$>>8
      001C00 1D                    1159 	.db	00137$>>8
      001C01 1D                    1160 	.db	00137$>>8
      001C02 1D                    1161 	.db	00137$>>8
      001C03 1D                    1162 	.db	00137$>>8
      001C04 1D                    1163 	.db	00133$>>8
      001C05 1D                    1164 	.db	00134$>>8
      001C06 1D                    1165 	.db	00137$>>8
      001C07 1D                    1166 	.db	00137$>>8
      001C08 1D                    1167 	.db	00137$>>8
      001C09 1D                    1168 	.db	00137$>>8
      001C0A 1D                    1169 	.db	00137$>>8
      001C0B 1D                    1170 	.db	00137$>>8
      001C0C 1D                    1171 	.db	00137$>>8
      001C0D 1D                    1172 	.db	00135$>>8
      001C0E 1D                    1173 	.db	00136$>>8
                                   1174 ;	hardware.c:46: case 0x00:
      001C0F                       1175 00101$:
                                   1176 ;	hardware.c:47: value = SYNC1;
      001C0F 90 DF 00         [24] 1177 	mov	dptr,#_SYNC1
      001C12 E0               [24] 1178 	movx	a,@dptr
      001C13 FF               [12] 1179 	mov	r7,a
                                   1180 ;	hardware.c:48: break;
      001C14 02 1D 21         [24] 1181 	ljmp	00138$
                                   1182 ;	hardware.c:49: case 0x01:
      001C17                       1183 00102$:
                                   1184 ;	hardware.c:50: value = SYNC0;
      001C17 90 DF 01         [24] 1185 	mov	dptr,#_SYNC0
      001C1A E0               [24] 1186 	movx	a,@dptr
      001C1B FF               [12] 1187 	mov	r7,a
                                   1188 ;	hardware.c:51: break;
      001C1C 02 1D 21         [24] 1189 	ljmp	00138$
                                   1190 ;	hardware.c:52: case 0x02:
      001C1F                       1191 00103$:
                                   1192 ;	hardware.c:53: value = PKTLEN;
      001C1F 90 DF 02         [24] 1193 	mov	dptr,#_PKTLEN
      001C22 E0               [24] 1194 	movx	a,@dptr
      001C23 FF               [12] 1195 	mov	r7,a
                                   1196 ;	hardware.c:54: break;
      001C24 02 1D 21         [24] 1197 	ljmp	00138$
                                   1198 ;	hardware.c:55: case 0x03:
      001C27                       1199 00104$:
                                   1200 ;	hardware.c:56: value = PKTCTRL1;
      001C27 90 DF 03         [24] 1201 	mov	dptr,#_PKTCTRL1
      001C2A E0               [24] 1202 	movx	a,@dptr
      001C2B FF               [12] 1203 	mov	r7,a
                                   1204 ;	hardware.c:57: break;
      001C2C 02 1D 21         [24] 1205 	ljmp	00138$
                                   1206 ;	hardware.c:58: case 0x04:
      001C2F                       1207 00105$:
                                   1208 ;	hardware.c:59: value = PKTCTRL0;
      001C2F 90 DF 04         [24] 1209 	mov	dptr,#_PKTCTRL0
      001C32 E0               [24] 1210 	movx	a,@dptr
      001C33 FF               [12] 1211 	mov	r7,a
                                   1212 ;	hardware.c:60: break;
      001C34 02 1D 21         [24] 1213 	ljmp	00138$
                                   1214 ;	hardware.c:61: case 0x05:
      001C37                       1215 00106$:
                                   1216 ;	hardware.c:62: value = ADDR;
      001C37 90 DF 05         [24] 1217 	mov	dptr,#_ADDR
      001C3A E0               [24] 1218 	movx	a,@dptr
      001C3B FF               [12] 1219 	mov	r7,a
                                   1220 ;	hardware.c:63: break;
      001C3C 02 1D 21         [24] 1221 	ljmp	00138$
                                   1222 ;	hardware.c:64: case 0x06:
      001C3F                       1223 00107$:
                                   1224 ;	hardware.c:65: value = CHANNR;
      001C3F 90 DF 06         [24] 1225 	mov	dptr,#_CHANNR
      001C42 E0               [24] 1226 	movx	a,@dptr
      001C43 FF               [12] 1227 	mov	r7,a
                                   1228 ;	hardware.c:66: break;
      001C44 02 1D 21         [24] 1229 	ljmp	00138$
                                   1230 ;	hardware.c:67: case 0x07:
      001C47                       1231 00108$:
                                   1232 ;	hardware.c:68: value = FSCTRL1;
      001C47 90 DF 07         [24] 1233 	mov	dptr,#_FSCTRL1
      001C4A E0               [24] 1234 	movx	a,@dptr
      001C4B FF               [12] 1235 	mov	r7,a
                                   1236 ;	hardware.c:69: break;
      001C4C 02 1D 21         [24] 1237 	ljmp	00138$
                                   1238 ;	hardware.c:70: case 0x08:
      001C4F                       1239 00109$:
                                   1240 ;	hardware.c:71: value = FSCTRL0;
      001C4F 90 DF 08         [24] 1241 	mov	dptr,#_FSCTRL0
      001C52 E0               [24] 1242 	movx	a,@dptr
      001C53 FF               [12] 1243 	mov	r7,a
                                   1244 ;	hardware.c:72: break;
      001C54 02 1D 21         [24] 1245 	ljmp	00138$
                                   1246 ;	hardware.c:73: case 0x09:
      001C57                       1247 00110$:
                                   1248 ;	hardware.c:74: value = FREQ2;
      001C57 90 DF 09         [24] 1249 	mov	dptr,#_FREQ2
      001C5A E0               [24] 1250 	movx	a,@dptr
      001C5B FF               [12] 1251 	mov	r7,a
                                   1252 ;	hardware.c:75: break;
      001C5C 02 1D 21         [24] 1253 	ljmp	00138$
                                   1254 ;	hardware.c:76: case 0x0A:
      001C5F                       1255 00111$:
                                   1256 ;	hardware.c:77: value = FREQ1;
      001C5F 90 DF 0A         [24] 1257 	mov	dptr,#_FREQ1
      001C62 E0               [24] 1258 	movx	a,@dptr
      001C63 FF               [12] 1259 	mov	r7,a
                                   1260 ;	hardware.c:78: break;
      001C64 02 1D 21         [24] 1261 	ljmp	00138$
                                   1262 ;	hardware.c:79: case 0x0B:
      001C67                       1263 00112$:
                                   1264 ;	hardware.c:80: value = FREQ0;
      001C67 90 DF 0B         [24] 1265 	mov	dptr,#_FREQ0
      001C6A E0               [24] 1266 	movx	a,@dptr
      001C6B FF               [12] 1267 	mov	r7,a
                                   1268 ;	hardware.c:81: break;
      001C6C 02 1D 21         [24] 1269 	ljmp	00138$
                                   1270 ;	hardware.c:82: case 0x0C:
      001C6F                       1271 00113$:
                                   1272 ;	hardware.c:83: value = MDMCFG4;
      001C6F 90 DF 0C         [24] 1273 	mov	dptr,#_MDMCFG4
      001C72 E0               [24] 1274 	movx	a,@dptr
      001C73 FF               [12] 1275 	mov	r7,a
                                   1276 ;	hardware.c:84: break;
      001C74 02 1D 21         [24] 1277 	ljmp	00138$
                                   1278 ;	hardware.c:85: case 0x0D:
      001C77                       1279 00114$:
                                   1280 ;	hardware.c:86: value = MDMCFG3;
      001C77 90 DF 0D         [24] 1281 	mov	dptr,#_MDMCFG3
      001C7A E0               [24] 1282 	movx	a,@dptr
      001C7B FF               [12] 1283 	mov	r7,a
                                   1284 ;	hardware.c:87: break;
      001C7C 02 1D 21         [24] 1285 	ljmp	00138$
                                   1286 ;	hardware.c:88: case 0x0E:
      001C7F                       1287 00115$:
                                   1288 ;	hardware.c:89: value = MDMCFG2;
      001C7F 90 DF 0E         [24] 1289 	mov	dptr,#_MDMCFG2
      001C82 E0               [24] 1290 	movx	a,@dptr
      001C83 FF               [12] 1291 	mov	r7,a
                                   1292 ;	hardware.c:90: break;
      001C84 02 1D 21         [24] 1293 	ljmp	00138$
                                   1294 ;	hardware.c:91: case 0x0F:
      001C87                       1295 00116$:
                                   1296 ;	hardware.c:92: value = MDMCFG1;
      001C87 90 DF 0F         [24] 1297 	mov	dptr,#_MDMCFG1
      001C8A E0               [24] 1298 	movx	a,@dptr
      001C8B FF               [12] 1299 	mov	r7,a
                                   1300 ;	hardware.c:93: break;
      001C8C 02 1D 21         [24] 1301 	ljmp	00138$
                                   1302 ;	hardware.c:94: case 0x10:
      001C8F                       1303 00117$:
                                   1304 ;	hardware.c:95: value = MDMCFG0;
      001C8F 90 DF 10         [24] 1305 	mov	dptr,#_MDMCFG0
      001C92 E0               [24] 1306 	movx	a,@dptr
      001C93 FF               [12] 1307 	mov	r7,a
                                   1308 ;	hardware.c:96: break;
      001C94 02 1D 21         [24] 1309 	ljmp	00138$
                                   1310 ;	hardware.c:97: case 0x11:
      001C97                       1311 00118$:
                                   1312 ;	hardware.c:98: value = DEVIATN;
      001C97 90 DF 11         [24] 1313 	mov	dptr,#_DEVIATN
      001C9A E0               [24] 1314 	movx	a,@dptr
      001C9B FF               [12] 1315 	mov	r7,a
                                   1316 ;	hardware.c:99: break;
      001C9C 02 1D 21         [24] 1317 	ljmp	00138$
                                   1318 ;	hardware.c:100: case 0x12:
      001C9F                       1319 00119$:
                                   1320 ;	hardware.c:101: value = MCSM2;
      001C9F 90 DF 12         [24] 1321 	mov	dptr,#_MCSM2
      001CA2 E0               [24] 1322 	movx	a,@dptr
      001CA3 FF               [12] 1323 	mov	r7,a
                                   1324 ;	hardware.c:102: break;
      001CA4 02 1D 21         [24] 1325 	ljmp	00138$
                                   1326 ;	hardware.c:103: case 0x13:
      001CA7                       1327 00120$:
                                   1328 ;	hardware.c:104: value = MCSM1;
      001CA7 90 DF 13         [24] 1329 	mov	dptr,#_MCSM1
      001CAA E0               [24] 1330 	movx	a,@dptr
      001CAB FF               [12] 1331 	mov	r7,a
                                   1332 ;	hardware.c:105: break;
      001CAC 02 1D 21         [24] 1333 	ljmp	00138$
                                   1334 ;	hardware.c:106: case 0x14:
      001CAF                       1335 00121$:
                                   1336 ;	hardware.c:107: value = MCSM0;
      001CAF 90 DF 14         [24] 1337 	mov	dptr,#_MCSM0
      001CB2 E0               [24] 1338 	movx	a,@dptr
      001CB3 FF               [12] 1339 	mov	r7,a
                                   1340 ;	hardware.c:108: break;
                                   1341 ;	hardware.c:109: case 0x15:
      001CB4 80 6B            [24] 1342 	sjmp	00138$
      001CB6                       1343 00122$:
                                   1344 ;	hardware.c:110: value = FOCCFG;
      001CB6 90 DF 15         [24] 1345 	mov	dptr,#_FOCCFG
      001CB9 E0               [24] 1346 	movx	a,@dptr
      001CBA FF               [12] 1347 	mov	r7,a
                                   1348 ;	hardware.c:111: break;
                                   1349 ;	hardware.c:112: case 0x16:
      001CBB 80 64            [24] 1350 	sjmp	00138$
      001CBD                       1351 00123$:
                                   1352 ;	hardware.c:113: value = BSCFG;
      001CBD 90 DF 16         [24] 1353 	mov	dptr,#_BSCFG
      001CC0 E0               [24] 1354 	movx	a,@dptr
      001CC1 FF               [12] 1355 	mov	r7,a
                                   1356 ;	hardware.c:114: break;
                                   1357 ;	hardware.c:115: case 0x17:
      001CC2 80 5D            [24] 1358 	sjmp	00138$
      001CC4                       1359 00124$:
                                   1360 ;	hardware.c:116: value = AGCCTRL2;
      001CC4 90 DF 17         [24] 1361 	mov	dptr,#_AGCCTRL2
      001CC7 E0               [24] 1362 	movx	a,@dptr
      001CC8 FF               [12] 1363 	mov	r7,a
                                   1364 ;	hardware.c:117: break;
                                   1365 ;	hardware.c:118: case 0x18:
      001CC9 80 56            [24] 1366 	sjmp	00138$
      001CCB                       1367 00125$:
                                   1368 ;	hardware.c:119: value = AGCCTRL1;
      001CCB 90 DF 18         [24] 1369 	mov	dptr,#_AGCCTRL1
      001CCE E0               [24] 1370 	movx	a,@dptr
      001CCF FF               [12] 1371 	mov	r7,a
                                   1372 ;	hardware.c:120: break;
                                   1373 ;	hardware.c:121: case 0x19:
      001CD0 80 4F            [24] 1374 	sjmp	00138$
      001CD2                       1375 00126$:
                                   1376 ;	hardware.c:122: value = AGCCTRL0;
      001CD2 90 DF 19         [24] 1377 	mov	dptr,#_AGCCTRL0
      001CD5 E0               [24] 1378 	movx	a,@dptr
      001CD6 FF               [12] 1379 	mov	r7,a
                                   1380 ;	hardware.c:123: break;
                                   1381 ;	hardware.c:124: case 0x1A:
      001CD7 80 48            [24] 1382 	sjmp	00138$
      001CD9                       1383 00127$:
                                   1384 ;	hardware.c:125: value = FREND1;
      001CD9 90 DF 1A         [24] 1385 	mov	dptr,#_FREND1
      001CDC E0               [24] 1386 	movx	a,@dptr
      001CDD FF               [12] 1387 	mov	r7,a
                                   1388 ;	hardware.c:126: break;
                                   1389 ;	hardware.c:127: case 0x1B:
      001CDE 80 41            [24] 1390 	sjmp	00138$
      001CE0                       1391 00128$:
                                   1392 ;	hardware.c:128: value = FREND0;
      001CE0 90 DF 1B         [24] 1393 	mov	dptr,#_FREND0
      001CE3 E0               [24] 1394 	movx	a,@dptr
      001CE4 FF               [12] 1395 	mov	r7,a
                                   1396 ;	hardware.c:129: break;
                                   1397 ;	hardware.c:130: case 0x1C:
      001CE5 80 3A            [24] 1398 	sjmp	00138$
      001CE7                       1399 00129$:
                                   1400 ;	hardware.c:131: value = FSCAL3;
      001CE7 90 DF 1C         [24] 1401 	mov	dptr,#_FSCAL3
      001CEA E0               [24] 1402 	movx	a,@dptr
      001CEB FF               [12] 1403 	mov	r7,a
                                   1404 ;	hardware.c:132: break;
                                   1405 ;	hardware.c:133: case 0x1D:
      001CEC 80 33            [24] 1406 	sjmp	00138$
      001CEE                       1407 00130$:
                                   1408 ;	hardware.c:134: value = FSCAL2;
      001CEE 90 DF 1D         [24] 1409 	mov	dptr,#_FSCAL2
      001CF1 E0               [24] 1410 	movx	a,@dptr
      001CF2 FF               [12] 1411 	mov	r7,a
                                   1412 ;	hardware.c:135: break;
                                   1413 ;	hardware.c:136: case 0x1E:
      001CF3 80 2C            [24] 1414 	sjmp	00138$
      001CF5                       1415 00131$:
                                   1416 ;	hardware.c:137: value = FSCAL1;
      001CF5 90 DF 1E         [24] 1417 	mov	dptr,#_FSCAL1
      001CF8 E0               [24] 1418 	movx	a,@dptr
      001CF9 FF               [12] 1419 	mov	r7,a
                                   1420 ;	hardware.c:138: break;
                                   1421 ;	hardware.c:139: case 0x1F:
      001CFA 80 25            [24] 1422 	sjmp	00138$
      001CFC                       1423 00132$:
                                   1424 ;	hardware.c:140: value = FSCAL0;
      001CFC 90 DF 1F         [24] 1425 	mov	dptr,#_FSCAL0
      001CFF E0               [24] 1426 	movx	a,@dptr
      001D00 FF               [12] 1427 	mov	r7,a
                                   1428 ;	hardware.c:141: break;
                                   1429 ;	hardware.c:142: case 0x24:
      001D01 80 1E            [24] 1430 	sjmp	00138$
      001D03                       1431 00133$:
                                   1432 ;	hardware.c:143: value = TEST1;
      001D03 90 DF 24         [24] 1433 	mov	dptr,#_TEST1
      001D06 E0               [24] 1434 	movx	a,@dptr
      001D07 FF               [12] 1435 	mov	r7,a
                                   1436 ;	hardware.c:144: break;
                                   1437 ;	hardware.c:145: case 0x25:
      001D08 80 17            [24] 1438 	sjmp	00138$
      001D0A                       1439 00134$:
                                   1440 ;	hardware.c:146: value = TEST0;
      001D0A 90 DF 25         [24] 1441 	mov	dptr,#_TEST0
      001D0D E0               [24] 1442 	movx	a,@dptr
      001D0E FF               [12] 1443 	mov	r7,a
                                   1444 ;	hardware.c:147: break;
                                   1445 ;	hardware.c:148: case 0x2D:
      001D0F 80 10            [24] 1446 	sjmp	00138$
      001D11                       1447 00135$:
                                   1448 ;	hardware.c:149: value = PA_TABLE1;
      001D11 90 DF 2D         [24] 1449 	mov	dptr,#_PA_TABLE1
      001D14 E0               [24] 1450 	movx	a,@dptr
      001D15 FF               [12] 1451 	mov	r7,a
                                   1452 ;	hardware.c:150: break;
                                   1453 ;	hardware.c:151: case 0x2E:
      001D16 80 09            [24] 1454 	sjmp	00138$
      001D18                       1455 00136$:
                                   1456 ;	hardware.c:152: value = PA_TABLE0;
      001D18 90 DF 2E         [24] 1457 	mov	dptr,#_PA_TABLE0
      001D1B E0               [24] 1458 	movx	a,@dptr
      001D1C FF               [12] 1459 	mov	r7,a
                                   1460 ;	hardware.c:153: break;
                                   1461 ;	hardware.c:154: default:
      001D1D 80 02            [24] 1462 	sjmp	00138$
      001D1F                       1463 00137$:
                                   1464 ;	hardware.c:155: value = 0x5A;
      001D1F 7F 5A            [12] 1465 	mov	r7,#0x5a
                                   1466 ;	hardware.c:156: }
      001D21                       1467 00138$:
                                   1468 ;	hardware.c:157: return value;
      001D21 8F 82            [24] 1469 	mov	dpl,r7
                                   1470 ;	hardware.c:158: }
      001D23 22               [24] 1471 	ret
                                   1472 ;------------------------------------------------------------
                                   1473 ;Allocation info for local variables in function 'set_register'
                                   1474 ;------------------------------------------------------------
                                   1475 ;	hardware.c:160: uint8_t set_register(uint8_t addr, uint8_t value) {
                                   1476 ;	-----------------------------------------
                                   1477 ;	 function set_register
                                   1478 ;	-----------------------------------------
      001D24                       1479 _set_register:
      001D24 AF 82            [24] 1480 	mov	r7,dpl
                                   1481 ;	hardware.c:162: rval = RESPONSE_CODE_SUCCESS;
      001D26 7E DD            [12] 1482 	mov	r6,#0xdd
                                   1483 ;	hardware.c:163: switch(addr) {
      001D28 EF               [12] 1484 	mov	a,r7
      001D29 24 D1            [12] 1485 	add	a,#0xff - 0x2e
      001D2B 50 03            [24] 1486 	jnc	00145$
      001D2D 02 1E F7         [24] 1487 	ljmp	00137$
      001D30                       1488 00145$:
      001D30 EF               [12] 1489 	mov	a,r7
      001D31 24 0A            [12] 1490 	add	a,#(00146$-3-.)
      001D33 83               [24] 1491 	movc	a,@a+pc
      001D34 F5 82            [12] 1492 	mov	dpl,a
      001D36 EF               [12] 1493 	mov	a,r7
      001D37 24 33            [12] 1494 	add	a,#(00147$-3-.)
      001D39 83               [24] 1495 	movc	a,@a+pc
      001D3A F5 83            [12] 1496 	mov	dph,a
      001D3C E4               [12] 1497 	clr	a
      001D3D 73               [24] 1498 	jmp	@a+dptr
      001D3E                       1499 00146$:
      001D3E 9C                    1500 	.db	00101$
      001D3F A6                    1501 	.db	00102$
      001D40 B0                    1502 	.db	00103$
      001D41 BA                    1503 	.db	00104$
      001D42 C4                    1504 	.db	00105$
      001D43 CE                    1505 	.db	00106$
      001D44 D8                    1506 	.db	00107$
      001D45 E2                    1507 	.db	00108$
      001D46 EC                    1508 	.db	00109$
      001D47 F6                    1509 	.db	00110$
      001D48 00                    1510 	.db	00111$
      001D49 0A                    1511 	.db	00112$
      001D4A 14                    1512 	.db	00113$
      001D4B 1E                    1513 	.db	00114$
      001D4C 28                    1514 	.db	00115$
      001D4D 32                    1515 	.db	00116$
      001D4E 3C                    1516 	.db	00117$
      001D4F 46                    1517 	.db	00118$
      001D50 50                    1518 	.db	00119$
      001D51 5A                    1519 	.db	00120$
      001D52 64                    1520 	.db	00121$
      001D53 6E                    1521 	.db	00122$
      001D54 78                    1522 	.db	00123$
      001D55 82                    1523 	.db	00124$
      001D56 8B                    1524 	.db	00125$
      001D57 94                    1525 	.db	00126$
      001D58 9D                    1526 	.db	00127$
      001D59 A6                    1527 	.db	00128$
      001D5A AF                    1528 	.db	00129$
      001D5B B8                    1529 	.db	00130$
      001D5C C1                    1530 	.db	00131$
      001D5D CA                    1531 	.db	00132$
      001D5E F7                    1532 	.db	00137$
      001D5F F7                    1533 	.db	00137$
      001D60 F7                    1534 	.db	00137$
      001D61 F7                    1535 	.db	00137$
      001D62 D3                    1536 	.db	00133$
      001D63 DC                    1537 	.db	00134$
      001D64 F7                    1538 	.db	00137$
      001D65 F7                    1539 	.db	00137$
      001D66 F7                    1540 	.db	00137$
      001D67 F7                    1541 	.db	00137$
      001D68 F7                    1542 	.db	00137$
      001D69 F7                    1543 	.db	00137$
      001D6A F7                    1544 	.db	00137$
      001D6B E5                    1545 	.db	00135$
      001D6C EE                    1546 	.db	00136$
      001D6D                       1547 00147$:
      001D6D 1D                    1548 	.db	00101$>>8
      001D6E 1D                    1549 	.db	00102$>>8
      001D6F 1D                    1550 	.db	00103$>>8
      001D70 1D                    1551 	.db	00104$>>8
      001D71 1D                    1552 	.db	00105$>>8
      001D72 1D                    1553 	.db	00106$>>8
      001D73 1D                    1554 	.db	00107$>>8
      001D74 1D                    1555 	.db	00108$>>8
      001D75 1D                    1556 	.db	00109$>>8
      001D76 1D                    1557 	.db	00110$>>8
      001D77 1E                    1558 	.db	00111$>>8
      001D78 1E                    1559 	.db	00112$>>8
      001D79 1E                    1560 	.db	00113$>>8
      001D7A 1E                    1561 	.db	00114$>>8
      001D7B 1E                    1562 	.db	00115$>>8
      001D7C 1E                    1563 	.db	00116$>>8
      001D7D 1E                    1564 	.db	00117$>>8
      001D7E 1E                    1565 	.db	00118$>>8
      001D7F 1E                    1566 	.db	00119$>>8
      001D80 1E                    1567 	.db	00120$>>8
      001D81 1E                    1568 	.db	00121$>>8
      001D82 1E                    1569 	.db	00122$>>8
      001D83 1E                    1570 	.db	00123$>>8
      001D84 1E                    1571 	.db	00124$>>8
      001D85 1E                    1572 	.db	00125$>>8
      001D86 1E                    1573 	.db	00126$>>8
      001D87 1E                    1574 	.db	00127$>>8
      001D88 1E                    1575 	.db	00128$>>8
      001D89 1E                    1576 	.db	00129$>>8
      001D8A 1E                    1577 	.db	00130$>>8
      001D8B 1E                    1578 	.db	00131$>>8
      001D8C 1E                    1579 	.db	00132$>>8
      001D8D 1E                    1580 	.db	00137$>>8
      001D8E 1E                    1581 	.db	00137$>>8
      001D8F 1E                    1582 	.db	00137$>>8
      001D90 1E                    1583 	.db	00137$>>8
      001D91 1E                    1584 	.db	00133$>>8
      001D92 1E                    1585 	.db	00134$>>8
      001D93 1E                    1586 	.db	00137$>>8
      001D94 1E                    1587 	.db	00137$>>8
      001D95 1E                    1588 	.db	00137$>>8
      001D96 1E                    1589 	.db	00137$>>8
      001D97 1E                    1590 	.db	00137$>>8
      001D98 1E                    1591 	.db	00137$>>8
      001D99 1E                    1592 	.db	00137$>>8
      001D9A 1E                    1593 	.db	00135$>>8
      001D9B 1E                    1594 	.db	00136$>>8
                                   1595 ;	hardware.c:164: case 0x00:
      001D9C                       1596 00101$:
                                   1597 ;	hardware.c:165: SYNC1 = value;
      001D9C 78 5A            [12] 1598 	mov	r0,#_set_register_PARM_2
      001D9E 90 DF 00         [24] 1599 	mov	dptr,#_SYNC1
      001DA1 E2               [24] 1600 	movx	a,@r0
      001DA2 F0               [24] 1601 	movx	@dptr,a
                                   1602 ;	hardware.c:166: break;
      001DA3 02 1E F9         [24] 1603 	ljmp	00138$
                                   1604 ;	hardware.c:167: case 0x01:
      001DA6                       1605 00102$:
                                   1606 ;	hardware.c:168: SYNC0 = value;
      001DA6 78 5A            [12] 1607 	mov	r0,#_set_register_PARM_2
      001DA8 90 DF 01         [24] 1608 	mov	dptr,#_SYNC0
      001DAB E2               [24] 1609 	movx	a,@r0
      001DAC F0               [24] 1610 	movx	@dptr,a
                                   1611 ;	hardware.c:169: break;
      001DAD 02 1E F9         [24] 1612 	ljmp	00138$
                                   1613 ;	hardware.c:170: case 0x02:
      001DB0                       1614 00103$:
                                   1615 ;	hardware.c:171: PKTLEN = value;
      001DB0 78 5A            [12] 1616 	mov	r0,#_set_register_PARM_2
      001DB2 90 DF 02         [24] 1617 	mov	dptr,#_PKTLEN
      001DB5 E2               [24] 1618 	movx	a,@r0
      001DB6 F0               [24] 1619 	movx	@dptr,a
                                   1620 ;	hardware.c:172: break;
      001DB7 02 1E F9         [24] 1621 	ljmp	00138$
                                   1622 ;	hardware.c:173: case 0x03:
      001DBA                       1623 00104$:
                                   1624 ;	hardware.c:174: PKTCTRL1 = value;
      001DBA 78 5A            [12] 1625 	mov	r0,#_set_register_PARM_2
      001DBC 90 DF 03         [24] 1626 	mov	dptr,#_PKTCTRL1
      001DBF E2               [24] 1627 	movx	a,@r0
      001DC0 F0               [24] 1628 	movx	@dptr,a
                                   1629 ;	hardware.c:175: break;
      001DC1 02 1E F9         [24] 1630 	ljmp	00138$
                                   1631 ;	hardware.c:176: case 0x04:
      001DC4                       1632 00105$:
                                   1633 ;	hardware.c:177: PKTCTRL0 = value;
      001DC4 78 5A            [12] 1634 	mov	r0,#_set_register_PARM_2
      001DC6 90 DF 04         [24] 1635 	mov	dptr,#_PKTCTRL0
      001DC9 E2               [24] 1636 	movx	a,@r0
      001DCA F0               [24] 1637 	movx	@dptr,a
                                   1638 ;	hardware.c:178: break;
      001DCB 02 1E F9         [24] 1639 	ljmp	00138$
                                   1640 ;	hardware.c:179: case 0x05:
      001DCE                       1641 00106$:
                                   1642 ;	hardware.c:180: ADDR = value;
      001DCE 78 5A            [12] 1643 	mov	r0,#_set_register_PARM_2
      001DD0 90 DF 05         [24] 1644 	mov	dptr,#_ADDR
      001DD3 E2               [24] 1645 	movx	a,@r0
      001DD4 F0               [24] 1646 	movx	@dptr,a
                                   1647 ;	hardware.c:181: break;
      001DD5 02 1E F9         [24] 1648 	ljmp	00138$
                                   1649 ;	hardware.c:182: case 0x06:
      001DD8                       1650 00107$:
                                   1651 ;	hardware.c:183: CHANNR = value;
      001DD8 78 5A            [12] 1652 	mov	r0,#_set_register_PARM_2
      001DDA 90 DF 06         [24] 1653 	mov	dptr,#_CHANNR
      001DDD E2               [24] 1654 	movx	a,@r0
      001DDE F0               [24] 1655 	movx	@dptr,a
                                   1656 ;	hardware.c:184: break;
      001DDF 02 1E F9         [24] 1657 	ljmp	00138$
                                   1658 ;	hardware.c:185: case 0x07:
      001DE2                       1659 00108$:
                                   1660 ;	hardware.c:186: FSCTRL1 = value;
      001DE2 78 5A            [12] 1661 	mov	r0,#_set_register_PARM_2
      001DE4 90 DF 07         [24] 1662 	mov	dptr,#_FSCTRL1
      001DE7 E2               [24] 1663 	movx	a,@r0
      001DE8 F0               [24] 1664 	movx	@dptr,a
                                   1665 ;	hardware.c:187: break;
      001DE9 02 1E F9         [24] 1666 	ljmp	00138$
                                   1667 ;	hardware.c:188: case 0x08:
      001DEC                       1668 00109$:
                                   1669 ;	hardware.c:189: FSCTRL0 = value;
      001DEC 78 5A            [12] 1670 	mov	r0,#_set_register_PARM_2
      001DEE 90 DF 08         [24] 1671 	mov	dptr,#_FSCTRL0
      001DF1 E2               [24] 1672 	movx	a,@r0
      001DF2 F0               [24] 1673 	movx	@dptr,a
                                   1674 ;	hardware.c:190: break;
      001DF3 02 1E F9         [24] 1675 	ljmp	00138$
                                   1676 ;	hardware.c:191: case 0x09:
      001DF6                       1677 00110$:
                                   1678 ;	hardware.c:192: FREQ2 = value;
      001DF6 78 5A            [12] 1679 	mov	r0,#_set_register_PARM_2
      001DF8 90 DF 09         [24] 1680 	mov	dptr,#_FREQ2
      001DFB E2               [24] 1681 	movx	a,@r0
      001DFC F0               [24] 1682 	movx	@dptr,a
                                   1683 ;	hardware.c:193: break;
      001DFD 02 1E F9         [24] 1684 	ljmp	00138$
                                   1685 ;	hardware.c:194: case 0x0A:
      001E00                       1686 00111$:
                                   1687 ;	hardware.c:195: FREQ1 = value;
      001E00 78 5A            [12] 1688 	mov	r0,#_set_register_PARM_2
      001E02 90 DF 0A         [24] 1689 	mov	dptr,#_FREQ1
      001E05 E2               [24] 1690 	movx	a,@r0
      001E06 F0               [24] 1691 	movx	@dptr,a
                                   1692 ;	hardware.c:196: break;
      001E07 02 1E F9         [24] 1693 	ljmp	00138$
                                   1694 ;	hardware.c:197: case 0x0B:
      001E0A                       1695 00112$:
                                   1696 ;	hardware.c:198: FREQ0 = value;
      001E0A 78 5A            [12] 1697 	mov	r0,#_set_register_PARM_2
      001E0C 90 DF 0B         [24] 1698 	mov	dptr,#_FREQ0
      001E0F E2               [24] 1699 	movx	a,@r0
      001E10 F0               [24] 1700 	movx	@dptr,a
                                   1701 ;	hardware.c:199: break;
      001E11 02 1E F9         [24] 1702 	ljmp	00138$
                                   1703 ;	hardware.c:200: case 0x0C:
      001E14                       1704 00113$:
                                   1705 ;	hardware.c:201: MDMCFG4 = value;
      001E14 78 5A            [12] 1706 	mov	r0,#_set_register_PARM_2
      001E16 90 DF 0C         [24] 1707 	mov	dptr,#_MDMCFG4
      001E19 E2               [24] 1708 	movx	a,@r0
      001E1A F0               [24] 1709 	movx	@dptr,a
                                   1710 ;	hardware.c:202: break;
      001E1B 02 1E F9         [24] 1711 	ljmp	00138$
                                   1712 ;	hardware.c:203: case 0x0D:
      001E1E                       1713 00114$:
                                   1714 ;	hardware.c:204: MDMCFG3 = value;
      001E1E 78 5A            [12] 1715 	mov	r0,#_set_register_PARM_2
      001E20 90 DF 0D         [24] 1716 	mov	dptr,#_MDMCFG3
      001E23 E2               [24] 1717 	movx	a,@r0
      001E24 F0               [24] 1718 	movx	@dptr,a
                                   1719 ;	hardware.c:205: break;
      001E25 02 1E F9         [24] 1720 	ljmp	00138$
                                   1721 ;	hardware.c:206: case 0x0E:
      001E28                       1722 00115$:
                                   1723 ;	hardware.c:207: MDMCFG2 = value;
      001E28 78 5A            [12] 1724 	mov	r0,#_set_register_PARM_2
      001E2A 90 DF 0E         [24] 1725 	mov	dptr,#_MDMCFG2
      001E2D E2               [24] 1726 	movx	a,@r0
      001E2E F0               [24] 1727 	movx	@dptr,a
                                   1728 ;	hardware.c:208: break;
      001E2F 02 1E F9         [24] 1729 	ljmp	00138$
                                   1730 ;	hardware.c:209: case 0x0F:
      001E32                       1731 00116$:
                                   1732 ;	hardware.c:210: MDMCFG1 = value;
      001E32 78 5A            [12] 1733 	mov	r0,#_set_register_PARM_2
      001E34 90 DF 0F         [24] 1734 	mov	dptr,#_MDMCFG1
      001E37 E2               [24] 1735 	movx	a,@r0
      001E38 F0               [24] 1736 	movx	@dptr,a
                                   1737 ;	hardware.c:211: break;
      001E39 02 1E F9         [24] 1738 	ljmp	00138$
                                   1739 ;	hardware.c:212: case 0x10:
      001E3C                       1740 00117$:
                                   1741 ;	hardware.c:213: MDMCFG0 = value;
      001E3C 78 5A            [12] 1742 	mov	r0,#_set_register_PARM_2
      001E3E 90 DF 10         [24] 1743 	mov	dptr,#_MDMCFG0
      001E41 E2               [24] 1744 	movx	a,@r0
      001E42 F0               [24] 1745 	movx	@dptr,a
                                   1746 ;	hardware.c:214: break;
      001E43 02 1E F9         [24] 1747 	ljmp	00138$
                                   1748 ;	hardware.c:215: case 0x11:
      001E46                       1749 00118$:
                                   1750 ;	hardware.c:216: DEVIATN = value;
      001E46 78 5A            [12] 1751 	mov	r0,#_set_register_PARM_2
      001E48 90 DF 11         [24] 1752 	mov	dptr,#_DEVIATN
      001E4B E2               [24] 1753 	movx	a,@r0
      001E4C F0               [24] 1754 	movx	@dptr,a
                                   1755 ;	hardware.c:217: break;
      001E4D 02 1E F9         [24] 1756 	ljmp	00138$
                                   1757 ;	hardware.c:218: case 0x12:
      001E50                       1758 00119$:
                                   1759 ;	hardware.c:219: MCSM2 = value;
      001E50 78 5A            [12] 1760 	mov	r0,#_set_register_PARM_2
      001E52 90 DF 12         [24] 1761 	mov	dptr,#_MCSM2
      001E55 E2               [24] 1762 	movx	a,@r0
      001E56 F0               [24] 1763 	movx	@dptr,a
                                   1764 ;	hardware.c:220: break;
      001E57 02 1E F9         [24] 1765 	ljmp	00138$
                                   1766 ;	hardware.c:221: case 0x13:
      001E5A                       1767 00120$:
                                   1768 ;	hardware.c:222: MCSM1 = value;
      001E5A 78 5A            [12] 1769 	mov	r0,#_set_register_PARM_2
      001E5C 90 DF 13         [24] 1770 	mov	dptr,#_MCSM1
      001E5F E2               [24] 1771 	movx	a,@r0
      001E60 F0               [24] 1772 	movx	@dptr,a
                                   1773 ;	hardware.c:223: break;
      001E61 02 1E F9         [24] 1774 	ljmp	00138$
                                   1775 ;	hardware.c:224: case 0x14:
      001E64                       1776 00121$:
                                   1777 ;	hardware.c:225: MCSM0 = value;
      001E64 78 5A            [12] 1778 	mov	r0,#_set_register_PARM_2
      001E66 90 DF 14         [24] 1779 	mov	dptr,#_MCSM0
      001E69 E2               [24] 1780 	movx	a,@r0
      001E6A F0               [24] 1781 	movx	@dptr,a
                                   1782 ;	hardware.c:226: break;
      001E6B 02 1E F9         [24] 1783 	ljmp	00138$
                                   1784 ;	hardware.c:227: case 0x15:
      001E6E                       1785 00122$:
                                   1786 ;	hardware.c:228: FOCCFG = value;
      001E6E 78 5A            [12] 1787 	mov	r0,#_set_register_PARM_2
      001E70 90 DF 15         [24] 1788 	mov	dptr,#_FOCCFG
      001E73 E2               [24] 1789 	movx	a,@r0
      001E74 F0               [24] 1790 	movx	@dptr,a
                                   1791 ;	hardware.c:229: break;
      001E75 02 1E F9         [24] 1792 	ljmp	00138$
                                   1793 ;	hardware.c:230: case 0x16:
      001E78                       1794 00123$:
                                   1795 ;	hardware.c:231: BSCFG = value;
      001E78 78 5A            [12] 1796 	mov	r0,#_set_register_PARM_2
      001E7A 90 DF 16         [24] 1797 	mov	dptr,#_BSCFG
      001E7D E2               [24] 1798 	movx	a,@r0
      001E7E F0               [24] 1799 	movx	@dptr,a
                                   1800 ;	hardware.c:232: break;
      001E7F 02 1E F9         [24] 1801 	ljmp	00138$
                                   1802 ;	hardware.c:233: case 0x17:
      001E82                       1803 00124$:
                                   1804 ;	hardware.c:234: AGCCTRL2 = value;
      001E82 78 5A            [12] 1805 	mov	r0,#_set_register_PARM_2
      001E84 90 DF 17         [24] 1806 	mov	dptr,#_AGCCTRL2
      001E87 E2               [24] 1807 	movx	a,@r0
      001E88 F0               [24] 1808 	movx	@dptr,a
                                   1809 ;	hardware.c:235: break;
                                   1810 ;	hardware.c:236: case 0x18:
      001E89 80 6E            [24] 1811 	sjmp	00138$
      001E8B                       1812 00125$:
                                   1813 ;	hardware.c:237: AGCCTRL1= value;
      001E8B 78 5A            [12] 1814 	mov	r0,#_set_register_PARM_2
      001E8D 90 DF 18         [24] 1815 	mov	dptr,#_AGCCTRL1
      001E90 E2               [24] 1816 	movx	a,@r0
      001E91 F0               [24] 1817 	movx	@dptr,a
                                   1818 ;	hardware.c:238: break;
                                   1819 ;	hardware.c:239: case 0x19:
      001E92 80 65            [24] 1820 	sjmp	00138$
      001E94                       1821 00126$:
                                   1822 ;	hardware.c:240: AGCCTRL0 = value;
      001E94 78 5A            [12] 1823 	mov	r0,#_set_register_PARM_2
      001E96 90 DF 19         [24] 1824 	mov	dptr,#_AGCCTRL0
      001E99 E2               [24] 1825 	movx	a,@r0
      001E9A F0               [24] 1826 	movx	@dptr,a
                                   1827 ;	hardware.c:241: break;
                                   1828 ;	hardware.c:242: case 0x1A:
      001E9B 80 5C            [24] 1829 	sjmp	00138$
      001E9D                       1830 00127$:
                                   1831 ;	hardware.c:243: FREND1 = value;
      001E9D 78 5A            [12] 1832 	mov	r0,#_set_register_PARM_2
      001E9F 90 DF 1A         [24] 1833 	mov	dptr,#_FREND1
      001EA2 E2               [24] 1834 	movx	a,@r0
      001EA3 F0               [24] 1835 	movx	@dptr,a
                                   1836 ;	hardware.c:244: break;
                                   1837 ;	hardware.c:245: case 0x1B:
      001EA4 80 53            [24] 1838 	sjmp	00138$
      001EA6                       1839 00128$:
                                   1840 ;	hardware.c:246: FREND0 = value;
      001EA6 78 5A            [12] 1841 	mov	r0,#_set_register_PARM_2
      001EA8 90 DF 1B         [24] 1842 	mov	dptr,#_FREND0
      001EAB E2               [24] 1843 	movx	a,@r0
      001EAC F0               [24] 1844 	movx	@dptr,a
                                   1845 ;	hardware.c:247: break;
                                   1846 ;	hardware.c:248: case 0x1C:
      001EAD 80 4A            [24] 1847 	sjmp	00138$
      001EAF                       1848 00129$:
                                   1849 ;	hardware.c:249: FSCAL3 = value;
      001EAF 78 5A            [12] 1850 	mov	r0,#_set_register_PARM_2
      001EB1 90 DF 1C         [24] 1851 	mov	dptr,#_FSCAL3
      001EB4 E2               [24] 1852 	movx	a,@r0
      001EB5 F0               [24] 1853 	movx	@dptr,a
                                   1854 ;	hardware.c:250: break;
                                   1855 ;	hardware.c:251: case 0x1D:
      001EB6 80 41            [24] 1856 	sjmp	00138$
      001EB8                       1857 00130$:
                                   1858 ;	hardware.c:252: FSCAL2 = value;
      001EB8 78 5A            [12] 1859 	mov	r0,#_set_register_PARM_2
      001EBA 90 DF 1D         [24] 1860 	mov	dptr,#_FSCAL2
      001EBD E2               [24] 1861 	movx	a,@r0
      001EBE F0               [24] 1862 	movx	@dptr,a
                                   1863 ;	hardware.c:253: break;
                                   1864 ;	hardware.c:254: case 0x1E:
      001EBF 80 38            [24] 1865 	sjmp	00138$
      001EC1                       1866 00131$:
                                   1867 ;	hardware.c:255: FSCAL1 = value;
      001EC1 78 5A            [12] 1868 	mov	r0,#_set_register_PARM_2
      001EC3 90 DF 1E         [24] 1869 	mov	dptr,#_FSCAL1
      001EC6 E2               [24] 1870 	movx	a,@r0
      001EC7 F0               [24] 1871 	movx	@dptr,a
                                   1872 ;	hardware.c:256: break;
                                   1873 ;	hardware.c:257: case 0x1F:
      001EC8 80 2F            [24] 1874 	sjmp	00138$
      001ECA                       1875 00132$:
                                   1876 ;	hardware.c:258: FSCAL0 = value;
      001ECA 78 5A            [12] 1877 	mov	r0,#_set_register_PARM_2
      001ECC 90 DF 1F         [24] 1878 	mov	dptr,#_FSCAL0
      001ECF E2               [24] 1879 	movx	a,@r0
      001ED0 F0               [24] 1880 	movx	@dptr,a
                                   1881 ;	hardware.c:259: break;
                                   1882 ;	hardware.c:260: case 0x24:
      001ED1 80 26            [24] 1883 	sjmp	00138$
      001ED3                       1884 00133$:
                                   1885 ;	hardware.c:261: TEST1 = value;
      001ED3 78 5A            [12] 1886 	mov	r0,#_set_register_PARM_2
      001ED5 90 DF 24         [24] 1887 	mov	dptr,#_TEST1
      001ED8 E2               [24] 1888 	movx	a,@r0
      001ED9 F0               [24] 1889 	movx	@dptr,a
                                   1890 ;	hardware.c:262: break;
                                   1891 ;	hardware.c:263: case 0x25:
      001EDA 80 1D            [24] 1892 	sjmp	00138$
      001EDC                       1893 00134$:
                                   1894 ;	hardware.c:264: TEST0 = value;
      001EDC 78 5A            [12] 1895 	mov	r0,#_set_register_PARM_2
      001EDE 90 DF 25         [24] 1896 	mov	dptr,#_TEST0
      001EE1 E2               [24] 1897 	movx	a,@r0
      001EE2 F0               [24] 1898 	movx	@dptr,a
                                   1899 ;	hardware.c:265: break;
                                   1900 ;	hardware.c:266: case 0x2D:
      001EE3 80 14            [24] 1901 	sjmp	00138$
      001EE5                       1902 00135$:
                                   1903 ;	hardware.c:267: PA_TABLE1 = value;
      001EE5 78 5A            [12] 1904 	mov	r0,#_set_register_PARM_2
      001EE7 90 DF 2D         [24] 1905 	mov	dptr,#_PA_TABLE1
      001EEA E2               [24] 1906 	movx	a,@r0
      001EEB F0               [24] 1907 	movx	@dptr,a
                                   1908 ;	hardware.c:268: break;
                                   1909 ;	hardware.c:269: case 0x2E:
      001EEC 80 0B            [24] 1910 	sjmp	00138$
      001EEE                       1911 00136$:
                                   1912 ;	hardware.c:270: PA_TABLE0 = value;
      001EEE 78 5A            [12] 1913 	mov	r0,#_set_register_PARM_2
      001EF0 90 DF 2E         [24] 1914 	mov	dptr,#_PA_TABLE0
      001EF3 E2               [24] 1915 	movx	a,@r0
      001EF4 F0               [24] 1916 	movx	@dptr,a
                                   1917 ;	hardware.c:271: break;
                                   1918 ;	hardware.c:272: default:
      001EF5 80 02            [24] 1919 	sjmp	00138$
      001EF7                       1920 00137$:
                                   1921 ;	hardware.c:273: rval = RESPONSE_CODE_PARAM_ERROR;
      001EF7 7E 11            [12] 1922 	mov	r6,#0x11
                                   1923 ;	hardware.c:274: }
      001EF9                       1924 00138$:
                                   1925 ;	hardware.c:275: return rval;
      001EF9 8E 82            [24] 1926 	mov	dpl,r6
                                   1927 ;	hardware.c:276: }
      001EFB 22               [24] 1928 	ret
                                   1929 ;------------------------------------------------------------
                                   1930 ;Allocation info for local variables in function 'mode_registers_clear'
                                   1931 ;------------------------------------------------------------
                                   1932 ;	hardware.c:278: void mode_registers_clear(mode_registers *mode) {
                                   1933 ;	-----------------------------------------
                                   1934 ;	 function mode_registers_clear
                                   1935 ;	-----------------------------------------
      001EFC                       1936 _mode_registers_clear:
                                   1937 ;	hardware.c:279: mode->count = 0;
      001EFC E4               [12] 1938 	clr	a
                                   1939 ;	hardware.c:280: }
      001EFD 02 2D 8A         [24] 1940 	ljmp	__gptrput
                                   1941 ;------------------------------------------------------------
                                   1942 ;Allocation info for local variables in function 'mode_registers_add'
                                   1943 ;------------------------------------------------------------
                                   1944 ;	hardware.c:282: void mode_registers_add(mode_registers *mode, uint8_t addr, uint8_t value) {
                                   1945 ;	-----------------------------------------
                                   1946 ;	 function mode_registers_add
                                   1947 ;	-----------------------------------------
      001F00                       1948 _mode_registers_add:
      001F00 AF F0            [24] 1949 	mov	r7,b
      001F02 AE 83            [24] 1950 	mov	r6,dph
      001F04 E5 82            [12] 1951 	mov	a,dpl
      001F06 78 5D            [12] 1952 	mov	r0,#_mode_registers_add_mode_65536_39
      001F08 F2               [24] 1953 	movx	@r0,a
      001F09 08               [12] 1954 	inc	r0
      001F0A EE               [12] 1955 	mov	a,r6
      001F0B F2               [24] 1956 	movx	@r0,a
      001F0C 08               [12] 1957 	inc	r0
      001F0D EF               [12] 1958 	mov	a,r7
      001F0E F2               [24] 1959 	movx	@r0,a
                                   1960 ;	hardware.c:283: if (mode->count < MAX_MODE_REGISTERS - 1) {
      001F0F 78 5D            [12] 1961 	mov	r0,#_mode_registers_add_mode_65536_39
      001F11 E2               [24] 1962 	movx	a,@r0
      001F12 F5 82            [12] 1963 	mov	dpl,a
      001F14 08               [12] 1964 	inc	r0
      001F15 E2               [24] 1965 	movx	a,@r0
      001F16 F5 83            [12] 1966 	mov	dph,a
      001F18 08               [12] 1967 	inc	r0
      001F19 E2               [24] 1968 	movx	a,@r0
      001F1A F5 F0            [12] 1969 	mov	b,a
      001F1C 12 2E 55         [24] 1970 	lcall	__gptrget
      001F1F FC               [12] 1971 	mov	r4,a
      001F20 BC 07 00         [24] 1972 	cjne	r4,#0x07,00109$
      001F23                       1973 00109$:
      001F23 50 6F            [24] 1974 	jnc	00103$
                                   1975 ;	hardware.c:284: mode->registers[mode->count].addr = addr;
      001F25 78 5D            [12] 1976 	mov	r0,#_mode_registers_add_mode_65536_39
      001F27 E2               [24] 1977 	movx	a,@r0
      001F28 24 01            [12] 1978 	add	a,#0x01
      001F2A FA               [12] 1979 	mov	r2,a
      001F2B 08               [12] 1980 	inc	r0
      001F2C E2               [24] 1981 	movx	a,@r0
      001F2D 34 00            [12] 1982 	addc	a,#0x00
      001F2F FB               [12] 1983 	mov	r3,a
      001F30 08               [12] 1984 	inc	r0
      001F31 E2               [24] 1985 	movx	a,@r0
      001F32 FF               [12] 1986 	mov	r7,a
      001F33 EC               [12] 1987 	mov	a,r4
      001F34 2C               [12] 1988 	add	a,r4
      001F35 2A               [12] 1989 	add	a,r2
      001F36 FC               [12] 1990 	mov	r4,a
      001F37 E4               [12] 1991 	clr	a
      001F38 3B               [12] 1992 	addc	a,r3
      001F39 FE               [12] 1993 	mov	r6,a
      001F3A 8F 05            [24] 1994 	mov	ar5,r7
      001F3C 8C 82            [24] 1995 	mov	dpl,r4
      001F3E 8E 83            [24] 1996 	mov	dph,r6
      001F40 8D F0            [24] 1997 	mov	b,r5
      001F42 78 5B            [12] 1998 	mov	r0,#_mode_registers_add_PARM_2
      001F44 E2               [24] 1999 	movx	a,@r0
      001F45 12 2D 8A         [24] 2000 	lcall	__gptrput
                                   2001 ;	hardware.c:285: mode->registers[mode->count].value = value;
      001F48 78 5D            [12] 2002 	mov	r0,#_mode_registers_add_mode_65536_39
      001F4A E2               [24] 2003 	movx	a,@r0
      001F4B F5 82            [12] 2004 	mov	dpl,a
      001F4D 08               [12] 2005 	inc	r0
      001F4E E2               [24] 2006 	movx	a,@r0
      001F4F F5 83            [12] 2007 	mov	dph,a
      001F51 08               [12] 2008 	inc	r0
      001F52 E2               [24] 2009 	movx	a,@r0
      001F53 F5 F0            [12] 2010 	mov	b,a
      001F55 12 2E 55         [24] 2011 	lcall	__gptrget
      001F58 25 E0            [12] 2012 	add	a,acc
      001F5A FE               [12] 2013 	mov	r6,a
      001F5B 2A               [12] 2014 	add	a,r2
      001F5C FA               [12] 2015 	mov	r2,a
      001F5D E4               [12] 2016 	clr	a
      001F5E 3B               [12] 2017 	addc	a,r3
      001F5F FB               [12] 2018 	mov	r3,a
      001F60 0A               [12] 2019 	inc	r2
      001F61 BA 00 01         [24] 2020 	cjne	r2,#0x00,00111$
      001F64 0B               [12] 2021 	inc	r3
      001F65                       2022 00111$:
      001F65 8A 82            [24] 2023 	mov	dpl,r2
      001F67 8B 83            [24] 2024 	mov	dph,r3
      001F69 8F F0            [24] 2025 	mov	b,r7
      001F6B 78 5C            [12] 2026 	mov	r0,#_mode_registers_add_PARM_3
      001F6D E2               [24] 2027 	movx	a,@r0
      001F6E 12 2D 8A         [24] 2028 	lcall	__gptrput
                                   2029 ;	hardware.c:286: mode->count++;
      001F71 78 5D            [12] 2030 	mov	r0,#_mode_registers_add_mode_65536_39
      001F73 E2               [24] 2031 	movx	a,@r0
      001F74 F5 82            [12] 2032 	mov	dpl,a
      001F76 08               [12] 2033 	inc	r0
      001F77 E2               [24] 2034 	movx	a,@r0
      001F78 F5 83            [12] 2035 	mov	dph,a
      001F7A 08               [12] 2036 	inc	r0
      001F7B E2               [24] 2037 	movx	a,@r0
      001F7C F5 F0            [12] 2038 	mov	b,a
      001F7E 12 2E 55         [24] 2039 	lcall	__gptrget
      001F81 FF               [12] 2040 	mov	r7,a
      001F82 0F               [12] 2041 	inc	r7
      001F83 78 5D            [12] 2042 	mov	r0,#_mode_registers_add_mode_65536_39
      001F85 E2               [24] 2043 	movx	a,@r0
      001F86 F5 82            [12] 2044 	mov	dpl,a
      001F88 08               [12] 2045 	inc	r0
      001F89 E2               [24] 2046 	movx	a,@r0
      001F8A F5 83            [12] 2047 	mov	dph,a
      001F8C 08               [12] 2048 	inc	r0
      001F8D E2               [24] 2049 	movx	a,@r0
      001F8E F5 F0            [12] 2050 	mov	b,a
      001F90 EF               [12] 2051 	mov	a,r7
                                   2052 ;	hardware.c:288: }
      001F91 02 2D 8A         [24] 2053 	ljmp	__gptrput
      001F94                       2054 00103$:
      001F94 22               [24] 2055 	ret
                                   2056 ;------------------------------------------------------------
                                   2057 ;Allocation info for local variables in function 'mode_registers_enact'
                                   2058 ;------------------------------------------------------------
                                   2059 ;sloc0                     Allocated with name '_mode_registers_enact_sloc0_1_0'
                                   2060 ;sloc1                     Allocated with name '_mode_registers_enact_sloc1_1_0'
                                   2061 ;------------------------------------------------------------
                                   2062 ;	hardware.c:290: void mode_registers_enact(mode_registers const *mode) {
                                   2063 ;	-----------------------------------------
                                   2064 ;	 function mode_registers_enact
                                   2065 ;	-----------------------------------------
      001F95                       2066 _mode_registers_enact:
      001F95 AF F0            [24] 2067 	mov	r7,b
      001F97 AE 83            [24] 2068 	mov	r6,dph
      001F99 E5 82            [12] 2069 	mov	a,dpl
      001F9B 78 60            [12] 2070 	mov	r0,#_mode_registers_enact_mode_65536_42
      001F9D F2               [24] 2071 	movx	@r0,a
      001F9E 08               [12] 2072 	inc	r0
      001F9F EE               [12] 2073 	mov	a,r6
      001FA0 F2               [24] 2074 	movx	@r0,a
      001FA1 08               [12] 2075 	inc	r0
      001FA2 EF               [12] 2076 	mov	a,r7
      001FA3 F2               [24] 2077 	movx	@r0,a
                                   2078 ;	hardware.c:292: for (i=0; i<mode->count; i++) {
      001FA4 78 60            [12] 2079 	mov	r0,#_mode_registers_enact_mode_65536_42
      001FA6 E2               [24] 2080 	movx	a,@r0
      001FA7 24 01            [12] 2081 	add	a,#0x01
      001FA9 FA               [12] 2082 	mov	r2,a
      001FAA 08               [12] 2083 	inc	r0
      001FAB E2               [24] 2084 	movx	a,@r0
      001FAC 34 00            [12] 2085 	addc	a,#0x00
      001FAE FB               [12] 2086 	mov	r3,a
      001FAF 08               [12] 2087 	inc	r0
      001FB0 E2               [24] 2088 	movx	a,@r0
      001FB1 FC               [12] 2089 	mov	r4,a
      001FB2 78 63            [12] 2090 	mov	r0,#_mode_registers_enact_i_65536_43
      001FB4 E4               [12] 2091 	clr	a
      001FB5 F2               [24] 2092 	movx	@r0,a
      001FB6 08               [12] 2093 	inc	r0
      001FB7 F2               [24] 2094 	movx	@r0,a
      001FB8                       2095 00103$:
      001FB8 C0 02            [24] 2096 	push	ar2
      001FBA C0 03            [24] 2097 	push	ar3
      001FBC C0 04            [24] 2098 	push	ar4
      001FBE 78 60            [12] 2099 	mov	r0,#_mode_registers_enact_mode_65536_42
      001FC0 E2               [24] 2100 	movx	a,@r0
      001FC1 F5 82            [12] 2101 	mov	dpl,a
      001FC3 08               [12] 2102 	inc	r0
      001FC4 E2               [24] 2103 	movx	a,@r0
      001FC5 F5 83            [12] 2104 	mov	dph,a
      001FC7 08               [12] 2105 	inc	r0
      001FC8 E2               [24] 2106 	movx	a,@r0
      001FC9 F5 F0            [12] 2107 	mov	b,a
      001FCB 12 2E 55         [24] 2108 	lcall	__gptrget
      001FCE FC               [12] 2109 	mov	r4,a
      001FCF 7D 00            [12] 2110 	mov	r5,#0x00
      001FD1 78 63            [12] 2111 	mov	r0,#_mode_registers_enact_i_65536_43
      001FD3 C3               [12] 2112 	clr	c
      001FD4 E2               [24] 2113 	movx	a,@r0
      001FD5 9C               [12] 2114 	subb	a,r4
      001FD6 08               [12] 2115 	inc	r0
      001FD7 E2               [24] 2116 	movx	a,@r0
      001FD8 64 80            [12] 2117 	xrl	a,#0x80
      001FDA 8D F0            [24] 2118 	mov	b,r5
      001FDC 63 F0 80         [24] 2119 	xrl	b,#0x80
      001FDF 95 F0            [12] 2120 	subb	a,b
      001FE1 D0 04            [24] 2121 	pop	ar4
      001FE3 D0 03            [24] 2122 	pop	ar3
      001FE5 D0 02            [24] 2123 	pop	ar2
      001FE7 50 5C            [24] 2124 	jnc	00105$
                                   2125 ;	hardware.c:293: set_register(mode->registers[i].addr, mode->registers[i].value);
      001FE9 78 63            [12] 2126 	mov	r0,#_mode_registers_enact_i_65536_43
      001FEB E2               [24] 2127 	movx	a,@r0
      001FEC 25 E0            [12] 2128 	add	a,acc
      001FEE F5 15            [12] 2129 	mov	_mode_registers_enact_sloc0_1_0,a
      001FF0 08               [12] 2130 	inc	r0
      001FF1 E2               [24] 2131 	movx	a,@r0
      001FF2 33               [12] 2132 	rlc	a
      001FF3 F5 16            [12] 2133 	mov	(_mode_registers_enact_sloc0_1_0 + 1),a
      001FF5 E5 15            [12] 2134 	mov	a,_mode_registers_enact_sloc0_1_0
      001FF7 2A               [12] 2135 	add	a,r2
      001FF8 FD               [12] 2136 	mov	r5,a
      001FF9 E5 16            [12] 2137 	mov	a,(_mode_registers_enact_sloc0_1_0 + 1)
      001FFB 3B               [12] 2138 	addc	a,r3
      001FFC FE               [12] 2139 	mov	r6,a
      001FFD 8C 07            [24] 2140 	mov	ar7,r4
      001FFF 8D 82            [24] 2141 	mov	dpl,r5
      002001 8E 83            [24] 2142 	mov	dph,r6
      002003 8F F0            [24] 2143 	mov	b,r7
      002005 12 2E 55         [24] 2144 	lcall	__gptrget
      002008 F5 17            [12] 2145 	mov	_mode_registers_enact_sloc1_1_0,a
      00200A E5 15            [12] 2146 	mov	a,_mode_registers_enact_sloc0_1_0
      00200C 2A               [12] 2147 	add	a,r2
      00200D FD               [12] 2148 	mov	r5,a
      00200E E5 16            [12] 2149 	mov	a,(_mode_registers_enact_sloc0_1_0 + 1)
      002010 3B               [12] 2150 	addc	a,r3
      002011 FE               [12] 2151 	mov	r6,a
      002012 8C 07            [24] 2152 	mov	ar7,r4
      002014 0D               [12] 2153 	inc	r5
      002015 BD 00 01         [24] 2154 	cjne	r5,#0x00,00117$
      002018 0E               [12] 2155 	inc	r6
      002019                       2156 00117$:
      002019 8D 82            [24] 2157 	mov	dpl,r5
      00201B 8E 83            [24] 2158 	mov	dph,r6
      00201D 8F F0            [24] 2159 	mov	b,r7
      00201F 78 5A            [12] 2160 	mov	r0,#_set_register_PARM_2
      002021 12 2E 55         [24] 2161 	lcall	__gptrget
      002024 F2               [24] 2162 	movx	@r0,a
      002025 85 17 82         [24] 2163 	mov	dpl,_mode_registers_enact_sloc1_1_0
      002028 C0 04            [24] 2164 	push	ar4
      00202A C0 03            [24] 2165 	push	ar3
      00202C C0 02            [24] 2166 	push	ar2
      00202E 12 1D 24         [24] 2167 	lcall	_set_register
      002031 D0 02            [24] 2168 	pop	ar2
      002033 D0 03            [24] 2169 	pop	ar3
      002035 D0 04            [24] 2170 	pop	ar4
                                   2171 ;	hardware.c:292: for (i=0; i<mode->count; i++) {
      002037 78 63            [12] 2172 	mov	r0,#_mode_registers_enact_i_65536_43
      002039 E2               [24] 2173 	movx	a,@r0
      00203A 24 01            [12] 2174 	add	a,#0x01
      00203C F2               [24] 2175 	movx	@r0,a
      00203D 08               [12] 2176 	inc	r0
      00203E E2               [24] 2177 	movx	a,@r0
      00203F 34 00            [12] 2178 	addc	a,#0x00
      002041 F2               [24] 2179 	movx	@r0,a
      002042 02 1F B8         [24] 2180 	ljmp	00103$
      002045                       2181 00105$:
                                   2182 ;	hardware.c:295: }
      002045 22               [24] 2183 	ret
                                   2184 	.area CSEG    (CODE)
                                   2185 	.area CONST   (CODE)
                                   2186 	.area XINIT   (CODE)
                                   2187 	.area CABS    (ABS,CODE)
