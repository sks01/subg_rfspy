                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.0.2 #11662 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module timer
                                      6 	.optsdcc -mmcs51 --model-medium
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _t1_isr
                                     12 	.globl _MODE
                                     13 	.globl _RE
                                     14 	.globl _SLAVE
                                     15 	.globl _FE
                                     16 	.globl _ERR
                                     17 	.globl _RX_BYTE
                                     18 	.globl _TX_BYTE
                                     19 	.globl _ACTIVE
                                     20 	.globl _B_7
                                     21 	.globl _B_6
                                     22 	.globl _B_5
                                     23 	.globl _B_4
                                     24 	.globl _B_3
                                     25 	.globl _B_2
                                     26 	.globl _B_1
                                     27 	.globl _B_0
                                     28 	.globl _WDTIF
                                     29 	.globl _P1IF
                                     30 	.globl _UTX1IF
                                     31 	.globl _UTX0IF
                                     32 	.globl _P2IF
                                     33 	.globl _ACC_7
                                     34 	.globl _ACC_6
                                     35 	.globl _ACC_5
                                     36 	.globl _ACC_4
                                     37 	.globl _ACC_3
                                     38 	.globl _ACC_2
                                     39 	.globl _ACC_1
                                     40 	.globl _ACC_0
                                     41 	.globl _OVFIM
                                     42 	.globl _T4CH1IF
                                     43 	.globl _T4CH0IF
                                     44 	.globl _T4OVFIF
                                     45 	.globl _T3CH1IF
                                     46 	.globl _T3CH0IF
                                     47 	.globl _T3OVFIF
                                     48 	.globl _CY
                                     49 	.globl _AC
                                     50 	.globl _F0
                                     51 	.globl _RS1
                                     52 	.globl _RS0
                                     53 	.globl _OV
                                     54 	.globl _F1
                                     55 	.globl _P
                                     56 	.globl _STIF
                                     57 	.globl _P0IF
                                     58 	.globl _T4IF
                                     59 	.globl _T3IF
                                     60 	.globl _T2IF
                                     61 	.globl _T1IF
                                     62 	.globl _DMAIF
                                     63 	.globl _P0IE
                                     64 	.globl _T4IE
                                     65 	.globl _T3IE
                                     66 	.globl _T2IE
                                     67 	.globl _T1IE
                                     68 	.globl _DMAIE
                                     69 	.globl _EA
                                     70 	.globl _STIE
                                     71 	.globl _ENCIE
                                     72 	.globl _URX1IE
                                     73 	.globl _URX0IE
                                     74 	.globl _ADCIE
                                     75 	.globl _RFTXRXIE
                                     76 	.globl _P2_7
                                     77 	.globl _P2_6
                                     78 	.globl _P2_5
                                     79 	.globl _P2_4
                                     80 	.globl _P2_3
                                     81 	.globl _P2_2
                                     82 	.globl _P2_1
                                     83 	.globl _P2_0
                                     84 	.globl _ENCIF_1
                                     85 	.globl _ENCIF_0
                                     86 	.globl _P1_7
                                     87 	.globl _P1_6
                                     88 	.globl _P1_5
                                     89 	.globl _P1_4
                                     90 	.globl _P1_3
                                     91 	.globl _P1_2
                                     92 	.globl _P1_1
                                     93 	.globl _P1_0
                                     94 	.globl _URX1IF
                                     95 	.globl _ADCIF
                                     96 	.globl _URX0IF
                                     97 	.globl _IT1
                                     98 	.globl _RFTXRXIF
                                     99 	.globl _IT0
                                    100 	.globl _P0_7
                                    101 	.globl _P0_6
                                    102 	.globl _P0_5
                                    103 	.globl _P0_4
                                    104 	.globl _P0_3
                                    105 	.globl _P0_2
                                    106 	.globl _P0_1
                                    107 	.globl _P0_0
                                    108 	.globl _P2DIR
                                    109 	.globl _P1DIR
                                    110 	.globl _P0DIR
                                    111 	.globl _U1GCR
                                    112 	.globl _U1UCR
                                    113 	.globl _U1BAUD
                                    114 	.globl _U1DBUF
                                    115 	.globl _U1CSR
                                    116 	.globl _P2INP
                                    117 	.globl _P1INP
                                    118 	.globl _P2SEL
                                    119 	.globl _P1SEL
                                    120 	.globl _P0SEL
                                    121 	.globl _ADCCFG
                                    122 	.globl _PERCFG
                                    123 	.globl _B
                                    124 	.globl _T4CC1
                                    125 	.globl _T4CCTL1
                                    126 	.globl _T4CC0
                                    127 	.globl _T4CCTL0
                                    128 	.globl _T4CTL
                                    129 	.globl _T4CNT
                                    130 	.globl _RFIF
                                    131 	.globl _IRCON2
                                    132 	.globl _T1CCTL2
                                    133 	.globl _T1CCTL1
                                    134 	.globl _T1CCTL0
                                    135 	.globl _T1CTL
                                    136 	.globl _T1CNTH
                                    137 	.globl _T1CNTL
                                    138 	.globl _RFST
                                    139 	.globl _ACC
                                    140 	.globl _T1CC2H
                                    141 	.globl _T1CC2L
                                    142 	.globl _T1CC1H
                                    143 	.globl _T1CC1L
                                    144 	.globl _T1CC0H
                                    145 	.globl _T1CC0L
                                    146 	.globl _RFD
                                    147 	.globl _TIMIF
                                    148 	.globl _DMAREQ
                                    149 	.globl _DMAARM
                                    150 	.globl _DMA0CFGH
                                    151 	.globl _DMA0CFGL
                                    152 	.globl _DMA1CFGH
                                    153 	.globl _DMA1CFGL
                                    154 	.globl _DMAIRQ
                                    155 	.globl _PSW
                                    156 	.globl _T3CC1
                                    157 	.globl _T3CCTL1
                                    158 	.globl _T3CC0
                                    159 	.globl _T3CCTL0
                                    160 	.globl _T3CTL
                                    161 	.globl _T3CNT
                                    162 	.globl _WDCTL
                                    163 	.globl __SFRC8
                                    164 	.globl _MEMCTR
                                    165 	.globl _CLKCON
                                    166 	.globl _U0GCR
                                    167 	.globl _U0UCR
                                    168 	.globl __SFRC3
                                    169 	.globl _U0BAUD
                                    170 	.globl _U0DBUF
                                    171 	.globl _IRCON
                                    172 	.globl __SFRBF
                                    173 	.globl _SLEEP
                                    174 	.globl _RNDH
                                    175 	.globl _RNDL
                                    176 	.globl _ADCH
                                    177 	.globl _ADCL
                                    178 	.globl _IP1
                                    179 	.globl _IEN1
                                    180 	.globl __SFRB7
                                    181 	.globl _ADCCON3
                                    182 	.globl _ADCCON2
                                    183 	.globl _ADCCON1
                                    184 	.globl _ENCCS
                                    185 	.globl _ENCDO
                                    186 	.globl _ENCDI
                                    187 	.globl __SFRB0
                                    188 	.globl _FWDATA
                                    189 	.globl _FCTL
                                    190 	.globl _FADDRH
                                    191 	.globl _FADDRL
                                    192 	.globl _FWT
                                    193 	.globl __SFRAA
                                    194 	.globl _IP0
                                    195 	.globl _IEN0
                                    196 	.globl __SFRA7
                                    197 	.globl _WORTIME1
                                    198 	.globl _WORTIME0
                                    199 	.globl _WOREVT1
                                    200 	.globl _WOREVT0
                                    201 	.globl _WORCTRL
                                    202 	.globl _WORIRQ
                                    203 	.globl _P2
                                    204 	.globl __SFR9F
                                    205 	.globl _T2CTL
                                    206 	.globl _T2PR
                                    207 	.globl _T2CT
                                    208 	.globl _S1CON
                                    209 	.globl _IEN2
                                    210 	.globl __SFR99
                                    211 	.globl _S0CON
                                    212 	.globl __SFR97
                                    213 	.globl __SFR96
                                    214 	.globl __SFR95
                                    215 	.globl __SFR94
                                    216 	.globl __XPAGE
                                    217 	.globl _MPAGE
                                    218 	.globl _DPS
                                    219 	.globl _RFIM
                                    220 	.globl _P1
                                    221 	.globl _P0INP
                                    222 	.globl __SFR8E
                                    223 	.globl _P1IEN
                                    224 	.globl _PICTL
                                    225 	.globl _P2IFG
                                    226 	.globl _P1IFG
                                    227 	.globl _P0IFG
                                    228 	.globl _TCON
                                    229 	.globl _PCON
                                    230 	.globl _U0CSR
                                    231 	.globl _DPH1
                                    232 	.globl _DPL1
                                    233 	.globl _DPH0
                                    234 	.globl _DPL0
                                    235 	.globl _SP
                                    236 	.globl _P0
                                    237 	.globl _X_P2DIR
                                    238 	.globl _X_P1DIR
                                    239 	.globl _X_P0DIR
                                    240 	.globl _X_U1GCR
                                    241 	.globl _X_U1UCR
                                    242 	.globl _X_U1BAUD
                                    243 	.globl _X_U1DBUF
                                    244 	.globl _X_U1CSR
                                    245 	.globl _X_P2INP
                                    246 	.globl _X_P1INP
                                    247 	.globl _X_P2SEL
                                    248 	.globl _X_P1SEL
                                    249 	.globl _X_P0SEL
                                    250 	.globl _X_ADCCFG
                                    251 	.globl _X_PERCFG
                                    252 	.globl __NA_B
                                    253 	.globl _X_T4CC1
                                    254 	.globl _X_T4CCTL1
                                    255 	.globl _X_T4CC0
                                    256 	.globl _X_T4CCTL0
                                    257 	.globl _X_T4CTL
                                    258 	.globl _X_T4CNT
                                    259 	.globl _X_RFIF
                                    260 	.globl __NA_IRCON2
                                    261 	.globl _X_T1CCTL2
                                    262 	.globl _X_T1CCTL1
                                    263 	.globl _X_T1CCTL0
                                    264 	.globl _X_T1CTL
                                    265 	.globl _X_T1CNTH
                                    266 	.globl _X_T1CNTL
                                    267 	.globl _X_RFST
                                    268 	.globl __NA_ACC
                                    269 	.globl _X_T1CC2H
                                    270 	.globl _X_T1CC2L
                                    271 	.globl _X_T1CC1H
                                    272 	.globl _X_T1CC1L
                                    273 	.globl _X_T1CC0H
                                    274 	.globl _X_T1CC0L
                                    275 	.globl _X_RFD
                                    276 	.globl _X_TIMIF
                                    277 	.globl _X_DMAREQ
                                    278 	.globl _X_DMAARM
                                    279 	.globl _X_DMA0CFGH
                                    280 	.globl _X_DMA0CFGL
                                    281 	.globl _X_DMA1CFGH
                                    282 	.globl _X_DMA1CFGL
                                    283 	.globl _X_DMAIRQ
                                    284 	.globl __NA_PSW
                                    285 	.globl _X_T3CC1
                                    286 	.globl _X_T3CCTL1
                                    287 	.globl _X_T3CC0
                                    288 	.globl _X_T3CCTL0
                                    289 	.globl _X_T3CTL
                                    290 	.globl _X_T3CNT
                                    291 	.globl _X_WDCTL
                                    292 	.globl __X_SFRC8
                                    293 	.globl _X_MEMCTR
                                    294 	.globl _X_CLKCON
                                    295 	.globl _X_U0GCR
                                    296 	.globl _X_U0UCR
                                    297 	.globl __X_SFRC3
                                    298 	.globl _X_U0BAUD
                                    299 	.globl _X_U0DBUF
                                    300 	.globl __NA_IRCON
                                    301 	.globl __X_SFRBF
                                    302 	.globl _X_SLEEP
                                    303 	.globl _X_RNDH
                                    304 	.globl _X_RNDL
                                    305 	.globl _X_ADCH
                                    306 	.globl _X_ADCL
                                    307 	.globl __NA_IP1
                                    308 	.globl __NA_IEN1
                                    309 	.globl __X_SFRB7
                                    310 	.globl _X_ADCCON3
                                    311 	.globl _X_ADCCON2
                                    312 	.globl _X_ADCCON1
                                    313 	.globl _X_ENCCS
                                    314 	.globl _X_ENCDO
                                    315 	.globl _X_ENCDI
                                    316 	.globl __X_SFRB0
                                    317 	.globl _X_FWDATA
                                    318 	.globl _X_FCTL
                                    319 	.globl _X_FADDRH
                                    320 	.globl _X_FADDRL
                                    321 	.globl _X_FWT
                                    322 	.globl __X_SFRAA
                                    323 	.globl __NA_IP0
                                    324 	.globl __NA_IEN0
                                    325 	.globl __X_SFRA7
                                    326 	.globl _X_WORTIME1
                                    327 	.globl _X_WORTIME0
                                    328 	.globl _X_WOREVT1
                                    329 	.globl _X_WOREVT0
                                    330 	.globl _X_WORCTRL
                                    331 	.globl _X_WORIRQ
                                    332 	.globl __NA_P2
                                    333 	.globl __X_SFR9F
                                    334 	.globl _X_T2CTL
                                    335 	.globl _X_T2PR
                                    336 	.globl _X_T2CT
                                    337 	.globl __NA_S1CON
                                    338 	.globl __NA_IEN2
                                    339 	.globl __X_SFR99
                                    340 	.globl __NA_S0CON
                                    341 	.globl __X_SFR97
                                    342 	.globl __X_SFR96
                                    343 	.globl __X_SFR95
                                    344 	.globl __X_SFR94
                                    345 	.globl _X_MPAGE
                                    346 	.globl __NA_DPS
                                    347 	.globl _X_RFIM
                                    348 	.globl __NA_P1
                                    349 	.globl _X_P0INP
                                    350 	.globl __X_SFR8E
                                    351 	.globl _X_P1IEN
                                    352 	.globl _X_PICTL
                                    353 	.globl _X_P2IFG
                                    354 	.globl _X_P1IFG
                                    355 	.globl _X_P0IFG
                                    356 	.globl __NA_TCON
                                    357 	.globl __NA_PCON
                                    358 	.globl _X_U0CSR
                                    359 	.globl __NA_DPH1
                                    360 	.globl __NA_DPL1
                                    361 	.globl __NA_DPH0
                                    362 	.globl __NA_DPL0
                                    363 	.globl __NA_SP
                                    364 	.globl __NA_P0
                                    365 	.globl _I2SCLKF2
                                    366 	.globl _I2SCLKF1
                                    367 	.globl _I2SCLKF0
                                    368 	.globl _I2SSTAT
                                    369 	.globl _I2SWCNT
                                    370 	.globl _I2SDATH
                                    371 	.globl _I2SDATL
                                    372 	.globl _I2SCFG1
                                    373 	.globl _I2SCFG0
                                    374 	.globl _VCO_VC_DAC
                                    375 	.globl _PKTSTATUS
                                    376 	.globl _MARCSTATE
                                    377 	.globl _RSSI
                                    378 	.globl _LQI
                                    379 	.globl _FREQEST
                                    380 	.globl _VERSION
                                    381 	.globl _PARTNUM
                                    382 	.globl __XREGDF35
                                    383 	.globl __XREGDF34
                                    384 	.globl __XREGDF33
                                    385 	.globl __XREGDF32
                                    386 	.globl _IOCFG0
                                    387 	.globl _IOCFG1
                                    388 	.globl _IOCFG2
                                    389 	.globl _PA_TABLE0
                                    390 	.globl _PA_TABLE1
                                    391 	.globl _PA_TABLE2
                                    392 	.globl _PA_TABLE3
                                    393 	.globl _PA_TABLE4
                                    394 	.globl _PA_TABLE5
                                    395 	.globl _PA_TABLE6
                                    396 	.globl _PA_TABLE7
                                    397 	.globl __XREGDF26
                                    398 	.globl _TEST0
                                    399 	.globl _TEST1
                                    400 	.globl _TEST2
                                    401 	.globl __XREGDF22
                                    402 	.globl __XREGDF21
                                    403 	.globl __XREGDF20
                                    404 	.globl _FSCAL0
                                    405 	.globl _FSCAL1
                                    406 	.globl _FSCAL2
                                    407 	.globl _FSCAL3
                                    408 	.globl _FREND0
                                    409 	.globl _FREND1
                                    410 	.globl _AGCCTRL0
                                    411 	.globl _AGCCTRL1
                                    412 	.globl _AGCCTRL2
                                    413 	.globl _BSCFG
                                    414 	.globl _FOCCFG
                                    415 	.globl _MCSM0
                                    416 	.globl _MCSM1
                                    417 	.globl _MCSM2
                                    418 	.globl _DEVIATN
                                    419 	.globl _MDMCFG0
                                    420 	.globl _MDMCFG1
                                    421 	.globl _MDMCFG2
                                    422 	.globl _MDMCFG3
                                    423 	.globl _MDMCFG4
                                    424 	.globl _FREQ0
                                    425 	.globl _FREQ1
                                    426 	.globl _FREQ2
                                    427 	.globl _FSCTRL0
                                    428 	.globl _FSCTRL1
                                    429 	.globl _CHANNR
                                    430 	.globl _ADDR
                                    431 	.globl _PKTCTRL0
                                    432 	.globl _PKTCTRL1
                                    433 	.globl _PKTLEN
                                    434 	.globl _SYNC0
                                    435 	.globl _SYNC1
                                    436 	.globl _MDMCTRL0H
                                    437 	.globl ___timerCounter
                                    438 	.globl _init_timer
                                    439 	.globl _delay
                                    440 ;--------------------------------------------------------
                                    441 ; special function registers
                                    442 ;--------------------------------------------------------
                                    443 	.area RSEG    (ABS,DATA)
      000000                        444 	.org 0x0000
                           000080   445 _P0	=	0x0080
                           000081   446 _SP	=	0x0081
                           000082   447 _DPL0	=	0x0082
                           000083   448 _DPH0	=	0x0083
                           000084   449 _DPL1	=	0x0084
                           000085   450 _DPH1	=	0x0085
                           000086   451 _U0CSR	=	0x0086
                           000087   452 _PCON	=	0x0087
                           000088   453 _TCON	=	0x0088
                           000089   454 _P0IFG	=	0x0089
                           00008A   455 _P1IFG	=	0x008a
                           00008B   456 _P2IFG	=	0x008b
                           00008C   457 _PICTL	=	0x008c
                           00008D   458 _P1IEN	=	0x008d
                           00008E   459 __SFR8E	=	0x008e
                           00008F   460 _P0INP	=	0x008f
                           000090   461 _P1	=	0x0090
                           000091   462 _RFIM	=	0x0091
                           000092   463 _DPS	=	0x0092
                           000093   464 _MPAGE	=	0x0093
                           000093   465 __XPAGE	=	0x0093
                           000094   466 __SFR94	=	0x0094
                           000095   467 __SFR95	=	0x0095
                           000096   468 __SFR96	=	0x0096
                           000097   469 __SFR97	=	0x0097
                           000098   470 _S0CON	=	0x0098
                           000099   471 __SFR99	=	0x0099
                           00009A   472 _IEN2	=	0x009a
                           00009B   473 _S1CON	=	0x009b
                           00009C   474 _T2CT	=	0x009c
                           00009D   475 _T2PR	=	0x009d
                           00009E   476 _T2CTL	=	0x009e
                           00009F   477 __SFR9F	=	0x009f
                           0000A0   478 _P2	=	0x00a0
                           0000A1   479 _WORIRQ	=	0x00a1
                           0000A2   480 _WORCTRL	=	0x00a2
                           0000A3   481 _WOREVT0	=	0x00a3
                           0000A4   482 _WOREVT1	=	0x00a4
                           0000A5   483 _WORTIME0	=	0x00a5
                           0000A6   484 _WORTIME1	=	0x00a6
                           0000A7   485 __SFRA7	=	0x00a7
                           0000A8   486 _IEN0	=	0x00a8
                           0000A9   487 _IP0	=	0x00a9
                           0000AA   488 __SFRAA	=	0x00aa
                           0000AB   489 _FWT	=	0x00ab
                           0000AC   490 _FADDRL	=	0x00ac
                           0000AD   491 _FADDRH	=	0x00ad
                           0000AE   492 _FCTL	=	0x00ae
                           0000AF   493 _FWDATA	=	0x00af
                           0000B0   494 __SFRB0	=	0x00b0
                           0000B1   495 _ENCDI	=	0x00b1
                           0000B2   496 _ENCDO	=	0x00b2
                           0000B3   497 _ENCCS	=	0x00b3
                           0000B4   498 _ADCCON1	=	0x00b4
                           0000B5   499 _ADCCON2	=	0x00b5
                           0000B6   500 _ADCCON3	=	0x00b6
                           0000B7   501 __SFRB7	=	0x00b7
                           0000B8   502 _IEN1	=	0x00b8
                           0000B9   503 _IP1	=	0x00b9
                           0000BA   504 _ADCL	=	0x00ba
                           0000BB   505 _ADCH	=	0x00bb
                           0000BC   506 _RNDL	=	0x00bc
                           0000BD   507 _RNDH	=	0x00bd
                           0000BE   508 _SLEEP	=	0x00be
                           0000BF   509 __SFRBF	=	0x00bf
                           0000C0   510 _IRCON	=	0x00c0
                           0000C1   511 _U0DBUF	=	0x00c1
                           0000C2   512 _U0BAUD	=	0x00c2
                           0000C3   513 __SFRC3	=	0x00c3
                           0000C4   514 _U0UCR	=	0x00c4
                           0000C5   515 _U0GCR	=	0x00c5
                           0000C6   516 _CLKCON	=	0x00c6
                           0000C7   517 _MEMCTR	=	0x00c7
                           0000C8   518 __SFRC8	=	0x00c8
                           0000C9   519 _WDCTL	=	0x00c9
                           0000CA   520 _T3CNT	=	0x00ca
                           0000CB   521 _T3CTL	=	0x00cb
                           0000CC   522 _T3CCTL0	=	0x00cc
                           0000CD   523 _T3CC0	=	0x00cd
                           0000CE   524 _T3CCTL1	=	0x00ce
                           0000CF   525 _T3CC1	=	0x00cf
                           0000D0   526 _PSW	=	0x00d0
                           0000D1   527 _DMAIRQ	=	0x00d1
                           0000D2   528 _DMA1CFGL	=	0x00d2
                           0000D3   529 _DMA1CFGH	=	0x00d3
                           0000D4   530 _DMA0CFGL	=	0x00d4
                           0000D5   531 _DMA0CFGH	=	0x00d5
                           0000D6   532 _DMAARM	=	0x00d6
                           0000D7   533 _DMAREQ	=	0x00d7
                           0000D8   534 _TIMIF	=	0x00d8
                           0000D9   535 _RFD	=	0x00d9
                           0000DA   536 _T1CC0L	=	0x00da
                           0000DB   537 _T1CC0H	=	0x00db
                           0000DC   538 _T1CC1L	=	0x00dc
                           0000DD   539 _T1CC1H	=	0x00dd
                           0000DE   540 _T1CC2L	=	0x00de
                           0000DF   541 _T1CC2H	=	0x00df
                           0000E0   542 _ACC	=	0x00e0
                           0000E1   543 _RFST	=	0x00e1
                           0000E2   544 _T1CNTL	=	0x00e2
                           0000E3   545 _T1CNTH	=	0x00e3
                           0000E4   546 _T1CTL	=	0x00e4
                           0000E5   547 _T1CCTL0	=	0x00e5
                           0000E6   548 _T1CCTL1	=	0x00e6
                           0000E7   549 _T1CCTL2	=	0x00e7
                           0000E8   550 _IRCON2	=	0x00e8
                           0000E9   551 _RFIF	=	0x00e9
                           0000EA   552 _T4CNT	=	0x00ea
                           0000EB   553 _T4CTL	=	0x00eb
                           0000EC   554 _T4CCTL0	=	0x00ec
                           0000ED   555 _T4CC0	=	0x00ed
                           0000EE   556 _T4CCTL1	=	0x00ee
                           0000EF   557 _T4CC1	=	0x00ef
                           0000F0   558 _B	=	0x00f0
                           0000F1   559 _PERCFG	=	0x00f1
                           0000F2   560 _ADCCFG	=	0x00f2
                           0000F3   561 _P0SEL	=	0x00f3
                           0000F4   562 _P1SEL	=	0x00f4
                           0000F5   563 _P2SEL	=	0x00f5
                           0000F6   564 _P1INP	=	0x00f6
                           0000F7   565 _P2INP	=	0x00f7
                           0000F8   566 _U1CSR	=	0x00f8
                           0000F9   567 _U1DBUF	=	0x00f9
                           0000FA   568 _U1BAUD	=	0x00fa
                           0000FB   569 _U1UCR	=	0x00fb
                           0000FC   570 _U1GCR	=	0x00fc
                           0000FD   571 _P0DIR	=	0x00fd
                           0000FE   572 _P1DIR	=	0x00fe
                           0000FF   573 _P2DIR	=	0x00ff
                                    574 ;--------------------------------------------------------
                                    575 ; special function bits
                                    576 ;--------------------------------------------------------
                                    577 	.area RSEG    (ABS,DATA)
      000000                        578 	.org 0x0000
                           000080   579 _P0_0	=	0x0080
                           000081   580 _P0_1	=	0x0081
                           000082   581 _P0_2	=	0x0082
                           000083   582 _P0_3	=	0x0083
                           000084   583 _P0_4	=	0x0084
                           000085   584 _P0_5	=	0x0085
                           000086   585 _P0_6	=	0x0086
                           000087   586 _P0_7	=	0x0087
                           000088   587 _IT0	=	0x0088
                           000089   588 _RFTXRXIF	=	0x0089
                           00008A   589 _IT1	=	0x008a
                           00008B   590 _URX0IF	=	0x008b
                           00008D   591 _ADCIF	=	0x008d
                           00008F   592 _URX1IF	=	0x008f
                           000090   593 _P1_0	=	0x0090
                           000091   594 _P1_1	=	0x0091
                           000092   595 _P1_2	=	0x0092
                           000093   596 _P1_3	=	0x0093
                           000094   597 _P1_4	=	0x0094
                           000095   598 _P1_5	=	0x0095
                           000096   599 _P1_6	=	0x0096
                           000097   600 _P1_7	=	0x0097
                           000098   601 _ENCIF_0	=	0x0098
                           000099   602 _ENCIF_1	=	0x0099
                           0000A0   603 _P2_0	=	0x00a0
                           0000A1   604 _P2_1	=	0x00a1
                           0000A2   605 _P2_2	=	0x00a2
                           0000A3   606 _P2_3	=	0x00a3
                           0000A4   607 _P2_4	=	0x00a4
                           0000A5   608 _P2_5	=	0x00a5
                           0000A6   609 _P2_6	=	0x00a6
                           0000A7   610 _P2_7	=	0x00a7
                           0000A8   611 _RFTXRXIE	=	0x00a8
                           0000A9   612 _ADCIE	=	0x00a9
                           0000AA   613 _URX0IE	=	0x00aa
                           0000AB   614 _URX1IE	=	0x00ab
                           0000AC   615 _ENCIE	=	0x00ac
                           0000AD   616 _STIE	=	0x00ad
                           0000AF   617 _EA	=	0x00af
                           0000B8   618 _DMAIE	=	0x00b8
                           0000B9   619 _T1IE	=	0x00b9
                           0000BA   620 _T2IE	=	0x00ba
                           0000BB   621 _T3IE	=	0x00bb
                           0000BC   622 _T4IE	=	0x00bc
                           0000BD   623 _P0IE	=	0x00bd
                           0000C0   624 _DMAIF	=	0x00c0
                           0000C1   625 _T1IF	=	0x00c1
                           0000C2   626 _T2IF	=	0x00c2
                           0000C3   627 _T3IF	=	0x00c3
                           0000C4   628 _T4IF	=	0x00c4
                           0000C5   629 _P0IF	=	0x00c5
                           0000C7   630 _STIF	=	0x00c7
                           0000D0   631 _P	=	0x00d0
                           0000D1   632 _F1	=	0x00d1
                           0000D2   633 _OV	=	0x00d2
                           0000D3   634 _RS0	=	0x00d3
                           0000D4   635 _RS1	=	0x00d4
                           0000D5   636 _F0	=	0x00d5
                           0000D6   637 _AC	=	0x00d6
                           0000D7   638 _CY	=	0x00d7
                           0000D8   639 _T3OVFIF	=	0x00d8
                           0000D9   640 _T3CH0IF	=	0x00d9
                           0000DA   641 _T3CH1IF	=	0x00da
                           0000DB   642 _T4OVFIF	=	0x00db
                           0000DC   643 _T4CH0IF	=	0x00dc
                           0000DD   644 _T4CH1IF	=	0x00dd
                           0000DE   645 _OVFIM	=	0x00de
                           0000E0   646 _ACC_0	=	0x00e0
                           0000E1   647 _ACC_1	=	0x00e1
                           0000E2   648 _ACC_2	=	0x00e2
                           0000E3   649 _ACC_3	=	0x00e3
                           0000E4   650 _ACC_4	=	0x00e4
                           0000E5   651 _ACC_5	=	0x00e5
                           0000E6   652 _ACC_6	=	0x00e6
                           0000E7   653 _ACC_7	=	0x00e7
                           0000E8   654 _P2IF	=	0x00e8
                           0000E9   655 _UTX0IF	=	0x00e9
                           0000EA   656 _UTX1IF	=	0x00ea
                           0000EB   657 _P1IF	=	0x00eb
                           0000EC   658 _WDTIF	=	0x00ec
                           0000F0   659 _B_0	=	0x00f0
                           0000F1   660 _B_1	=	0x00f1
                           0000F2   661 _B_2	=	0x00f2
                           0000F3   662 _B_3	=	0x00f3
                           0000F4   663 _B_4	=	0x00f4
                           0000F5   664 _B_5	=	0x00f5
                           0000F6   665 _B_6	=	0x00f6
                           0000F7   666 _B_7	=	0x00f7
                           0000F8   667 _ACTIVE	=	0x00f8
                           0000F9   668 _TX_BYTE	=	0x00f9
                           0000FA   669 _RX_BYTE	=	0x00fa
                           0000FB   670 _ERR	=	0x00fb
                           0000FC   671 _FE	=	0x00fc
                           0000FD   672 _SLAVE	=	0x00fd
                           0000FE   673 _RE	=	0x00fe
                           0000FF   674 _MODE	=	0x00ff
                                    675 ;--------------------------------------------------------
                                    676 ; overlayable register banks
                                    677 ;--------------------------------------------------------
                                    678 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        679 	.ds 8
                                    680 ;--------------------------------------------------------
                                    681 ; internal ram data
                                    682 ;--------------------------------------------------------
                                    683 	.area DSEG    (DATA)
                                    684 ;--------------------------------------------------------
                                    685 ; overlayable items in internal ram 
                                    686 ;--------------------------------------------------------
                                    687 ;--------------------------------------------------------
                                    688 ; indirectly addressable internal ram data
                                    689 ;--------------------------------------------------------
                                    690 	.area ISEG    (DATA)
                                    691 ;--------------------------------------------------------
                                    692 ; absolute internal ram data
                                    693 ;--------------------------------------------------------
                                    694 	.area IABS    (ABS,DATA)
                                    695 	.area IABS    (ABS,DATA)
                                    696 ;--------------------------------------------------------
                                    697 ; bit data
                                    698 ;--------------------------------------------------------
                                    699 	.area BSEG    (BIT)
                                    700 ;--------------------------------------------------------
                                    701 ; paged external ram data
                                    702 ;--------------------------------------------------------
                                    703 	.area PSEG    (PAG,XDATA)
      00F02E                        704 ___timerCounter::
      00F02E                        705 	.ds 4
      00F032                        706 _init_timer_t1cnt_65536_13:
      00F032                        707 	.ds 2
      00F034                        708 _delay_msec_65536_17:
      00F034                        709 	.ds 4
      00F038                        710 _delay_start_time_65536_18:
      00F038                        711 	.ds 4
      00F03C                        712 _delay_rval_262144_25:
      00F03C                        713 	.ds 1
                                    714 ;--------------------------------------------------------
                                    715 ; external ram data
                                    716 ;--------------------------------------------------------
                                    717 	.area XSEG    (XDATA)
                           00DF02   718 _MDMCTRL0H	=	0xdf02
                           00DF00   719 _SYNC1	=	0xdf00
                           00DF01   720 _SYNC0	=	0xdf01
                           00DF02   721 _PKTLEN	=	0xdf02
                           00DF03   722 _PKTCTRL1	=	0xdf03
                           00DF04   723 _PKTCTRL0	=	0xdf04
                           00DF05   724 _ADDR	=	0xdf05
                           00DF06   725 _CHANNR	=	0xdf06
                           00DF07   726 _FSCTRL1	=	0xdf07
                           00DF08   727 _FSCTRL0	=	0xdf08
                           00DF09   728 _FREQ2	=	0xdf09
                           00DF0A   729 _FREQ1	=	0xdf0a
                           00DF0B   730 _FREQ0	=	0xdf0b
                           00DF0C   731 _MDMCFG4	=	0xdf0c
                           00DF0D   732 _MDMCFG3	=	0xdf0d
                           00DF0E   733 _MDMCFG2	=	0xdf0e
                           00DF0F   734 _MDMCFG1	=	0xdf0f
                           00DF10   735 _MDMCFG0	=	0xdf10
                           00DF11   736 _DEVIATN	=	0xdf11
                           00DF12   737 _MCSM2	=	0xdf12
                           00DF13   738 _MCSM1	=	0xdf13
                           00DF14   739 _MCSM0	=	0xdf14
                           00DF15   740 _FOCCFG	=	0xdf15
                           00DF16   741 _BSCFG	=	0xdf16
                           00DF17   742 _AGCCTRL2	=	0xdf17
                           00DF18   743 _AGCCTRL1	=	0xdf18
                           00DF19   744 _AGCCTRL0	=	0xdf19
                           00DF1A   745 _FREND1	=	0xdf1a
                           00DF1B   746 _FREND0	=	0xdf1b
                           00DF1C   747 _FSCAL3	=	0xdf1c
                           00DF1D   748 _FSCAL2	=	0xdf1d
                           00DF1E   749 _FSCAL1	=	0xdf1e
                           00DF1F   750 _FSCAL0	=	0xdf1f
                           00DF20   751 __XREGDF20	=	0xdf20
                           00DF21   752 __XREGDF21	=	0xdf21
                           00DF22   753 __XREGDF22	=	0xdf22
                           00DF23   754 _TEST2	=	0xdf23
                           00DF24   755 _TEST1	=	0xdf24
                           00DF25   756 _TEST0	=	0xdf25
                           00DF26   757 __XREGDF26	=	0xdf26
                           00DF27   758 _PA_TABLE7	=	0xdf27
                           00DF28   759 _PA_TABLE6	=	0xdf28
                           00DF29   760 _PA_TABLE5	=	0xdf29
                           00DF2A   761 _PA_TABLE4	=	0xdf2a
                           00DF2B   762 _PA_TABLE3	=	0xdf2b
                           00DF2C   763 _PA_TABLE2	=	0xdf2c
                           00DF2D   764 _PA_TABLE1	=	0xdf2d
                           00DF2E   765 _PA_TABLE0	=	0xdf2e
                           00DF2F   766 _IOCFG2	=	0xdf2f
                           00DF30   767 _IOCFG1	=	0xdf30
                           00DF31   768 _IOCFG0	=	0xdf31
                           00DF32   769 __XREGDF32	=	0xdf32
                           00DF33   770 __XREGDF33	=	0xdf33
                           00DF34   771 __XREGDF34	=	0xdf34
                           00DF35   772 __XREGDF35	=	0xdf35
                           00DF36   773 _PARTNUM	=	0xdf36
                           00DF37   774 _VERSION	=	0xdf37
                           00DF38   775 _FREQEST	=	0xdf38
                           00DF39   776 _LQI	=	0xdf39
                           00DF3A   777 _RSSI	=	0xdf3a
                           00DF3B   778 _MARCSTATE	=	0xdf3b
                           00DF3C   779 _PKTSTATUS	=	0xdf3c
                           00DF3D   780 _VCO_VC_DAC	=	0xdf3d
                           00DF40   781 _I2SCFG0	=	0xdf40
                           00DF41   782 _I2SCFG1	=	0xdf41
                           00DF42   783 _I2SDATL	=	0xdf42
                           00DF43   784 _I2SDATH	=	0xdf43
                           00DF44   785 _I2SWCNT	=	0xdf44
                           00DF45   786 _I2SSTAT	=	0xdf45
                           00DF46   787 _I2SCLKF0	=	0xdf46
                           00DF47   788 _I2SCLKF1	=	0xdf47
                           00DF48   789 _I2SCLKF2	=	0xdf48
                           00DF80   790 __NA_P0	=	0xdf80
                           00DF81   791 __NA_SP	=	0xdf81
                           00DF82   792 __NA_DPL0	=	0xdf82
                           00DF83   793 __NA_DPH0	=	0xdf83
                           00DF84   794 __NA_DPL1	=	0xdf84
                           00DF85   795 __NA_DPH1	=	0xdf85
                           00DF86   796 _X_U0CSR	=	0xdf86
                           00DF87   797 __NA_PCON	=	0xdf87
                           00DF88   798 __NA_TCON	=	0xdf88
                           00DF89   799 _X_P0IFG	=	0xdf89
                           00DF8A   800 _X_P1IFG	=	0xdf8a
                           00DF8B   801 _X_P2IFG	=	0xdf8b
                           00DF8C   802 _X_PICTL	=	0xdf8c
                           00DF8D   803 _X_P1IEN	=	0xdf8d
                           00DF8E   804 __X_SFR8E	=	0xdf8e
                           00DF8F   805 _X_P0INP	=	0xdf8f
                           00DF90   806 __NA_P1	=	0xdf90
                           00DF91   807 _X_RFIM	=	0xdf91
                           00DF92   808 __NA_DPS	=	0xdf92
                           00DF93   809 _X_MPAGE	=	0xdf93
                           00DF94   810 __X_SFR94	=	0xdf94
                           00DF95   811 __X_SFR95	=	0xdf95
                           00DF96   812 __X_SFR96	=	0xdf96
                           00DF97   813 __X_SFR97	=	0xdf97
                           00DF98   814 __NA_S0CON	=	0xdf98
                           00DF99   815 __X_SFR99	=	0xdf99
                           00DF9A   816 __NA_IEN2	=	0xdf9a
                           00DF9B   817 __NA_S1CON	=	0xdf9b
                           00DF9C   818 _X_T2CT	=	0xdf9c
                           00DF9D   819 _X_T2PR	=	0xdf9d
                           00DF9E   820 _X_T2CTL	=	0xdf9e
                           00DF9F   821 __X_SFR9F	=	0xdf9f
                           00DFA0   822 __NA_P2	=	0xdfa0
                           00DFA1   823 _X_WORIRQ	=	0xdfa1
                           00DFA2   824 _X_WORCTRL	=	0xdfa2
                           00DFA3   825 _X_WOREVT0	=	0xdfa3
                           00DFA4   826 _X_WOREVT1	=	0xdfa4
                           00DFA5   827 _X_WORTIME0	=	0xdfa5
                           00DFA6   828 _X_WORTIME1	=	0xdfa6
                           00DFA7   829 __X_SFRA7	=	0xdfa7
                           00DFA8   830 __NA_IEN0	=	0xdfa8
                           00DFA9   831 __NA_IP0	=	0xdfa9
                           00DFAA   832 __X_SFRAA	=	0xdfaa
                           00DFAB   833 _X_FWT	=	0xdfab
                           00DFAC   834 _X_FADDRL	=	0xdfac
                           00DFAD   835 _X_FADDRH	=	0xdfad
                           00DFAE   836 _X_FCTL	=	0xdfae
                           00DFAF   837 _X_FWDATA	=	0xdfaf
                           00DFB0   838 __X_SFRB0	=	0xdfb0
                           00DFB1   839 _X_ENCDI	=	0xdfb1
                           00DFB2   840 _X_ENCDO	=	0xdfb2
                           00DFB3   841 _X_ENCCS	=	0xdfb3
                           00DFB4   842 _X_ADCCON1	=	0xdfb4
                           00DFB5   843 _X_ADCCON2	=	0xdfb5
                           00DFB6   844 _X_ADCCON3	=	0xdfb6
                           00DFB7   845 __X_SFRB7	=	0xdfb7
                           00DFB8   846 __NA_IEN1	=	0xdfb8
                           00DFB9   847 __NA_IP1	=	0xdfb9
                           00DFBA   848 _X_ADCL	=	0xdfba
                           00DFBB   849 _X_ADCH	=	0xdfbb
                           00DFBC   850 _X_RNDL	=	0xdfbc
                           00DFBD   851 _X_RNDH	=	0xdfbd
                           00DFBE   852 _X_SLEEP	=	0xdfbe
                           00DFBF   853 __X_SFRBF	=	0xdfbf
                           00DFC0   854 __NA_IRCON	=	0xdfc0
                           00DFC1   855 _X_U0DBUF	=	0xdfc1
                           00DFC2   856 _X_U0BAUD	=	0xdfc2
                           00DFC3   857 __X_SFRC3	=	0xdfc3
                           00DFC4   858 _X_U0UCR	=	0xdfc4
                           00DFC5   859 _X_U0GCR	=	0xdfc5
                           00DFC6   860 _X_CLKCON	=	0xdfc6
                           00DFC7   861 _X_MEMCTR	=	0xdfc7
                           00DFC8   862 __X_SFRC8	=	0xdfc8
                           00DFC9   863 _X_WDCTL	=	0xdfc9
                           00DFCA   864 _X_T3CNT	=	0xdfca
                           00DFCB   865 _X_T3CTL	=	0xdfcb
                           00DFCC   866 _X_T3CCTL0	=	0xdfcc
                           00DFCD   867 _X_T3CC0	=	0xdfcd
                           00DFCE   868 _X_T3CCTL1	=	0xdfce
                           00DFCF   869 _X_T3CC1	=	0xdfcf
                           00DFD0   870 __NA_PSW	=	0xdfd0
                           00DFD1   871 _X_DMAIRQ	=	0xdfd1
                           00DFD2   872 _X_DMA1CFGL	=	0xdfd2
                           00DFD3   873 _X_DMA1CFGH	=	0xdfd3
                           00DFD4   874 _X_DMA0CFGL	=	0xdfd4
                           00DFD5   875 _X_DMA0CFGH	=	0xdfd5
                           00DFD6   876 _X_DMAARM	=	0xdfd6
                           00DFD7   877 _X_DMAREQ	=	0xdfd7
                           00DFD8   878 _X_TIMIF	=	0xdfd8
                           00DFD9   879 _X_RFD	=	0xdfd9
                           00DFDA   880 _X_T1CC0L	=	0xdfda
                           00DFDB   881 _X_T1CC0H	=	0xdfdb
                           00DFDC   882 _X_T1CC1L	=	0xdfdc
                           00DFDD   883 _X_T1CC1H	=	0xdfdd
                           00DFDE   884 _X_T1CC2L	=	0xdfde
                           00DFDF   885 _X_T1CC2H	=	0xdfdf
                           00DFE0   886 __NA_ACC	=	0xdfe0
                           00DFE1   887 _X_RFST	=	0xdfe1
                           00DFE2   888 _X_T1CNTL	=	0xdfe2
                           00DFE3   889 _X_T1CNTH	=	0xdfe3
                           00DFE4   890 _X_T1CTL	=	0xdfe4
                           00DFE5   891 _X_T1CCTL0	=	0xdfe5
                           00DFE6   892 _X_T1CCTL1	=	0xdfe6
                           00DFE7   893 _X_T1CCTL2	=	0xdfe7
                           00DFE8   894 __NA_IRCON2	=	0xdfe8
                           00DFE9   895 _X_RFIF	=	0xdfe9
                           00DFEA   896 _X_T4CNT	=	0xdfea
                           00DFEB   897 _X_T4CTL	=	0xdfeb
                           00DFEC   898 _X_T4CCTL0	=	0xdfec
                           00DFED   899 _X_T4CC0	=	0xdfed
                           00DFEE   900 _X_T4CCTL1	=	0xdfee
                           00DFEF   901 _X_T4CC1	=	0xdfef
                           00DFF0   902 __NA_B	=	0xdff0
                           00DFF1   903 _X_PERCFG	=	0xdff1
                           00DFF2   904 _X_ADCCFG	=	0xdff2
                           00DFF3   905 _X_P0SEL	=	0xdff3
                           00DFF4   906 _X_P1SEL	=	0xdff4
                           00DFF5   907 _X_P2SEL	=	0xdff5
                           00DFF6   908 _X_P1INP	=	0xdff6
                           00DFF7   909 _X_P2INP	=	0xdff7
                           00DFF8   910 _X_U1CSR	=	0xdff8
                           00DFF9   911 _X_U1DBUF	=	0xdff9
                           00DFFA   912 _X_U1BAUD	=	0xdffa
                           00DFFB   913 _X_U1UCR	=	0xdffb
                           00DFFC   914 _X_U1GCR	=	0xdffc
                           00DFFD   915 _X_P0DIR	=	0xdffd
                           00DFFE   916 _X_P1DIR	=	0xdffe
                           00DFFF   917 _X_P2DIR	=	0xdfff
                                    918 ;--------------------------------------------------------
                                    919 ; absolute external ram data
                                    920 ;--------------------------------------------------------
                                    921 	.area XABS    (ABS,XDATA)
                                    922 ;--------------------------------------------------------
                                    923 ; external initialized ram data
                                    924 ;--------------------------------------------------------
                                    925 	.area XISEG   (XDATA)
                                    926 	.area HOME    (CODE)
                                    927 	.area GSINIT0 (CODE)
                                    928 	.area GSINIT1 (CODE)
                                    929 	.area GSINIT2 (CODE)
                                    930 	.area GSINIT3 (CODE)
                                    931 	.area GSINIT4 (CODE)
                                    932 	.area GSINIT5 (CODE)
                                    933 	.area GSINIT  (CODE)
                                    934 	.area GSFINAL (CODE)
                                    935 	.area CSEG    (CODE)
                                    936 ;--------------------------------------------------------
                                    937 ; global & static initialisations
                                    938 ;--------------------------------------------------------
                                    939 	.area HOME    (CODE)
                                    940 	.area GSINIT  (CODE)
                                    941 	.area GSFINAL (CODE)
                                    942 	.area GSINIT  (CODE)
                                    943 ;	timer.c:10: volatile uint32_t __timerCounter = 0;
      0000E8 78 2E            [12]  944 	mov	r0,#___timerCounter
      0000EA E4               [12]  945 	clr	a
      0000EB F2               [24]  946 	movx	@r0,a
      0000EC 08               [12]  947 	inc	r0
      0000ED F2               [24]  948 	movx	@r0,a
      0000EE 08               [12]  949 	inc	r0
      0000EF F2               [24]  950 	movx	@r0,a
      0000F0 08               [12]  951 	inc	r0
      0000F1 F2               [24]  952 	movx	@r0,a
                                    953 ;--------------------------------------------------------
                                    954 ; Home
                                    955 ;--------------------------------------------------------
                                    956 	.area HOME    (CODE)
                                    957 	.area HOME    (CODE)
                                    958 ;--------------------------------------------------------
                                    959 ; code
                                    960 ;--------------------------------------------------------
                                    961 	.area CSEG    (CODE)
                                    962 ;------------------------------------------------------------
                                    963 ;Allocation info for local variables in function 'init_timer'
                                    964 ;------------------------------------------------------------
                                    965 ;	timer.c:12: void init_timer() {
                                    966 ;	-----------------------------------------
                                    967 ;	 function init_timer
                                    968 ;	-----------------------------------------
      000BF0                        969 _init_timer:
                           000007   970 	ar7 = 0x07
                           000006   971 	ar6 = 0x06
                           000005   972 	ar5 = 0x05
                           000004   973 	ar4 = 0x04
                           000003   974 	ar3 = 0x03
                           000002   975 	ar2 = 0x02
                           000001   976 	ar1 = 0x01
                           000000   977 	ar0 = 0x00
                                    978 ;	timer.c:22: __timerCounter = 0;
      000BF0 78 2E            [12]  979 	mov	r0,#___timerCounter
      000BF2 E4               [12]  980 	clr	a
      000BF3 F2               [24]  981 	movx	@r0,a
      000BF4 08               [12]  982 	inc	r0
      000BF5 F2               [24]  983 	movx	@r0,a
      000BF6 08               [12]  984 	inc	r0
      000BF7 F2               [24]  985 	movx	@r0,a
      000BF8 08               [12]  986 	inc	r0
      000BF9 F2               [24]  987 	movx	@r0,a
                                    988 ;	timer.c:24: T1CTL = 0x00; // disable timer
                                    989 ;	1-genFromRTrack replaced	mov	_T1CTL,#0x00
      000BFA F5 E4            [12]  990 	mov	_T1CTL,a
                                    991 ;	timer.c:25: T1CNTL = 0x00; // Clear counter low
                                    992 ;	1-genFromRTrack replaced	mov	_T1CNTL,#0x00
      000BFC F5 E2            [12]  993 	mov	_T1CNTL,a
                                    994 ;	timer.c:28: T1CTL = 0x01;
      000BFE 75 E4 01         [24]  995 	mov	_T1CTL,#0x01
                                    996 ;	timer.c:30: do {
      000C01                        997 00101$:
                                    998 ;	timer.c:31: t1cnt.byte[0] = T1CNTL;
      000C01 78 32            [12]  999 	mov	r0,#_init_timer_t1cnt_65536_13
      000C03 E5 E2            [12] 1000 	mov	a,_T1CNTL
      000C05 F2               [24] 1001 	movx	@r0,a
                                   1002 ;	timer.c:32: t1cnt.byte[1] = T1CNTH;
      000C06 78 33            [12] 1003 	mov	r0,#(_init_timer_t1cnt_65536_13 + 0x0001)
      000C08 E5 E3            [12] 1004 	mov	a,_T1CNTH
      000C0A F2               [24] 1005 	movx	@r0,a
                                   1006 ;	timer.c:33: } while (t1cnt.val <= 0xA000);
      000C0B 78 32            [12] 1007 	mov	r0,#_init_timer_t1cnt_65536_13
      000C0D E2               [24] 1008 	movx	a,@r0
      000C0E FE               [12] 1009 	mov	r6,a
      000C0F 08               [12] 1010 	inc	r0
      000C10 E2               [24] 1011 	movx	a,@r0
      000C11 FF               [12] 1012 	mov	r7,a
      000C12 C3               [12] 1013 	clr	c
      000C13 E4               [12] 1014 	clr	a
      000C14 9E               [12] 1015 	subb	a,r6
      000C15 74 A0            [12] 1016 	mov	a,#0xa0
      000C17 9F               [12] 1017 	subb	a,r7
      000C18 50 E7            [24] 1018 	jnc	00101$
                                   1019 ;	timer.c:36: T1CTL = 0x00;
      000C1A 75 E4 00         [24] 1020 	mov	_T1CTL,#0x00
                                   1021 ;	timer.c:39: T1CC0H = timer_ticks_per_ms >> 8;
      000C1D 75 DB 00         [24] 1022 	mov	_T1CC0H,#0x00
                                   1023 ;	timer.c:40: T1CC0L = timer_ticks_per_ms & 0xff;
      000C20 75 DA 5D         [24] 1024 	mov	_T1CC0L,#0x5d
                                   1025 ;	timer.c:42: T1CCTL0 = 0x44; // Enable int, set output on compare, compare mode, no capture
      000C23 75 E5 44         [24] 1026 	mov	_T1CCTL0,#0x44
                                   1027 ;	timer.c:43: TIMIF |= OVFIM; // Enable Timer 1 overflow interrupt mask
      000C26 A2 DE            [12] 1028 	mov	c,_OVFIM
      000C28 E4               [12] 1029 	clr	a
      000C29 33               [12] 1030 	rlc	a
      000C2A 42 D8            [12] 1031 	orl	_TIMIF,a
                                   1032 ;	timer.c:44: T1IE = 1;
                                   1033 ;	assignBit
      000C2C D2 B9            [12] 1034 	setb	_T1IE
                                   1035 ;	timer.c:45: EA = 1;
                                   1036 ;	assignBit
      000C2E D2 AF            [12] 1037 	setb	_EA
                                   1038 ;	timer.c:47: T1CTL = 0x06;  // TickFreq/8, modulo
      000C30 75 E4 06         [24] 1039 	mov	_T1CTL,#0x06
                                   1040 ;	timer.c:48: }
      000C33 22               [24] 1041 	ret
                                   1042 ;------------------------------------------------------------
                                   1043 ;Allocation info for local variables in function 't1_isr'
                                   1044 ;------------------------------------------------------------
                                   1045 ;	timer.c:50: void t1_isr(void) __interrupt T1_VECTOR
                                   1046 ;	-----------------------------------------
                                   1047 ;	 function t1_isr
                                   1048 ;	-----------------------------------------
      000C34                       1049 _t1_isr:
      000C34 C0 E0            [24] 1050 	push	acc
      000C36 C0 07            [24] 1051 	push	ar7
      000C38 C0 06            [24] 1052 	push	ar6
      000C3A C0 05            [24] 1053 	push	ar5
      000C3C C0 04            [24] 1054 	push	ar4
      000C3E C0 00            [24] 1055 	push	ar0
      000C40 C0 D0            [24] 1056 	push	psw
      000C42 75 D0 00         [24] 1057 	mov	psw,#0x00
                                   1058 ;	timer.c:52: __timerCounter++;
      000C45 78 2E            [12] 1059 	mov	r0,#___timerCounter
      000C47 E2               [24] 1060 	movx	a,@r0
      000C48 FC               [12] 1061 	mov	r4,a
      000C49 08               [12] 1062 	inc	r0
      000C4A E2               [24] 1063 	movx	a,@r0
      000C4B FD               [12] 1064 	mov	r5,a
      000C4C 08               [12] 1065 	inc	r0
      000C4D E2               [24] 1066 	movx	a,@r0
      000C4E FE               [12] 1067 	mov	r6,a
      000C4F 08               [12] 1068 	inc	r0
      000C50 E2               [24] 1069 	movx	a,@r0
      000C51 FF               [12] 1070 	mov	r7,a
      000C52 78 2E            [12] 1071 	mov	r0,#___timerCounter
      000C54 74 01            [12] 1072 	mov	a,#0x01
      000C56 2C               [12] 1073 	add	a,r4
      000C57 F2               [24] 1074 	movx	@r0,a
      000C58 E4               [12] 1075 	clr	a
      000C59 3D               [12] 1076 	addc	a,r5
      000C5A 08               [12] 1077 	inc	r0
      000C5B F2               [24] 1078 	movx	@r0,a
      000C5C E4               [12] 1079 	clr	a
      000C5D 3E               [12] 1080 	addc	a,r6
      000C5E 08               [12] 1081 	inc	r0
      000C5F F2               [24] 1082 	movx	@r0,a
      000C60 E4               [12] 1083 	clr	a
      000C61 3F               [12] 1084 	addc	a,r7
      000C62 08               [12] 1085 	inc	r0
      000C63 F2               [24] 1086 	movx	@r0,a
                                   1087 ;	timer.c:53: }
      000C64 D0 D0            [24] 1088 	pop	psw
      000C66 D0 00            [24] 1089 	pop	ar0
      000C68 D0 04            [24] 1090 	pop	ar4
      000C6A D0 05            [24] 1091 	pop	ar5
      000C6C D0 06            [24] 1092 	pop	ar6
      000C6E D0 07            [24] 1093 	pop	ar7
      000C70 D0 E0            [24] 1094 	pop	acc
      000C72 32               [24] 1095 	reti
                                   1096 ;	eliminated unneeded push/pop ar1
                                   1097 ;	eliminated unneeded push/pop dpl
                                   1098 ;	eliminated unneeded push/pop dph
                                   1099 ;	eliminated unneeded push/pop b
                                   1100 ;------------------------------------------------------------
                                   1101 ;Allocation info for local variables in function 'delay'
                                   1102 ;------------------------------------------------------------
                                   1103 ;	timer.c:55: void delay(uint32_t msec) {
                                   1104 ;	-----------------------------------------
                                   1105 ;	 function delay
                                   1106 ;	-----------------------------------------
      000C73                       1107 _delay:
      000C73 AF 82            [24] 1108 	mov	r7,dpl
      000C75 AE 83            [24] 1109 	mov	r6,dph
      000C77 AD F0            [24] 1110 	mov	r5,b
      000C79 FC               [12] 1111 	mov	r4,a
      000C7A 78 34            [12] 1112 	mov	r0,#_delay_msec_65536_17
      000C7C EF               [12] 1113 	mov	a,r7
      000C7D F2               [24] 1114 	movx	@r0,a
      000C7E 08               [12] 1115 	inc	r0
      000C7F EE               [12] 1116 	mov	a,r6
      000C80 F2               [24] 1117 	movx	@r0,a
      000C81 08               [12] 1118 	inc	r0
      000C82 ED               [12] 1119 	mov	a,r5
      000C83 F2               [24] 1120 	movx	@r0,a
      000C84 08               [12] 1121 	inc	r0
      000C85 EC               [12] 1122 	mov	a,r4
      000C86 F2               [24] 1123 	movx	@r0,a
                                   1124 ;	timer.c:57: read_timer(&start_time);
                                   1125 ;	timer.h:14: EA = 0;
                                   1126 ;	assignBit
      000C87 C2 AF            [12] 1127 	clr	_EA
                                   1128 ;	timer.h:15: *result = __timerCounter;
      000C89 78 38            [12] 1129 	mov	r0,#_delay_start_time_65536_18
      000C8B 79 2E            [12] 1130 	mov	r1,#___timerCounter
      000C8D E3               [24] 1131 	movx	a,@r1
      000C8E F2               [24] 1132 	movx	@r0,a
      000C8F 08               [12] 1133 	inc	r0
      000C90 09               [12] 1134 	inc	r1
      000C91 E3               [24] 1135 	movx	a,@r1
      000C92 F2               [24] 1136 	movx	@r0,a
      000C93 08               [12] 1137 	inc	r0
      000C94 09               [12] 1138 	inc	r1
      000C95 E3               [24] 1139 	movx	a,@r1
      000C96 F2               [24] 1140 	movx	@r0,a
      000C97 08               [12] 1141 	inc	r0
      000C98 09               [12] 1142 	inc	r1
      000C99 E3               [24] 1143 	movx	a,@r1
      000C9A F2               [24] 1144 	movx	@r0,a
                                   1145 ;	timer.h:16: EA = 1;
                                   1146 ;	assignBit
      000C9B D2 AF            [12] 1147 	setb	_EA
                                   1148 ;	timer.c:58: while(!check_elapsed(start_time, msec)) {
      000C9D                       1149 00101$:
                                   1150 ;	timer.h:22: EA = 0;
                                   1151 ;	assignBit
      000C9D C2 AF            [12] 1152 	clr	_EA
                                   1153 ;	timer.h:23: rval = (__timerCounter - start_time) > duration;
      000C9F 78 2E            [12] 1154 	mov	r0,#___timerCounter
      000CA1 79 38            [12] 1155 	mov	r1,#_delay_start_time_65536_18
      000CA3 E3               [24] 1156 	movx	a,@r1
      000CA4 F5 F0            [12] 1157 	mov	b,a
      000CA6 C3               [12] 1158 	clr	c
      000CA7 E2               [24] 1159 	movx	a,@r0
      000CA8 95 F0            [12] 1160 	subb	a,b
      000CAA FA               [12] 1161 	mov	r2,a
      000CAB 09               [12] 1162 	inc	r1
      000CAC E3               [24] 1163 	movx	a,@r1
      000CAD F5 F0            [12] 1164 	mov	b,a
      000CAF 08               [12] 1165 	inc	r0
      000CB0 E2               [24] 1166 	movx	a,@r0
      000CB1 95 F0            [12] 1167 	subb	a,b
      000CB3 FB               [12] 1168 	mov	r3,a
      000CB4 09               [12] 1169 	inc	r1
      000CB5 E3               [24] 1170 	movx	a,@r1
      000CB6 F5 F0            [12] 1171 	mov	b,a
      000CB8 08               [12] 1172 	inc	r0
      000CB9 E2               [24] 1173 	movx	a,@r0
      000CBA 95 F0            [12] 1174 	subb	a,b
      000CBC FE               [12] 1175 	mov	r6,a
      000CBD 09               [12] 1176 	inc	r1
      000CBE E3               [24] 1177 	movx	a,@r1
      000CBF F5 F0            [12] 1178 	mov	b,a
      000CC1 08               [12] 1179 	inc	r0
      000CC2 E2               [24] 1180 	movx	a,@r0
      000CC3 95 F0            [12] 1181 	subb	a,b
      000CC5 FF               [12] 1182 	mov	r7,a
      000CC6 78 3C            [12] 1183 	mov	r0,#_delay_rval_262144_25
      000CC8 79 34            [12] 1184 	mov	r1,#_delay_msec_65536_17
      000CCA C3               [12] 1185 	clr	c
      000CCB E3               [24] 1186 	movx	a,@r1
      000CCC 9A               [12] 1187 	subb	a,r2
      000CCD 09               [12] 1188 	inc	r1
      000CCE E3               [24] 1189 	movx	a,@r1
      000CCF 9B               [12] 1190 	subb	a,r3
      000CD0 09               [12] 1191 	inc	r1
      000CD1 E3               [24] 1192 	movx	a,@r1
      000CD2 9E               [12] 1193 	subb	a,r6
      000CD3 09               [12] 1194 	inc	r1
      000CD4 E3               [24] 1195 	movx	a,@r1
      000CD5 9F               [12] 1196 	subb	a,r7
      000CD6 E4               [12] 1197 	clr	a
      000CD7 33               [12] 1198 	rlc	a
      000CD8 F2               [24] 1199 	movx	@r0,a
                                   1200 ;	timer.h:24: EA = 1;
                                   1201 ;	assignBit
      000CD9 D2 AF            [12] 1202 	setb	_EA
                                   1203 ;	timer.c:58: while(!check_elapsed(start_time, msec)) {
      000CDB 78 3C            [12] 1204 	mov	r0,#_delay_rval_262144_25
      000CDD E2               [24] 1205 	movx	a,@r0
      000CDE 60 BD            [24] 1206 	jz	00101$
                                   1207 ;	timer.c:61: }
      000CE0 22               [24] 1208 	ret
                                   1209 	.area CSEG    (CODE)
                                   1210 	.area CONST   (CODE)
                                   1211 	.area XINIT   (CODE)
                                   1212 	.area CABS    (ABS,CODE)
