                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.0.2 #11662 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module subg_rfspy
                                      6 	.optsdcc -mmcs51 --model-medium
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _go_to_sleep
                                     12 	.globl _port1_isr
                                     13 	.globl _get_command
                                     14 	.globl _init_timer
                                     15 	.globl _configure_radio
                                     16 	.globl _configure_serial
                                     17 	.globl _MODE
                                     18 	.globl _RE
                                     19 	.globl _SLAVE
                                     20 	.globl _FE
                                     21 	.globl _ERR
                                     22 	.globl _RX_BYTE
                                     23 	.globl _TX_BYTE
                                     24 	.globl _ACTIVE
                                     25 	.globl _B_7
                                     26 	.globl _B_6
                                     27 	.globl _B_5
                                     28 	.globl _B_4
                                     29 	.globl _B_3
                                     30 	.globl _B_2
                                     31 	.globl _B_1
                                     32 	.globl _B_0
                                     33 	.globl _WDTIF
                                     34 	.globl _P1IF
                                     35 	.globl _UTX1IF
                                     36 	.globl _UTX0IF
                                     37 	.globl _P2IF
                                     38 	.globl _ACC_7
                                     39 	.globl _ACC_6
                                     40 	.globl _ACC_5
                                     41 	.globl _ACC_4
                                     42 	.globl _ACC_3
                                     43 	.globl _ACC_2
                                     44 	.globl _ACC_1
                                     45 	.globl _ACC_0
                                     46 	.globl _OVFIM
                                     47 	.globl _T4CH1IF
                                     48 	.globl _T4CH0IF
                                     49 	.globl _T4OVFIF
                                     50 	.globl _T3CH1IF
                                     51 	.globl _T3CH0IF
                                     52 	.globl _T3OVFIF
                                     53 	.globl _CY
                                     54 	.globl _AC
                                     55 	.globl _F0
                                     56 	.globl _RS1
                                     57 	.globl _RS0
                                     58 	.globl _OV
                                     59 	.globl _F1
                                     60 	.globl _P
                                     61 	.globl _STIF
                                     62 	.globl _P0IF
                                     63 	.globl _T4IF
                                     64 	.globl _T3IF
                                     65 	.globl _T2IF
                                     66 	.globl _T1IF
                                     67 	.globl _DMAIF
                                     68 	.globl _P0IE
                                     69 	.globl _T4IE
                                     70 	.globl _T3IE
                                     71 	.globl _T2IE
                                     72 	.globl _T1IE
                                     73 	.globl _DMAIE
                                     74 	.globl _EA
                                     75 	.globl _STIE
                                     76 	.globl _ENCIE
                                     77 	.globl _URX1IE
                                     78 	.globl _URX0IE
                                     79 	.globl _ADCIE
                                     80 	.globl _RFTXRXIE
                                     81 	.globl _P2_7
                                     82 	.globl _P2_6
                                     83 	.globl _P2_5
                                     84 	.globl _P2_4
                                     85 	.globl _P2_3
                                     86 	.globl _P2_2
                                     87 	.globl _P2_1
                                     88 	.globl _P2_0
                                     89 	.globl _ENCIF_1
                                     90 	.globl _ENCIF_0
                                     91 	.globl _P1_7
                                     92 	.globl _P1_6
                                     93 	.globl _P1_5
                                     94 	.globl _P1_4
                                     95 	.globl _P1_3
                                     96 	.globl _P1_2
                                     97 	.globl _P1_1
                                     98 	.globl _P1_0
                                     99 	.globl _URX1IF
                                    100 	.globl _ADCIF
                                    101 	.globl _URX0IF
                                    102 	.globl _IT1
                                    103 	.globl _RFTXRXIF
                                    104 	.globl _IT0
                                    105 	.globl _P0_7
                                    106 	.globl _P0_6
                                    107 	.globl _P0_5
                                    108 	.globl _P0_4
                                    109 	.globl _P0_3
                                    110 	.globl _P0_2
                                    111 	.globl _P0_1
                                    112 	.globl _P0_0
                                    113 	.globl _P2DIR
                                    114 	.globl _P1DIR
                                    115 	.globl _P0DIR
                                    116 	.globl _U1GCR
                                    117 	.globl _U1UCR
                                    118 	.globl _U1BAUD
                                    119 	.globl _U1DBUF
                                    120 	.globl _U1CSR
                                    121 	.globl _P2INP
                                    122 	.globl _P1INP
                                    123 	.globl _P2SEL
                                    124 	.globl _P1SEL
                                    125 	.globl _P0SEL
                                    126 	.globl _ADCCFG
                                    127 	.globl _PERCFG
                                    128 	.globl _B
                                    129 	.globl _T4CC1
                                    130 	.globl _T4CCTL1
                                    131 	.globl _T4CC0
                                    132 	.globl _T4CCTL0
                                    133 	.globl _T4CTL
                                    134 	.globl _T4CNT
                                    135 	.globl _RFIF
                                    136 	.globl _IRCON2
                                    137 	.globl _T1CCTL2
                                    138 	.globl _T1CCTL1
                                    139 	.globl _T1CCTL0
                                    140 	.globl _T1CTL
                                    141 	.globl _T1CNTH
                                    142 	.globl _T1CNTL
                                    143 	.globl _RFST
                                    144 	.globl _ACC
                                    145 	.globl _T1CC2H
                                    146 	.globl _T1CC2L
                                    147 	.globl _T1CC1H
                                    148 	.globl _T1CC1L
                                    149 	.globl _T1CC0H
                                    150 	.globl _T1CC0L
                                    151 	.globl _RFD
                                    152 	.globl _TIMIF
                                    153 	.globl _DMAREQ
                                    154 	.globl _DMAARM
                                    155 	.globl _DMA0CFGH
                                    156 	.globl _DMA0CFGL
                                    157 	.globl _DMA1CFGH
                                    158 	.globl _DMA1CFGL
                                    159 	.globl _DMAIRQ
                                    160 	.globl _PSW
                                    161 	.globl _T3CC1
                                    162 	.globl _T3CCTL1
                                    163 	.globl _T3CC0
                                    164 	.globl _T3CCTL0
                                    165 	.globl _T3CTL
                                    166 	.globl _T3CNT
                                    167 	.globl _WDCTL
                                    168 	.globl __SFRC8
                                    169 	.globl _MEMCTR
                                    170 	.globl _CLKCON
                                    171 	.globl _U0GCR
                                    172 	.globl _U0UCR
                                    173 	.globl __SFRC3
                                    174 	.globl _U0BAUD
                                    175 	.globl _U0DBUF
                                    176 	.globl _IRCON
                                    177 	.globl __SFRBF
                                    178 	.globl _SLEEP
                                    179 	.globl _RNDH
                                    180 	.globl _RNDL
                                    181 	.globl _ADCH
                                    182 	.globl _ADCL
                                    183 	.globl _IP1
                                    184 	.globl _IEN1
                                    185 	.globl __SFRB7
                                    186 	.globl _ADCCON3
                                    187 	.globl _ADCCON2
                                    188 	.globl _ADCCON1
                                    189 	.globl _ENCCS
                                    190 	.globl _ENCDO
                                    191 	.globl _ENCDI
                                    192 	.globl __SFRB0
                                    193 	.globl _FWDATA
                                    194 	.globl _FCTL
                                    195 	.globl _FADDRH
                                    196 	.globl _FADDRL
                                    197 	.globl _FWT
                                    198 	.globl __SFRAA
                                    199 	.globl _IP0
                                    200 	.globl _IEN0
                                    201 	.globl __SFRA7
                                    202 	.globl _WORTIME1
                                    203 	.globl _WORTIME0
                                    204 	.globl _WOREVT1
                                    205 	.globl _WOREVT0
                                    206 	.globl _WORCTRL
                                    207 	.globl _WORIRQ
                                    208 	.globl _P2
                                    209 	.globl __SFR9F
                                    210 	.globl _T2CTL
                                    211 	.globl _T2PR
                                    212 	.globl _T2CT
                                    213 	.globl _S1CON
                                    214 	.globl _IEN2
                                    215 	.globl __SFR99
                                    216 	.globl _S0CON
                                    217 	.globl __SFR97
                                    218 	.globl __SFR96
                                    219 	.globl __SFR95
                                    220 	.globl __SFR94
                                    221 	.globl __XPAGE
                                    222 	.globl _MPAGE
                                    223 	.globl _DPS
                                    224 	.globl _RFIM
                                    225 	.globl _P1
                                    226 	.globl _P0INP
                                    227 	.globl __SFR8E
                                    228 	.globl _P1IEN
                                    229 	.globl _PICTL
                                    230 	.globl _P2IFG
                                    231 	.globl _P1IFG
                                    232 	.globl _P0IFG
                                    233 	.globl _TCON
                                    234 	.globl _PCON
                                    235 	.globl _U0CSR
                                    236 	.globl _DPH1
                                    237 	.globl _DPL1
                                    238 	.globl _DPH0
                                    239 	.globl _DPL0
                                    240 	.globl _SP
                                    241 	.globl _P0
                                    242 	.globl _subg_rfspy_should_exit
                                    243 	.globl _subg_rfspy_init_finished
                                    244 	.globl _X_P2DIR
                                    245 	.globl _X_P1DIR
                                    246 	.globl _X_P0DIR
                                    247 	.globl _X_U1GCR
                                    248 	.globl _X_U1UCR
                                    249 	.globl _X_U1BAUD
                                    250 	.globl _X_U1DBUF
                                    251 	.globl _X_U1CSR
                                    252 	.globl _X_P2INP
                                    253 	.globl _X_P1INP
                                    254 	.globl _X_P2SEL
                                    255 	.globl _X_P1SEL
                                    256 	.globl _X_P0SEL
                                    257 	.globl _X_ADCCFG
                                    258 	.globl _X_PERCFG
                                    259 	.globl __NA_B
                                    260 	.globl _X_T4CC1
                                    261 	.globl _X_T4CCTL1
                                    262 	.globl _X_T4CC0
                                    263 	.globl _X_T4CCTL0
                                    264 	.globl _X_T4CTL
                                    265 	.globl _X_T4CNT
                                    266 	.globl _X_RFIF
                                    267 	.globl __NA_IRCON2
                                    268 	.globl _X_T1CCTL2
                                    269 	.globl _X_T1CCTL1
                                    270 	.globl _X_T1CCTL0
                                    271 	.globl _X_T1CTL
                                    272 	.globl _X_T1CNTH
                                    273 	.globl _X_T1CNTL
                                    274 	.globl _X_RFST
                                    275 	.globl __NA_ACC
                                    276 	.globl _X_T1CC2H
                                    277 	.globl _X_T1CC2L
                                    278 	.globl _X_T1CC1H
                                    279 	.globl _X_T1CC1L
                                    280 	.globl _X_T1CC0H
                                    281 	.globl _X_T1CC0L
                                    282 	.globl _X_RFD
                                    283 	.globl _X_TIMIF
                                    284 	.globl _X_DMAREQ
                                    285 	.globl _X_DMAARM
                                    286 	.globl _X_DMA0CFGH
                                    287 	.globl _X_DMA0CFGL
                                    288 	.globl _X_DMA1CFGH
                                    289 	.globl _X_DMA1CFGL
                                    290 	.globl _X_DMAIRQ
                                    291 	.globl __NA_PSW
                                    292 	.globl _X_T3CC1
                                    293 	.globl _X_T3CCTL1
                                    294 	.globl _X_T3CC0
                                    295 	.globl _X_T3CCTL0
                                    296 	.globl _X_T3CTL
                                    297 	.globl _X_T3CNT
                                    298 	.globl _X_WDCTL
                                    299 	.globl __X_SFRC8
                                    300 	.globl _X_MEMCTR
                                    301 	.globl _X_CLKCON
                                    302 	.globl _X_U0GCR
                                    303 	.globl _X_U0UCR
                                    304 	.globl __X_SFRC3
                                    305 	.globl _X_U0BAUD
                                    306 	.globl _X_U0DBUF
                                    307 	.globl __NA_IRCON
                                    308 	.globl __X_SFRBF
                                    309 	.globl _X_SLEEP
                                    310 	.globl _X_RNDH
                                    311 	.globl _X_RNDL
                                    312 	.globl _X_ADCH
                                    313 	.globl _X_ADCL
                                    314 	.globl __NA_IP1
                                    315 	.globl __NA_IEN1
                                    316 	.globl __X_SFRB7
                                    317 	.globl _X_ADCCON3
                                    318 	.globl _X_ADCCON2
                                    319 	.globl _X_ADCCON1
                                    320 	.globl _X_ENCCS
                                    321 	.globl _X_ENCDO
                                    322 	.globl _X_ENCDI
                                    323 	.globl __X_SFRB0
                                    324 	.globl _X_FWDATA
                                    325 	.globl _X_FCTL
                                    326 	.globl _X_FADDRH
                                    327 	.globl _X_FADDRL
                                    328 	.globl _X_FWT
                                    329 	.globl __X_SFRAA
                                    330 	.globl __NA_IP0
                                    331 	.globl __NA_IEN0
                                    332 	.globl __X_SFRA7
                                    333 	.globl _X_WORTIME1
                                    334 	.globl _X_WORTIME0
                                    335 	.globl _X_WOREVT1
                                    336 	.globl _X_WOREVT0
                                    337 	.globl _X_WORCTRL
                                    338 	.globl _X_WORIRQ
                                    339 	.globl __NA_P2
                                    340 	.globl __X_SFR9F
                                    341 	.globl _X_T2CTL
                                    342 	.globl _X_T2PR
                                    343 	.globl _X_T2CT
                                    344 	.globl __NA_S1CON
                                    345 	.globl __NA_IEN2
                                    346 	.globl __X_SFR99
                                    347 	.globl __NA_S0CON
                                    348 	.globl __X_SFR97
                                    349 	.globl __X_SFR96
                                    350 	.globl __X_SFR95
                                    351 	.globl __X_SFR94
                                    352 	.globl _X_MPAGE
                                    353 	.globl __NA_DPS
                                    354 	.globl _X_RFIM
                                    355 	.globl __NA_P1
                                    356 	.globl _X_P0INP
                                    357 	.globl __X_SFR8E
                                    358 	.globl _X_P1IEN
                                    359 	.globl _X_PICTL
                                    360 	.globl _X_P2IFG
                                    361 	.globl _X_P1IFG
                                    362 	.globl _X_P0IFG
                                    363 	.globl __NA_TCON
                                    364 	.globl __NA_PCON
                                    365 	.globl _X_U0CSR
                                    366 	.globl __NA_DPH1
                                    367 	.globl __NA_DPL1
                                    368 	.globl __NA_DPH0
                                    369 	.globl __NA_DPL0
                                    370 	.globl __NA_SP
                                    371 	.globl __NA_P0
                                    372 	.globl _I2SCLKF2
                                    373 	.globl _I2SCLKF1
                                    374 	.globl _I2SCLKF0
                                    375 	.globl _I2SSTAT
                                    376 	.globl _I2SWCNT
                                    377 	.globl _I2SDATH
                                    378 	.globl _I2SDATL
                                    379 	.globl _I2SCFG1
                                    380 	.globl _I2SCFG0
                                    381 	.globl _VCO_VC_DAC
                                    382 	.globl _PKTSTATUS
                                    383 	.globl _MARCSTATE
                                    384 	.globl _RSSI
                                    385 	.globl _LQI
                                    386 	.globl _FREQEST
                                    387 	.globl _VERSION
                                    388 	.globl _PARTNUM
                                    389 	.globl __XREGDF35
                                    390 	.globl __XREGDF34
                                    391 	.globl __XREGDF33
                                    392 	.globl __XREGDF32
                                    393 	.globl _IOCFG0
                                    394 	.globl _IOCFG1
                                    395 	.globl _IOCFG2
                                    396 	.globl _PA_TABLE0
                                    397 	.globl _PA_TABLE1
                                    398 	.globl _PA_TABLE2
                                    399 	.globl _PA_TABLE3
                                    400 	.globl _PA_TABLE4
                                    401 	.globl _PA_TABLE5
                                    402 	.globl _PA_TABLE6
                                    403 	.globl _PA_TABLE7
                                    404 	.globl __XREGDF26
                                    405 	.globl _TEST0
                                    406 	.globl _TEST1
                                    407 	.globl _TEST2
                                    408 	.globl __XREGDF22
                                    409 	.globl __XREGDF21
                                    410 	.globl __XREGDF20
                                    411 	.globl _FSCAL0
                                    412 	.globl _FSCAL1
                                    413 	.globl _FSCAL2
                                    414 	.globl _FSCAL3
                                    415 	.globl _FREND0
                                    416 	.globl _FREND1
                                    417 	.globl _AGCCTRL0
                                    418 	.globl _AGCCTRL1
                                    419 	.globl _AGCCTRL2
                                    420 	.globl _BSCFG
                                    421 	.globl _FOCCFG
                                    422 	.globl _MCSM0
                                    423 	.globl _MCSM1
                                    424 	.globl _MCSM2
                                    425 	.globl _DEVIATN
                                    426 	.globl _MDMCFG0
                                    427 	.globl _MDMCFG1
                                    428 	.globl _MDMCFG2
                                    429 	.globl _MDMCFG3
                                    430 	.globl _MDMCFG4
                                    431 	.globl _FREQ0
                                    432 	.globl _FREQ1
                                    433 	.globl _FREQ2
                                    434 	.globl _FSCTRL0
                                    435 	.globl _FSCTRL1
                                    436 	.globl _CHANNR
                                    437 	.globl _ADDR
                                    438 	.globl _PKTCTRL0
                                    439 	.globl _PKTCTRL1
                                    440 	.globl _PKTLEN
                                    441 	.globl _SYNC0
                                    442 	.globl _SYNC1
                                    443 	.globl _MDMCTRL0H
                                    444 	.globl _subg_rfspy_main
                                    445 ;--------------------------------------------------------
                                    446 ; special function registers
                                    447 ;--------------------------------------------------------
                                    448 	.area RSEG    (ABS,DATA)
      000000                        449 	.org 0x0000
                           000080   450 _P0	=	0x0080
                           000081   451 _SP	=	0x0081
                           000082   452 _DPL0	=	0x0082
                           000083   453 _DPH0	=	0x0083
                           000084   454 _DPL1	=	0x0084
                           000085   455 _DPH1	=	0x0085
                           000086   456 _U0CSR	=	0x0086
                           000087   457 _PCON	=	0x0087
                           000088   458 _TCON	=	0x0088
                           000089   459 _P0IFG	=	0x0089
                           00008A   460 _P1IFG	=	0x008a
                           00008B   461 _P2IFG	=	0x008b
                           00008C   462 _PICTL	=	0x008c
                           00008D   463 _P1IEN	=	0x008d
                           00008E   464 __SFR8E	=	0x008e
                           00008F   465 _P0INP	=	0x008f
                           000090   466 _P1	=	0x0090
                           000091   467 _RFIM	=	0x0091
                           000092   468 _DPS	=	0x0092
                           000093   469 _MPAGE	=	0x0093
                           000093   470 __XPAGE	=	0x0093
                           000094   471 __SFR94	=	0x0094
                           000095   472 __SFR95	=	0x0095
                           000096   473 __SFR96	=	0x0096
                           000097   474 __SFR97	=	0x0097
                           000098   475 _S0CON	=	0x0098
                           000099   476 __SFR99	=	0x0099
                           00009A   477 _IEN2	=	0x009a
                           00009B   478 _S1CON	=	0x009b
                           00009C   479 _T2CT	=	0x009c
                           00009D   480 _T2PR	=	0x009d
                           00009E   481 _T2CTL	=	0x009e
                           00009F   482 __SFR9F	=	0x009f
                           0000A0   483 _P2	=	0x00a0
                           0000A1   484 _WORIRQ	=	0x00a1
                           0000A2   485 _WORCTRL	=	0x00a2
                           0000A3   486 _WOREVT0	=	0x00a3
                           0000A4   487 _WOREVT1	=	0x00a4
                           0000A5   488 _WORTIME0	=	0x00a5
                           0000A6   489 _WORTIME1	=	0x00a6
                           0000A7   490 __SFRA7	=	0x00a7
                           0000A8   491 _IEN0	=	0x00a8
                           0000A9   492 _IP0	=	0x00a9
                           0000AA   493 __SFRAA	=	0x00aa
                           0000AB   494 _FWT	=	0x00ab
                           0000AC   495 _FADDRL	=	0x00ac
                           0000AD   496 _FADDRH	=	0x00ad
                           0000AE   497 _FCTL	=	0x00ae
                           0000AF   498 _FWDATA	=	0x00af
                           0000B0   499 __SFRB0	=	0x00b0
                           0000B1   500 _ENCDI	=	0x00b1
                           0000B2   501 _ENCDO	=	0x00b2
                           0000B3   502 _ENCCS	=	0x00b3
                           0000B4   503 _ADCCON1	=	0x00b4
                           0000B5   504 _ADCCON2	=	0x00b5
                           0000B6   505 _ADCCON3	=	0x00b6
                           0000B7   506 __SFRB7	=	0x00b7
                           0000B8   507 _IEN1	=	0x00b8
                           0000B9   508 _IP1	=	0x00b9
                           0000BA   509 _ADCL	=	0x00ba
                           0000BB   510 _ADCH	=	0x00bb
                           0000BC   511 _RNDL	=	0x00bc
                           0000BD   512 _RNDH	=	0x00bd
                           0000BE   513 _SLEEP	=	0x00be
                           0000BF   514 __SFRBF	=	0x00bf
                           0000C0   515 _IRCON	=	0x00c0
                           0000C1   516 _U0DBUF	=	0x00c1
                           0000C2   517 _U0BAUD	=	0x00c2
                           0000C3   518 __SFRC3	=	0x00c3
                           0000C4   519 _U0UCR	=	0x00c4
                           0000C5   520 _U0GCR	=	0x00c5
                           0000C6   521 _CLKCON	=	0x00c6
                           0000C7   522 _MEMCTR	=	0x00c7
                           0000C8   523 __SFRC8	=	0x00c8
                           0000C9   524 _WDCTL	=	0x00c9
                           0000CA   525 _T3CNT	=	0x00ca
                           0000CB   526 _T3CTL	=	0x00cb
                           0000CC   527 _T3CCTL0	=	0x00cc
                           0000CD   528 _T3CC0	=	0x00cd
                           0000CE   529 _T3CCTL1	=	0x00ce
                           0000CF   530 _T3CC1	=	0x00cf
                           0000D0   531 _PSW	=	0x00d0
                           0000D1   532 _DMAIRQ	=	0x00d1
                           0000D2   533 _DMA1CFGL	=	0x00d2
                           0000D3   534 _DMA1CFGH	=	0x00d3
                           0000D4   535 _DMA0CFGL	=	0x00d4
                           0000D5   536 _DMA0CFGH	=	0x00d5
                           0000D6   537 _DMAARM	=	0x00d6
                           0000D7   538 _DMAREQ	=	0x00d7
                           0000D8   539 _TIMIF	=	0x00d8
                           0000D9   540 _RFD	=	0x00d9
                           0000DA   541 _T1CC0L	=	0x00da
                           0000DB   542 _T1CC0H	=	0x00db
                           0000DC   543 _T1CC1L	=	0x00dc
                           0000DD   544 _T1CC1H	=	0x00dd
                           0000DE   545 _T1CC2L	=	0x00de
                           0000DF   546 _T1CC2H	=	0x00df
                           0000E0   547 _ACC	=	0x00e0
                           0000E1   548 _RFST	=	0x00e1
                           0000E2   549 _T1CNTL	=	0x00e2
                           0000E3   550 _T1CNTH	=	0x00e3
                           0000E4   551 _T1CTL	=	0x00e4
                           0000E5   552 _T1CCTL0	=	0x00e5
                           0000E6   553 _T1CCTL1	=	0x00e6
                           0000E7   554 _T1CCTL2	=	0x00e7
                           0000E8   555 _IRCON2	=	0x00e8
                           0000E9   556 _RFIF	=	0x00e9
                           0000EA   557 _T4CNT	=	0x00ea
                           0000EB   558 _T4CTL	=	0x00eb
                           0000EC   559 _T4CCTL0	=	0x00ec
                           0000ED   560 _T4CC0	=	0x00ed
                           0000EE   561 _T4CCTL1	=	0x00ee
                           0000EF   562 _T4CC1	=	0x00ef
                           0000F0   563 _B	=	0x00f0
                           0000F1   564 _PERCFG	=	0x00f1
                           0000F2   565 _ADCCFG	=	0x00f2
                           0000F3   566 _P0SEL	=	0x00f3
                           0000F4   567 _P1SEL	=	0x00f4
                           0000F5   568 _P2SEL	=	0x00f5
                           0000F6   569 _P1INP	=	0x00f6
                           0000F7   570 _P2INP	=	0x00f7
                           0000F8   571 _U1CSR	=	0x00f8
                           0000F9   572 _U1DBUF	=	0x00f9
                           0000FA   573 _U1BAUD	=	0x00fa
                           0000FB   574 _U1UCR	=	0x00fb
                           0000FC   575 _U1GCR	=	0x00fc
                           0000FD   576 _P0DIR	=	0x00fd
                           0000FE   577 _P1DIR	=	0x00fe
                           0000FF   578 _P2DIR	=	0x00ff
                                    579 ;--------------------------------------------------------
                                    580 ; special function bits
                                    581 ;--------------------------------------------------------
                                    582 	.area RSEG    (ABS,DATA)
      000000                        583 	.org 0x0000
                           000080   584 _P0_0	=	0x0080
                           000081   585 _P0_1	=	0x0081
                           000082   586 _P0_2	=	0x0082
                           000083   587 _P0_3	=	0x0083
                           000084   588 _P0_4	=	0x0084
                           000085   589 _P0_5	=	0x0085
                           000086   590 _P0_6	=	0x0086
                           000087   591 _P0_7	=	0x0087
                           000088   592 _IT0	=	0x0088
                           000089   593 _RFTXRXIF	=	0x0089
                           00008A   594 _IT1	=	0x008a
                           00008B   595 _URX0IF	=	0x008b
                           00008D   596 _ADCIF	=	0x008d
                           00008F   597 _URX1IF	=	0x008f
                           000090   598 _P1_0	=	0x0090
                           000091   599 _P1_1	=	0x0091
                           000092   600 _P1_2	=	0x0092
                           000093   601 _P1_3	=	0x0093
                           000094   602 _P1_4	=	0x0094
                           000095   603 _P1_5	=	0x0095
                           000096   604 _P1_6	=	0x0096
                           000097   605 _P1_7	=	0x0097
                           000098   606 _ENCIF_0	=	0x0098
                           000099   607 _ENCIF_1	=	0x0099
                           0000A0   608 _P2_0	=	0x00a0
                           0000A1   609 _P2_1	=	0x00a1
                           0000A2   610 _P2_2	=	0x00a2
                           0000A3   611 _P2_3	=	0x00a3
                           0000A4   612 _P2_4	=	0x00a4
                           0000A5   613 _P2_5	=	0x00a5
                           0000A6   614 _P2_6	=	0x00a6
                           0000A7   615 _P2_7	=	0x00a7
                           0000A8   616 _RFTXRXIE	=	0x00a8
                           0000A9   617 _ADCIE	=	0x00a9
                           0000AA   618 _URX0IE	=	0x00aa
                           0000AB   619 _URX1IE	=	0x00ab
                           0000AC   620 _ENCIE	=	0x00ac
                           0000AD   621 _STIE	=	0x00ad
                           0000AF   622 _EA	=	0x00af
                           0000B8   623 _DMAIE	=	0x00b8
                           0000B9   624 _T1IE	=	0x00b9
                           0000BA   625 _T2IE	=	0x00ba
                           0000BB   626 _T3IE	=	0x00bb
                           0000BC   627 _T4IE	=	0x00bc
                           0000BD   628 _P0IE	=	0x00bd
                           0000C0   629 _DMAIF	=	0x00c0
                           0000C1   630 _T1IF	=	0x00c1
                           0000C2   631 _T2IF	=	0x00c2
                           0000C3   632 _T3IF	=	0x00c3
                           0000C4   633 _T4IF	=	0x00c4
                           0000C5   634 _P0IF	=	0x00c5
                           0000C7   635 _STIF	=	0x00c7
                           0000D0   636 _P	=	0x00d0
                           0000D1   637 _F1	=	0x00d1
                           0000D2   638 _OV	=	0x00d2
                           0000D3   639 _RS0	=	0x00d3
                           0000D4   640 _RS1	=	0x00d4
                           0000D5   641 _F0	=	0x00d5
                           0000D6   642 _AC	=	0x00d6
                           0000D7   643 _CY	=	0x00d7
                           0000D8   644 _T3OVFIF	=	0x00d8
                           0000D9   645 _T3CH0IF	=	0x00d9
                           0000DA   646 _T3CH1IF	=	0x00da
                           0000DB   647 _T4OVFIF	=	0x00db
                           0000DC   648 _T4CH0IF	=	0x00dc
                           0000DD   649 _T4CH1IF	=	0x00dd
                           0000DE   650 _OVFIM	=	0x00de
                           0000E0   651 _ACC_0	=	0x00e0
                           0000E1   652 _ACC_1	=	0x00e1
                           0000E2   653 _ACC_2	=	0x00e2
                           0000E3   654 _ACC_3	=	0x00e3
                           0000E4   655 _ACC_4	=	0x00e4
                           0000E5   656 _ACC_5	=	0x00e5
                           0000E6   657 _ACC_6	=	0x00e6
                           0000E7   658 _ACC_7	=	0x00e7
                           0000E8   659 _P2IF	=	0x00e8
                           0000E9   660 _UTX0IF	=	0x00e9
                           0000EA   661 _UTX1IF	=	0x00ea
                           0000EB   662 _P1IF	=	0x00eb
                           0000EC   663 _WDTIF	=	0x00ec
                           0000F0   664 _B_0	=	0x00f0
                           0000F1   665 _B_1	=	0x00f1
                           0000F2   666 _B_2	=	0x00f2
                           0000F3   667 _B_3	=	0x00f3
                           0000F4   668 _B_4	=	0x00f4
                           0000F5   669 _B_5	=	0x00f5
                           0000F6   670 _B_6	=	0x00f6
                           0000F7   671 _B_7	=	0x00f7
                           0000F8   672 _ACTIVE	=	0x00f8
                           0000F9   673 _TX_BYTE	=	0x00f9
                           0000FA   674 _RX_BYTE	=	0x00fa
                           0000FB   675 _ERR	=	0x00fb
                           0000FC   676 _FE	=	0x00fc
                           0000FD   677 _SLAVE	=	0x00fd
                           0000FE   678 _RE	=	0x00fe
                           0000FF   679 _MODE	=	0x00ff
                                    680 ;--------------------------------------------------------
                                    681 ; overlayable register banks
                                    682 ;--------------------------------------------------------
                                    683 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        684 	.ds 8
                                    685 ;--------------------------------------------------------
                                    686 ; internal ram data
                                    687 ;--------------------------------------------------------
                                    688 	.area DSEG    (DATA)
                                    689 ;--------------------------------------------------------
                                    690 ; overlayable items in internal ram 
                                    691 ;--------------------------------------------------------
                                    692 ;--------------------------------------------------------
                                    693 ; indirectly addressable internal ram data
                                    694 ;--------------------------------------------------------
                                    695 	.area ISEG    (DATA)
                                    696 ;--------------------------------------------------------
                                    697 ; absolute internal ram data
                                    698 ;--------------------------------------------------------
                                    699 	.area IABS    (ABS,DATA)
                                    700 	.area IABS    (ABS,DATA)
                                    701 ;--------------------------------------------------------
                                    702 ; bit data
                                    703 ;--------------------------------------------------------
                                    704 	.area BSEG    (BIT)
                                    705 ;--------------------------------------------------------
                                    706 ; paged external ram data
                                    707 ;--------------------------------------------------------
                                    708 	.area PSEG    (PAG,XDATA)
      00F000                        709 _go_to_sleep_i_65536_43:
      00F000                        710 	.ds 2
                                    711 ;--------------------------------------------------------
                                    712 ; external ram data
                                    713 ;--------------------------------------------------------
                                    714 	.area XSEG    (XDATA)
                           00DF02   715 _MDMCTRL0H	=	0xdf02
                           00DF00   716 _SYNC1	=	0xdf00
                           00DF01   717 _SYNC0	=	0xdf01
                           00DF02   718 _PKTLEN	=	0xdf02
                           00DF03   719 _PKTCTRL1	=	0xdf03
                           00DF04   720 _PKTCTRL0	=	0xdf04
                           00DF05   721 _ADDR	=	0xdf05
                           00DF06   722 _CHANNR	=	0xdf06
                           00DF07   723 _FSCTRL1	=	0xdf07
                           00DF08   724 _FSCTRL0	=	0xdf08
                           00DF09   725 _FREQ2	=	0xdf09
                           00DF0A   726 _FREQ1	=	0xdf0a
                           00DF0B   727 _FREQ0	=	0xdf0b
                           00DF0C   728 _MDMCFG4	=	0xdf0c
                           00DF0D   729 _MDMCFG3	=	0xdf0d
                           00DF0E   730 _MDMCFG2	=	0xdf0e
                           00DF0F   731 _MDMCFG1	=	0xdf0f
                           00DF10   732 _MDMCFG0	=	0xdf10
                           00DF11   733 _DEVIATN	=	0xdf11
                           00DF12   734 _MCSM2	=	0xdf12
                           00DF13   735 _MCSM1	=	0xdf13
                           00DF14   736 _MCSM0	=	0xdf14
                           00DF15   737 _FOCCFG	=	0xdf15
                           00DF16   738 _BSCFG	=	0xdf16
                           00DF17   739 _AGCCTRL2	=	0xdf17
                           00DF18   740 _AGCCTRL1	=	0xdf18
                           00DF19   741 _AGCCTRL0	=	0xdf19
                           00DF1A   742 _FREND1	=	0xdf1a
                           00DF1B   743 _FREND0	=	0xdf1b
                           00DF1C   744 _FSCAL3	=	0xdf1c
                           00DF1D   745 _FSCAL2	=	0xdf1d
                           00DF1E   746 _FSCAL1	=	0xdf1e
                           00DF1F   747 _FSCAL0	=	0xdf1f
                           00DF20   748 __XREGDF20	=	0xdf20
                           00DF21   749 __XREGDF21	=	0xdf21
                           00DF22   750 __XREGDF22	=	0xdf22
                           00DF23   751 _TEST2	=	0xdf23
                           00DF24   752 _TEST1	=	0xdf24
                           00DF25   753 _TEST0	=	0xdf25
                           00DF26   754 __XREGDF26	=	0xdf26
                           00DF27   755 _PA_TABLE7	=	0xdf27
                           00DF28   756 _PA_TABLE6	=	0xdf28
                           00DF29   757 _PA_TABLE5	=	0xdf29
                           00DF2A   758 _PA_TABLE4	=	0xdf2a
                           00DF2B   759 _PA_TABLE3	=	0xdf2b
                           00DF2C   760 _PA_TABLE2	=	0xdf2c
                           00DF2D   761 _PA_TABLE1	=	0xdf2d
                           00DF2E   762 _PA_TABLE0	=	0xdf2e
                           00DF2F   763 _IOCFG2	=	0xdf2f
                           00DF30   764 _IOCFG1	=	0xdf30
                           00DF31   765 _IOCFG0	=	0xdf31
                           00DF32   766 __XREGDF32	=	0xdf32
                           00DF33   767 __XREGDF33	=	0xdf33
                           00DF34   768 __XREGDF34	=	0xdf34
                           00DF35   769 __XREGDF35	=	0xdf35
                           00DF36   770 _PARTNUM	=	0xdf36
                           00DF37   771 _VERSION	=	0xdf37
                           00DF38   772 _FREQEST	=	0xdf38
                           00DF39   773 _LQI	=	0xdf39
                           00DF3A   774 _RSSI	=	0xdf3a
                           00DF3B   775 _MARCSTATE	=	0xdf3b
                           00DF3C   776 _PKTSTATUS	=	0xdf3c
                           00DF3D   777 _VCO_VC_DAC	=	0xdf3d
                           00DF40   778 _I2SCFG0	=	0xdf40
                           00DF41   779 _I2SCFG1	=	0xdf41
                           00DF42   780 _I2SDATL	=	0xdf42
                           00DF43   781 _I2SDATH	=	0xdf43
                           00DF44   782 _I2SWCNT	=	0xdf44
                           00DF45   783 _I2SSTAT	=	0xdf45
                           00DF46   784 _I2SCLKF0	=	0xdf46
                           00DF47   785 _I2SCLKF1	=	0xdf47
                           00DF48   786 _I2SCLKF2	=	0xdf48
                           00DF80   787 __NA_P0	=	0xdf80
                           00DF81   788 __NA_SP	=	0xdf81
                           00DF82   789 __NA_DPL0	=	0xdf82
                           00DF83   790 __NA_DPH0	=	0xdf83
                           00DF84   791 __NA_DPL1	=	0xdf84
                           00DF85   792 __NA_DPH1	=	0xdf85
                           00DF86   793 _X_U0CSR	=	0xdf86
                           00DF87   794 __NA_PCON	=	0xdf87
                           00DF88   795 __NA_TCON	=	0xdf88
                           00DF89   796 _X_P0IFG	=	0xdf89
                           00DF8A   797 _X_P1IFG	=	0xdf8a
                           00DF8B   798 _X_P2IFG	=	0xdf8b
                           00DF8C   799 _X_PICTL	=	0xdf8c
                           00DF8D   800 _X_P1IEN	=	0xdf8d
                           00DF8E   801 __X_SFR8E	=	0xdf8e
                           00DF8F   802 _X_P0INP	=	0xdf8f
                           00DF90   803 __NA_P1	=	0xdf90
                           00DF91   804 _X_RFIM	=	0xdf91
                           00DF92   805 __NA_DPS	=	0xdf92
                           00DF93   806 _X_MPAGE	=	0xdf93
                           00DF94   807 __X_SFR94	=	0xdf94
                           00DF95   808 __X_SFR95	=	0xdf95
                           00DF96   809 __X_SFR96	=	0xdf96
                           00DF97   810 __X_SFR97	=	0xdf97
                           00DF98   811 __NA_S0CON	=	0xdf98
                           00DF99   812 __X_SFR99	=	0xdf99
                           00DF9A   813 __NA_IEN2	=	0xdf9a
                           00DF9B   814 __NA_S1CON	=	0xdf9b
                           00DF9C   815 _X_T2CT	=	0xdf9c
                           00DF9D   816 _X_T2PR	=	0xdf9d
                           00DF9E   817 _X_T2CTL	=	0xdf9e
                           00DF9F   818 __X_SFR9F	=	0xdf9f
                           00DFA0   819 __NA_P2	=	0xdfa0
                           00DFA1   820 _X_WORIRQ	=	0xdfa1
                           00DFA2   821 _X_WORCTRL	=	0xdfa2
                           00DFA3   822 _X_WOREVT0	=	0xdfa3
                           00DFA4   823 _X_WOREVT1	=	0xdfa4
                           00DFA5   824 _X_WORTIME0	=	0xdfa5
                           00DFA6   825 _X_WORTIME1	=	0xdfa6
                           00DFA7   826 __X_SFRA7	=	0xdfa7
                           00DFA8   827 __NA_IEN0	=	0xdfa8
                           00DFA9   828 __NA_IP0	=	0xdfa9
                           00DFAA   829 __X_SFRAA	=	0xdfaa
                           00DFAB   830 _X_FWT	=	0xdfab
                           00DFAC   831 _X_FADDRL	=	0xdfac
                           00DFAD   832 _X_FADDRH	=	0xdfad
                           00DFAE   833 _X_FCTL	=	0xdfae
                           00DFAF   834 _X_FWDATA	=	0xdfaf
                           00DFB0   835 __X_SFRB0	=	0xdfb0
                           00DFB1   836 _X_ENCDI	=	0xdfb1
                           00DFB2   837 _X_ENCDO	=	0xdfb2
                           00DFB3   838 _X_ENCCS	=	0xdfb3
                           00DFB4   839 _X_ADCCON1	=	0xdfb4
                           00DFB5   840 _X_ADCCON2	=	0xdfb5
                           00DFB6   841 _X_ADCCON3	=	0xdfb6
                           00DFB7   842 __X_SFRB7	=	0xdfb7
                           00DFB8   843 __NA_IEN1	=	0xdfb8
                           00DFB9   844 __NA_IP1	=	0xdfb9
                           00DFBA   845 _X_ADCL	=	0xdfba
                           00DFBB   846 _X_ADCH	=	0xdfbb
                           00DFBC   847 _X_RNDL	=	0xdfbc
                           00DFBD   848 _X_RNDH	=	0xdfbd
                           00DFBE   849 _X_SLEEP	=	0xdfbe
                           00DFBF   850 __X_SFRBF	=	0xdfbf
                           00DFC0   851 __NA_IRCON	=	0xdfc0
                           00DFC1   852 _X_U0DBUF	=	0xdfc1
                           00DFC2   853 _X_U0BAUD	=	0xdfc2
                           00DFC3   854 __X_SFRC3	=	0xdfc3
                           00DFC4   855 _X_U0UCR	=	0xdfc4
                           00DFC5   856 _X_U0GCR	=	0xdfc5
                           00DFC6   857 _X_CLKCON	=	0xdfc6
                           00DFC7   858 _X_MEMCTR	=	0xdfc7
                           00DFC8   859 __X_SFRC8	=	0xdfc8
                           00DFC9   860 _X_WDCTL	=	0xdfc9
                           00DFCA   861 _X_T3CNT	=	0xdfca
                           00DFCB   862 _X_T3CTL	=	0xdfcb
                           00DFCC   863 _X_T3CCTL0	=	0xdfcc
                           00DFCD   864 _X_T3CC0	=	0xdfcd
                           00DFCE   865 _X_T3CCTL1	=	0xdfce
                           00DFCF   866 _X_T3CC1	=	0xdfcf
                           00DFD0   867 __NA_PSW	=	0xdfd0
                           00DFD1   868 _X_DMAIRQ	=	0xdfd1
                           00DFD2   869 _X_DMA1CFGL	=	0xdfd2
                           00DFD3   870 _X_DMA1CFGH	=	0xdfd3
                           00DFD4   871 _X_DMA0CFGL	=	0xdfd4
                           00DFD5   872 _X_DMA0CFGH	=	0xdfd5
                           00DFD6   873 _X_DMAARM	=	0xdfd6
                           00DFD7   874 _X_DMAREQ	=	0xdfd7
                           00DFD8   875 _X_TIMIF	=	0xdfd8
                           00DFD9   876 _X_RFD	=	0xdfd9
                           00DFDA   877 _X_T1CC0L	=	0xdfda
                           00DFDB   878 _X_T1CC0H	=	0xdfdb
                           00DFDC   879 _X_T1CC1L	=	0xdfdc
                           00DFDD   880 _X_T1CC1H	=	0xdfdd
                           00DFDE   881 _X_T1CC2L	=	0xdfde
                           00DFDF   882 _X_T1CC2H	=	0xdfdf
                           00DFE0   883 __NA_ACC	=	0xdfe0
                           00DFE1   884 _X_RFST	=	0xdfe1
                           00DFE2   885 _X_T1CNTL	=	0xdfe2
                           00DFE3   886 _X_T1CNTH	=	0xdfe3
                           00DFE4   887 _X_T1CTL	=	0xdfe4
                           00DFE5   888 _X_T1CCTL0	=	0xdfe5
                           00DFE6   889 _X_T1CCTL1	=	0xdfe6
                           00DFE7   890 _X_T1CCTL2	=	0xdfe7
                           00DFE8   891 __NA_IRCON2	=	0xdfe8
                           00DFE9   892 _X_RFIF	=	0xdfe9
                           00DFEA   893 _X_T4CNT	=	0xdfea
                           00DFEB   894 _X_T4CTL	=	0xdfeb
                           00DFEC   895 _X_T4CCTL0	=	0xdfec
                           00DFED   896 _X_T4CC0	=	0xdfed
                           00DFEE   897 _X_T4CCTL1	=	0xdfee
                           00DFEF   898 _X_T4CC1	=	0xdfef
                           00DFF0   899 __NA_B	=	0xdff0
                           00DFF1   900 _X_PERCFG	=	0xdff1
                           00DFF2   901 _X_ADCCFG	=	0xdff2
                           00DFF3   902 _X_P0SEL	=	0xdff3
                           00DFF4   903 _X_P1SEL	=	0xdff4
                           00DFF5   904 _X_P2SEL	=	0xdff5
                           00DFF6   905 _X_P1INP	=	0xdff6
                           00DFF7   906 _X_P2INP	=	0xdff7
                           00DFF8   907 _X_U1CSR	=	0xdff8
                           00DFF9   908 _X_U1DBUF	=	0xdff9
                           00DFFA   909 _X_U1BAUD	=	0xdffa
                           00DFFB   910 _X_U1UCR	=	0xdffb
                           00DFFC   911 _X_U1GCR	=	0xdffc
                           00DFFD   912 _X_P0DIR	=	0xdffd
                           00DFFE   913 _X_P1DIR	=	0xdffe
                           00DFFF   914 _X_P2DIR	=	0xdfff
      00F0B6                        915 _subg_rfspy_init_finished::
      00F0B6                        916 	.ds 1
      00F0B7                        917 _subg_rfspy_should_exit::
      00F0B7                        918 	.ds 1
                                    919 ;--------------------------------------------------------
                                    920 ; absolute external ram data
                                    921 ;--------------------------------------------------------
                                    922 	.area XABS    (ABS,XDATA)
                                    923 ;--------------------------------------------------------
                                    924 ; external initialized ram data
                                    925 ;--------------------------------------------------------
                                    926 	.area XISEG   (XDATA)
                                    927 	.area HOME    (CODE)
                                    928 	.area GSINIT0 (CODE)
                                    929 	.area GSINIT1 (CODE)
                                    930 	.area GSINIT2 (CODE)
                                    931 	.area GSINIT3 (CODE)
                                    932 	.area GSINIT4 (CODE)
                                    933 	.area GSINIT5 (CODE)
                                    934 	.area GSINIT  (CODE)
                                    935 	.area GSFINAL (CODE)
                                    936 	.area CSEG    (CODE)
                                    937 ;--------------------------------------------------------
                                    938 ; global & static initialisations
                                    939 ;--------------------------------------------------------
                                    940 	.area HOME    (CODE)
                                    941 	.area GSINIT  (CODE)
                                    942 	.area GSFINAL (CODE)
                                    943 	.area GSINIT  (CODE)
                                    944 ;--------------------------------------------------------
                                    945 ; Home
                                    946 ;--------------------------------------------------------
                                    947 	.area HOME    (CODE)
                                    948 	.area HOME    (CODE)
                                    949 ;--------------------------------------------------------
                                    950 ; code
                                    951 ;--------------------------------------------------------
                                    952 	.area CSEG    (CODE)
                                    953 ;------------------------------------------------------------
                                    954 ;Allocation info for local variables in function 'port1_isr'
                                    955 ;------------------------------------------------------------
                                    956 ;	subg_rfspy.c:20: void port1_isr(void) __interrupt P1INT_VECTOR
                                    957 ;	-----------------------------------------
                                    958 ;	 function port1_isr
                                    959 ;	-----------------------------------------
      00010F                        960 _port1_isr:
                           000007   961 	ar7 = 0x07
                           000006   962 	ar6 = 0x06
                           000005   963 	ar5 = 0x05
                           000004   964 	ar4 = 0x04
                           000003   965 	ar3 = 0x03
                           000002   966 	ar2 = 0x02
                           000001   967 	ar1 = 0x01
                           000000   968 	ar0 = 0x00
                                    969 ;	subg_rfspy.c:25: P1IFG = 0;				//Clear P1 interrupt flags
      00010F 75 8A 00         [24]  970 	mov	_P1IFG,#0x00
                                    971 ;	subg_rfspy.c:26: IRCON2 &= ~BIT3; 		//Clear P1IF cpu interrupt flag
      000112 53 E8 F7         [24]  972 	anl	_IRCON2,#0xf7
                                    973 ;	subg_rfspy.c:27: SLEEP &= 0xFC; 			//
      000115 53 BE FC         [24]  974 	anl	_SLEEP,#0xfc
                                    975 ;	subg_rfspy.c:28: }
      000118 32               [24]  976 	reti
                                    977 ;	eliminated unneeded mov psw,# (no regs used in bank)
                                    978 ;	eliminated unneeded push/pop not_psw
                                    979 ;	eliminated unneeded push/pop dpl
                                    980 ;	eliminated unneeded push/pop dph
                                    981 ;	eliminated unneeded push/pop b
                                    982 ;	eliminated unneeded push/pop acc
                                    983 ;------------------------------------------------------------
                                    984 ;Allocation info for local variables in function 'go_to_sleep'
                                    985 ;------------------------------------------------------------
                                    986 ;	subg_rfspy.c:30: void go_to_sleep() {
                                    987 ;	-----------------------------------------
                                    988 ;	 function go_to_sleep
                                    989 ;	-----------------------------------------
      000119                        990 _go_to_sleep:
                                    991 ;	subg_rfspy.c:31: volatile uint16_t i=50;
      000119 78 00            [12]  992 	mov	r0,#_go_to_sleep_i_65536_43
      00011B 74 32            [12]  993 	mov	a,#0x32
      00011D F2               [24]  994 	movx	@r0,a
      00011E 08               [12]  995 	inc	r0
      00011F E4               [12]  996 	clr	a
      000120 F2               [24]  997 	movx	@r0,a
                                    998 ;	subg_rfspy.c:35: IRCON2 &= ~P1IF; 	//Clear P1IF
      000121 A2 EB            [12]  999 	mov	c,_P1IF
      000123 E4               [12] 1000 	clr	a
      000124 33               [12] 1001 	rlc	a
      000125 F4               [12] 1002 	cpl	a
      000126 FF               [12] 1003 	mov	r7,a
      000127 52 E8            [12] 1004 	anl	_IRCON2,a
                                   1005 ;	subg_rfspy.c:36: P1IFG = 0;			//Clear IF for all P1 pins
      000129 75 8A 00         [24] 1006 	mov	_P1IFG,#0x00
                                   1007 ;	subg_rfspy.c:37: IEN2 |= BIT4;    	//Enable P1IE interrupt
      00012C 43 9A 10         [24] 1008 	orl	_IEN2,#0x10
                                   1009 ;	subg_rfspy.c:38: P1IEN |= BIT2;		//Enable P1_2 interrupt
      00012F 43 8D 04         [24] 1010 	orl	_P1IEN,#0x04
                                   1011 ;	subg_rfspy.c:40: P1_2 = 1;		//going to sleep, don't disturb me unless you have a new command for me
                                   1012 ;	assignBit
      000132 D2 92            [12] 1013 	setb	_P1_2
                                   1014 ;	subg_rfspy.c:41: P1DIR &= ~BIT2;	//P1_2 as input
      000134 53 FE FB         [24] 1015 	anl	_P1DIR,#0xfb
                                   1016 ;	subg_rfspy.c:43: SLEEP = (SLEEP & 0xFC) | 0x01;
      000137 E5 BE            [12] 1017 	mov	a,_SLEEP
      000139 54 FC            [12] 1018 	anl	a,#0xfc
      00013B 44 01            [12] 1019 	orl	a,#0x01
      00013D F5 BE            [12] 1020 	mov	_SLEEP,a
                                   1021 ;	subg_rfspy.c:48: __endasm;
      00013F 00               [12] 1022 	nop
      000140 00               [12] 1023 	nop
      000141 00               [12] 1024 	nop
                                   1025 ;	subg_rfspy.c:52: if (SLEEP & 0x03) { 
      000142 E5 BE            [12] 1026 	mov	a,_SLEEP
      000144 54 03            [12] 1027 	anl	a,#0x03
      000146 60 04            [24] 1028 	jz	00103$
                                   1029 ;	subg_rfspy.c:53: PCON |= 0x01;	//activate PM1
      000148 43 87 01         [24] 1030 	orl	_PCON,#0x01
                                   1031 ;	subg_rfspy.c:57: __endasm;
      00014B 00               [12] 1032 	nop
                                   1033 ;	subg_rfspy.c:60: while(i--);  					//Wait until [HS XOSC] is stable following errata C (software delay)
      00014C                       1034 00103$:
      00014C 78 00            [12] 1035 	mov	r0,#_go_to_sleep_i_65536_43
      00014E E2               [24] 1036 	movx	a,@r0
      00014F FE               [12] 1037 	mov	r6,a
      000150 08               [12] 1038 	inc	r0
      000151 E2               [24] 1039 	movx	a,@r0
      000152 FF               [12] 1040 	mov	r7,a
      000153 78 00            [12] 1041 	mov	r0,#_go_to_sleep_i_65536_43
      000155 EE               [12] 1042 	mov	a,r6
      000156 24 FF            [12] 1043 	add	a,#0xff
      000158 F2               [24] 1044 	movx	@r0,a
      000159 EF               [12] 1045 	mov	a,r7
      00015A 34 FF            [12] 1046 	addc	a,#0xff
      00015C 08               [12] 1047 	inc	r0
      00015D F2               [24] 1048 	movx	@r0,a
      00015E EE               [12] 1049 	mov	a,r6
      00015F 4F               [12] 1050 	orl	a,r7
      000160 70 EA            [24] 1051 	jnz	00103$
                                   1052 ;	subg_rfspy.c:61: while(!(SLEEP & 0x40));			// Monitor SLEEP.XOSC_STB to ensure the HS XOSC is stable before continuing
      000162                       1053 00106$:
      000162 E5 BE            [12] 1054 	mov	a,_SLEEP
      000164 30 E6 FB         [24] 1055 	jnb	acc.6,00106$
                                   1056 ;	subg_rfspy.c:62: SLEEP |= 0x04;					// Set SLEEP.OSC_PD to power down the HS RCOSC
      000167 43 BE 04         [24] 1057 	orl	_SLEEP,#0x04
                                   1058 ;	subg_rfspy.c:64: IRCON2 &= ~P1IF; 	//Clear P1IF
      00016A A2 EB            [12] 1059 	mov	c,_P1IF
      00016C E4               [12] 1060 	clr	a
      00016D 33               [12] 1061 	rlc	a
      00016E F4               [12] 1062 	cpl	a
      00016F 52 E8            [12] 1063 	anl	_IRCON2,a
                                   1064 ;	subg_rfspy.c:65: P1IFG = 0;			//Clear IF for all P1 pins
      000171 75 8A 00         [24] 1065 	mov	_P1IFG,#0x00
                                   1066 ;	subg_rfspy.c:66: IEN2 &= ~BIT4;    	//Disable P1IE interrupt
      000174 53 9A EF         [24] 1067 	anl	_IEN2,#0xef
                                   1068 ;	subg_rfspy.c:67: P1IEN &= ~BIT2;		//Disable P1_2 interrupt
      000177 53 8D FB         [24] 1069 	anl	_P1IEN,#0xfb
                                   1070 ;	subg_rfspy.c:69: P1_2 = 0;		//I'm awake and doing something usefull
                                   1071 ;	assignBit
      00017A C2 92            [12] 1072 	clr	_P1_2
                                   1073 ;	subg_rfspy.c:70: P1DIR |= BIT2;	//P1_2 as output to signal to BLE
      00017C 43 FE 04         [24] 1074 	orl	_P1DIR,#0x04
                                   1075 ;	subg_rfspy.c:73: }
      00017F 22               [24] 1076 	ret
                                   1077 ;------------------------------------------------------------
                                   1078 ;Allocation info for local variables in function 'subg_rfspy_main'
                                   1079 ;------------------------------------------------------------
                                   1080 ;	subg_rfspy.c:75: void subg_rfspy_main() {
                                   1081 ;	-----------------------------------------
                                   1082 ;	 function subg_rfspy_main
                                   1083 ;	-----------------------------------------
      000180                       1084 _subg_rfspy_main:
                                   1085 ;	subg_rfspy.c:76: SLEEP &= ~SLEEP_OSC_PD;
      000180 53 BE FB         [24] 1086 	anl	_SLEEP,#0xfb
                                   1087 ;	subg_rfspy.c:77: while( !(SLEEP & SLEEP_XOSC_S) );
      000183                       1088 00101$:
      000183 E5 BE            [12] 1089 	mov	a,_SLEEP
      000185 30 E6 FB         [24] 1090 	jnb	acc.6,00101$
                                   1091 ;	subg_rfspy.c:82: CLKCON =  0xA8;			//CLKSPD = 24Mhz, TICKSPD = 750Khz
      000188 75 C6 A8         [24] 1092 	mov	_CLKCON,#0xa8
                                   1093 ;	subg_rfspy.c:83: while (CLKCON & CLKCON_OSC);
      00018B                       1094 00104$:
      00018B E5 C6            [12] 1095 	mov	a,_CLKCON
      00018D 20 E6 FB         [24] 1096 	jb	acc.6,00104$
                                   1097 ;	subg_rfspy.c:84: SLEEP |= SLEEP_OSC_PD;
      000190 43 BE 04         [24] 1098 	orl	_SLEEP,#0x04
                                   1099 ;	subg_rfspy.c:86: P2DIR |= BIT1;			//activate P2_1 as output for debugging
      000193 43 FF 02         [24] 1100 	orl	_P2DIR,#0x02
                                   1101 ;	subg_rfspy.c:87: P2_1 = 1;					//activate debug
                                   1102 ;	assignBit
      000196 D2 A1            [12] 1103 	setb	_P2_1
                                   1104 ;	subg_rfspy.c:88: P2_1 = 0;					//pulse to show it works
                                   1105 ;	assignBit
      000198 C2 A1            [12] 1106 	clr	_P2_1
                                   1107 ;	subg_rfspy.c:89: P2_1 = 1;					//
                                   1108 ;	assignBit
      00019A D2 A1            [12] 1109 	setb	_P2_1
                                   1110 ;	subg_rfspy.c:91: IOCFG1 |= IOCFG1_GDO_DS; 		//In applications where the digital I/O power supply voltage VDD on pin DVDD is below 2.6 V, the register bit IOCFG1.GDO_DS should be set to 1.
      00019C 90 DF 30         [24] 1111 	mov	dptr,#_IOCFG1
      00019F E0               [24] 1112 	movx	a,@dptr
      0001A0 43 E0 80         [24] 1113 	orl	acc,#0x80
      0001A3 F0               [24] 1114 	movx	@dptr,a
                                   1115 ;	subg_rfspy.c:93: PICTL |= 0x02; 		//P1ICON = 1 (Falling edge interrupt on Port 1)
      0001A4 43 8C 02         [24] 1116 	orl	_PICTL,#0x02
                                   1117 ;	subg_rfspy.c:95: init_timer();
      0001A7 12 0B F0         [24] 1118 	lcall	_init_timer
                                   1119 ;	subg_rfspy.c:96: EA = 1;		  // Global interrupt enable
                                   1120 ;	assignBit
      0001AA D2 AF            [12] 1121 	setb	_EA
                                   1122 ;	subg_rfspy.c:98: configure_serial();
      0001AC 12 20 46         [24] 1123 	lcall	_configure_serial
                                   1124 ;	subg_rfspy.c:99: configure_radio();
      0001AF 12 01 C7         [24] 1125 	lcall	_configure_radio
                                   1126 ;	subg_rfspy.c:101: subg_rfspy_init_finished = true;
      0001B2 90 F0 B6         [24] 1127 	mov	dptr,#_subg_rfspy_init_finished
      0001B5 74 01            [12] 1128 	mov	a,#0x01
      0001B7 F0               [24] 1129 	movx	@dptr,a
                                   1130 ;	subg_rfspy.c:105: while(!subg_rfspy_should_exit) {
      0001B8                       1131 00107$:
      0001B8 90 F0 B7         [24] 1132 	mov	dptr,#_subg_rfspy_should_exit
      0001BB E0               [24] 1133 	movx	a,@dptr
      0001BC 70 08            [24] 1134 	jnz	00110$
                                   1135 ;	subg_rfspy.c:106: go_to_sleep(); 	//nothing to do yet, wait for the wake-up call from BLE module
      0001BE 12 01 19         [24] 1136 	lcall	_go_to_sleep
                                   1137 ;	subg_rfspy.c:107: get_command();
      0001C1 12 16 F2         [24] 1138 	lcall	_get_command
      0001C4 80 F2            [24] 1139 	sjmp	00107$
      0001C6                       1140 00110$:
                                   1141 ;	subg_rfspy.c:110: }
      0001C6 22               [24] 1142 	ret
                                   1143 	.area CSEG    (CODE)
                                   1144 	.area CONST   (CODE)
                                   1145 	.area XINIT   (CODE)
                                   1146 	.area CABS    (ABS,CODE)
