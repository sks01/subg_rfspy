;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.2 #11662 (MINGW64)
;--------------------------------------------------------
	.module radio
	.optsdcc -mmcs51 --model-medium
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _rf_isr
	.globl _rftxrx_isr
	.globl _init_decoder
	.globl _init_encoder
	.globl _delay
	.globl _serial_rx_byte
	.globl _serial_tx_byte
	.globl _mode_registers_enact
	.globl _memset
	.globl _MODE
	.globl _RE
	.globl _SLAVE
	.globl _FE
	.globl _ERR
	.globl _RX_BYTE
	.globl _TX_BYTE
	.globl _ACTIVE
	.globl _B_7
	.globl _B_6
	.globl _B_5
	.globl _B_4
	.globl _B_3
	.globl _B_2
	.globl _B_1
	.globl _B_0
	.globl _WDTIF
	.globl _P1IF
	.globl _UTX1IF
	.globl _UTX0IF
	.globl _P2IF
	.globl _ACC_7
	.globl _ACC_6
	.globl _ACC_5
	.globl _ACC_4
	.globl _ACC_3
	.globl _ACC_2
	.globl _ACC_1
	.globl _ACC_0
	.globl _OVFIM
	.globl _T4CH1IF
	.globl _T4CH0IF
	.globl _T4OVFIF
	.globl _T3CH1IF
	.globl _T3CH0IF
	.globl _T3OVFIF
	.globl _CY
	.globl _AC
	.globl _F0
	.globl _RS1
	.globl _RS0
	.globl _OV
	.globl _F1
	.globl _P
	.globl _STIF
	.globl _P0IF
	.globl _T4IF
	.globl _T3IF
	.globl _T2IF
	.globl _T1IF
	.globl _DMAIF
	.globl _P0IE
	.globl _T4IE
	.globl _T3IE
	.globl _T2IE
	.globl _T1IE
	.globl _DMAIE
	.globl _EA
	.globl _STIE
	.globl _ENCIE
	.globl _URX1IE
	.globl _URX0IE
	.globl _ADCIE
	.globl _RFTXRXIE
	.globl _P2_7
	.globl _P2_6
	.globl _P2_5
	.globl _P2_4
	.globl _P2_3
	.globl _P2_2
	.globl _P2_1
	.globl _P2_0
	.globl _ENCIF_1
	.globl _ENCIF_0
	.globl _P1_7
	.globl _P1_6
	.globl _P1_5
	.globl _P1_4
	.globl _P1_3
	.globl _P1_2
	.globl _P1_1
	.globl _P1_0
	.globl _URX1IF
	.globl _ADCIF
	.globl _URX0IF
	.globl _IT1
	.globl _RFTXRXIF
	.globl _IT0
	.globl _P0_7
	.globl _P0_6
	.globl _P0_5
	.globl _P0_4
	.globl _P0_3
	.globl _P0_2
	.globl _P0_1
	.globl _P0_0
	.globl _P2DIR
	.globl _P1DIR
	.globl _P0DIR
	.globl _U1GCR
	.globl _U1UCR
	.globl _U1BAUD
	.globl _U1DBUF
	.globl _U1CSR
	.globl _P2INP
	.globl _P1INP
	.globl _P2SEL
	.globl _P1SEL
	.globl _P0SEL
	.globl _ADCCFG
	.globl _PERCFG
	.globl _B
	.globl _T4CC1
	.globl _T4CCTL1
	.globl _T4CC0
	.globl _T4CCTL0
	.globl _T4CTL
	.globl _T4CNT
	.globl _RFIF
	.globl _IRCON2
	.globl _T1CCTL2
	.globl _T1CCTL1
	.globl _T1CCTL0
	.globl _T1CTL
	.globl _T1CNTH
	.globl _T1CNTL
	.globl _RFST
	.globl _ACC
	.globl _T1CC2H
	.globl _T1CC2L
	.globl _T1CC1H
	.globl _T1CC1L
	.globl _T1CC0H
	.globl _T1CC0L
	.globl _RFD
	.globl _TIMIF
	.globl _DMAREQ
	.globl _DMAARM
	.globl _DMA0CFGH
	.globl _DMA0CFGL
	.globl _DMA1CFGH
	.globl _DMA1CFGL
	.globl _DMAIRQ
	.globl _PSW
	.globl _T3CC1
	.globl _T3CCTL1
	.globl _T3CC0
	.globl _T3CCTL0
	.globl _T3CTL
	.globl _T3CNT
	.globl _WDCTL
	.globl __SFRC8
	.globl _MEMCTR
	.globl _CLKCON
	.globl _U0GCR
	.globl _U0UCR
	.globl __SFRC3
	.globl _U0BAUD
	.globl _U0DBUF
	.globl _IRCON
	.globl __SFRBF
	.globl _SLEEP
	.globl _RNDH
	.globl _RNDL
	.globl _ADCH
	.globl _ADCL
	.globl _IP1
	.globl _IEN1
	.globl __SFRB7
	.globl _ADCCON3
	.globl _ADCCON2
	.globl _ADCCON1
	.globl _ENCCS
	.globl _ENCDO
	.globl _ENCDI
	.globl __SFRB0
	.globl _FWDATA
	.globl _FCTL
	.globl _FADDRH
	.globl _FADDRL
	.globl _FWT
	.globl __SFRAA
	.globl _IP0
	.globl _IEN0
	.globl __SFRA7
	.globl _WORTIME1
	.globl _WORTIME0
	.globl _WOREVT1
	.globl _WOREVT0
	.globl _WORCTRL
	.globl _WORIRQ
	.globl _P2
	.globl __SFR9F
	.globl _T2CTL
	.globl _T2PR
	.globl _T2CT
	.globl _S1CON
	.globl _IEN2
	.globl __SFR99
	.globl _S0CON
	.globl __SFR97
	.globl __SFR96
	.globl __SFR95
	.globl __SFR94
	.globl __XPAGE
	.globl _MPAGE
	.globl _DPS
	.globl _RFIM
	.globl _P1
	.globl _P0INP
	.globl __SFR8E
	.globl _P1IEN
	.globl _PICTL
	.globl _P2IFG
	.globl _P1IFG
	.globl _P0IFG
	.globl _TCON
	.globl _PCON
	.globl _U0CSR
	.globl _DPH1
	.globl _DPL1
	.globl _DPH0
	.globl _DPL0
	.globl _SP
	.globl _P0
	.globl _X_P2DIR
	.globl _X_P1DIR
	.globl _X_P0DIR
	.globl _X_U1GCR
	.globl _X_U1UCR
	.globl _X_U1BAUD
	.globl _X_U1DBUF
	.globl _X_U1CSR
	.globl _X_P2INP
	.globl _X_P1INP
	.globl _X_P2SEL
	.globl _X_P1SEL
	.globl _X_P0SEL
	.globl _X_ADCCFG
	.globl _X_PERCFG
	.globl __NA_B
	.globl _X_T4CC1
	.globl _X_T4CCTL1
	.globl _X_T4CC0
	.globl _X_T4CCTL0
	.globl _X_T4CTL
	.globl _X_T4CNT
	.globl _X_RFIF
	.globl __NA_IRCON2
	.globl _X_T1CCTL2
	.globl _X_T1CCTL1
	.globl _X_T1CCTL0
	.globl _X_T1CTL
	.globl _X_T1CNTH
	.globl _X_T1CNTL
	.globl _X_RFST
	.globl __NA_ACC
	.globl _X_T1CC2H
	.globl _X_T1CC2L
	.globl _X_T1CC1H
	.globl _X_T1CC1L
	.globl _X_T1CC0H
	.globl _X_T1CC0L
	.globl _X_RFD
	.globl _X_TIMIF
	.globl _X_DMAREQ
	.globl _X_DMAARM
	.globl _X_DMA0CFGH
	.globl _X_DMA0CFGL
	.globl _X_DMA1CFGH
	.globl _X_DMA1CFGL
	.globl _X_DMAIRQ
	.globl __NA_PSW
	.globl _X_T3CC1
	.globl _X_T3CCTL1
	.globl _X_T3CC0
	.globl _X_T3CCTL0
	.globl _X_T3CTL
	.globl _X_T3CNT
	.globl _X_WDCTL
	.globl __X_SFRC8
	.globl _X_MEMCTR
	.globl _X_CLKCON
	.globl _X_U0GCR
	.globl _X_U0UCR
	.globl __X_SFRC3
	.globl _X_U0BAUD
	.globl _X_U0DBUF
	.globl __NA_IRCON
	.globl __X_SFRBF
	.globl _X_SLEEP
	.globl _X_RNDH
	.globl _X_RNDL
	.globl _X_ADCH
	.globl _X_ADCL
	.globl __NA_IP1
	.globl __NA_IEN1
	.globl __X_SFRB7
	.globl _X_ADCCON3
	.globl _X_ADCCON2
	.globl _X_ADCCON1
	.globl _X_ENCCS
	.globl _X_ENCDO
	.globl _X_ENCDI
	.globl __X_SFRB0
	.globl _X_FWDATA
	.globl _X_FCTL
	.globl _X_FADDRH
	.globl _X_FADDRL
	.globl _X_FWT
	.globl __X_SFRAA
	.globl __NA_IP0
	.globl __NA_IEN0
	.globl __X_SFRA7
	.globl _X_WORTIME1
	.globl _X_WORTIME0
	.globl _X_WOREVT1
	.globl _X_WOREVT0
	.globl _X_WORCTRL
	.globl _X_WORIRQ
	.globl __NA_P2
	.globl __X_SFR9F
	.globl _X_T2CTL
	.globl _X_T2PR
	.globl _X_T2CT
	.globl __NA_S1CON
	.globl __NA_IEN2
	.globl __X_SFR99
	.globl __NA_S0CON
	.globl __X_SFR97
	.globl __X_SFR96
	.globl __X_SFR95
	.globl __X_SFR94
	.globl _X_MPAGE
	.globl __NA_DPS
	.globl _X_RFIM
	.globl __NA_P1
	.globl _X_P0INP
	.globl __X_SFR8E
	.globl _X_P1IEN
	.globl _X_PICTL
	.globl _X_P2IFG
	.globl _X_P1IFG
	.globl _X_P0IFG
	.globl __NA_TCON
	.globl __NA_PCON
	.globl _X_U0CSR
	.globl __NA_DPH1
	.globl __NA_DPL1
	.globl __NA_DPH0
	.globl __NA_DPL0
	.globl __NA_SP
	.globl __NA_P0
	.globl _I2SCLKF2
	.globl _I2SCLKF1
	.globl _I2SCLKF0
	.globl _I2SSTAT
	.globl _I2SWCNT
	.globl _I2SDATH
	.globl _I2SDATL
	.globl _I2SCFG1
	.globl _I2SCFG0
	.globl _VCO_VC_DAC
	.globl _PKTSTATUS
	.globl _MARCSTATE
	.globl _RSSI
	.globl _LQI
	.globl _FREQEST
	.globl _VERSION
	.globl _PARTNUM
	.globl __XREGDF35
	.globl __XREGDF34
	.globl __XREGDF33
	.globl __XREGDF32
	.globl _IOCFG0
	.globl _IOCFG1
	.globl _IOCFG2
	.globl _PA_TABLE0
	.globl _PA_TABLE1
	.globl _PA_TABLE2
	.globl _PA_TABLE3
	.globl _PA_TABLE4
	.globl _PA_TABLE5
	.globl _PA_TABLE6
	.globl _PA_TABLE7
	.globl __XREGDF26
	.globl _TEST0
	.globl _TEST1
	.globl _TEST2
	.globl __XREGDF22
	.globl __XREGDF21
	.globl __XREGDF20
	.globl _FSCAL0
	.globl _FSCAL1
	.globl _FSCAL2
	.globl _FSCAL3
	.globl _FREND0
	.globl _FREND1
	.globl _AGCCTRL0
	.globl _AGCCTRL1
	.globl _AGCCTRL2
	.globl _BSCFG
	.globl _FOCCFG
	.globl _MCSM0
	.globl _MCSM1
	.globl _MCSM2
	.globl _DEVIATN
	.globl _MDMCFG0
	.globl _MDMCFG1
	.globl _MDMCFG2
	.globl _MDMCFG3
	.globl _MDMCFG4
	.globl _FREQ0
	.globl _FREQ1
	.globl _FREQ2
	.globl _FSCTRL0
	.globl _FSCTRL1
	.globl _CHANNR
	.globl _ADDR
	.globl _PKTCTRL0
	.globl _PKTCTRL1
	.globl _PKTLEN
	.globl _SYNC0
	.globl _SYNC1
	.globl _MDMCTRL0H
	.globl _get_packet_and_write_to_serial_PARM_3
	.globl _get_packet_and_write_to_serial_PARM_2
	.globl _send_from_tx_buf_PARM_2
	.globl _send_packet_from_serial_PARM_5
	.globl _send_packet_from_serial_PARM_4
	.globl _send_packet_from_serial_PARM_3
	.globl _send_packet_from_serial_PARM_2
	.globl _encoding_type
	.globl _tx_state
	.globl _configure_radio
	.globl _set_encoding_type
	.globl _send_packet_from_serial
	.globl _send_from_tx_buf
	.globl _get_packet_and_write_to_serial
	.globl _radio_set_preamble
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_P0	=	0x0080
_SP	=	0x0081
_DPL0	=	0x0082
_DPH0	=	0x0083
_DPL1	=	0x0084
_DPH1	=	0x0085
_U0CSR	=	0x0086
_PCON	=	0x0087
_TCON	=	0x0088
_P0IFG	=	0x0089
_P1IFG	=	0x008a
_P2IFG	=	0x008b
_PICTL	=	0x008c
_P1IEN	=	0x008d
__SFR8E	=	0x008e
_P0INP	=	0x008f
_P1	=	0x0090
_RFIM	=	0x0091
_DPS	=	0x0092
_MPAGE	=	0x0093
__XPAGE	=	0x0093
__SFR94	=	0x0094
__SFR95	=	0x0095
__SFR96	=	0x0096
__SFR97	=	0x0097
_S0CON	=	0x0098
__SFR99	=	0x0099
_IEN2	=	0x009a
_S1CON	=	0x009b
_T2CT	=	0x009c
_T2PR	=	0x009d
_T2CTL	=	0x009e
__SFR9F	=	0x009f
_P2	=	0x00a0
_WORIRQ	=	0x00a1
_WORCTRL	=	0x00a2
_WOREVT0	=	0x00a3
_WOREVT1	=	0x00a4
_WORTIME0	=	0x00a5
_WORTIME1	=	0x00a6
__SFRA7	=	0x00a7
_IEN0	=	0x00a8
_IP0	=	0x00a9
__SFRAA	=	0x00aa
_FWT	=	0x00ab
_FADDRL	=	0x00ac
_FADDRH	=	0x00ad
_FCTL	=	0x00ae
_FWDATA	=	0x00af
__SFRB0	=	0x00b0
_ENCDI	=	0x00b1
_ENCDO	=	0x00b2
_ENCCS	=	0x00b3
_ADCCON1	=	0x00b4
_ADCCON2	=	0x00b5
_ADCCON3	=	0x00b6
__SFRB7	=	0x00b7
_IEN1	=	0x00b8
_IP1	=	0x00b9
_ADCL	=	0x00ba
_ADCH	=	0x00bb
_RNDL	=	0x00bc
_RNDH	=	0x00bd
_SLEEP	=	0x00be
__SFRBF	=	0x00bf
_IRCON	=	0x00c0
_U0DBUF	=	0x00c1
_U0BAUD	=	0x00c2
__SFRC3	=	0x00c3
_U0UCR	=	0x00c4
_U0GCR	=	0x00c5
_CLKCON	=	0x00c6
_MEMCTR	=	0x00c7
__SFRC8	=	0x00c8
_WDCTL	=	0x00c9
_T3CNT	=	0x00ca
_T3CTL	=	0x00cb
_T3CCTL0	=	0x00cc
_T3CC0	=	0x00cd
_T3CCTL1	=	0x00ce
_T3CC1	=	0x00cf
_PSW	=	0x00d0
_DMAIRQ	=	0x00d1
_DMA1CFGL	=	0x00d2
_DMA1CFGH	=	0x00d3
_DMA0CFGL	=	0x00d4
_DMA0CFGH	=	0x00d5
_DMAARM	=	0x00d6
_DMAREQ	=	0x00d7
_TIMIF	=	0x00d8
_RFD	=	0x00d9
_T1CC0L	=	0x00da
_T1CC0H	=	0x00db
_T1CC1L	=	0x00dc
_T1CC1H	=	0x00dd
_T1CC2L	=	0x00de
_T1CC2H	=	0x00df
_ACC	=	0x00e0
_RFST	=	0x00e1
_T1CNTL	=	0x00e2
_T1CNTH	=	0x00e3
_T1CTL	=	0x00e4
_T1CCTL0	=	0x00e5
_T1CCTL1	=	0x00e6
_T1CCTL2	=	0x00e7
_IRCON2	=	0x00e8
_RFIF	=	0x00e9
_T4CNT	=	0x00ea
_T4CTL	=	0x00eb
_T4CCTL0	=	0x00ec
_T4CC0	=	0x00ed
_T4CCTL1	=	0x00ee
_T4CC1	=	0x00ef
_B	=	0x00f0
_PERCFG	=	0x00f1
_ADCCFG	=	0x00f2
_P0SEL	=	0x00f3
_P1SEL	=	0x00f4
_P2SEL	=	0x00f5
_P1INP	=	0x00f6
_P2INP	=	0x00f7
_U1CSR	=	0x00f8
_U1DBUF	=	0x00f9
_U1BAUD	=	0x00fa
_U1UCR	=	0x00fb
_U1GCR	=	0x00fc
_P0DIR	=	0x00fd
_P1DIR	=	0x00fe
_P2DIR	=	0x00ff
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_P0_0	=	0x0080
_P0_1	=	0x0081
_P0_2	=	0x0082
_P0_3	=	0x0083
_P0_4	=	0x0084
_P0_5	=	0x0085
_P0_6	=	0x0086
_P0_7	=	0x0087
_IT0	=	0x0088
_RFTXRXIF	=	0x0089
_IT1	=	0x008a
_URX0IF	=	0x008b
_ADCIF	=	0x008d
_URX1IF	=	0x008f
_P1_0	=	0x0090
_P1_1	=	0x0091
_P1_2	=	0x0092
_P1_3	=	0x0093
_P1_4	=	0x0094
_P1_5	=	0x0095
_P1_6	=	0x0096
_P1_7	=	0x0097
_ENCIF_0	=	0x0098
_ENCIF_1	=	0x0099
_P2_0	=	0x00a0
_P2_1	=	0x00a1
_P2_2	=	0x00a2
_P2_3	=	0x00a3
_P2_4	=	0x00a4
_P2_5	=	0x00a5
_P2_6	=	0x00a6
_P2_7	=	0x00a7
_RFTXRXIE	=	0x00a8
_ADCIE	=	0x00a9
_URX0IE	=	0x00aa
_URX1IE	=	0x00ab
_ENCIE	=	0x00ac
_STIE	=	0x00ad
_EA	=	0x00af
_DMAIE	=	0x00b8
_T1IE	=	0x00b9
_T2IE	=	0x00ba
_T3IE	=	0x00bb
_T4IE	=	0x00bc
_P0IE	=	0x00bd
_DMAIF	=	0x00c0
_T1IF	=	0x00c1
_T2IF	=	0x00c2
_T3IF	=	0x00c3
_T4IF	=	0x00c4
_P0IF	=	0x00c5
_STIF	=	0x00c7
_P	=	0x00d0
_F1	=	0x00d1
_OV	=	0x00d2
_RS0	=	0x00d3
_RS1	=	0x00d4
_F0	=	0x00d5
_AC	=	0x00d6
_CY	=	0x00d7
_T3OVFIF	=	0x00d8
_T3CH0IF	=	0x00d9
_T3CH1IF	=	0x00da
_T4OVFIF	=	0x00db
_T4CH0IF	=	0x00dc
_T4CH1IF	=	0x00dd
_OVFIM	=	0x00de
_ACC_0	=	0x00e0
_ACC_1	=	0x00e1
_ACC_2	=	0x00e2
_ACC_3	=	0x00e3
_ACC_4	=	0x00e4
_ACC_5	=	0x00e5
_ACC_6	=	0x00e6
_ACC_7	=	0x00e7
_P2IF	=	0x00e8
_UTX0IF	=	0x00e9
_UTX1IF	=	0x00ea
_P1IF	=	0x00eb
_WDTIF	=	0x00ec
_B_0	=	0x00f0
_B_1	=	0x00f1
_B_2	=	0x00f2
_B_3	=	0x00f3
_B_4	=	0x00f4
_B_5	=	0x00f5
_B_6	=	0x00f6
_B_7	=	0x00f7
_ACTIVE	=	0x00f8
_TX_BYTE	=	0x00f9
_RX_BYTE	=	0x00fa
_ERR	=	0x00fb
_FE	=	0x00fc
_SLAVE	=	0x00fd
_RE	=	0x00fe
_MODE	=	0x00ff
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_get_packet_and_write_to_serial_sloc0_1_0:
	.ds 2
_get_packet_and_write_to_serial_sloc1_1_0:
	.ds 1
_get_packet_and_write_to_serial_sloc2_1_0:
	.ds 4
_get_packet_and_write_to_serial_sloc3_1_0:
	.ds 3
_get_packet_and_write_to_serial_sloc4_1_0:
	.ds 3
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_send_packet_from_serial_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
_rx_len:
	.ds 1
_stop_custom_preamble_semaphore:
	.ds 1
_tx_state::
	.ds 1
_encoding_type::
	.ds 1
_send_packet_from_serial_PARM_2:
	.ds 1
_send_packet_from_serial_PARM_3:
	.ds 2
_send_packet_from_serial_PARM_4:
	.ds 2
_send_packet_from_serial_PARM_5:
	.ds 1
_send_packet_from_serial_channel_65536_127:
	.ds 1
_send_packet_from_serial_s_byte_65536_128:
	.ds 1
_send_packet_from_serial_encoder_65536_128:
	.ds 4
_send_packet_from_serial_encoder_state_65536_128:
	.ds 3
_send_from_tx_buf_PARM_2:
	.ds 2
_get_packet_and_write_to_serial_PARM_2:
	.ds 4
_get_packet_and_write_to_serial_PARM_3:
	.ds 1
_get_packet_and_write_to_serial___1310720043_131072_145:
	.ds 1
_get_packet_and_write_to_serial_read_idx_65536_145:
	.ds 1
_get_packet_and_write_to_serial_d_byte_65536_145:
	.ds 1
_get_packet_and_write_to_serial_rval_65536_145:
	.ds 1
_get_packet_and_write_to_serial_timer_start_65536_145:
	.ds 4
_get_packet_and_write_to_serial___1966080033_196608_147:
	.ds 1
_get_packet_and_write_to_serial_b_327680_169:
	.ds 3
_get_packet_and_write_to_serial___1310720012_393216_170:
	.ds 1
_get_packet_and_write_to_serial_rval_327680_180:
	.ds 1
_get_packet_and_write_to_serial_b_262144_188:
	.ds 3
_get_packet_and_write_to_serial___1310720012_327680_189:
	.ds 1
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_MDMCTRL0H	=	0xdf02
_SYNC1	=	0xdf00
_SYNC0	=	0xdf01
_PKTLEN	=	0xdf02
_PKTCTRL1	=	0xdf03
_PKTCTRL0	=	0xdf04
_ADDR	=	0xdf05
_CHANNR	=	0xdf06
_FSCTRL1	=	0xdf07
_FSCTRL0	=	0xdf08
_FREQ2	=	0xdf09
_FREQ1	=	0xdf0a
_FREQ0	=	0xdf0b
_MDMCFG4	=	0xdf0c
_MDMCFG3	=	0xdf0d
_MDMCFG2	=	0xdf0e
_MDMCFG1	=	0xdf0f
_MDMCFG0	=	0xdf10
_DEVIATN	=	0xdf11
_MCSM2	=	0xdf12
_MCSM1	=	0xdf13
_MCSM0	=	0xdf14
_FOCCFG	=	0xdf15
_BSCFG	=	0xdf16
_AGCCTRL2	=	0xdf17
_AGCCTRL1	=	0xdf18
_AGCCTRL0	=	0xdf19
_FREND1	=	0xdf1a
_FREND0	=	0xdf1b
_FSCAL3	=	0xdf1c
_FSCAL2	=	0xdf1d
_FSCAL1	=	0xdf1e
_FSCAL0	=	0xdf1f
__XREGDF20	=	0xdf20
__XREGDF21	=	0xdf21
__XREGDF22	=	0xdf22
_TEST2	=	0xdf23
_TEST1	=	0xdf24
_TEST0	=	0xdf25
__XREGDF26	=	0xdf26
_PA_TABLE7	=	0xdf27
_PA_TABLE6	=	0xdf28
_PA_TABLE5	=	0xdf29
_PA_TABLE4	=	0xdf2a
_PA_TABLE3	=	0xdf2b
_PA_TABLE2	=	0xdf2c
_PA_TABLE1	=	0xdf2d
_PA_TABLE0	=	0xdf2e
_IOCFG2	=	0xdf2f
_IOCFG1	=	0xdf30
_IOCFG0	=	0xdf31
__XREGDF32	=	0xdf32
__XREGDF33	=	0xdf33
__XREGDF34	=	0xdf34
__XREGDF35	=	0xdf35
_PARTNUM	=	0xdf36
_VERSION	=	0xdf37
_FREQEST	=	0xdf38
_LQI	=	0xdf39
_RSSI	=	0xdf3a
_MARCSTATE	=	0xdf3b
_PKTSTATUS	=	0xdf3c
_VCO_VC_DAC	=	0xdf3d
_I2SCFG0	=	0xdf40
_I2SCFG1	=	0xdf41
_I2SDATL	=	0xdf42
_I2SDATH	=	0xdf43
_I2SWCNT	=	0xdf44
_I2SSTAT	=	0xdf45
_I2SCLKF0	=	0xdf46
_I2SCLKF1	=	0xdf47
_I2SCLKF2	=	0xdf48
__NA_P0	=	0xdf80
__NA_SP	=	0xdf81
__NA_DPL0	=	0xdf82
__NA_DPH0	=	0xdf83
__NA_DPL1	=	0xdf84
__NA_DPH1	=	0xdf85
_X_U0CSR	=	0xdf86
__NA_PCON	=	0xdf87
__NA_TCON	=	0xdf88
_X_P0IFG	=	0xdf89
_X_P1IFG	=	0xdf8a
_X_P2IFG	=	0xdf8b
_X_PICTL	=	0xdf8c
_X_P1IEN	=	0xdf8d
__X_SFR8E	=	0xdf8e
_X_P0INP	=	0xdf8f
__NA_P1	=	0xdf90
_X_RFIM	=	0xdf91
__NA_DPS	=	0xdf92
_X_MPAGE	=	0xdf93
__X_SFR94	=	0xdf94
__X_SFR95	=	0xdf95
__X_SFR96	=	0xdf96
__X_SFR97	=	0xdf97
__NA_S0CON	=	0xdf98
__X_SFR99	=	0xdf99
__NA_IEN2	=	0xdf9a
__NA_S1CON	=	0xdf9b
_X_T2CT	=	0xdf9c
_X_T2PR	=	0xdf9d
_X_T2CTL	=	0xdf9e
__X_SFR9F	=	0xdf9f
__NA_P2	=	0xdfa0
_X_WORIRQ	=	0xdfa1
_X_WORCTRL	=	0xdfa2
_X_WOREVT0	=	0xdfa3
_X_WOREVT1	=	0xdfa4
_X_WORTIME0	=	0xdfa5
_X_WORTIME1	=	0xdfa6
__X_SFRA7	=	0xdfa7
__NA_IEN0	=	0xdfa8
__NA_IP0	=	0xdfa9
__X_SFRAA	=	0xdfaa
_X_FWT	=	0xdfab
_X_FADDRL	=	0xdfac
_X_FADDRH	=	0xdfad
_X_FCTL	=	0xdfae
_X_FWDATA	=	0xdfaf
__X_SFRB0	=	0xdfb0
_X_ENCDI	=	0xdfb1
_X_ENCDO	=	0xdfb2
_X_ENCCS	=	0xdfb3
_X_ADCCON1	=	0xdfb4
_X_ADCCON2	=	0xdfb5
_X_ADCCON3	=	0xdfb6
__X_SFRB7	=	0xdfb7
__NA_IEN1	=	0xdfb8
__NA_IP1	=	0xdfb9
_X_ADCL	=	0xdfba
_X_ADCH	=	0xdfbb
_X_RNDL	=	0xdfbc
_X_RNDH	=	0xdfbd
_X_SLEEP	=	0xdfbe
__X_SFRBF	=	0xdfbf
__NA_IRCON	=	0xdfc0
_X_U0DBUF	=	0xdfc1
_X_U0BAUD	=	0xdfc2
__X_SFRC3	=	0xdfc3
_X_U0UCR	=	0xdfc4
_X_U0GCR	=	0xdfc5
_X_CLKCON	=	0xdfc6
_X_MEMCTR	=	0xdfc7
__X_SFRC8	=	0xdfc8
_X_WDCTL	=	0xdfc9
_X_T3CNT	=	0xdfca
_X_T3CTL	=	0xdfcb
_X_T3CCTL0	=	0xdfcc
_X_T3CC0	=	0xdfcd
_X_T3CCTL1	=	0xdfce
_X_T3CC1	=	0xdfcf
__NA_PSW	=	0xdfd0
_X_DMAIRQ	=	0xdfd1
_X_DMA1CFGL	=	0xdfd2
_X_DMA1CFGH	=	0xdfd3
_X_DMA0CFGL	=	0xdfd4
_X_DMA0CFGH	=	0xdfd5
_X_DMAARM	=	0xdfd6
_X_DMAREQ	=	0xdfd7
_X_TIMIF	=	0xdfd8
_X_RFD	=	0xdfd9
_X_T1CC0L	=	0xdfda
_X_T1CC0H	=	0xdfdb
_X_T1CC1L	=	0xdfdc
_X_T1CC1H	=	0xdfdd
_X_T1CC2L	=	0xdfde
_X_T1CC2H	=	0xdfdf
__NA_ACC	=	0xdfe0
_X_RFST	=	0xdfe1
_X_T1CNTL	=	0xdfe2
_X_T1CNTH	=	0xdfe3
_X_T1CTL	=	0xdfe4
_X_T1CCTL0	=	0xdfe5
_X_T1CCTL1	=	0xdfe6
_X_T1CCTL2	=	0xdfe7
__NA_IRCON2	=	0xdfe8
_X_RFIF	=	0xdfe9
_X_T4CNT	=	0xdfea
_X_T4CTL	=	0xdfeb
_X_T4CCTL0	=	0xdfec
_X_T4CC0	=	0xdfed
_X_T4CCTL1	=	0xdfee
_X_T4CC1	=	0xdfef
__NA_B	=	0xdff0
_X_PERCFG	=	0xdff1
_X_ADCCFG	=	0xdff2
_X_P0SEL	=	0xdff3
_X_P1SEL	=	0xdff4
_X_P2SEL	=	0xdff5
_X_P1INP	=	0xdff6
_X_P2INP	=	0xdff7
_X_U1CSR	=	0xdff8
_X_U1DBUF	=	0xdff9
_X_U1BAUD	=	0xdffa
_X_U1UCR	=	0xdffb
_X_U1GCR	=	0xdffc
_X_P0DIR	=	0xdffd
_X_P1DIR	=	0xdffe
_X_P2DIR	=	0xdfff
_radio_rx_buf:
	.ds 32
_rx_fifo:
	.ds 6
_radio_tx_buf:
	.ds 255
_radio_tx_buf_read_idx:
	.ds 1
_radio_tx_buf_len:
	.ds 1
_preamble_word:
	.ds 2
_get_packet_and_write_to_serial_decoder_65536_145:
	.ds 4
_get_packet_and_write_to_serial_decoder_state_65536_145:
	.ds 6
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;	radio.c:51: EncodingType encoding_type = EncodingTypeNone;
	mov	r0,#_encoding_type
	clr	a
	movx	@r0,a
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'configure_radio'
;------------------------------------------------------------
;	radio.c:53: void configure_radio()
;	-----------------------------------------
;	 function configure_radio
;	-----------------------------------------
_configure_radio:
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	radio.c:56: SYNC1     = 0xFF; // sync word, high byte
	mov	dptr,#_SYNC1
	mov	a,#0xff
	movx	@dptr,a
;	radio.c:57: SYNC0     = 0x00; // sync word, low byte
	mov	dptr,#_SYNC0
	clr	a
	movx	@dptr,a
;	radio.c:58: PKTLEN    = 0xFF; // packet length
	mov	dptr,#_PKTLEN
	dec	a
	movx	@dptr,a
;	radio.c:59: PKTCTRL1  = 0x00; // packet automation control
	mov	dptr,#_PKTCTRL1
	clr	a
	movx	@dptr,a
;	radio.c:60: PKTCTRL0  = 0x00; // packet automation control
	mov	dptr,#_PKTCTRL0
	movx	@dptr,a
;	radio.c:61: ADDR      = 0x00;
	mov	dptr,#_ADDR
	movx	@dptr,a
;	radio.c:63: FSCTRL1   = 0x06; // frequency synthesizer control
	mov	dptr,#_FSCTRL1
	mov	a,#0x06
	movx	@dptr,a
;	radio.c:64: FSCTRL0   = 0x00;
	mov	dptr,#_FSCTRL0
	clr	a
	movx	@dptr,a
;	radio.c:66: MDMCFG4   = 0x99; // 150.5 kHz rx filter bandwidth. Narrower can improve range,
	mov	dptr,#_MDMCFG4
	mov	a,#0x99
	movx	@dptr,a
;	radio.c:69: MDMCFG3   = 0x66; // modem configuration
	mov	dptr,#_MDMCFG3
	cpl	a
	movx	@dptr,a
;	radio.c:70: MDMCFG2   = 0x33; // modem configuration
	mov	dptr,#_MDMCFG2
	rr	a
	movx	@dptr,a
;	radio.c:71: MDMCFG1   = 0x61; // modem configuration
	mov	dptr,#_MDMCFG1
	mov	a,#0x61
	movx	@dptr,a
;	radio.c:72: MDMCFG0   = 0x7E; // modem configuration
	mov	dptr,#_MDMCFG0
	mov	a,#0x7e
	movx	@dptr,a
;	radio.c:73: DEVIATN   = 0x15; // modem deviation setting
	mov	dptr,#_DEVIATN
	mov	a,#0x15
	movx	@dptr,a
;	radio.c:74: MCSM2     = 0x07;
	mov	dptr,#_MCSM2
	mov	a,#0x07
	movx	@dptr,a
;	radio.c:75: MCSM1     = 0x30;
	mov	dptr,#_MCSM1
	mov	a,#0x30
	movx	@dptr,a
;	radio.c:76: MCSM0     = 0x18; // main radio control state machine configuration
	mov	dptr,#_MCSM0
	rr	a
	movx	@dptr,a
;	radio.c:77: FOCCFG    = 0x17; // frequency offset compensation configuration
	mov	dptr,#_FOCCFG
	dec	a
	movx	@dptr,a
;	radio.c:78: BSCFG     = 0x6C; // bit synchronization configuration
	mov	dptr,#_BSCFG
	mov	a,#0x6c
	movx	@dptr,a
;	radio.c:79: FREND1    = 0xB6; // front end tx configuration
	mov	dptr,#_FREND1
	mov	a,#0xb6
	movx	@dptr,a
;	radio.c:80: FREND0    = 0x11; // front end tx configuration
	mov	dptr,#_FREND0
	mov	a,#0x11
	movx	@dptr,a
;	radio.c:81: FSCAL3    = 0xE9; // frequency synthesizer calibration
	mov	dptr,#_FSCAL3
	mov	a,#0xe9
	movx	@dptr,a
;	radio.c:82: FSCAL2    = 0x2A; // frequency synthesizer calibration
	mov	dptr,#_FSCAL2
	mov	a,#0x2a
	movx	@dptr,a
;	radio.c:83: FSCAL1    = 0x00; // frequency synthesizer calibration
	mov	dptr,#_FSCAL1
	clr	a
	movx	@dptr,a
;	radio.c:84: FSCAL0    = 0x1F; // frequency synthesizer calibration
	mov	dptr,#_FSCAL0
	mov	a,#0x1f
	movx	@dptr,a
;	radio.c:85: TEST1     = 0x31; // various test settings
	mov	dptr,#_TEST1
	mov	a,#0x31
	movx	@dptr,a
;	radio.c:86: TEST0     = 0x09; // various test settings
	mov	dptr,#_TEST0
	mov	a,#0x09
	movx	@dptr,a
;	radio.c:87: PA_TABLE0 = 0x00; // needs to be explicitly set!
	mov	dptr,#_PA_TABLE0
	clr	a
	movx	@dptr,a
;	radio.c:90: AGCCTRL2 = 0x07; // 0x03 to 0x07 - default: 0x03
	mov	dptr,#_AGCCTRL2
	mov	a,#0x07
	movx	@dptr,a
;	radio.c:91: AGCCTRL1 = 0x00; // 0x00         - default: 0x40
	mov	dptr,#_AGCCTRL1
	clr	a
	movx	@dptr,a
;	radio.c:92: AGCCTRL0 = 0x91; // 0x91 or 0x92 - default: 0x91
	mov	dptr,#_AGCCTRL0
	mov	a,#0x91
	movx	@dptr,a
;	radio.c:95: FREQ2     = 0x26; // 916.541MHz is midpoint between freq of pump in free space,
	mov	dptr,#_FREQ2
	mov	a,#0x26
	movx	@dptr,a
;	radio.c:96: FREQ1     = 0x30; // and pump held close to the body.
	mov	dptr,#_FREQ1
	mov	a,#0x30
	movx	@dptr,a
;	radio.c:97: FREQ0     = 0x70; //
	mov	dptr,#_FREQ0
	mov	a,#0x70
	movx	@dptr,a
;	radio.c:98: CHANNR    = 0x02; // channel number
	mov	dptr,#_CHANNR
	mov	a,#0x02
	movx	@dptr,a
;	radio.c:99: PA_TABLE1 = 0xC0; // pa power setting 10 dBm
	mov	dptr,#_PA_TABLE1
	mov	a,#0xc0
	movx	@dptr,a
;	radio.c:108: IEN2 |= IEN2_RFIE;
	orl	_IEN2,#0x01
;	radio.c:109: RFTXRXIE = 1;
;	assignBit
	setb	_RFTXRXIE
;	radio.c:111: fifo_init(&rx_fifo, radio_rx_buf, RX_FIFO_SIZE);
;	fifo.h:71: if (b) {
	mov	a,#_rx_fifo
	orl	a,#(_rx_fifo >> 8)
	jz	00104$
;	fifo.h:72: b->head = 0;
	mov	dptr,#_rx_fifo
	clr	a
	movx	@dptr,a
;	fifo.h:73: b->tail = 0;
	mov	dptr,#(_rx_fifo + 0x0001)
	mov	b,#0x00
	lcall	__gptrput
;	fifo.h:74: b->buffer = buffer;
	mov	dptr,#(_rx_fifo + 0x0002)
	mov	b,#0x00
	mov	a,#_radio_rx_buf
	lcall	__gptrput
	inc	dptr
	mov	a,#(_radio_rx_buf >> 8)
	lcall	__gptrput
	inc	dptr
	clr	a
	lcall	__gptrput
;	fifo.h:75: b->buffer_len = size;
	mov	dptr,#(_rx_fifo + 0x0005)
	mov	b,#0x00
	mov	a,#0x20
;	radio.c:111: fifo_init(&rx_fifo, radio_rx_buf, RX_FIFO_SIZE);
;	radio.c:112: }
	ljmp	__gptrput
00104$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'set_encoding_type'
;------------------------------------------------------------
;	radio.c:115: bool set_encoding_type(EncodingType new_type) {
;	-----------------------------------------
;	 function set_encoding_type
;	-----------------------------------------
_set_encoding_type:
;	radio.c:116: if (new_type <= MaxEncodingTypeValue) {
	mov	a,dpl
	mov	r7,a
	add	a,#0xff - 0x02
	jc	00102$
;	radio.c:117: encoding_type = new_type;
	mov	r0,#_encoding_type
	mov	a,r7
	movx	@r0,a
;	radio.c:118: return true;
	mov	dpl,#0x01
	ret
00102$:
;	radio.c:120: return false;
	mov	dpl,#0x00
;	radio.c:122: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rftxrx_isr'
;------------------------------------------------------------
;	radio.c:132: void rftxrx_isr(void) __interrupt RFTXRX_VECTOR {
;	-----------------------------------------
;	 function rftxrx_isr
;	-----------------------------------------
_rftxrx_isr:
	push	acc
	push	b
	push	dpl
	push	dph
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	push	ar0
	push	psw
	mov	psw,#0x00
;	radio.c:134: CLKCON =  0xA8;		//CLKSPD = 24Mhz, TICKSPD = 750Khz
	mov	_CLKCON,#0xa8
;	radio.c:135: if (MARCSTATE==MARC_STATE_RX) {
	mov	dptr,#_MARCSTATE
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x0d,00171$
	sjmp	00172$
00171$:
	ljmp	00119$
00172$:
;	radio.c:136: d_byte = RFD;
	mov	r7,_RFD
;	radio.c:137: if (rx_len == 0) {
	mov	r0,#_rx_len
	movx	a,@r0
	jz	00173$
	ljmp	00102$
00173$:
;	radio.c:138: put_rx(RSSI);
	mov	dptr,#_RSSI
	movx	a,@dptr
	mov	r6,a
;	radio.c:125: if (rx_fifo.head - rx_fifo.tail == RX_FIFO_SIZE) radio_rx_fifo_overflow_count++;
	mov	dptr,#_rx_fifo
	movx	a,@dptr
	mov	r5,a
	mov	r4,#0x00
	mov	dptr,#(_rx_fifo + 0x0001)
	movx	a,@dptr
	mov	r3,a
	mov	r2,#0x00
	mov	a,r5
	clr	c
	subb	a,r3
	mov	r5,a
	mov	a,r4
	subb	a,r2
	mov	r4,a
	cjne	r5,#0x20,00122$
	cjne	r4,#0x00,00122$
	mov	r0,#_radio_rx_fifo_overflow_count
	movx	a,@r0
	mov	r4,a
	inc	r0
	movx	a,@r0
	mov	r5,a
	mov	r0,#_radio_rx_fifo_overflow_count
	mov	a,#0x01
	add	a,r4
	movx	@r0,a
	clr	a
	addc	a,r5
	inc	r0
	movx	@r0,a
	sjmp	00124$
00122$:
;	radio.c:127: rx_fifo.buffer[rx_fifo.head & RX_FIFO_MASK] = data; 
	push	ar7
	mov	dptr,#(_rx_fifo + 0x0002)
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_rx_fifo
	movx	a,@dptr
	mov	r2,a
	anl	ar2,#0x1f
	mov	r7,#0x00
	mov	a,r2
	add	a,r3
	mov	r3,a
	mov	a,r7
	addc	a,r4
	mov	r4,a
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
	mov	a,r6
	lcall	__gptrput
;	radio.c:128: rx_fifo.head++;
	mov	dptr,#_rx_fifo
	movx	a,@dptr
	mov	r7,a
	inc	r7
	mov	dptr,#_rx_fifo
	mov	a,r7
	movx	@dptr,a
;	radio.c:179: }
	pop	ar7
;	radio.c:138: put_rx(RSSI);
00124$:
;	radio.c:139: put_rx(packet_rx_count & 0xff);
	mov	r0,#_packet_rx_count
	movx	a,@r0
	mov	r6,a
;	radio.c:125: if (rx_fifo.head - rx_fifo.tail == RX_FIFO_SIZE) radio_rx_fifo_overflow_count++;
	mov	dptr,#_rx_fifo
	movx	a,@dptr
	mov	r5,a
	mov	r4,#0x00
	mov	dptr,#(_rx_fifo + 0x0001)
	movx	a,@dptr
	mov	r3,a
	mov	r2,#0x00
	mov	a,r5
	clr	c
	subb	a,r3
	mov	r5,a
	mov	a,r4
	subb	a,r2
	mov	r4,a
	cjne	r5,#0x20,00126$
	cjne	r4,#0x00,00126$
	mov	r0,#_radio_rx_fifo_overflow_count
	movx	a,@r0
	mov	r4,a
	inc	r0
	movx	a,@r0
	mov	r5,a
	mov	r0,#_radio_rx_fifo_overflow_count
	mov	a,#0x01
	add	a,r4
	movx	@r0,a
	clr	a
	addc	a,r5
	inc	r0
	movx	@r0,a
	sjmp	00128$
00126$:
;	radio.c:127: rx_fifo.buffer[rx_fifo.head & RX_FIFO_MASK] = data; 
	push	ar7
	mov	dptr,#(_rx_fifo + 0x0002)
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_rx_fifo
	movx	a,@dptr
	mov	r2,a
	anl	ar2,#0x1f
	mov	r7,#0x00
	mov	a,r2
	add	a,r3
	mov	r3,a
	mov	a,r7
	addc	a,r4
	mov	r4,a
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
	mov	a,r6
	lcall	__gptrput
;	radio.c:128: rx_fifo.head++;
	mov	dptr,#_rx_fifo
	movx	a,@dptr
	mov	r7,a
	inc	r7
	mov	dptr,#_rx_fifo
	mov	a,r7
	movx	@dptr,a
;	radio.c:179: }
	pop	ar7
;	radio.c:139: put_rx(packet_rx_count & 0xff);
00128$:
;	radio.c:140: rx_len = 2;
	mov	r0,#_rx_len
	mov	a,#0x02
	movx	@r0,a
00102$:
;	radio.c:125: if (rx_fifo.head - rx_fifo.tail == RX_FIFO_SIZE) radio_rx_fifo_overflow_count++;
	mov	dptr,#_rx_fifo
	movx	a,@dptr
	mov	r6,a
	mov	r5,#0x00
	mov	dptr,#(_rx_fifo + 0x0001)
	movx	a,@dptr
	mov	r4,a
	mov	r3,#0x00
	mov	a,r6
	clr	c
	subb	a,r4
	mov	r6,a
	mov	a,r5
	subb	a,r3
	mov	r5,a
	cjne	r6,#0x20,00130$
	cjne	r5,#0x00,00130$
	mov	r0,#_radio_rx_fifo_overflow_count
	movx	a,@r0
	mov	r5,a
	inc	r0
	movx	a,@r0
	mov	r6,a
	mov	r0,#_radio_rx_fifo_overflow_count
	mov	a,#0x01
	add	a,r5
	movx	@r0,a
	clr	a
	addc	a,r6
	inc	r0
	movx	@r0,a
	sjmp	00132$
00130$:
;	radio.c:127: rx_fifo.buffer[rx_fifo.head & RX_FIFO_MASK] = data; 
	mov	dptr,#(_rx_fifo + 0x0002)
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	mov	dptr,#_rx_fifo
	movx	a,@dptr
	mov	r3,a
	anl	ar3,#0x1f
	mov	r2,#0x00
	mov	a,r3
	add	a,r4
	mov	r4,a
	mov	a,r2
	addc	a,r5
	mov	r5,a
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	mov	a,r7
	lcall	__gptrput
;	radio.c:128: rx_fifo.head++;
	mov	dptr,#_rx_fifo
	movx	a,@dptr
	mov	r7,a
	inc	r7
	mov	dptr,#_rx_fifo
	mov	a,r7
	movx	@dptr,a
;	radio.c:142: put_rx(d_byte);
00132$:
;	radio.c:143: rx_len++;
	mov	r0,#_rx_len
	movx	a,@r0
	mov	r0,#_rx_len
	inc	a
	movx	@r0,a
	ljmp	00133$
00119$:
;	radio.c:145: else if (MARCSTATE==MARC_STATE_TX) {
	mov	dptr,#_MARCSTATE
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x13,00180$
	sjmp	00181$
00180$:
	ljmp	00133$
00181$:
;	radio.c:146: switch (tx_state) {
	mov	r0,#_tx_state
	movx	a,@r0
	mov  r7,a
	add	a,#0xff - 0x06
	jnc	00182$
	ljmp	00133$
00182$:
	mov	a,r7
	add	a,r7
;	radio.c:147: case TxStatePreambleByte0:
	mov	dptr,#00183$
	jmp	@a+dptr
00183$:
	sjmp	00103$
	sjmp	00104$
	sjmp	00133$
	sjmp	00109$
	sjmp	00108$
	sjmp	00110$
	sjmp	00133$
00103$:
;	radio.c:148: RFD = preamble_word >> 8;
	mov	dptr,#_preamble_word
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	_RFD,r7
;	radio.c:149: tx_state = TxStatePreambleByte1;
	mov	r0,#_tx_state
	mov	a,#0x01
	movx	@r0,a
;	radio.c:150: break;
;	radio.c:151: case TxStatePreambleByte1:
	sjmp	00133$
00104$:
;	radio.c:152: RFD = preamble_word & 0xff;
	mov	dptr,#_preamble_word
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	_RFD,r6
;	radio.c:153: if (stop_custom_preamble_semaphore) {
	mov	r0,#_stop_custom_preamble_semaphore
	movx	a,@r0
	jz	00106$
;	radio.c:154: tx_state = TxStateSync1;
	mov	r0,#_tx_state
	mov	a,#0x04
	movx	@r0,a
	sjmp	00133$
00106$:
;	radio.c:156: tx_state = TxStatePreambleByte0;
	mov	r0,#_tx_state
	clr	a
	movx	@r0,a
;	radio.c:158: break;
;	radio.c:159: case TxStateSync1:
	sjmp	00133$
00108$:
;	radio.c:160: RFD = SYNC1;
	mov	dptr,#_SYNC1
	movx	a,@dptr
	mov	_RFD,a
;	radio.c:161: tx_state = TxStateSync0;
	mov	r0,#_tx_state
	mov	a,#0x03
	movx	@r0,a
;	radio.c:162: break;
;	radio.c:163: case TxStateSync0:
	sjmp	00133$
00109$:
;	radio.c:164: RFD = SYNC0;
	mov	dptr,#_SYNC0
	movx	a,@dptr
	mov	_RFD,a
;	radio.c:165: tx_state = TxStateData;
	mov	r0,#_tx_state
	mov	a,#0x05
	movx	@r0,a
;	radio.c:166: break;
;	radio.c:167: case TxStateData:
	sjmp	00133$
00110$:
;	radio.c:168: RFD = radio_tx_buf[radio_tx_buf_read_idx++];
	mov	dptr,#_radio_tx_buf_read_idx
	movx	a,@dptr
	mov	r7,a
	inc	a
	movx	@dptr,a
	mov	a,r7
	add	a,#_radio_tx_buf
	mov	dpl,a
	clr	a
	addc	a,#(_radio_tx_buf >> 8)
	mov	dph,a
	movx	a,@dptr
	mov	_RFD,a
;	radio.c:169: if (radio_tx_buf_read_idx >= radio_tx_buf_len) {
	mov	dptr,#_radio_tx_buf_read_idx
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_radio_tx_buf_len
	movx	a,@dptr
	mov	r6,a
	clr	c
	mov	a,r7
	subb	a,r6
	jc	00133$
;	radio.c:170: tx_state = TxStateDone;
	mov	r0,#_tx_state
	mov	a,#0x06
	movx	@r0,a
;	radio.c:179: }
00133$:
;	radio.c:182: }
	pop	psw
	pop	ar0
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	pop	dph
	pop	dpl
	pop	b
	pop	acc
	reti
;	eliminated unneeded push/pop ar1
;------------------------------------------------------------
;Allocation info for local variables in function 'rf_isr'
;------------------------------------------------------------
;	radio.c:184: void rf_isr(void) __interrupt RF_VECTOR {
;	-----------------------------------------
;	 function rf_isr
;	-----------------------------------------
_rf_isr:
	push	acc
	push	ar7
	push	ar6
	push	ar0
	push	psw
	mov	psw,#0x00
;	radio.c:185: S1CON &= ~0x03; // Clear CPU interrupt flag
	anl	_S1CON,#0xfc
;	radio.c:186: if(RFIF & 0x80) // TX underflow
	mov	a,_RFIF
	jnb	acc.7,00107$
;	radio.c:189: RFST = RFST_SIDLE;
	mov	_RFST,#0x04
;	radio.c:190: RFIF &= ~0x80; // Clear module interrupt flag
	anl	_RFIF,#0x7f
	sjmp	00109$
00107$:
;	radio.c:192: else if(RFIF & 0x40) // RX overflow
	mov	a,_RFIF
	jnb	acc.6,00104$
;	radio.c:194: radio_rx_overflow_count++;
	mov	r0,#_radio_rx_overflow_count
	movx	a,@r0
	mov	r6,a
	inc	r0
	movx	a,@r0
	mov	r7,a
	mov	r0,#_radio_rx_overflow_count
	mov	a,#0x01
	add	a,r6
	movx	@r0,a
	clr	a
	addc	a,r7
	inc	r0
	movx	@r0,a
;	radio.c:195: RFIF &= ~0x40; // Clear module interrupt flag
	anl	_RFIF,#0xbf
	sjmp	00109$
00104$:
;	radio.c:197: else if(RFIF & 0x20) // RX timeout
	mov	a,_RFIF
	jnb	acc.5,00109$
;	radio.c:199: RFIF &= ~0x20; // Clear module interrupt flag
	anl	_RFIF,#0xdf
00109$:
;	radio.c:202: }
	pop	psw
	pop	ar0
	pop	ar6
	pop	ar7
	pop	acc
	reti
;	eliminated unneeded push/pop ar1
;	eliminated unneeded push/pop dpl
;	eliminated unneeded push/pop dph
;	eliminated unneeded push/pop b
;------------------------------------------------------------
;Allocation info for local variables in function 'send_packet_from_serial'
;------------------------------------------------------------
;	radio.c:204: void send_packet_from_serial(uint8_t channel, uint8_t repeat_count, uint16_t delay_ms, uint16_t preamble_extend_ms, uint8_t len) {
;	-----------------------------------------
;	 function send_packet_from_serial
;	-----------------------------------------
_send_packet_from_serial:
	mov	a,dpl
	mov	r0,#_send_packet_from_serial_channel_65536_127
	movx	@r0,a
;	radio.c:207: uint16_t total_send_count = repeat_count + 1;
	mov	r0,#_send_packet_from_serial_PARM_2
	movx	a,@r0
	mov	r5,a
	mov	r6,#0x00
	inc	r5
	cjne	r5,#0x00,00155$
	inc	r6
00155$:
;	radio.c:212: init_encoder(encoding_type, &encoder, &encoder_state);
	mov	r0,#_init_encoder_PARM_2
	mov	a,#_send_packet_from_serial_encoder_65536_128
	movx	@r0,a
	inc	r0
	clr	a
	movx	@r0,a
	inc	r0
	mov	a,#0x60
	movx	@r0,a
	mov	r0,#_init_encoder_PARM_3
	mov	a,#_send_packet_from_serial_encoder_state_65536_128
	movx	@r0,a
	inc	r0
	clr	a
	movx	@r0,a
	inc	r0
	mov	a,#0x60
	movx	@r0,a
	mov	r0,#_encoding_type
	movx	a,@r0
	mov	dpl,a
	push	ar6
	push	ar5
	lcall	_init_encoder
;	radio.c:214: mode_registers_enact(&tx_registers);
	mov	dptr,#_tx_registers
	mov	b,#0x00
	lcall	_mode_registers_enact
	pop	ar5
	pop	ar6
;	radio.c:216: CHANNR = channel;
	mov	r0,#_send_packet_from_serial_channel_65536_127
	mov	dptr,#_CHANNR
	movx	a,@r0
	movx	@dptr,a
;	radio.c:218: radio_tx_buf_len = 0;
	mov	dptr,#_radio_tx_buf_len
	clr	a
	movx	@dptr,a
;	radio.c:219: while (len > 0) {
	mov	r0,#_send_packet_from_serial_PARM_5
	movx	a,@r0
	mov	r4,a
00106$:
	mov	a,r4
	jnz	00156$
	ljmp	00125$
00156$:
;	radio.c:220: s_byte = serial_rx_byte();
	push	ar5
	push	ar6
	push	ar6
	push	ar5
	push	ar4
	lcall	_serial_rx_byte
	mov	r3,dpl
	pop	ar4
	pop	ar5
	pop	ar6
	mov	r0,#_send_packet_from_serial_s_byte_65536_128
	mov	a,r3
	movx	@r0,a
;	radio.c:221: len--;
	dec	r4
;	radio.c:222: encoder.add_raw_byte(&encoder_state, s_byte);
	mov	r0,#_send_packet_from_serial_encoder_65536_128
	movx	a,@r0
	mov	r2,a
	inc	r0
	movx	a,@r0
	mov	r6,a
	push	ar6
	push	ar5
	push	ar4
	push	ar2
	push	ar3
	lcall	00157$
	sjmp	00158$
00157$:
	push	ar2
	push	ar6
	mov	dptr,#_send_packet_from_serial_encoder_state_65536_128
	mov	b,#0x60
	ret
00158$:
	dec	sp
	pop	ar2
	pop	ar4
	pop	ar5
	pop	ar6
;	radio.c:223: while (encoder.next_encoded_byte(&encoder_state, &s_byte, len == 0)) {
	mov	a,r4
	cjne	a,#0x01,00159$
00159$:
	mov	_send_packet_from_serial_sloc0_1_0,c
;	radio.c:240: send_count++;
	pop	ar6
	pop	ar5
;	radio.c:223: while (encoder.next_encoded_byte(&encoder_state, &s_byte, len == 0)) {
00103$:
	mov	r0,#(_send_packet_from_serial_encoder_65536_128 + 0x0002)
	movx	a,@r0
	mov	r2,a
	inc	r0
	movx	a,@r0
	mov	r3,a
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	mov	c,_send_packet_from_serial_sloc0_1_0
	clr	a
	rlc	a
	push	acc
	mov	a,#_send_packet_from_serial_s_byte_65536_128
	push	acc
	mov	a,#(_send_packet_from_serial_s_byte_65536_128 >> 8)
	push	acc
	mov	a,#0x60
	push	acc
	lcall	00160$
	sjmp	00161$
00160$:
	push	ar2
	push	ar3
	mov	dptr,#_send_packet_from_serial_encoder_state_65536_128
	mov	b,#0x60
	ret
00161$:
	mov	r2,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	mov	a,r2
	jnz	00162$
	ljmp	00106$
00162$:
;	radio.c:224: if (radio_tx_buf_len+1 < TX_BUF_SIZE) {
	mov	dptr,#_radio_tx_buf_len
	movx	a,@dptr
	mov	r3,a
	mov	r2,#0x00
	inc	r3
	cjne	r3,#0x00,00163$
	inc	r2
00163$:
	clr	c
	mov	a,r3
	subb	a,#0xff
	mov	a,r2
	xrl	a,#0x80
	subb	a,#0x80
	jnc	00103$
;	radio.c:225: radio_tx_buf[radio_tx_buf_len++] = s_byte;
	mov	dptr,#_radio_tx_buf_len
	movx	a,@dptr
	mov	r3,a
	inc	a
	movx	@dptr,a
	mov	a,r3
	add	a,#_radio_tx_buf
	mov	dpl,a
	clr	a
	addc	a,#(_radio_tx_buf >> 8)
	mov	dph,a
	mov	r0,#_send_packet_from_serial_s_byte_65536_128
	movx	a,@r0
	movx	@dptr,a
;	radio.c:230: while(send_count < total_send_count) {
	sjmp	00103$
00125$:
	mov	r3,#0x00
	mov	r4,#0x00
00112$:
	clr	c
	mov	a,r3
	subb	a,r5
	mov	a,r4
	subb	a,r6
	jnc	00115$
;	radio.c:233: if (send_count > 0 && delay_ms > 0) {
	mov	a,r3
	orl	a,r4
	jz	00110$
	mov	r0,#_send_packet_from_serial_PARM_3
	movx	a,@r0
	mov	b,a
	inc	r0
	movx	a,@r0
	orl	a,b
	jz	00110$
;	radio.c:234: delay(delay_ms);
	push	ar5
	push	ar6
	mov	r0,#_send_packet_from_serial_PARM_3
	movx	a,@r0
	mov	r2,a
	inc	r0
	movx	a,@r0
	mov	r5,a
	mov	r6,#0x00
	mov	r7,#0x00
	mov	dpl,r2
	mov	dph,r5
	mov	b,r6
	mov	a,r7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	lcall	_delay
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
;	radio.c:240: send_count++;
	pop	ar6
	pop	ar5
;	radio.c:234: delay(delay_ms);
00110$:
;	radio.c:238: send_from_tx_buf(channel, preamble_extend_ms);
	mov	r0,#_send_packet_from_serial_PARM_4
	mov	r1,#_send_from_tx_buf_PARM_2
	movx	a,@r0
	movx	@r1,a
	inc	r0
	movx	a,@r0
	inc	r1
	movx	@r1,a
	mov	r0,#_send_packet_from_serial_channel_65536_127
	movx	a,@r0
	mov	dpl,a
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	lcall	_send_from_tx_buf
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
;	radio.c:240: send_count++;
	inc	r3
	cjne	r3,#0x00,00112$
	inc	r4
	sjmp	00112$
00115$:
;	radio.c:242: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'send_from_tx_buf'
;------------------------------------------------------------
;	radio.c:244: void send_from_tx_buf(uint8_t channel, uint16_t preamble_extend_ms) {
;	-----------------------------------------
;	 function send_from_tx_buf
;	-----------------------------------------
_send_from_tx_buf:
	mov	r7,dpl
;	radio.c:249: mdmcfg2_save = MDMCFG2;
	mov	dptr,#_MDMCFG2
	movx	a,@dptr
	mov	r6,a
;	radio.c:250: pktlen_save = PKTLEN;
	mov	dptr,#_PKTLEN
	movx	a,@dptr
	mov	r5,a
;	radio.c:251: pktctrl0_save = PKTCTRL0;
	mov	dptr,#_PKTCTRL0
	movx	a,@dptr
	mov	r4,a
;	radio.c:253: packet_tx_count++;
	mov	r0,#_packet_tx_count
	movx	a,@r0
	add	a,#0x01
	movx	@r0,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	movx	@r0,a
;	radio.c:255: if (preamble_word != 0) {
	mov	dptr,#_preamble_word
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	orl	a,r2
	jz	00105$
;	radio.c:257: MDMCFG2 &= 0b11111100;  // Disable PREAMBLE/SYNC
	mov	dptr,#_MDMCFG2
	movx	a,@dptr
	anl	acc,#0xfc
	movx	@dptr,a
;	radio.c:258: PKTCTRL0 = (PKTCTRL0 & ~0b11) | 0b10; // Enter "infinite" tx mode
	mov	dptr,#_PKTCTRL0
	movx	a,@dptr
	anl	a,#0xfc
	orl	a,#0x02
	movx	@dptr,a
;	radio.c:259: PKTLEN = 0;
	mov	dptr,#_PKTLEN
	clr	a
	movx	@dptr,a
;	radio.c:260: stop_custom_preamble_semaphore = 0;
	mov	r0,#_stop_custom_preamble_semaphore
	movx	@r0,a
;	radio.c:261: tx_state = TxStatePreambleByte0;
	mov	r0,#_tx_state
	movx	@r0,a
	sjmp	00106$
00105$:
;	radio.c:263: if (preamble_extend_ms) {
	mov	r0,#_send_from_tx_buf_PARM_2
	movx	a,@r0
	mov	b,a
	inc	r0
	movx	a,@r0
	orl	a,b
	jz	00102$
;	radio.c:264: tx_state = TxStatePreambleDefault;
	mov	r0,#_tx_state
	mov	a,#0x02
	movx	@r0,a
	sjmp	00103$
00102$:
;	radio.c:266: tx_state = TxStateData;
	mov	r0,#_tx_state
	mov	a,#0x05
	movx	@r0,a
00103$:
;	radio.c:268: PKTLEN = radio_tx_buf_len;
	mov	dptr,#_radio_tx_buf_len
	movx	a,@dptr
	mov	dptr,#_PKTLEN
	movx	@dptr,a
00106$:
;	radio.c:271: RFST = RFST_SIDLE;
	mov	_RFST,#0x04
;	radio.c:272: while(MARCSTATE!=MARC_STATE_IDLE);
00107$:
	mov	dptr,#_MARCSTATE
	movx	a,@dptr
	mov	r3,a
	cjne	r3,#0x01,00107$
;	radio.c:274: CHANNR = channel;
	mov	dptr,#_CHANNR
	mov	a,r7
	movx	@dptr,a
;	radio.c:276: radio_tx_buf_read_idx = 0;
	mov	dptr,#_radio_tx_buf_read_idx
	clr	a
	movx	@dptr,a
;	radio.c:279: RFST = RFST_STX;
	mov	_RFST,#0x03
;	radio.c:280: while(MARCSTATE!=MARC_STATE_TX);
00110$:
	mov	dptr,#_MARCSTATE
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x13,00110$
;	radio.c:282: if (preamble_extend_ms > 0) {
	mov	r0,#_send_from_tx_buf_PARM_2
	movx	a,@r0
	mov	b,a
	inc	r0
	movx	a,@r0
	orl	a,b
	jz	00116$
;	radio.c:283: delay(preamble_extend_ms);
	push	ar4
	mov	r0,#_send_from_tx_buf_PARM_2
	movx	a,@r0
	mov	r2,a
	inc	r0
	movx	a,@r0
	mov	r3,a
	mov	r4,#0x00
	mov	r7,#0x00
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r7
	push	ar6
	push	ar5
	push	ar4
	lcall	_delay
	pop	ar4
	pop	ar5
	pop	ar6
;	radio.c:284: if(preamble_word==0) {
	mov	dptr,#_preamble_word
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	orl	a,r4
	pop	ar4
	jnz	00116$
;	radio.c:285: tx_state = TxStateData;
	mov	r0,#_tx_state
	mov	a,#0x05
	movx	@r0,a
;	radio.c:286: TCON |= 0b10;  // Manually trigger RFTXRX vector.
	orl	_TCON,#0x02
00116$:
;	radio.c:290: if (preamble_word != 0) {
	mov	dptr,#_preamble_word
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	orl	a,r3
	jz	00119$
;	radio.c:291: stop_custom_preamble_semaphore = 1;
	mov	r0,#_stop_custom_preamble_semaphore
	mov	a,#0x01
	movx	@r0,a
;	radio.c:295: while(MARCSTATE==MARC_STATE_TX);
00119$:
	mov	dptr,#_MARCSTATE
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x13,00183$
	sjmp	00119$
00183$:
;	radio.c:297: if (MARCSTATE==MARC_STATE_TX_UNDERFLOW) {
	mov	dptr,#_MARCSTATE
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x16,00123$
;	radio.c:298: RFST = RFST_SIDLE;
	mov	_RFST,#0x04
00123$:
;	radio.c:301: PKTLEN = pktlen_save;
	mov	dptr,#_PKTLEN
	mov	a,r5
	movx	@dptr,a
;	radio.c:302: MDMCFG2 = mdmcfg2_save;
	mov	dptr,#_MDMCFG2
	mov	a,r6
	movx	@dptr,a
;	radio.c:303: PKTCTRL0 = pktctrl0_save;
	mov	dptr,#_PKTCTRL0
	mov	a,r4
	movx	@dptr,a
;	radio.c:305: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'get_packet_and_write_to_serial'
;------------------------------------------------------------
;sloc0                     Allocated with name '_get_packet_and_write_to_serial_sloc0_1_0'
;sloc1                     Allocated with name '_get_packet_and_write_to_serial_sloc1_1_0'
;sloc2                     Allocated with name '_get_packet_and_write_to_serial_sloc2_1_0'
;sloc3                     Allocated with name '_get_packet_and_write_to_serial_sloc3_1_0'
;sloc4                     Allocated with name '_get_packet_and_write_to_serial_sloc4_1_0'
;decoder                   Allocated with name '_get_packet_and_write_to_serial_decoder_65536_145'
;decoder_state             Allocated with name '_get_packet_and_write_to_serial_decoder_state_65536_145'
;------------------------------------------------------------
;	radio.c:307: uint8_t get_packet_and_write_to_serial(uint8_t channel, uint32_t timeout_ms, uint8_t use_pktlen) {
;	-----------------------------------------
;	 function get_packet_and_write_to_serial
;	-----------------------------------------
_get_packet_and_write_to_serial:
	mov	r7,dpl
;	radio.c:310: uint8_t d_byte = 0;
	mov	r0,#_get_packet_and_write_to_serial_d_byte_65536_145
	clr	a
	movx	@r0,a
;	radio.c:311: uint8_t rval = 0;
	mov	r0,#_get_packet_and_write_to_serial_rval_65536_145
	movx	@r0,a
;	radio.c:312: uint8_t encoding_error = 0;
;	1-genFromRTrack replaced	mov	_get_packet_and_write_to_serial_sloc1_1_0,#0x00
	mov	_get_packet_and_write_to_serial_sloc1_1_0,a
;	radio.c:318: if (timeout_ms > 0) {
	mov	r0,#_get_packet_and_write_to_serial_PARM_2
	movx	a,@r0
	mov	b,a
	inc	r0
	movx	a,@r0
	orl	b,a
	inc	r0
	movx	a,@r0
	orl	b,a
	inc	r0
	movx	a,@r0
	orl	a,b
	jz	00102$
;	radio.c:319: read_timer(&timer_start);
;	timer.h:14: EA = 0;
;	assignBit
	clr	_EA
;	timer.h:15: *result = __timerCounter;
	mov	r0,#_get_packet_and_write_to_serial_timer_start_65536_145
	mov	r1,#___timerCounter
	movx	a,@r1
	movx	@r0,a
	inc	r0
	inc	r1
	movx	a,@r1
	movx	@r0,a
	inc	r0
	inc	r1
	movx	a,@r1
	movx	@r0,a
	inc	r0
	inc	r1
	movx	a,@r1
	movx	@r0,a
;	timer.h:16: EA = 1;
;	assignBit
	setb	_EA
;	radio.c:319: read_timer(&timer_start);
00102$:
;	radio.c:322: mode_registers_enact(&rx_registers);
	mov	dptr,#_rx_registers
	mov	b,#0x00
	push	ar7
	lcall	_mode_registers_enact
;	radio.c:324: init_decoder(encoding_type, &decoder, &decoder_state);
	mov	r0,#_init_decoder_PARM_2
	mov	a,#_get_packet_and_write_to_serial_decoder_65536_145
	movx	@r0,a
	inc	r0
	mov	a,#(_get_packet_and_write_to_serial_decoder_65536_145 >> 8)
	movx	@r0,a
	inc	r0
	clr	a
	movx	@r0,a
	mov	r0,#_init_decoder_PARM_3
	mov	a,#_get_packet_and_write_to_serial_decoder_state_65536_145
	movx	@r0,a
	inc	r0
	mov	a,#(_get_packet_and_write_to_serial_decoder_state_65536_145 >> 8)
	movx	@r0,a
	inc	r0
	clr	a
	movx	@r0,a
	mov	r0,#_encoding_type
	movx	a,@r0
	mov	dpl,a
	lcall	_init_decoder
	pop	ar7
;	radio.c:326: RFST = RFST_SIDLE;
	mov	_RFST,#0x04
;	radio.c:327: while(MARCSTATE!=MARC_STATE_IDLE);
00103$:
	mov	dptr,#_MARCSTATE
	movx	a,@dptr
	mov	r4,a
	cjne	r4,#0x01,00103$
;	radio.c:329: CHANNR = channel;
	mov	dptr,#_CHANNR
	mov	a,r7
	movx	@dptr,a
;	radio.c:331: rx_len = 0;
	mov	r0,#_rx_len
	clr	a
	movx	@r0,a
;	radio.c:332: memset((void*)radio_rx_buf, 0x11, RX_FIFO_SIZE);
	mov	r0,#_memset_PARM_2
	mov	a,#0x11
	movx	@r0,a
	mov	r0,#_memset_PARM_3
	mov	a,#0x20
	movx	@r0,a
	inc	r0
	clr	a
	movx	@r0,a
	mov	dptr,#_radio_rx_buf
	mov	b,#0x00
	lcall	_memset
;	radio.c:334: CLKCON = 0xAB;  	//slow down now, you just wait for a packet that may never come; CLKSPD = 3Mhz, TICKSPD = 750Khz
	mov	_CLKCON,#0xab
;	radio.c:336: RFST = RFST_SRX;
	mov	_RFST,#0x02
;	radio.c:337: while(MARCSTATE!=MARC_STATE_RX);
00106$:
	mov	dptr,#_MARCSTATE
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x0d,00106$
;	radio.c:339: while(1) {
	mov	r0,#_get_packet_and_write_to_serial_PARM_2
	movx	a,@r0
	mov	_get_packet_and_write_to_serial_sloc2_1_0,a
	inc	r0
	movx	a,@r0
	mov	(_get_packet_and_write_to_serial_sloc2_1_0 + 1),a
	inc	r0
	movx	a,@r0
	mov	(_get_packet_and_write_to_serial_sloc2_1_0 + 2),a
	inc	r0
	movx	a,@r0
	mov	(_get_packet_and_write_to_serial_sloc2_1_0 + 3),a
	mov	r0,#_get_packet_and_write_to_serial_read_idx_65536_145
	clr	a
	movx	@r0,a
00130$:
;	radio.c:344: if (!fifo_empty(&rx_fifo)) {
;	fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
	mov	a,#_rx_fifo
	orl	a,#(_rx_fifo >> 8)
	jz	00158$
;	fifo.h:28: return (b ? (b->head - b->tail) : 0);
	mov	a,#_rx_fifo
	orl	a,#(_rx_fifo >> 8)
	jz	00160$
	mov	dptr,#_rx_fifo
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#(_rx_fifo + 0x0001)
	mov	b,#0x00
	lcall	__gptrget
	mov	r6,a
	mov	a,r5
	clr	c
	subb	a,r6
	mov	r5,a
	mov	_get_packet_and_write_to_serial_sloc0_1_0,r5
	mov	(_get_packet_and_write_to_serial_sloc0_1_0 + 1),#0x00
	sjmp	00161$
00160$:
	clr	a
	mov	_get_packet_and_write_to_serial_sloc0_1_0,a
	mov	(_get_packet_and_write_to_serial_sloc0_1_0 + 1),a
00161$:
	mov	r6,_get_packet_and_write_to_serial_sloc0_1_0
;	fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
	mov	r0,#_get_packet_and_write_to_serial___1966080033_196608_147
	mov	a,r6
	cjne	a,#0x01,00303$
00303$:
	clr	a
	rlc	a
	movx	@r0,a
	sjmp	00159$
00158$:
	mov	r0,#_get_packet_and_write_to_serial___1966080033_196608_147
	mov	a,#0x01
	movx	@r0,a
00159$:
;	radio.c:344: if (!fifo_empty(&rx_fifo)) {
	mov	r0,#_get_packet_and_write_to_serial___1966080033_196608_147
	movx	a,@r0
	jz	00304$
	ljmp	00123$
00304$:
;	radio.c:346: d_byte = fifo_get(&rx_fifo);
	mov	r0,#_get_packet_and_write_to_serial_b_327680_169
	mov	a,#_rx_fifo
	movx	@r0,a
	inc	r0
	mov	a,#(_rx_fifo >> 8)
	movx	@r0,a
	inc	r0
	clr	a
	movx	@r0,a
;	fifo.h:36: uint8_t data_byte = 0;
	mov	r4,#0x00
;	fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
	mov	a,#_rx_fifo
	orl	a,#(_rx_fifo >> 8)
	jz	00162$
;	fifo.h:28: return (b ? (b->head - b->tail) : 0);
	mov	a,#_rx_fifo
	orl	a,#(_rx_fifo >> 8)
	jz	00164$
	mov	dptr,#_rx_fifo
	movx	a,@dptr
	mov	r3,a
	mov	dptr,#(_rx_fifo + 0x0001)
	mov	b,#0x00
	lcall	__gptrget
	mov	r2,a
	mov	a,r3
	clr	c
	subb	a,r2
	mov	r2,a
	mov	r3,#0x00
	sjmp	00165$
00164$:
	mov	r2,#0x00
	mov	r3,#0x00
00165$:
;	fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
	mov	r0,#_get_packet_and_write_to_serial___1310720012_393216_170
	mov	a,r2
	cjne	a,#0x01,00307$
00307$:
	clr	a
	rlc	a
	movx	@r0,a
	sjmp	00163$
00162$:
	mov	r0,#_get_packet_and_write_to_serial___1310720012_393216_170
	mov	a,#0x01
	movx	@r0,a
00163$:
;	fifo.h:38: if (!fifo_empty(b)) {
	mov	r0,#_get_packet_and_write_to_serial___1310720012_393216_170
	movx	a,@r0
	jz	00308$
	ljmp	00146$
00308$:
;	fifo.h:39: data_byte = b->buffer[b->tail % b->buffer_len];
	mov	r0,#_get_packet_and_write_to_serial_b_327680_169
	movx	a,@r0
	add	a,#0x02
	mov	r2,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r7,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r7
	lcall	__gptrget
	mov	_get_packet_and_write_to_serial_sloc3_1_0,a
	inc	dptr
	lcall	__gptrget
	mov	(_get_packet_and_write_to_serial_sloc3_1_0 + 1),a
	inc	dptr
	lcall	__gptrget
	mov	(_get_packet_and_write_to_serial_sloc3_1_0 + 2),a
	mov	r0,#_get_packet_and_write_to_serial_b_327680_169
	movx	a,@r0
	add	a,#0x01
	mov	_get_packet_and_write_to_serial_sloc4_1_0,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	(_get_packet_and_write_to_serial_sloc4_1_0 + 1),a
	inc	r0
	movx	a,@r0
	mov	(_get_packet_and_write_to_serial_sloc4_1_0 + 2),a
	mov	dpl,_get_packet_and_write_to_serial_sloc4_1_0
	mov	dph,(_get_packet_and_write_to_serial_sloc4_1_0 + 1)
	mov	b,(_get_packet_and_write_to_serial_sloc4_1_0 + 2)
	lcall	__gptrget
	mov	_get_packet_and_write_to_serial_sloc0_1_0,a
	mov	r0,#_get_packet_and_write_to_serial_b_327680_169
	movx	a,@r0
	add	a,#0x05
	mov	r2,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r7,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r7
	lcall	__gptrget
	mov	r2,a
	mov	b,r2
	mov	a,_get_packet_and_write_to_serial_sloc0_1_0
	div	ab
	mov	a,b
	add	a,_get_packet_and_write_to_serial_sloc3_1_0
	mov	r2,a
	clr	a
	addc	a,(_get_packet_and_write_to_serial_sloc3_1_0 + 1)
	mov	r7,a
	mov	r6,(_get_packet_and_write_to_serial_sloc3_1_0 + 2)
	mov	dpl,r2
	mov	dph,r7
	mov	b,r6
	lcall	__gptrget
	mov	r4,a
;	fifo.h:40: b->tail++;
	mov	dpl,_get_packet_and_write_to_serial_sloc4_1_0
	mov	dph,(_get_packet_and_write_to_serial_sloc4_1_0 + 1)
	mov	b,(_get_packet_and_write_to_serial_sloc4_1_0 + 2)
	lcall	__gptrget
	mov	r7,a
	inc	r7
	mov	dpl,_get_packet_and_write_to_serial_sloc4_1_0
	mov	dph,(_get_packet_and_write_to_serial_sloc4_1_0 + 1)
	mov	b,(_get_packet_and_write_to_serial_sloc4_1_0 + 2)
	mov	a,r7
	lcall	__gptrput
00146$:
;	radio.c:346: d_byte = fifo_get(&rx_fifo);
	mov	r0,#_get_packet_and_write_to_serial_d_byte_65536_145
	mov	a,r4
	movx	@r0,a
;	radio.c:347: read_idx++;
	mov	r0,#_get_packet_and_write_to_serial_read_idx_65536_145
	movx	a,@r0
	add	a,#0x01
	movx	@r0,a
;	radio.c:350: if (read_idx == 1) {
	mov	r0,#_get_packet_and_write_to_serial_read_idx_65536_145
	movx	a,@r0
	cjne	a,#0x01,00110$
;	radio.c:351: serial_tx_byte(RESPONSE_CODE_SUCCESS);
	mov	dpl,#0xdd
	lcall	_serial_tx_byte
00110$:
;	radio.c:354: if (read_idx < 3) {
	mov	r0,#_get_packet_and_write_to_serial_read_idx_65536_145
	movx	a,@r0
	cjne	a,#0x03,00311$
00311$:
	jnc	00115$
;	radio.c:355: serial_tx_byte(d_byte);
	mov	r0,#_get_packet_and_write_to_serial_d_byte_65536_145
	movx	a,@r0
	mov	dpl,a
	lcall	_serial_tx_byte
	sjmp	00116$
00115$:
;	radio.c:357: encoding_error = decoder.add_encoded_byte(&decoder_state, d_byte);
	mov	dptr,#_get_packet_and_write_to_serial_decoder_65536_145
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	push	ar7
	push	ar6
	mov	r0,#_get_packet_and_write_to_serial_d_byte_65536_145
	movx	a,@r0
	push	acc
	lcall	00313$
	sjmp	00314$
00313$:
	push	ar6
	push	ar7
	mov	dptr,#_get_packet_and_write_to_serial_decoder_state_65536_145
	mov	b,#0x00
	ret
00314$:
	mov	_get_packet_and_write_to_serial_sloc1_1_0,dpl
	dec	sp
	pop	ar6
	pop	ar7
;	radio.c:359: while (decoder.next_decoded_byte(&decoder_state, &d_byte)) {
00111$:
	mov	dptr,#(_get_packet_and_write_to_serial_decoder_65536_145 + 0x0002)
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	push	ar7
	mov	a,#_get_packet_and_write_to_serial_d_byte_65536_145
	push	acc
	mov	a,#(_get_packet_and_write_to_serial_d_byte_65536_145 >> 8)
	push	acc
	mov	a,#0x60
	push	acc
	lcall	00315$
	sjmp	00316$
00315$:
	push	ar6
	push	ar7
	mov	dptr,#_get_packet_and_write_to_serial_decoder_state_65536_145
	mov	b,#0x00
	ret
00316$:
	mov	r6,dpl
	dec	sp
	dec	sp
	dec	sp
	pop	ar7
	mov	a,r6
	jz	00116$
;	radio.c:360: serial_tx_byte(d_byte);
	mov	r0,#_get_packet_and_write_to_serial_d_byte_65536_145
	movx	a,@r0
	mov	dpl,a
	lcall	_serial_tx_byte
	sjmp	00111$
00116$:
;	radio.c:364: if (encoding_error) {
	mov	a,_get_packet_and_write_to_serial_sloc1_1_0
	jnz	00131$
;	radio.c:369: if (use_pktlen && read_idx == PKTLEN) {
	mov	r0,#_get_packet_and_write_to_serial_PARM_3
	movx	a,@r0
	jz	00123$
	mov	dptr,#_PKTLEN
	movx	a,@dptr
	mov	r7,a
	mov	r0,#_get_packet_and_write_to_serial_read_idx_65536_145
	movx	a,@r0
	cjne	a,ar7,00320$
	sjmp	00131$
00320$:
;	radio.c:370: break;
00123$:
;	radio.c:374: if (timeout_ms > 0 && check_elapsed(timer_start, timeout_ms)) {
	mov	a,_get_packet_and_write_to_serial_sloc2_1_0
	orl	a,(_get_packet_and_write_to_serial_sloc2_1_0 + 1)
	orl	a,(_get_packet_and_write_to_serial_sloc2_1_0 + 2)
	orl	a,(_get_packet_and_write_to_serial_sloc2_1_0 + 3)
	jz	00125$
;	timer.h:22: EA = 0;
;	assignBit
	clr	_EA
;	timer.h:23: rval = (__timerCounter - start_time) > duration;
	mov	r0,#___timerCounter
	mov	r1,#_get_packet_and_write_to_serial_timer_start_65536_145
	movx	a,@r1
	mov	b,a
	clr	c
	movx	a,@r0
	subb	a,b
	mov	r4,a
	inc	r1
	movx	a,@r1
	mov	b,a
	inc	r0
	movx	a,@r0
	subb	a,b
	mov	r5,a
	inc	r1
	movx	a,@r1
	mov	b,a
	inc	r0
	movx	a,@r0
	subb	a,b
	mov	r6,a
	inc	r1
	movx	a,@r1
	mov	b,a
	inc	r0
	movx	a,@r0
	subb	a,b
	mov	r7,a
	mov	r0,#_get_packet_and_write_to_serial_rval_327680_180
	clr	c
	mov	a,_get_packet_and_write_to_serial_sloc2_1_0
	subb	a,r4
	mov	a,(_get_packet_and_write_to_serial_sloc2_1_0 + 1)
	subb	a,r5
	mov	a,(_get_packet_and_write_to_serial_sloc2_1_0 + 2)
	subb	a,r6
	mov	a,(_get_packet_and_write_to_serial_sloc2_1_0 + 3)
	subb	a,r7
	clr	a
	rlc	a
	movx	@r0,a
;	timer.h:24: EA = 1;
;	assignBit
	setb	_EA
;	radio.c:374: if (timeout_ms > 0 && check_elapsed(timer_start, timeout_ms)) {
	mov	r0,#_get_packet_and_write_to_serial_rval_327680_180
	movx	a,@r0
	jz	00125$
;	radio.c:375: rval = RESPONSE_CODE_RX_TIMEOUT;
	mov	r0,#_get_packet_and_write_to_serial_rval_65536_145
	mov	a,#0xaa
	movx	@r0,a
;	radio.c:376: break;
	sjmp	00131$
00125$:
;	radio.c:380: if (SERIAL_DATA_AVAILABLE) {
	mov	r0,#_serial_data_available
	movx	a,@r0
	jnz	00323$
	ljmp	00130$
00323$:
;	radio.c:383: interrupting_cmd = serial_rx_byte();
	lcall	_serial_rx_byte
	mov	a,dpl
	mov	r0,#_interrupting_cmd
	movx	@r0,a
;	radio.c:384: rval = RESPONSE_CODE_CMD_INTERRUPTED;
	mov	r0,#_get_packet_and_write_to_serial_rval_65536_145
	mov	a,#0xbb
	movx	@r0,a
;	radio.c:385: break;
00131$:
;	radio.c:389: RFST = RFST_SIDLE;
	mov	_RFST,#0x04
;	radio.c:390: while(MARCSTATE!=MARC_STATE_IDLE);
00132$:
	mov	dptr,#_MARCSTATE
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x01,00132$
;	radio.c:392: while(!fifo_empty(&rx_fifo)) {
00135$:
;	fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
	mov	a,#_rx_fifo
	orl	a,#(_rx_fifo >> 8)
	jz	00166$
;	fifo.h:28: return (b ? (b->head - b->tail) : 0);
	mov	a,#_rx_fifo
	orl	a,#(_rx_fifo >> 8)
	jz	00168$
	mov	dptr,#_rx_fifo
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#(_rx_fifo + 0x0001)
	mov	b,#0x00
	lcall	__gptrget
	mov	r6,a
	mov	a,r7
	clr	c
	subb	a,r6
	mov	r6,a
	mov	r7,#0x00
	sjmp	00169$
00168$:
	mov	r6,#0x00
	mov	r7,#0x00
00169$:
;	fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
	mov	r0,#_get_packet_and_write_to_serial___1310720043_131072_145
	mov	a,r6
	cjne	a,#0x01,00328$
00328$:
	clr	a
	rlc	a
	movx	@r0,a
	sjmp	00167$
00166$:
	mov	r0,#_get_packet_and_write_to_serial___1310720043_131072_145
	mov	a,#0x01
	movx	@r0,a
00167$:
;	radio.c:392: while(!fifo_empty(&rx_fifo)) {
	mov	r0,#_get_packet_and_write_to_serial___1310720043_131072_145
	movx	a,@r0
	jz	00329$
	ljmp	00137$
00329$:
;	radio.c:393: fifo_get(&rx_fifo);
	mov	r0,#_get_packet_and_write_to_serial_b_262144_188
	mov	a,#_rx_fifo
	movx	@r0,a
	inc	r0
	mov	a,#(_rx_fifo >> 8)
	movx	@r0,a
	inc	r0
	clr	a
	movx	@r0,a
;	fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
	mov	a,#_rx_fifo
	orl	a,#(_rx_fifo >> 8)
	jz	00170$
;	fifo.h:28: return (b ? (b->head - b->tail) : 0);
	mov	a,#_rx_fifo
	orl	a,#(_rx_fifo >> 8)
	jz	00172$
	mov	dptr,#_rx_fifo
	movx	a,@dptr
	mov	r4,a
	mov	dptr,#(_rx_fifo + 0x0001)
	mov	b,#0x00
	lcall	__gptrget
	mov	r3,a
	mov	a,r4
	clr	c
	subb	a,r3
	mov	r3,a
	mov	r4,#0x00
	sjmp	00173$
00172$:
	mov	r3,#0x00
	mov	r4,#0x00
00173$:
;	fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
	mov	r0,#_get_packet_and_write_to_serial___1310720012_327680_189
	mov	a,r3
	cjne	a,#0x01,00332$
00332$:
	clr	a
	rlc	a
	movx	@r0,a
	sjmp	00171$
00170$:
	mov	r0,#_get_packet_and_write_to_serial___1310720012_327680_189
	mov	a,#0x01
	movx	@r0,a
00171$:
;	fifo.h:38: if (!fifo_empty(b)) {
	mov	r0,#_get_packet_and_write_to_serial___1310720012_327680_189
	movx	a,@r0
	jz	00333$
	ljmp	00135$
00333$:
;	fifo.h:39: data_byte = b->buffer[b->tail % b->buffer_len];
	mov	r0,#_get_packet_and_write_to_serial_b_262144_188
	movx	a,@r0
	add	a,#0x02
	mov	r2,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r4,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	_get_packet_and_write_to_serial_sloc4_1_0,a
	inc	dptr
	lcall	__gptrget
	mov	(_get_packet_and_write_to_serial_sloc4_1_0 + 1),a
	inc	dptr
	lcall	__gptrget
	mov	(_get_packet_and_write_to_serial_sloc4_1_0 + 2),a
	mov	r0,#_get_packet_and_write_to_serial_b_262144_188
	movx	a,@r0
	add	a,#0x01
	mov	r5,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r6,a
	inc	r0
	movx	a,@r0
	mov	r7,a
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	_get_packet_and_write_to_serial_sloc3_1_0,a
	mov	r0,#_get_packet_and_write_to_serial_b_262144_188
	movx	a,@r0
	add	a,#0x05
	mov	r2,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r4,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r2,a
	mov	b,r2
	mov	a,_get_packet_and_write_to_serial_sloc3_1_0
	div	ab
	mov	a,b
	add	a,_get_packet_and_write_to_serial_sloc4_1_0
	mov	r2,a
	clr	a
	addc	a,(_get_packet_and_write_to_serial_sloc4_1_0 + 1)
	mov	r4,a
	mov	r3,(_get_packet_and_write_to_serial_sloc4_1_0 + 2)
	mov	dpl,r2
	mov	dph,r4
	mov	b,r3
	lcall	__gptrget
;	fifo.h:40: b->tail++;
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	r4,a
	inc	r4
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	mov	a,r4
	lcall	__gptrput
;	radio.c:393: fifo_get(&rx_fifo);
	ljmp	00135$
00137$:
;	radio.c:396: if (rval == 0) {
	mov	r0,#_get_packet_and_write_to_serial_rval_65536_145
	movx	a,@r0
	jnz	00139$
;	radio.c:397: packet_rx_count++;
	mov	r0,#_packet_rx_count
	movx	a,@r0
	add	a,#0x01
	movx	@r0,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	movx	@r0,a
00139$:
;	radio.c:400: return rval;
	mov	r0,#_get_packet_and_write_to_serial_rval_65536_145
	movx	a,@r0
	mov	dpl,a
;	radio.c:401: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'radio_set_preamble'
;------------------------------------------------------------
;	radio.c:404: void radio_set_preamble(uint16_t p) {
;	-----------------------------------------
;	 function radio_set_preamble
;	-----------------------------------------
_radio_set_preamble:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_preamble_word
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	radio.c:405: preamble_word = p;
;	radio.c:406: }
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)
