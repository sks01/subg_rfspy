;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.2 #11662 (MINGW64)
;--------------------------------------------------------
	.module serial
	.optsdcc -mmcs51 --model-medium
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _tx1_isr
	.globl _rx1_isr
	.globl _MODE
	.globl _RE
	.globl _SLAVE
	.globl _FE
	.globl _ERR
	.globl _RX_BYTE
	.globl _TX_BYTE
	.globl _ACTIVE
	.globl _B_7
	.globl _B_6
	.globl _B_5
	.globl _B_4
	.globl _B_3
	.globl _B_2
	.globl _B_1
	.globl _B_0
	.globl _WDTIF
	.globl _P1IF
	.globl _UTX1IF
	.globl _UTX0IF
	.globl _P2IF
	.globl _ACC_7
	.globl _ACC_6
	.globl _ACC_5
	.globl _ACC_4
	.globl _ACC_3
	.globl _ACC_2
	.globl _ACC_1
	.globl _ACC_0
	.globl _OVFIM
	.globl _T4CH1IF
	.globl _T4CH0IF
	.globl _T4OVFIF
	.globl _T3CH1IF
	.globl _T3CH0IF
	.globl _T3OVFIF
	.globl _CY
	.globl _AC
	.globl _F0
	.globl _RS1
	.globl _RS0
	.globl _OV
	.globl _F1
	.globl _P
	.globl _STIF
	.globl _P0IF
	.globl _T4IF
	.globl _T3IF
	.globl _T2IF
	.globl _T1IF
	.globl _DMAIF
	.globl _P0IE
	.globl _T4IE
	.globl _T3IE
	.globl _T2IE
	.globl _T1IE
	.globl _DMAIE
	.globl _EA
	.globl _STIE
	.globl _ENCIE
	.globl _URX1IE
	.globl _URX0IE
	.globl _ADCIE
	.globl _RFTXRXIE
	.globl _P2_7
	.globl _P2_6
	.globl _P2_5
	.globl _P2_4
	.globl _P2_3
	.globl _P2_2
	.globl _P2_1
	.globl _P2_0
	.globl _ENCIF_1
	.globl _ENCIF_0
	.globl _P1_7
	.globl _P1_6
	.globl _P1_5
	.globl _P1_4
	.globl _P1_3
	.globl _P1_2
	.globl _P1_1
	.globl _P1_0
	.globl _URX1IF
	.globl _ADCIF
	.globl _URX0IF
	.globl _IT1
	.globl _RFTXRXIF
	.globl _IT0
	.globl _P0_7
	.globl _P0_6
	.globl _P0_5
	.globl _P0_4
	.globl _P0_3
	.globl _P0_2
	.globl _P0_1
	.globl _P0_0
	.globl _P2DIR
	.globl _P1DIR
	.globl _P0DIR
	.globl _U1GCR
	.globl _U1UCR
	.globl _U1BAUD
	.globl _U1DBUF
	.globl _U1CSR
	.globl _P2INP
	.globl _P1INP
	.globl _P2SEL
	.globl _P1SEL
	.globl _P0SEL
	.globl _ADCCFG
	.globl _PERCFG
	.globl _B
	.globl _T4CC1
	.globl _T4CCTL1
	.globl _T4CC0
	.globl _T4CCTL0
	.globl _T4CTL
	.globl _T4CNT
	.globl _RFIF
	.globl _IRCON2
	.globl _T1CCTL2
	.globl _T1CCTL1
	.globl _T1CCTL0
	.globl _T1CTL
	.globl _T1CNTH
	.globl _T1CNTL
	.globl _RFST
	.globl _ACC
	.globl _T1CC2H
	.globl _T1CC2L
	.globl _T1CC1H
	.globl _T1CC1L
	.globl _T1CC0H
	.globl _T1CC0L
	.globl _RFD
	.globl _TIMIF
	.globl _DMAREQ
	.globl _DMAARM
	.globl _DMA0CFGH
	.globl _DMA0CFGL
	.globl _DMA1CFGH
	.globl _DMA1CFGL
	.globl _DMAIRQ
	.globl _PSW
	.globl _T3CC1
	.globl _T3CCTL1
	.globl _T3CC0
	.globl _T3CCTL0
	.globl _T3CTL
	.globl _T3CNT
	.globl _WDCTL
	.globl __SFRC8
	.globl _MEMCTR
	.globl _CLKCON
	.globl _U0GCR
	.globl _U0UCR
	.globl __SFRC3
	.globl _U0BAUD
	.globl _U0DBUF
	.globl _IRCON
	.globl __SFRBF
	.globl _SLEEP
	.globl _RNDH
	.globl _RNDL
	.globl _ADCH
	.globl _ADCL
	.globl _IP1
	.globl _IEN1
	.globl __SFRB7
	.globl _ADCCON3
	.globl _ADCCON2
	.globl _ADCCON1
	.globl _ENCCS
	.globl _ENCDO
	.globl _ENCDI
	.globl __SFRB0
	.globl _FWDATA
	.globl _FCTL
	.globl _FADDRH
	.globl _FADDRL
	.globl _FWT
	.globl __SFRAA
	.globl _IP0
	.globl _IEN0
	.globl __SFRA7
	.globl _WORTIME1
	.globl _WORTIME0
	.globl _WOREVT1
	.globl _WOREVT0
	.globl _WORCTRL
	.globl _WORIRQ
	.globl _P2
	.globl __SFR9F
	.globl _T2CTL
	.globl _T2PR
	.globl _T2CT
	.globl _S1CON
	.globl _IEN2
	.globl __SFR99
	.globl _S0CON
	.globl __SFR97
	.globl __SFR96
	.globl __SFR95
	.globl __SFR94
	.globl __XPAGE
	.globl _MPAGE
	.globl _DPS
	.globl _RFIM
	.globl _P1
	.globl _P0INP
	.globl __SFR8E
	.globl _P1IEN
	.globl _PICTL
	.globl _P2IFG
	.globl _P1IFG
	.globl _P0IFG
	.globl _TCON
	.globl _PCON
	.globl _U0CSR
	.globl _DPH1
	.globl _DPL1
	.globl _DPH0
	.globl _DPL0
	.globl _SP
	.globl _P0
	.globl _X_P2DIR
	.globl _X_P1DIR
	.globl _X_P0DIR
	.globl _X_U1GCR
	.globl _X_U1UCR
	.globl _X_U1BAUD
	.globl _X_U1DBUF
	.globl _X_U1CSR
	.globl _X_P2INP
	.globl _X_P1INP
	.globl _X_P2SEL
	.globl _X_P1SEL
	.globl _X_P0SEL
	.globl _X_ADCCFG
	.globl _X_PERCFG
	.globl __NA_B
	.globl _X_T4CC1
	.globl _X_T4CCTL1
	.globl _X_T4CC0
	.globl _X_T4CCTL0
	.globl _X_T4CTL
	.globl _X_T4CNT
	.globl _X_RFIF
	.globl __NA_IRCON2
	.globl _X_T1CCTL2
	.globl _X_T1CCTL1
	.globl _X_T1CCTL0
	.globl _X_T1CTL
	.globl _X_T1CNTH
	.globl _X_T1CNTL
	.globl _X_RFST
	.globl __NA_ACC
	.globl _X_T1CC2H
	.globl _X_T1CC2L
	.globl _X_T1CC1H
	.globl _X_T1CC1L
	.globl _X_T1CC0H
	.globl _X_T1CC0L
	.globl _X_RFD
	.globl _X_TIMIF
	.globl _X_DMAREQ
	.globl _X_DMAARM
	.globl _X_DMA0CFGH
	.globl _X_DMA0CFGL
	.globl _X_DMA1CFGH
	.globl _X_DMA1CFGL
	.globl _X_DMAIRQ
	.globl __NA_PSW
	.globl _X_T3CC1
	.globl _X_T3CCTL1
	.globl _X_T3CC0
	.globl _X_T3CCTL0
	.globl _X_T3CTL
	.globl _X_T3CNT
	.globl _X_WDCTL
	.globl __X_SFRC8
	.globl _X_MEMCTR
	.globl _X_CLKCON
	.globl _X_U0GCR
	.globl _X_U0UCR
	.globl __X_SFRC3
	.globl _X_U0BAUD
	.globl _X_U0DBUF
	.globl __NA_IRCON
	.globl __X_SFRBF
	.globl _X_SLEEP
	.globl _X_RNDH
	.globl _X_RNDL
	.globl _X_ADCH
	.globl _X_ADCL
	.globl __NA_IP1
	.globl __NA_IEN1
	.globl __X_SFRB7
	.globl _X_ADCCON3
	.globl _X_ADCCON2
	.globl _X_ADCCON1
	.globl _X_ENCCS
	.globl _X_ENCDO
	.globl _X_ENCDI
	.globl __X_SFRB0
	.globl _X_FWDATA
	.globl _X_FCTL
	.globl _X_FADDRH
	.globl _X_FADDRL
	.globl _X_FWT
	.globl __X_SFRAA
	.globl __NA_IP0
	.globl __NA_IEN0
	.globl __X_SFRA7
	.globl _X_WORTIME1
	.globl _X_WORTIME0
	.globl _X_WOREVT1
	.globl _X_WOREVT0
	.globl _X_WORCTRL
	.globl _X_WORIRQ
	.globl __NA_P2
	.globl __X_SFR9F
	.globl _X_T2CTL
	.globl _X_T2PR
	.globl _X_T2CT
	.globl __NA_S1CON
	.globl __NA_IEN2
	.globl __X_SFR99
	.globl __NA_S0CON
	.globl __X_SFR97
	.globl __X_SFR96
	.globl __X_SFR95
	.globl __X_SFR94
	.globl _X_MPAGE
	.globl __NA_DPS
	.globl _X_RFIM
	.globl __NA_P1
	.globl _X_P0INP
	.globl __X_SFR8E
	.globl _X_P1IEN
	.globl _X_PICTL
	.globl _X_P2IFG
	.globl _X_P1IFG
	.globl _X_P0IFG
	.globl __NA_TCON
	.globl __NA_PCON
	.globl _X_U0CSR
	.globl __NA_DPH1
	.globl __NA_DPL1
	.globl __NA_DPH0
	.globl __NA_DPL0
	.globl __NA_SP
	.globl __NA_P0
	.globl _I2SCLKF2
	.globl _I2SCLKF1
	.globl _I2SCLKF0
	.globl _I2SSTAT
	.globl _I2SWCNT
	.globl _I2SDATH
	.globl _I2SDATL
	.globl _I2SCFG1
	.globl _I2SCFG0
	.globl _VCO_VC_DAC
	.globl _PKTSTATUS
	.globl _MARCSTATE
	.globl _RSSI
	.globl _LQI
	.globl _FREQEST
	.globl _VERSION
	.globl _PARTNUM
	.globl __XREGDF35
	.globl __XREGDF34
	.globl __XREGDF33
	.globl __XREGDF32
	.globl _IOCFG0
	.globl _IOCFG1
	.globl _IOCFG2
	.globl _PA_TABLE0
	.globl _PA_TABLE1
	.globl _PA_TABLE2
	.globl _PA_TABLE3
	.globl _PA_TABLE4
	.globl _PA_TABLE5
	.globl _PA_TABLE6
	.globl _PA_TABLE7
	.globl __XREGDF26
	.globl _TEST0
	.globl _TEST1
	.globl _TEST2
	.globl __XREGDF22
	.globl __XREGDF21
	.globl __XREGDF20
	.globl _FSCAL0
	.globl _FSCAL1
	.globl _FSCAL2
	.globl _FSCAL3
	.globl _FREND0
	.globl _FREND1
	.globl _AGCCTRL0
	.globl _AGCCTRL1
	.globl _AGCCTRL2
	.globl _BSCFG
	.globl _FOCCFG
	.globl _MCSM0
	.globl _MCSM1
	.globl _MCSM2
	.globl _DEVIATN
	.globl _MDMCFG0
	.globl _MDMCFG1
	.globl _MDMCFG2
	.globl _MDMCFG3
	.globl _MDMCFG4
	.globl _FREQ0
	.globl _FREQ1
	.globl _FREQ2
	.globl _FSCTRL0
	.globl _FSCTRL1
	.globl _CHANNR
	.globl _ADDR
	.globl _PKTCTRL0
	.globl _PKTCTRL1
	.globl _PKTLEN
	.globl _SYNC0
	.globl _SYNC1
	.globl _MDMCTRL0H
	.globl _xfer_size
	.globl _slave_send_size
	.globl _master_send_size
	.globl _spi_mode
	.globl _serial_data_available
	.globl _ready_to_send
	.globl _configure_serial
	.globl _serial_rx_avail
	.globl _serial_rx_byte
	.globl _serial_rx_word
	.globl _serial_rx_long
	.globl _serial_tx_byte
	.globl _serial_tx_word
	.globl _serial_tx_long
	.globl _serial_flush
	.globl _serial_tx_str
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_P0	=	0x0080
_SP	=	0x0081
_DPL0	=	0x0082
_DPH0	=	0x0083
_DPL1	=	0x0084
_DPH1	=	0x0085
_U0CSR	=	0x0086
_PCON	=	0x0087
_TCON	=	0x0088
_P0IFG	=	0x0089
_P1IFG	=	0x008a
_P2IFG	=	0x008b
_PICTL	=	0x008c
_P1IEN	=	0x008d
__SFR8E	=	0x008e
_P0INP	=	0x008f
_P1	=	0x0090
_RFIM	=	0x0091
_DPS	=	0x0092
_MPAGE	=	0x0093
__XPAGE	=	0x0093
__SFR94	=	0x0094
__SFR95	=	0x0095
__SFR96	=	0x0096
__SFR97	=	0x0097
_S0CON	=	0x0098
__SFR99	=	0x0099
_IEN2	=	0x009a
_S1CON	=	0x009b
_T2CT	=	0x009c
_T2PR	=	0x009d
_T2CTL	=	0x009e
__SFR9F	=	0x009f
_P2	=	0x00a0
_WORIRQ	=	0x00a1
_WORCTRL	=	0x00a2
_WOREVT0	=	0x00a3
_WOREVT1	=	0x00a4
_WORTIME0	=	0x00a5
_WORTIME1	=	0x00a6
__SFRA7	=	0x00a7
_IEN0	=	0x00a8
_IP0	=	0x00a9
__SFRAA	=	0x00aa
_FWT	=	0x00ab
_FADDRL	=	0x00ac
_FADDRH	=	0x00ad
_FCTL	=	0x00ae
_FWDATA	=	0x00af
__SFRB0	=	0x00b0
_ENCDI	=	0x00b1
_ENCDO	=	0x00b2
_ENCCS	=	0x00b3
_ADCCON1	=	0x00b4
_ADCCON2	=	0x00b5
_ADCCON3	=	0x00b6
__SFRB7	=	0x00b7
_IEN1	=	0x00b8
_IP1	=	0x00b9
_ADCL	=	0x00ba
_ADCH	=	0x00bb
_RNDL	=	0x00bc
_RNDH	=	0x00bd
_SLEEP	=	0x00be
__SFRBF	=	0x00bf
_IRCON	=	0x00c0
_U0DBUF	=	0x00c1
_U0BAUD	=	0x00c2
__SFRC3	=	0x00c3
_U0UCR	=	0x00c4
_U0GCR	=	0x00c5
_CLKCON	=	0x00c6
_MEMCTR	=	0x00c7
__SFRC8	=	0x00c8
_WDCTL	=	0x00c9
_T3CNT	=	0x00ca
_T3CTL	=	0x00cb
_T3CCTL0	=	0x00cc
_T3CC0	=	0x00cd
_T3CCTL1	=	0x00ce
_T3CC1	=	0x00cf
_PSW	=	0x00d0
_DMAIRQ	=	0x00d1
_DMA1CFGL	=	0x00d2
_DMA1CFGH	=	0x00d3
_DMA0CFGL	=	0x00d4
_DMA0CFGH	=	0x00d5
_DMAARM	=	0x00d6
_DMAREQ	=	0x00d7
_TIMIF	=	0x00d8
_RFD	=	0x00d9
_T1CC0L	=	0x00da
_T1CC0H	=	0x00db
_T1CC1L	=	0x00dc
_T1CC1H	=	0x00dd
_T1CC2L	=	0x00de
_T1CC2H	=	0x00df
_ACC	=	0x00e0
_RFST	=	0x00e1
_T1CNTL	=	0x00e2
_T1CNTH	=	0x00e3
_T1CTL	=	0x00e4
_T1CCTL0	=	0x00e5
_T1CCTL1	=	0x00e6
_T1CCTL2	=	0x00e7
_IRCON2	=	0x00e8
_RFIF	=	0x00e9
_T4CNT	=	0x00ea
_T4CTL	=	0x00eb
_T4CCTL0	=	0x00ec
_T4CC0	=	0x00ed
_T4CCTL1	=	0x00ee
_T4CC1	=	0x00ef
_B	=	0x00f0
_PERCFG	=	0x00f1
_ADCCFG	=	0x00f2
_P0SEL	=	0x00f3
_P1SEL	=	0x00f4
_P2SEL	=	0x00f5
_P1INP	=	0x00f6
_P2INP	=	0x00f7
_U1CSR	=	0x00f8
_U1DBUF	=	0x00f9
_U1BAUD	=	0x00fa
_U1UCR	=	0x00fb
_U1GCR	=	0x00fc
_P0DIR	=	0x00fd
_P1DIR	=	0x00fe
_P2DIR	=	0x00ff
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_P0_0	=	0x0080
_P0_1	=	0x0081
_P0_2	=	0x0082
_P0_3	=	0x0083
_P0_4	=	0x0084
_P0_5	=	0x0085
_P0_6	=	0x0086
_P0_7	=	0x0087
_IT0	=	0x0088
_RFTXRXIF	=	0x0089
_IT1	=	0x008a
_URX0IF	=	0x008b
_ADCIF	=	0x008d
_URX1IF	=	0x008f
_P1_0	=	0x0090
_P1_1	=	0x0091
_P1_2	=	0x0092
_P1_3	=	0x0093
_P1_4	=	0x0094
_P1_5	=	0x0095
_P1_6	=	0x0096
_P1_7	=	0x0097
_ENCIF_0	=	0x0098
_ENCIF_1	=	0x0099
_P2_0	=	0x00a0
_P2_1	=	0x00a1
_P2_2	=	0x00a2
_P2_3	=	0x00a3
_P2_4	=	0x00a4
_P2_5	=	0x00a5
_P2_6	=	0x00a6
_P2_7	=	0x00a7
_RFTXRXIE	=	0x00a8
_ADCIE	=	0x00a9
_URX0IE	=	0x00aa
_URX1IE	=	0x00ab
_ENCIE	=	0x00ac
_STIE	=	0x00ad
_EA	=	0x00af
_DMAIE	=	0x00b8
_T1IE	=	0x00b9
_T2IE	=	0x00ba
_T3IE	=	0x00bb
_T4IE	=	0x00bc
_P0IE	=	0x00bd
_DMAIF	=	0x00c0
_T1IF	=	0x00c1
_T2IF	=	0x00c2
_T3IF	=	0x00c3
_T4IF	=	0x00c4
_P0IF	=	0x00c5
_STIF	=	0x00c7
_P	=	0x00d0
_F1	=	0x00d1
_OV	=	0x00d2
_RS0	=	0x00d3
_RS1	=	0x00d4
_F0	=	0x00d5
_AC	=	0x00d6
_CY	=	0x00d7
_T3OVFIF	=	0x00d8
_T3CH0IF	=	0x00d9
_T3CH1IF	=	0x00da
_T4OVFIF	=	0x00db
_T4CH0IF	=	0x00dc
_T4CH1IF	=	0x00dd
_OVFIM	=	0x00de
_ACC_0	=	0x00e0
_ACC_1	=	0x00e1
_ACC_2	=	0x00e2
_ACC_3	=	0x00e3
_ACC_4	=	0x00e4
_ACC_5	=	0x00e5
_ACC_6	=	0x00e6
_ACC_7	=	0x00e7
_P2IF	=	0x00e8
_UTX0IF	=	0x00e9
_UTX1IF	=	0x00ea
_P1IF	=	0x00eb
_WDTIF	=	0x00ec
_B_0	=	0x00f0
_B_1	=	0x00f1
_B_2	=	0x00f2
_B_3	=	0x00f3
_B_4	=	0x00f4
_B_5	=	0x00f5
_B_6	=	0x00f6
_B_7	=	0x00f7
_ACTIVE	=	0x00f8
_TX_BYTE	=	0x00f9
_RX_BYTE	=	0x00fa
_ERR	=	0x00fb
_FE	=	0x00fc
_SLAVE	=	0x00fd
_RE	=	0x00fe
_MODE	=	0x00ff
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area	OSEG    (OVR,DATA)
_serial_rx_byte_sloc0_1_0:
	.ds 3
_serial_rx_byte_sloc1_1_0:
	.ds 1
_serial_rx_byte_sloc2_1_0:
	.ds 3
	.area	OSEG    (OVR,DATA)
_serial_tx_byte_sloc0_1_0:
	.ds 1
_serial_tx_byte_sloc1_1_0:
	.ds 2
	.area	OSEG    (OVR,DATA)
_serial_tx_word_sloc0_1_0:
	.ds 2
_serial_tx_word_sloc1_1_0:
	.ds 3
_serial_tx_word_sloc2_1_0:
	.ds 3
	.area	OSEG    (OVR,DATA)
_serial_tx_long_sloc0_1_0:
	.ds 1
_serial_tx_long_sloc1_1_0:
	.ds 2
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
_ready_to_send::
	.ds 1
_serial_data_available::
	.ds 1
_spi_mode::
	.ds 1
_master_send_size::
	.ds 1
_slave_send_size::
	.ds 1
_xfer_size::
	.ds 1
_serial_rx_byte___1310720032_131072_103:
	.ds 1
_serial_rx_byte_b_196608_108:
	.ds 3
_serial_rx_byte___1310720012_262144_109:
	.ds 1
_serial_tx_byte_b_196608_128:
	.ds 3
_serial_tx_byte_data_byte_196608_128:
	.ds 1
_serial_tx_byte___1966080018_327680_130:
	.ds 1
_serial_tx_byte___1310720015_524288_133:
	.ds 1
_serial_tx_word_b_196608_141:
	.ds 3
_serial_tx_word___1966080018_327680_143:
	.ds 1
_serial_tx_word___1310720015_524288_146:
	.ds 1
_serial_tx_word_b_196608_152:
	.ds 3
_serial_tx_word___1966080018_327680_154:
	.ds 1
_serial_tx_long_tx_long_65536_162:
	.ds 4
_serial_tx_long_b_196608_165:
	.ds 3
_serial_tx_long_data_byte_196608_165:
	.ds 1
_serial_tx_long___1966080018_327680_167:
	.ds 1
_serial_tx_long_b_196608_176:
	.ds 3
_serial_tx_long_data_byte_196608_176:
	.ds 1
_serial_tx_long___1966080018_327680_178:
	.ds 1
_serial_tx_long_b_196608_187:
	.ds 3
_serial_tx_long_data_byte_196608_187:
	.ds 1
_serial_tx_long___1966080018_327680_189:
	.ds 1
_serial_tx_long_b_196608_198:
	.ds 3
_serial_tx_long_data_byte_196608_198:
	.ds 1
_serial_tx_long___1966080018_327680_200:
	.ds 1
_serial_flush___1310720068_131072_208:
	.ds 1
_serial_flush___1310720063_131072_208:
	.ds 1
_serial_flush_start_time_65536_208:
	.ds 4
_serial_flush_rval_327680_231:
	.ds 1
_serial_flush_rval_327680_234:
	.ds 1
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_MDMCTRL0H	=	0xdf02
_SYNC1	=	0xdf00
_SYNC0	=	0xdf01
_PKTLEN	=	0xdf02
_PKTCTRL1	=	0xdf03
_PKTCTRL0	=	0xdf04
_ADDR	=	0xdf05
_CHANNR	=	0xdf06
_FSCTRL1	=	0xdf07
_FSCTRL0	=	0xdf08
_FREQ2	=	0xdf09
_FREQ1	=	0xdf0a
_FREQ0	=	0xdf0b
_MDMCFG4	=	0xdf0c
_MDMCFG3	=	0xdf0d
_MDMCFG2	=	0xdf0e
_MDMCFG1	=	0xdf0f
_MDMCFG0	=	0xdf10
_DEVIATN	=	0xdf11
_MCSM2	=	0xdf12
_MCSM1	=	0xdf13
_MCSM0	=	0xdf14
_FOCCFG	=	0xdf15
_BSCFG	=	0xdf16
_AGCCTRL2	=	0xdf17
_AGCCTRL1	=	0xdf18
_AGCCTRL0	=	0xdf19
_FREND1	=	0xdf1a
_FREND0	=	0xdf1b
_FSCAL3	=	0xdf1c
_FSCAL2	=	0xdf1d
_FSCAL1	=	0xdf1e
_FSCAL0	=	0xdf1f
__XREGDF20	=	0xdf20
__XREGDF21	=	0xdf21
__XREGDF22	=	0xdf22
_TEST2	=	0xdf23
_TEST1	=	0xdf24
_TEST0	=	0xdf25
__XREGDF26	=	0xdf26
_PA_TABLE7	=	0xdf27
_PA_TABLE6	=	0xdf28
_PA_TABLE5	=	0xdf29
_PA_TABLE4	=	0xdf2a
_PA_TABLE3	=	0xdf2b
_PA_TABLE2	=	0xdf2c
_PA_TABLE1	=	0xdf2d
_PA_TABLE0	=	0xdf2e
_IOCFG2	=	0xdf2f
_IOCFG1	=	0xdf30
_IOCFG0	=	0xdf31
__XREGDF32	=	0xdf32
__XREGDF33	=	0xdf33
__XREGDF34	=	0xdf34
__XREGDF35	=	0xdf35
_PARTNUM	=	0xdf36
_VERSION	=	0xdf37
_FREQEST	=	0xdf38
_LQI	=	0xdf39
_RSSI	=	0xdf3a
_MARCSTATE	=	0xdf3b
_PKTSTATUS	=	0xdf3c
_VCO_VC_DAC	=	0xdf3d
_I2SCFG0	=	0xdf40
_I2SCFG1	=	0xdf41
_I2SDATL	=	0xdf42
_I2SDATH	=	0xdf43
_I2SWCNT	=	0xdf44
_I2SSTAT	=	0xdf45
_I2SCLKF0	=	0xdf46
_I2SCLKF1	=	0xdf47
_I2SCLKF2	=	0xdf48
__NA_P0	=	0xdf80
__NA_SP	=	0xdf81
__NA_DPL0	=	0xdf82
__NA_DPH0	=	0xdf83
__NA_DPL1	=	0xdf84
__NA_DPH1	=	0xdf85
_X_U0CSR	=	0xdf86
__NA_PCON	=	0xdf87
__NA_TCON	=	0xdf88
_X_P0IFG	=	0xdf89
_X_P1IFG	=	0xdf8a
_X_P2IFG	=	0xdf8b
_X_PICTL	=	0xdf8c
_X_P1IEN	=	0xdf8d
__X_SFR8E	=	0xdf8e
_X_P0INP	=	0xdf8f
__NA_P1	=	0xdf90
_X_RFIM	=	0xdf91
__NA_DPS	=	0xdf92
_X_MPAGE	=	0xdf93
__X_SFR94	=	0xdf94
__X_SFR95	=	0xdf95
__X_SFR96	=	0xdf96
__X_SFR97	=	0xdf97
__NA_S0CON	=	0xdf98
__X_SFR99	=	0xdf99
__NA_IEN2	=	0xdf9a
__NA_S1CON	=	0xdf9b
_X_T2CT	=	0xdf9c
_X_T2PR	=	0xdf9d
_X_T2CTL	=	0xdf9e
__X_SFR9F	=	0xdf9f
__NA_P2	=	0xdfa0
_X_WORIRQ	=	0xdfa1
_X_WORCTRL	=	0xdfa2
_X_WOREVT0	=	0xdfa3
_X_WOREVT1	=	0xdfa4
_X_WORTIME0	=	0xdfa5
_X_WORTIME1	=	0xdfa6
__X_SFRA7	=	0xdfa7
__NA_IEN0	=	0xdfa8
__NA_IP0	=	0xdfa9
__X_SFRAA	=	0xdfaa
_X_FWT	=	0xdfab
_X_FADDRL	=	0xdfac
_X_FADDRH	=	0xdfad
_X_FCTL	=	0xdfae
_X_FWDATA	=	0xdfaf
__X_SFRB0	=	0xdfb0
_X_ENCDI	=	0xdfb1
_X_ENCDO	=	0xdfb2
_X_ENCCS	=	0xdfb3
_X_ADCCON1	=	0xdfb4
_X_ADCCON2	=	0xdfb5
_X_ADCCON3	=	0xdfb6
__X_SFRB7	=	0xdfb7
__NA_IEN1	=	0xdfb8
__NA_IP1	=	0xdfb9
_X_ADCL	=	0xdfba
_X_ADCH	=	0xdfbb
_X_RNDL	=	0xdfbc
_X_RNDH	=	0xdfbd
_X_SLEEP	=	0xdfbe
__X_SFRBF	=	0xdfbf
__NA_IRCON	=	0xdfc0
_X_U0DBUF	=	0xdfc1
_X_U0BAUD	=	0xdfc2
__X_SFRC3	=	0xdfc3
_X_U0UCR	=	0xdfc4
_X_U0GCR	=	0xdfc5
_X_CLKCON	=	0xdfc6
_X_MEMCTR	=	0xdfc7
__X_SFRC8	=	0xdfc8
_X_WDCTL	=	0xdfc9
_X_T3CNT	=	0xdfca
_X_T3CTL	=	0xdfcb
_X_T3CCTL0	=	0xdfcc
_X_T3CC0	=	0xdfcd
_X_T3CCTL1	=	0xdfce
_X_T3CC1	=	0xdfcf
__NA_PSW	=	0xdfd0
_X_DMAIRQ	=	0xdfd1
_X_DMA1CFGL	=	0xdfd2
_X_DMA1CFGH	=	0xdfd3
_X_DMA0CFGL	=	0xdfd4
_X_DMA0CFGH	=	0xdfd5
_X_DMAARM	=	0xdfd6
_X_DMAREQ	=	0xdfd7
_X_TIMIF	=	0xdfd8
_X_RFD	=	0xdfd9
_X_T1CC0L	=	0xdfda
_X_T1CC0H	=	0xdfdb
_X_T1CC1L	=	0xdfdc
_X_T1CC1H	=	0xdfdd
_X_T1CC2L	=	0xdfde
_X_T1CC2H	=	0xdfdf
__NA_ACC	=	0xdfe0
_X_RFST	=	0xdfe1
_X_T1CNTL	=	0xdfe2
_X_T1CNTH	=	0xdfe3
_X_T1CTL	=	0xdfe4
_X_T1CCTL0	=	0xdfe5
_X_T1CCTL1	=	0xdfe6
_X_T1CCTL2	=	0xdfe7
__NA_IRCON2	=	0xdfe8
_X_RFIF	=	0xdfe9
_X_T4CNT	=	0xdfea
_X_T4CTL	=	0xdfeb
_X_T4CCTL0	=	0xdfec
_X_T4CC0	=	0xdfed
_X_T4CCTL1	=	0xdfee
_X_T4CC1	=	0xdfef
__NA_B	=	0xdff0
_X_PERCFG	=	0xdff1
_X_ADCCFG	=	0xdff2
_X_P0SEL	=	0xdff3
_X_P1SEL	=	0xdff4
_X_P2SEL	=	0xdff5
_X_P1INP	=	0xdff6
_X_P2INP	=	0xdff7
_X_U1CSR	=	0xdff8
_X_U1DBUF	=	0xdff9
_X_U1BAUD	=	0xdffa
_X_U1UCR	=	0xdffb
_X_U1GCR	=	0xdffc
_X_P0DIR	=	0xdffd
_X_P1DIR	=	0xdffe
_X_P2DIR	=	0xdfff
_input_buffer:
	.ds 6
_input_buffer_mem:
	.ds 128
_output_buffer:
	.ds 6
_output_buffer_mem:
	.ds 128
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;	spi1_alt2/serial.c:30: volatile uint8_t ready_to_send = 0;
	mov	r0,#_ready_to_send
	clr	a
	movx	@r0,a
;	spi1_alt2/serial.c:40: volatile uint8_t master_send_size = 0;
	mov	r0,#_master_send_size
	movx	@r0,a
;	spi1_alt2/serial.c:41: volatile uint8_t slave_send_size = 0;
	mov	r0,#_slave_send_size
	movx	@r0,a
;	spi1_alt2/serial.c:42: volatile uint8_t xfer_size = 0;
	mov	r0,#_xfer_size
	movx	@r0,a
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'configure_serial'
;------------------------------------------------------------
;	spi1_alt2/serial.c:55: void configure_serial()
;	-----------------------------------------
;	 function configure_serial
;	-----------------------------------------
_configure_serial:
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	spi1_alt2/serial.c:70: PERCFG = (PERCFG & ~PERCFG_U0CFG) | PERCFG_U1CFG;
	mov	a,#0xfe
	anl	a,_PERCFG
	orl	a,#0x02
	mov	_PERCFG,a
;	spi1_alt2/serial.c:73: P1SEL = P1SEL | BIT4 | BIT5 | BIT6 | BIT7;
	orl	_P1SEL,#0xf0
;	spi1_alt2/serial.c:74: P1DIR = P1DIR & ~(BIT4 | BIT5 | BIT6 | BIT7);
	anl	_P1DIR,#0x0f
;	spi1_alt2/serial.c:81: U1CSR = (U1CSR & ~U1CSR_MODE) | U1CSR_SLAVE;
	mov	a,#0x7f
	anl	a,_U1CSR
	orl	a,#0x20
	mov	_U1CSR,a
;	spi1_alt2/serial.c:94: U1BAUD = SPI_BAUD_M;
	mov	_U1BAUD,#0x3b
;	spi1_alt2/serial.c:95: U1GCR = (U1GCR & ~(U1GCR_BAUD_E | U1GCR_CPOL | U1GCR_CPHA | U1GCR_ORDER))
	mov	a,_U1GCR
	mov	_U1GCR,#0x0b
;	spi1_alt2/serial.c:98: TCON &= ~BIT3; // Clear URX1IF
	anl	_TCON,#0xf7
;	spi1_alt2/serial.c:99: URX1IE = 1;    // Enable URX1IE interrupt
;	assignBit
	setb	_URX1IE
;	spi1_alt2/serial.c:101: IRCON2 &= ~BIT2; // Clear UTX1IF
	anl	_IRCON2,#0xfb
;	spi1_alt2/serial.c:102: IEN2 |= BIT3;    // Enable UTX1IE interrupt
	orl	_IEN2,#0x08
;	spi1_alt2/serial.c:104: U1DBUF_write = 0x44;
	mov	_U1DBUF,#0x44
;	spi1_alt2/serial.c:107: fifo_init(&input_buffer, input_buffer_mem, SPI_BUF_LEN);
;	./fifo.h:71: if (b) {
	mov	a,#_input_buffer
	orl	a,#(_input_buffer >> 8)
	jz	00103$
;	./fifo.h:72: b->head = 0;
	mov	dptr,#_input_buffer
	clr	a
	movx	@dptr,a
;	./fifo.h:73: b->tail = 0;
	mov	dptr,#(_input_buffer + 0x0001)
	mov	b,#0x00
	lcall	__gptrput
;	./fifo.h:74: b->buffer = buffer;
	mov	dptr,#(_input_buffer + 0x0002)
	mov	b,#0x00
	mov	a,#_input_buffer_mem
	lcall	__gptrput
	inc	dptr
	mov	a,#(_input_buffer_mem >> 8)
	lcall	__gptrput
	inc	dptr
	clr	a
	lcall	__gptrput
;	./fifo.h:75: b->buffer_len = size;
	mov	dptr,#(_input_buffer + 0x0005)
	mov	b,#0x00
	mov	a,#0x80
	lcall	__gptrput
;	spi1_alt2/serial.c:107: fifo_init(&input_buffer, input_buffer_mem, SPI_BUF_LEN);
00103$:
;	spi1_alt2/serial.c:108: fifo_init(&output_buffer, output_buffer_mem, SPI_BUF_LEN);
;	./fifo.h:71: if (b) {
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jz	00107$
;	./fifo.h:72: b->head = 0;
	mov	dptr,#_output_buffer
	clr	a
	movx	@dptr,a
;	./fifo.h:73: b->tail = 0;
	mov	dptr,#(_output_buffer + 0x0001)
	mov	b,#0x00
	lcall	__gptrput
;	./fifo.h:74: b->buffer = buffer;
	mov	dptr,#(_output_buffer + 0x0002)
	mov	b,#0x00
	mov	a,#_output_buffer_mem
	lcall	__gptrput
	inc	dptr
	mov	a,#(_output_buffer_mem >> 8)
	lcall	__gptrput
	inc	dptr
	clr	a
	lcall	__gptrput
;	./fifo.h:75: b->buffer_len = size;
	mov	dptr,#(_output_buffer + 0x0005)
	mov	b,#0x00
	mov	a,#0x80
;	spi1_alt2/serial.c:108: fifo_init(&output_buffer, output_buffer_mem, SPI_BUF_LEN);
;	spi1_alt2/serial.c:109: }
	ljmp	__gptrput
00107$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rx1_isr'
;------------------------------------------------------------
;	spi1_alt2/serial.c:111: void rx1_isr(void) __interrupt URX1_VECTOR
;	-----------------------------------------
;	 function rx1_isr
;	-----------------------------------------
_rx1_isr:
	push	acc
	push	b
	push	dpl
	push	dph
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	push	ar1
	push	ar0
	push	psw
	mov	psw,#0x00
;	spi1_alt2/serial.c:114: value = U1DBUF_read;
	mov	r7,_U1DBUF
;	spi1_alt2/serial.c:115: switch(spi_mode)
	mov	r0,#_spi_mode
	movx	a,@r0
	mov  r6,a
	add	a,#0xff - 0x03
	jnc	00168$
	ljmp	00126$
00168$:
	mov	a,r6
	add	a,r6
	add	a,r6
	mov	dptr,#00169$
	jmp	@a+dptr
00169$:
	ljmp	00104$
	ljmp	00108$
	ljmp	00116$
;	spi1_alt2/serial.c:117: case SPI_MODE_OUT_OF_SYNC:
;	spi1_alt2/serial.c:118: if (value == 0x99) {
	cjne	r7,#0x99,00170$
	sjmp	00171$
00170$:
	ljmp	00126$
00171$:
;	spi1_alt2/serial.c:119: spi_mode = SPI_MODE_SIZE;
	mov	r0,#_spi_mode
	mov	a,#0x01
	movx	@r0,a
;	spi1_alt2/serial.c:121: break;
	ljmp	00126$
;	spi1_alt2/serial.c:122: case SPI_MODE_IDLE:
00104$:
;	spi1_alt2/serial.c:123: if (value != 0x99) {
	cjne	r7,#0x99,00172$
	sjmp	00106$
00172$:
;	spi1_alt2/serial.c:124: spi_sync_failure_count++;
	mov	r0,#_spi_sync_failure_count
	movx	a,@r0
	mov	r5,a
	inc	r0
	movx	a,@r0
	mov	r6,a
	mov	r0,#_spi_sync_failure_count
	mov	a,#0x01
	add	a,r5
	movx	@r0,a
	clr	a
	addc	a,r6
	inc	r0
	movx	@r0,a
;	spi1_alt2/serial.c:125: spi_mode = SPI_MODE_OUT_OF_SYNC;
	mov	r0,#_spi_mode
	mov	a,#0x03
	movx	@r0,a
	ljmp	00126$
00106$:
;	spi1_alt2/serial.c:127: spi_mode = SPI_MODE_SIZE;
	mov	r0,#_spi_mode
	mov	a,#0x01
	movx	@r0,a
;	spi1_alt2/serial.c:129: break;
	ljmp	00126$
;	spi1_alt2/serial.c:130: case SPI_MODE_SIZE:
00108$:
;	spi1_alt2/serial.c:131: if (value > SPI_BUF_LEN) {
	mov	a,r7
	add	a,#0xff - 0x80
	jnc	00110$
;	spi1_alt2/serial.c:132: spi_sync_failure_count++;
	mov	r0,#_spi_sync_failure_count
	movx	a,@r0
	mov	r5,a
	inc	r0
	movx	a,@r0
	mov	r6,a
	mov	r0,#_spi_sync_failure_count
	mov	a,#0x01
	add	a,r5
	movx	@r0,a
	clr	a
	addc	a,r6
	inc	r0
	movx	@r0,a
;	spi1_alt2/serial.c:133: spi_mode = SPI_MODE_OUT_OF_SYNC;
	mov	r0,#_spi_mode
	mov	a,#0x03
	movx	@r0,a
;	spi1_alt2/serial.c:134: return;
	ljmp	00126$
00110$:
;	spi1_alt2/serial.c:136: master_send_size = value;
	mov	r0,#_master_send_size
	mov	a,r7
	movx	@r0,a
;	spi1_alt2/serial.c:137: xfer_size = master_send_size;
	mov	r0,#_master_send_size
	mov	r1,#_xfer_size
	movx	a,@r0
	movx	@r1,a
;	spi1_alt2/serial.c:138: if (slave_send_size > xfer_size) {
	mov	r0,#_slave_send_size
	mov	r1,#_xfer_size
	clr	c
	movx	a,@r0
	mov	b,a
	movx	a,@r1
	subb	a,b
	jnc	00112$
;	spi1_alt2/serial.c:139: xfer_size = slave_send_size;
	mov	r0,#_slave_send_size
	mov	r1,#_xfer_size
	movx	a,@r0
	movx	@r1,a
00112$:
;	spi1_alt2/serial.c:141: if (xfer_size > 0) {
	mov	r0,#_xfer_size
	movx	a,@r0
	jz	00114$
;	spi1_alt2/serial.c:142: spi_mode = SPI_MODE_XFER;
	mov	r0,#_spi_mode
	mov	a,#0x02
	movx	@r0,a
;	spi1_alt2/serial.c:144: CLKCON =  0xA8;		//CLKSPD = 24Mhz, TICKSPD = 750Khz
	mov	_CLKCON,#0xa8
	ljmp	00126$
00114$:
;	spi1_alt2/serial.c:146: spi_mode = SPI_MODE_IDLE;
	mov	r0,#_spi_mode
	clr	a
	movx	@r0,a
;	spi1_alt2/serial.c:148: break;
	ljmp	00126$
;	spi1_alt2/serial.c:149: case SPI_MODE_XFER:
00116$:
;	spi1_alt2/serial.c:150: if(xfer_size > 0) {	
	mov	r0,#_xfer_size
	movx	a,@r0
	jz	00122$
;	spi1_alt2/serial.c:151: if  ((uint8_t)(input_buffer.head - input_buffer.tail) < master_send_size)	{		 				//fifo_count(&input_buffer) < master_send_size
	mov	dptr,#_input_buffer
	movx	a,@dptr
	mov	r6,a
	mov	dptr,#(_input_buffer + 0x0001)
	movx	a,@dptr
	mov	r5,a
	mov	a,r6
	clr	c
	subb	a,r5
	mov	r6,a
	mov	r0,#_master_send_size
	clr	c
	movx	a,@r0
	mov	b,a
	mov	a,r6
	subb	a,b
	jnc	00120$
;	spi1_alt2/serial.c:152: input_buffer.buffer[input_buffer.head & SPI_BUF_MASK] = value; input_buffer.head++;				//fifo_put(&input_buffer, value)
	mov	dptr,#(_input_buffer + 0x0002)
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	mov	dptr,#_input_buffer
	movx	a,@dptr
	mov	r3,a
	anl	ar3,#0x7f
	mov	r2,#0x00
	mov	a,r3
	add	a,r4
	mov	r4,a
	mov	a,r2
	addc	a,r5
	mov	r5,a
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	mov	a,r7
	lcall	__gptrput
	mov	dptr,#_input_buffer
	movx	a,@dptr
	mov	r7,a
	inc	r7
;	spi1_alt2/serial.c:153: if  ((uint8_t)(input_buffer.head - input_buffer.tail) == master_send_size) {					//(fifo_count(&input_buffer) == master_send_size)
	mov	dptr,#_input_buffer
	mov	a,r7
	movx	@dptr,a
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#(_input_buffer + 0x0001)
	movx	a,@dptr
	mov	r6,a
	mov	a,r7
	clr	c
	subb	a,r6
	mov	r7,a
	mov	r0,#_master_send_size
	movx	a,@r0
	cjne	a,ar7,00120$
;	spi1_alt2/serial.c:154: master_send_size = 0;
	mov	r0,#_master_send_size
	clr	a
	movx	@r0,a
;	spi1_alt2/serial.c:155: serial_data_available = 1;
	mov	r0,#_serial_data_available
	inc	a
	movx	@r0,a
00120$:
;	spi1_alt2/serial.c:158: xfer_size--;
	mov	r0,#_xfer_size
	movx	a,@r0
	mov	r0,#_xfer_size
	dec	a
	movx	@r0,a
00122$:
;	spi1_alt2/serial.c:160: if (xfer_size == 0) {
	mov	r0,#_xfer_size
	movx	a,@r0
	jnz	00126$
;	spi1_alt2/serial.c:161: slave_send_size = 0;
	mov	r0,#_slave_send_size
	clr	a
	movx	@r0,a
;	spi1_alt2/serial.c:162: spi_mode = SPI_MODE_IDLE;
	mov	r0,#_spi_mode
	movx	@r0,a
;	spi1_alt2/serial.c:165: }
00126$:
;	spi1_alt2/serial.c:166: }
	pop	psw
	pop	ar0
	pop	ar1
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	pop	dph
	pop	dpl
	pop	b
	pop	acc
	reti
;------------------------------------------------------------
;Allocation info for local variables in function 'tx1_isr'
;------------------------------------------------------------
;	spi1_alt2/serial.c:168: void tx1_isr(void) __interrupt UTX1_VECTOR
;	-----------------------------------------
;	 function tx1_isr
;	-----------------------------------------
_tx1_isr:
	push	acc
	push	b
	push	dpl
	push	dph
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	push	ar0
	push	psw
	mov	psw,#0x00
;	spi1_alt2/serial.c:170: IRCON2 &= ~BIT2; // Clear UTX1IF
	anl	_IRCON2,#0xfb
;	spi1_alt2/serial.c:171: if (spi_mode == SPI_MODE_IDLE) {
	mov	r0,#_spi_mode
	movx	a,@r0
	jnz	00111$
;	spi1_alt2/serial.c:172: if (ready_to_send) {
	mov	r0,#_ready_to_send
	movx	a,@r0
	jz	00102$
;	spi1_alt2/serial.c:173: slave_send_size = (output_buffer.head - output_buffer.tail) ; //tell BLE how many bytes you want to send; slave_send_size = fifo_count(&output_buffer);
	mov	dptr,#_output_buffer
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#(_output_buffer + 0x0001)
	movx	a,@dptr
	mov	r6,a
	mov	a,r7
	clr	c
	subb	a,r6
	mov	r0,#_slave_send_size
	movx	@r0,a
;	spi1_alt2/serial.c:174: U1DBUF_write = slave_send_size;
	mov	r0,#_slave_send_size
	movx	a,@r0
	mov	_U1DBUF,a
	sjmp	00113$
00102$:
;	spi1_alt2/serial.c:176: U1DBUF_write = 0;
	mov	_U1DBUF,#0x00
	sjmp	00113$
00111$:
;	spi1_alt2/serial.c:179: else if (slave_send_size > 0) {
	mov	r0,#_slave_send_size
	movx	a,@r0
	jz	00108$
;	spi1_alt2/serial.c:180: if (output_buffer.head != output_buffer.tail) { 	  //U1DBUF_write = fifo_get(&output_buffer);
	mov	dptr,#_output_buffer
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#(_output_buffer + 0x0001)
	movx	a,@dptr
	mov	r6,a
	mov	a,r7
	cjne	a,ar6,00134$
	sjmp	00105$
00134$:
;	spi1_alt2/serial.c:181: U1DBUF_write = output_buffer.buffer[output_buffer.tail & SPI_BUF_MASK]; output_buffer.tail++;  
	mov	dptr,#(_output_buffer + 0x0002)
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#(_output_buffer + 0x0001)
	movx	a,@dptr
	mov	r4,a
	anl	ar4,#0x7f
	mov	r3,#0x00
	mov	a,r4
	add	a,r5
	mov	r5,a
	mov	a,r3
	addc	a,r6
	mov	r6,a
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	_U1DBUF,a
	mov	dptr,#(_output_buffer + 0x0001)
	movx	a,@dptr
	mov	r7,a
	inc	r7
	mov	dptr,#(_output_buffer + 0x0001)
	mov	a,r7
	movx	@dptr,a
	sjmp	00113$
00105$:
;	spi1_alt2/serial.c:183: else U1DBUF_write = 0x00;	//nothing in buffer but still should have been something ...
	mov	_U1DBUF,#0x00
	sjmp	00113$
00108$:
;	spi1_alt2/serial.c:188: U1DBUF_write = 0x00;
	mov	_U1DBUF,#0x00
00113$:
;	spi1_alt2/serial.c:190: }
	pop	psw
	pop	ar0
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	pop	dph
	pop	dpl
	pop	b
	pop	acc
	reti
;	eliminated unneeded push/pop ar1
;------------------------------------------------------------
;Allocation info for local variables in function 'serial_rx_avail'
;------------------------------------------------------------
;	spi1_alt2/serial.c:192: uint8_t serial_rx_avail()
;	-----------------------------------------
;	 function serial_rx_avail
;	-----------------------------------------
_serial_rx_avail:
;	spi1_alt2/serial.c:195: return(input_buffer.head - input_buffer.tail);
	mov	dptr,#_input_buffer
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#(_input_buffer + 0x0001)
	movx	a,@dptr
	mov	r6,a
	mov	a,r7
	clr	c
	subb	a,r6
	mov	dpl,a
;	spi1_alt2/serial.c:196: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'serial_rx_byte'
;------------------------------------------------------------
;sloc0                     Allocated with name '_serial_rx_byte_sloc0_1_0'
;sloc1                     Allocated with name '_serial_rx_byte_sloc1_1_0'
;sloc2                     Allocated with name '_serial_rx_byte_sloc2_1_0'
;------------------------------------------------------------
;	spi1_alt2/serial.c:198: uint8_t serial_rx_byte()
;	-----------------------------------------
;	 function serial_rx_byte
;	-----------------------------------------
_serial_rx_byte:
;	spi1_alt2/serial.c:201: if (!serial_data_available) {
	mov	r0,#_serial_data_available
	movx	a,@r0
	jnz	00106$
;	spi1_alt2/serial.c:202: while(!serial_data_available && !subg_rfspy_should_exit) {
00102$:
	mov	r0,#_serial_data_available
	movx	a,@r0
	jnz	00106$
	mov	dptr,#_subg_rfspy_should_exit
	movx	a,@dptr
	jz	00102$
00106$:
;	spi1_alt2/serial.c:206: s_data = fifo_get(&input_buffer);
	mov	r0,#_serial_rx_byte_b_196608_108
	mov	a,#_input_buffer
	movx	@r0,a
	inc	r0
	mov	a,#(_input_buffer >> 8)
	movx	@r0,a
	inc	r0
	clr	a
	movx	@r0,a
;	./fifo.h:36: uint8_t data_byte = 0;
	mov	r4,#0x00
;	./fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
	mov	a,#_input_buffer
	orl	a,#(_input_buffer >> 8)
	jz	00118$
;	./fifo.h:28: return (b ? (b->head - b->tail) : 0);
	mov	a,#_input_buffer
	orl	a,#(_input_buffer >> 8)
	jz	00120$
	mov	dptr,#_input_buffer
	movx	a,@dptr
	mov	r3,a
	mov	dptr,#(_input_buffer + 0x0001)
	mov	b,#0x00
	lcall	__gptrget
	mov	r2,a
	mov	a,r3
	clr	c
	subb	a,r2
	mov	r2,a
	mov	r3,#0x00
	sjmp	00121$
00120$:
	mov	r2,#0x00
	mov	r3,#0x00
00121$:
;	./fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
	mov	r0,#_serial_rx_byte___1310720012_262144_109
	mov	a,r2
	cjne	a,#0x01,00163$
00163$:
	clr	a
	rlc	a
	movx	@r0,a
	sjmp	00119$
00118$:
	mov	r0,#_serial_rx_byte___1310720012_262144_109
	mov	a,#0x01
	movx	@r0,a
00119$:
;	./fifo.h:38: if (!fifo_empty(b)) {
	mov	r0,#_serial_rx_byte___1310720012_262144_109
	movx	a,@r0
	jz	00164$
	ljmp	00112$
00164$:
;	./fifo.h:39: data_byte = b->buffer[b->tail % b->buffer_len];
	mov	r0,#_serial_rx_byte_b_196608_108
	movx	a,@r0
	add	a,#0x02
	mov	r2,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r7,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r7
	lcall	__gptrget
	mov	_serial_rx_byte_sloc0_1_0,a
	inc	dptr
	lcall	__gptrget
	mov	(_serial_rx_byte_sloc0_1_0 + 1),a
	inc	dptr
	lcall	__gptrget
	mov	(_serial_rx_byte_sloc0_1_0 + 2),a
	mov	r0,#_serial_rx_byte_b_196608_108
	movx	a,@r0
	add	a,#0x01
	mov	_serial_rx_byte_sloc2_1_0,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	(_serial_rx_byte_sloc2_1_0 + 1),a
	inc	r0
	movx	a,@r0
	mov	(_serial_rx_byte_sloc2_1_0 + 2),a
	mov	dpl,_serial_rx_byte_sloc2_1_0
	mov	dph,(_serial_rx_byte_sloc2_1_0 + 1)
	mov	b,(_serial_rx_byte_sloc2_1_0 + 2)
	lcall	__gptrget
	mov	_serial_rx_byte_sloc1_1_0,a
	mov	r0,#_serial_rx_byte_b_196608_108
	movx	a,@r0
	add	a,#0x05
	mov	r2,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r7,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r7
	lcall	__gptrget
	mov	r2,a
	mov	b,r2
	mov	a,_serial_rx_byte_sloc1_1_0
	div	ab
	mov	a,b
	add	a,_serial_rx_byte_sloc0_1_0
	mov	r2,a
	clr	a
	addc	a,(_serial_rx_byte_sloc0_1_0 + 1)
	mov	r7,a
	mov	r6,(_serial_rx_byte_sloc0_1_0 + 2)
	mov	dpl,r2
	mov	dph,r7
	mov	b,r6
	lcall	__gptrget
	mov	r4,a
;	./fifo.h:40: b->tail++;
	mov	dpl,_serial_rx_byte_sloc2_1_0
	mov	dph,(_serial_rx_byte_sloc2_1_0 + 1)
	mov	b,(_serial_rx_byte_sloc2_1_0 + 2)
	lcall	__gptrget
	mov	r7,a
	inc	r7
	mov	dpl,_serial_rx_byte_sloc2_1_0
	mov	dph,(_serial_rx_byte_sloc2_1_0 + 1)
	mov	b,(_serial_rx_byte_sloc2_1_0 + 2)
	mov	a,r7
	lcall	__gptrput
00112$:
;	spi1_alt2/serial.c:206: s_data = fifo_get(&input_buffer);
	mov	ar7,r4
;	spi1_alt2/serial.c:207: if (fifo_empty(&input_buffer)) {
;	./fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
	mov	a,#_input_buffer
	orl	a,#(_input_buffer >> 8)
	jz	00122$
;	./fifo.h:28: return (b ? (b->head - b->tail) : 0);
	mov	a,#_input_buffer
	orl	a,#(_input_buffer >> 8)
	jz	00124$
	mov	dptr,#_input_buffer
	movx	a,@dptr
	mov	r6,a
	mov	dptr,#(_input_buffer + 0x0001)
	mov	b,#0x00
	lcall	__gptrget
	mov	r5,a
	mov	a,r6
	clr	c
	subb	a,r5
	mov	r5,a
	mov	r6,#0x00
	sjmp	00125$
00124$:
	mov	r5,#0x00
	mov	r6,#0x00
00125$:
;	./fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
	mov	r0,#_serial_rx_byte___1310720032_131072_103
	mov	a,r5
	cjne	a,#0x01,00167$
00167$:
	clr	a
	rlc	a
	movx	@r0,a
	sjmp	00123$
00122$:
	mov	r0,#_serial_rx_byte___1310720032_131072_103
	mov	a,#0x01
	movx	@r0,a
00123$:
;	spi1_alt2/serial.c:207: if (fifo_empty(&input_buffer)) {
	mov	r0,#_serial_rx_byte___1310720032_131072_103
	movx	a,@r0
	jz	00108$
;	spi1_alt2/serial.c:208: serial_data_available = 0;
	mov	r0,#_serial_data_available
	clr	a
	movx	@r0,a
00108$:
;	spi1_alt2/serial.c:210: return s_data;
	mov	dpl,r7
;	spi1_alt2/serial.c:211: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'serial_rx_word'
;------------------------------------------------------------
;	spi1_alt2/serial.c:213: uint16_t serial_rx_word()
;	-----------------------------------------
;	 function serial_rx_word
;	-----------------------------------------
_serial_rx_word:
;	spi1_alt2/serial.c:215: return (serial_rx_byte() << 8) + serial_rx_byte();
	lcall	_serial_rx_byte
	mov	r6,dpl
	mov	r7,#0x00
	push	ar7
	push	ar6
	lcall	_serial_rx_byte
	mov	r5,dpl
	pop	ar6
	pop	ar7
	mov	r4,#0x00
	mov	a,r5
	add	a,r7
	mov	r7,a
	mov	a,r4
	addc	a,r6
;	spi1_alt2/serial.c:216: }
	mov	dpl,r7
	mov	dph,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'serial_rx_long'
;------------------------------------------------------------
;	spi1_alt2/serial.c:218: uint32_t serial_rx_long()
;	-----------------------------------------
;	 function serial_rx_long
;	-----------------------------------------
_serial_rx_long:
;	spi1_alt2/serial.c:220: return ((uint32_t)serial_rx_word() << 16) + serial_rx_word();
	lcall	_serial_rx_word
	mov	r6,dpl
	mov	r7,dph
	mov	ar4,r7
	mov	ar5,r6
	mov	r6,#0x00
	mov	r7,#0x00
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_serial_rx_word
	mov	r2,dpl
	mov	r3,dph
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	mov	ar0,r2
	mov	ar1,r3
	clr	a
	mov	r2,a
	mov	r3,a
	mov	a,r0
	add	a,r6
	mov	r6,a
	mov	a,r1
	addc	a,r7
	mov	r7,a
	mov	a,r2
	addc	a,r5
	mov	r5,a
	mov	a,r3
	addc	a,r4
	mov	dpl,r6
	mov	dph,r7
	mov	b,r5
;	spi1_alt2/serial.c:221: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'serial_tx_byte'
;------------------------------------------------------------
;sloc0                     Allocated with name '_serial_tx_byte_sloc0_1_0'
;sloc1                     Allocated with name '_serial_tx_byte_sloc1_1_0'
;------------------------------------------------------------
;	spi1_alt2/serial.c:223: void serial_tx_byte(uint8_t tx_byte)
;	-----------------------------------------
;	 function serial_tx_byte
;	-----------------------------------------
_serial_tx_byte:
	mov	a,dpl
	mov	r0,#_serial_tx_byte_data_byte_196608_128
	movx	@r0,a
;	spi1_alt2/serial.c:225: fifo_put(&output_buffer, tx_byte);
	mov	r0,#_serial_tx_byte_b_196608_128
	mov	a,#_output_buffer
	movx	@r0,a
	inc	r0
	mov	a,#(_output_buffer >> 8)
	movx	@r0,a
	inc	r0
	clr	a
	movx	@r0,a
;	./fifo.h:59: if (b) {
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jnz	00130$
	ret
00130$:
;	./fifo.h:61: if (!fifo_full(b)) {
	mov	r6,#_output_buffer
	mov	r5,#(_output_buffer >> 8)
	mov	r4,#0x00
;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jz	00110$
;	./fifo.h:28: return (b ? (b->head - b->tail) : 0);
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jz	00112$
	mov	dptr,#_output_buffer
	movx	a,@dptr
	mov	_serial_tx_byte_sloc0_1_0,a
	mov	dptr,#(_output_buffer + 0x0001)
	mov	b,#0x00
	lcall	__gptrget
	mov	r7,a
	mov	a,_serial_tx_byte_sloc0_1_0
	clr	c
	subb	a,r7
	mov	r7,a
	mov	_serial_tx_byte_sloc1_1_0,r7
	mov	(_serial_tx_byte_sloc1_1_0 + 1),#0x00
	sjmp	00113$
00112$:
	clr	a
	mov	_serial_tx_byte_sloc1_1_0,a
	mov	(_serial_tx_byte_sloc1_1_0 + 1),a
00113$:
	mov	r0,#_serial_tx_byte___1310720015_524288_133
	mov	a,_serial_tx_byte_sloc1_1_0
	movx	@r0,a
;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
	mov	a,#0x05
	add	a,r6
	mov	r2,a
	clr	a
	addc	a,r5
	mov	r3,a
	mov	ar7,r4
	mov	dpl,r2
	mov	dph,r3
	mov	b,r7
	lcall	__gptrget
	mov	r2,a
	mov	r0,#_serial_tx_byte___1310720015_524288_133
	mov	r1,#_serial_tx_byte___1966080018_327680_130
	movx	a,@r0
	cjne	a,ar2,00133$
	mov	a,#0x01
	sjmp	00134$
00133$:
	clr	a
00134$:
	movx	@r1,a
	sjmp	00111$
00110$:
	mov	r0,#_serial_tx_byte___1966080018_327680_130
	mov	a,#0x01
	movx	@r0,a
00111$:
;	./fifo.h:61: if (!fifo_full(b)) {
	mov	r0,#_serial_tx_byte___1966080018_327680_130
	movx	a,@r0
	jz	00135$
	ret
00135$:
;	./fifo.h:62: b->buffer[b->head % b->buffer_len] = data_byte;
	mov	r0,#_serial_tx_byte_b_196608_128
	movx	a,@r0
	add	a,#0x02
	mov	r2,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r7,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r7
	lcall	__gptrget
	mov	r2,a
	inc	dptr
	lcall	__gptrget
	mov	r3,a
	inc	dptr
	lcall	__gptrget
	mov	r7,a
	mov	r0,#_serial_tx_byte_b_196608_128
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	lcall	__gptrget
	mov	_serial_tx_byte_sloc1_1_0,a
	mov	r0,#_serial_tx_byte_b_196608_128
	movx	a,@r0
	add	a,#0x05
	mov	r4,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r5,a
	inc	r0
	movx	a,@r0
	mov	r6,a
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	lcall	__gptrget
	mov	r4,a
	mov	b,r4
	mov	a,_serial_tx_byte_sloc1_1_0
	div	ab
	mov	a,b
	add	a,r2
	mov	r2,a
	clr	a
	addc	a,r3
	mov	r3,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r7
	mov	r0,#_serial_tx_byte_data_byte_196608_128
	movx	a,@r0
	lcall	__gptrput
;	./fifo.h:63: b->head++;
	mov	r0,#_serial_tx_byte_b_196608_128
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	lcall	__gptrget
	mov	r7,a
	inc	r7
	mov	r0,#_serial_tx_byte_b_196608_128
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	mov	a,r7
;	spi1_alt2/serial.c:225: fifo_put(&output_buffer, tx_byte);
;	spi1_alt2/serial.c:226: }
	ljmp	__gptrput
;------------------------------------------------------------
;Allocation info for local variables in function 'serial_tx_word'
;------------------------------------------------------------
;sloc0                     Allocated with name '_serial_tx_word_sloc0_1_0'
;sloc1                     Allocated with name '_serial_tx_word_sloc1_1_0'
;sloc2                     Allocated with name '_serial_tx_word_sloc2_1_0'
;------------------------------------------------------------
;	spi1_alt2/serial.c:228: void serial_tx_word(uint16_t tx_word)
;	-----------------------------------------
;	 function serial_tx_word
;	-----------------------------------------
_serial_tx_word:
	mov	r6,dpl
	mov	r7,dph
;	spi1_alt2/serial.c:230: fifo_put(&output_buffer, tx_word >> 8);
	mov	ar5,r7
	mov	r0,#_serial_tx_word_b_196608_141
	mov	a,#_output_buffer
	movx	@r0,a
	inc	r0
	mov	a,#(_output_buffer >> 8)
	movx	@r0,a
	inc	r0
	clr	a
	movx	@r0,a
;	./fifo.h:59: if (b) {
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jnz	00157$
	ljmp	00106$
00157$:
;	./fifo.h:61: if (!fifo_full(b)) {
	mov	r4,#_output_buffer
	mov	r3,#(_output_buffer >> 8)
	mov	r2,#0x00
;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jz	00117$
;	./fifo.h:28: return (b ? (b->head - b->tail) : 0);
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jz	00119$
	push	ar6
	push	ar7
	mov	dptr,#_output_buffer
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#(_output_buffer + 0x0001)
	mov	b,#0x00
	lcall	__gptrget
	mov	r6,a
	mov	a,r7
	clr	c
	subb	a,r6
	mov	r7,a
	mov	_serial_tx_word_sloc0_1_0,r7
	mov	(_serial_tx_word_sloc0_1_0 + 1),#0x00
	pop	ar7
	pop	ar6
	sjmp	00120$
00119$:
	clr	a
	mov	_serial_tx_word_sloc0_1_0,a
	mov	(_serial_tx_word_sloc0_1_0 + 1),a
00120$:
	push	ar6
	push	ar7
	mov	r0,#_serial_tx_word___1310720015_524288_146
	mov	a,_serial_tx_word_sloc0_1_0
	movx	@r0,a
;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
	mov	a,#0x05
	add	a,r4
	mov	r4,a
	clr	a
	addc	a,r3
	mov	r6,a
	mov	ar7,r2
	mov	dpl,r4
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	r4,a
	mov	r0,#_serial_tx_word___1310720015_524288_146
	mov	r1,#_serial_tx_word___1966080018_327680_143
	movx	a,@r0
	cjne	a,ar4,00160$
	mov	a,#0x01
	sjmp	00161$
00160$:
	clr	a
00161$:
	movx	@r1,a
	pop	ar7
	pop	ar6
	sjmp	00118$
00117$:
	mov	r0,#_serial_tx_word___1966080018_327680_143
	mov	a,#0x01
	movx	@r0,a
00118$:
;	./fifo.h:61: if (!fifo_full(b)) {
	mov	r0,#_serial_tx_word___1966080018_327680_143
	movx	a,@r0
	jz	00162$
	ljmp	00106$
00162$:
;	./fifo.h:62: b->buffer[b->head % b->buffer_len] = data_byte;
	push	ar6
	push	ar7
	mov	r0,#_serial_tx_word_b_196608_141
	movx	a,@r0
	add	a,#0x02
	mov	r2,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r4,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	_serial_tx_word_sloc1_1_0,a
	inc	dptr
	lcall	__gptrget
	mov	(_serial_tx_word_sloc1_1_0 + 1),a
	inc	dptr
	lcall	__gptrget
	mov	(_serial_tx_word_sloc1_1_0 + 2),a
	mov	r0,#_serial_tx_word_b_196608_141
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	lcall	__gptrget
	mov	_serial_tx_word_sloc0_1_0,a
	mov	r0,#_serial_tx_word_b_196608_141
	movx	a,@r0
	add	a,#0x05
	mov	r4,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r6,a
	inc	r0
	movx	a,@r0
	mov	r7,a
	mov	dpl,r4
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	r4,a
	mov	b,r4
	mov	a,_serial_tx_word_sloc0_1_0
	div	ab
	mov	a,b
	add	a,_serial_tx_word_sloc1_1_0
	mov	r4,a
	clr	a
	addc	a,(_serial_tx_word_sloc1_1_0 + 1)
	mov	r7,a
	mov	r6,(_serial_tx_word_sloc1_1_0 + 2)
	mov	dpl,r4
	mov	dph,r7
	mov	b,r6
	mov	a,r5
	lcall	__gptrput
;	./fifo.h:63: b->head++;
	mov	r0,#_serial_tx_word_b_196608_141
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	lcall	__gptrget
	mov	r7,a
	inc	r7
	mov	r0,#_serial_tx_word_b_196608_141
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	mov	a,r7
	lcall	__gptrput
;	spi1_alt2/serial.c:231: fifo_put(&output_buffer, tx_word & 0xff);
	pop	ar7
	pop	ar6
;	./fifo.h:64: status = true;
00106$:
;	spi1_alt2/serial.c:231: fifo_put(&output_buffer, tx_word & 0xff);
	mov	ar5,r6
	mov	r0,#_serial_tx_word_b_196608_152
	mov	a,#_output_buffer
	movx	@r0,a
	inc	r0
	mov	a,#(_output_buffer >> 8)
	movx	@r0,a
	inc	r0
	clr	a
	movx	@r0,a
;	./fifo.h:59: if (b) {
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jnz	00163$
	ret
00163$:
;	./fifo.h:61: if (!fifo_full(b)) {
	mov	r2,#_output_buffer
	mov	r6,#(_output_buffer >> 8)
	mov	r7,#0x00
;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jz	00121$
;	./fifo.h:28: return (b ? (b->head - b->tail) : 0);
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jz	00123$
	mov	dptr,#_output_buffer
	movx	a,@dptr
	mov	r4,a
	mov	dptr,#(_output_buffer + 0x0001)
	mov	b,#0x00
	lcall	__gptrget
	mov	r3,a
	mov	a,r4
	clr	c
	subb	a,r3
	mov	r3,a
	mov	r4,#0x00
	sjmp	00124$
00123$:
	mov	r3,#0x00
	mov	r4,#0x00
00124$:
;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
	mov	a,#0x05
	add	a,r2
	mov	r2,a
	clr	a
	addc	a,r6
	mov	r6,a
	mov	dpl,r2
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	r2,a
	mov	r0,#_serial_tx_word___1966080018_327680_154
	mov	a,r3
	cjne	a,ar2,00166$
	mov	a,#0x01
	sjmp	00167$
00166$:
	clr	a
00167$:
	movx	@r0,a
	sjmp	00122$
00121$:
	mov	r0,#_serial_tx_word___1966080018_327680_154
	mov	a,#0x01
	movx	@r0,a
00122$:
;	./fifo.h:61: if (!fifo_full(b)) {
	mov	r0,#_serial_tx_word___1966080018_327680_154
	movx	a,@r0
	jz	00168$
	ret
00168$:
;	./fifo.h:62: b->buffer[b->head % b->buffer_len] = data_byte;
	mov	r0,#_serial_tx_word_b_196608_152
	movx	a,@r0
	add	a,#0x02
	mov	r4,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r6,a
	inc	r0
	movx	a,@r0
	mov	r7,a
	mov	dpl,r4
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	_serial_tx_word_sloc2_1_0,a
	inc	dptr
	lcall	__gptrget
	mov	(_serial_tx_word_sloc2_1_0 + 1),a
	inc	dptr
	lcall	__gptrget
	mov	(_serial_tx_word_sloc2_1_0 + 2),a
	mov	r0,#_serial_tx_word_b_196608_152
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	lcall	__gptrget
	mov	_serial_tx_word_sloc1_1_0,a
	mov	r0,#_serial_tx_word_b_196608_152
	movx	a,@r0
	add	a,#0x05
	mov	r2,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r7,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r7
	lcall	__gptrget
	mov	r2,a
	mov	b,r2
	mov	a,_serial_tx_word_sloc1_1_0
	div	ab
	mov	a,b
	add	a,_serial_tx_word_sloc2_1_0
	mov	r2,a
	clr	a
	addc	a,(_serial_tx_word_sloc2_1_0 + 1)
	mov	r7,a
	mov	r6,(_serial_tx_word_sloc2_1_0 + 2)
	mov	dpl,r2
	mov	dph,r7
	mov	b,r6
	mov	a,r5
	lcall	__gptrput
;	./fifo.h:63: b->head++;
	mov	r0,#_serial_tx_word_b_196608_152
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	lcall	__gptrget
	mov	r7,a
	inc	r7
	mov	r0,#_serial_tx_word_b_196608_152
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	mov	a,r7
;	spi1_alt2/serial.c:231: fifo_put(&output_buffer, tx_word & 0xff);
;	spi1_alt2/serial.c:232: }
	ljmp	__gptrput
;------------------------------------------------------------
;Allocation info for local variables in function 'serial_tx_long'
;------------------------------------------------------------
;sloc0                     Allocated with name '_serial_tx_long_sloc0_1_0'
;sloc1                     Allocated with name '_serial_tx_long_sloc1_1_0'
;------------------------------------------------------------
;	spi1_alt2/serial.c:234: void serial_tx_long(uint32_t tx_long)
;	-----------------------------------------
;	 function serial_tx_long
;	-----------------------------------------
_serial_tx_long:
	mov	r7,dpl
	mov	r6,dph
	mov	r5,b
	mov	r4,a
	mov	r0,#_serial_tx_long_tx_long_65536_162
	mov	a,r7
	movx	@r0,a
	inc	r0
	mov	a,r6
	movx	@r0,a
	inc	r0
	mov	a,r5
	movx	@r0,a
	inc	r0
	mov	a,r4
	movx	@r0,a
;	spi1_alt2/serial.c:236: fifo_put(&output_buffer, tx_long >> 24);
	mov	r0,#_serial_tx_long_tx_long_65536_162
	mov	r1,#_serial_tx_long_data_byte_196608_165
	inc	r0
	inc	r0
	inc	r0
	movx	a,@r0
	movx	@r1,a
	mov	r0,#_serial_tx_long_b_196608_165
	mov	a,#_output_buffer
	movx	@r0,a
	inc	r0
	mov	a,#(_output_buffer >> 8)
	movx	@r0,a
	inc	r0
	clr	a
	movx	@r0,a
;	./fifo.h:59: if (b) {
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jnz	00211$
	ljmp	00106$
00211$:
;	./fifo.h:61: if (!fifo_full(b)) {
	mov	r2,#_output_buffer
	mov	r3,#(_output_buffer >> 8)
	mov	r7,#0x00
;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jz	00131$
;	./fifo.h:28: return (b ? (b->head - b->tail) : 0);
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jz	00133$
	mov	dptr,#_output_buffer
	movx	a,@dptr
	mov	r6,a
	mov	dptr,#(_output_buffer + 0x0001)
	mov	b,#0x00
	lcall	__gptrget
	mov	r5,a
	mov	a,r6
	clr	c
	subb	a,r5
	mov	r5,a
	mov	r6,#0x00
	sjmp	00134$
00133$:
	mov	r5,#0x00
	mov	r6,#0x00
00134$:
;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
	mov	a,#0x05
	add	a,r2
	mov	r2,a
	clr	a
	addc	a,r3
	mov	r3,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r7
	lcall	__gptrget
	mov	r2,a
	mov	r0,#_serial_tx_long___1966080018_327680_167
	mov	a,r5
	cjne	a,ar2,00214$
	mov	a,#0x01
	sjmp	00215$
00214$:
	clr	a
00215$:
	movx	@r0,a
	sjmp	00132$
00131$:
	mov	r0,#_serial_tx_long___1966080018_327680_167
	mov	a,#0x01
	movx	@r0,a
00132$:
;	./fifo.h:61: if (!fifo_full(b)) {
	mov	r0,#_serial_tx_long___1966080018_327680_167
	movx	a,@r0
	jz	00216$
	ljmp	00106$
00216$:
;	./fifo.h:62: b->buffer[b->head % b->buffer_len] = data_byte;
	mov	r0,#_serial_tx_long_b_196608_165
	movx	a,@r0
	add	a,#0x02
	mov	r5,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r6,a
	inc	r0
	movx	a,@r0
	mov	r7,a
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	r5,a
	inc	dptr
	lcall	__gptrget
	mov	r6,a
	inc	dptr
	lcall	__gptrget
	mov	r7,a
	mov	r0,#_serial_tx_long_b_196608_165
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	lcall	__gptrget
	mov	_serial_tx_long_sloc0_1_0,a
	mov	r0,#_serial_tx_long_b_196608_165
	movx	a,@r0
	add	a,#0x05
	mov	r2,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r4,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r2,a
	mov	b,r2
	mov	a,_serial_tx_long_sloc0_1_0
	div	ab
	mov	a,b
	mov	r2,a
	add	a,r5
	mov	r5,a
	clr	a
	addc	a,r6
	mov	r6,a
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	mov	r0,#_serial_tx_long_data_byte_196608_165
	movx	a,@r0
	lcall	__gptrput
;	./fifo.h:63: b->head++;
	mov	r0,#_serial_tx_long_b_196608_165
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	lcall	__gptrget
	mov	r7,a
	inc	r7
	mov	r0,#_serial_tx_long_b_196608_165
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	mov	a,r7
	lcall	__gptrput
;	./fifo.h:64: status = true;
00106$:
;	spi1_alt2/serial.c:237: fifo_put(&output_buffer, (tx_long >> 16) & 0xff);
	mov	r0,#_serial_tx_long_tx_long_65536_162
	mov	r1,#_serial_tx_long_data_byte_196608_176
	inc	r0
	inc	r0
	movx	a,@r0
	movx	@r1,a
	mov	r0,#_serial_tx_long_b_196608_176
	mov	a,#_output_buffer
	movx	@r0,a
	inc	r0
	mov	a,#(_output_buffer >> 8)
	movx	@r0,a
	inc	r0
	clr	a
	movx	@r0,a
;	./fifo.h:59: if (b) {
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jnz	00217$
	ljmp	00113$
00217$:
;	./fifo.h:61: if (!fifo_full(b)) {
	mov	r2,#_output_buffer
	mov	r3,#(_output_buffer >> 8)
	mov	r7,#0x00
;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jz	00135$
;	./fifo.h:28: return (b ? (b->head - b->tail) : 0);
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jz	00137$
	push	ar2
	push	ar3
	push	ar7
	mov	dptr,#_output_buffer
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#(_output_buffer + 0x0001)
	mov	b,#0x00
	lcall	__gptrget
	mov	r3,a
	mov	a,r7
	clr	c
	subb	a,r3
	mov	r7,a
	mov	_serial_tx_long_sloc1_1_0,r7
	mov	(_serial_tx_long_sloc1_1_0 + 1),#0x00
	pop	ar7
	pop	ar3
	pop	ar2
	sjmp	00138$
00137$:
	clr	a
	mov	_serial_tx_long_sloc1_1_0,a
	mov	(_serial_tx_long_sloc1_1_0 + 1),a
00138$:
	mov	r6,_serial_tx_long_sloc1_1_0
;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
	mov	a,#0x05
	add	a,r2
	mov	r2,a
	clr	a
	addc	a,r3
	mov	r3,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r7
	lcall	__gptrget
	mov	r2,a
	mov	r0,#_serial_tx_long___1966080018_327680_178
	mov	a,r6
	cjne	a,ar2,00220$
	mov	a,#0x01
	sjmp	00221$
00220$:
	clr	a
00221$:
	movx	@r0,a
	sjmp	00136$
00135$:
	mov	r0,#_serial_tx_long___1966080018_327680_178
	mov	a,#0x01
	movx	@r0,a
00136$:
;	./fifo.h:61: if (!fifo_full(b)) {
	mov	r0,#_serial_tx_long___1966080018_327680_178
	movx	a,@r0
	jz	00222$
	ljmp	00113$
00222$:
;	./fifo.h:62: b->buffer[b->head % b->buffer_len] = data_byte;
	mov	r0,#_serial_tx_long_b_196608_176
	movx	a,@r0
	add	a,#0x02
	mov	r2,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r7,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r7
	lcall	__gptrget
	mov	r2,a
	inc	dptr
	lcall	__gptrget
	mov	r3,a
	inc	dptr
	lcall	__gptrget
	mov	r7,a
	mov	r0,#_serial_tx_long_b_196608_176
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	lcall	__gptrget
	mov	_serial_tx_long_sloc1_1_0,a
	mov	r0,#_serial_tx_long_b_196608_176
	movx	a,@r0
	add	a,#0x05
	mov	r4,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r5,a
	inc	r0
	movx	a,@r0
	mov	r6,a
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	lcall	__gptrget
	mov	r4,a
	mov	b,r4
	mov	a,_serial_tx_long_sloc1_1_0
	div	ab
	mov	a,b
	mov	r4,a
	add	a,r2
	mov	r2,a
	clr	a
	addc	a,r3
	mov	r3,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r7
	mov	r0,#_serial_tx_long_data_byte_196608_176
	movx	a,@r0
	lcall	__gptrput
;	./fifo.h:63: b->head++;
	mov	r0,#_serial_tx_long_b_196608_176
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	lcall	__gptrget
	mov	r7,a
	inc	r7
	mov	r0,#_serial_tx_long_b_196608_176
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	mov	a,r7
	lcall	__gptrput
;	./fifo.h:64: status = true;
00113$:
;	spi1_alt2/serial.c:238: fifo_put(&output_buffer, (tx_long >> 8) & 0xff);
	mov	r0,#_serial_tx_long_tx_long_65536_162
	mov	r1,#_serial_tx_long_data_byte_196608_187
	inc	r0
	movx	a,@r0
	movx	@r1,a
	mov	r0,#_serial_tx_long_b_196608_187
	mov	a,#_output_buffer
	movx	@r0,a
	inc	r0
	mov	a,#(_output_buffer >> 8)
	movx	@r0,a
	inc	r0
	clr	a
	movx	@r0,a
;	./fifo.h:59: if (b) {
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jnz	00223$
	ljmp	00120$
00223$:
;	./fifo.h:61: if (!fifo_full(b)) {
	mov	r2,#_output_buffer
	mov	r3,#(_output_buffer >> 8)
	mov	r7,#0x00
;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jz	00139$
;	./fifo.h:28: return (b ? (b->head - b->tail) : 0);
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jz	00141$
	push	ar2
	push	ar3
	push	ar7
	mov	dptr,#_output_buffer
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#(_output_buffer + 0x0001)
	mov	b,#0x00
	lcall	__gptrget
	mov	r3,a
	mov	a,r7
	clr	c
	subb	a,r3
	mov	r7,a
	mov	_serial_tx_long_sloc1_1_0,r7
	mov	(_serial_tx_long_sloc1_1_0 + 1),#0x00
	pop	ar7
	pop	ar3
	pop	ar2
	sjmp	00142$
00141$:
	clr	a
	mov	_serial_tx_long_sloc1_1_0,a
	mov	(_serial_tx_long_sloc1_1_0 + 1),a
00142$:
	mov	r6,_serial_tx_long_sloc1_1_0
;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
	mov	a,#0x05
	add	a,r2
	mov	r2,a
	clr	a
	addc	a,r3
	mov	r3,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r7
	lcall	__gptrget
	mov	r2,a
	mov	r0,#_serial_tx_long___1966080018_327680_189
	mov	a,r6
	cjne	a,ar2,00226$
	mov	a,#0x01
	sjmp	00227$
00226$:
	clr	a
00227$:
	movx	@r0,a
	sjmp	00140$
00139$:
	mov	r0,#_serial_tx_long___1966080018_327680_189
	mov	a,#0x01
	movx	@r0,a
00140$:
;	./fifo.h:61: if (!fifo_full(b)) {
	mov	r0,#_serial_tx_long___1966080018_327680_189
	movx	a,@r0
	jz	00228$
	ljmp	00120$
00228$:
;	./fifo.h:62: b->buffer[b->head % b->buffer_len] = data_byte;
	mov	r0,#_serial_tx_long_b_196608_187
	movx	a,@r0
	add	a,#0x02
	mov	r2,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r7,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r7
	lcall	__gptrget
	mov	r2,a
	inc	dptr
	lcall	__gptrget
	mov	r3,a
	inc	dptr
	lcall	__gptrget
	mov	r7,a
	mov	r0,#_serial_tx_long_b_196608_187
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	lcall	__gptrget
	mov	_serial_tx_long_sloc1_1_0,a
	mov	r0,#_serial_tx_long_b_196608_187
	movx	a,@r0
	add	a,#0x05
	mov	r4,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r5,a
	inc	r0
	movx	a,@r0
	mov	r6,a
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	lcall	__gptrget
	mov	r4,a
	mov	b,r4
	mov	a,_serial_tx_long_sloc1_1_0
	div	ab
	mov	a,b
	mov	r4,a
	add	a,r2
	mov	r2,a
	clr	a
	addc	a,r3
	mov	r3,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r7
	mov	r0,#_serial_tx_long_data_byte_196608_187
	movx	a,@r0
	lcall	__gptrput
;	./fifo.h:63: b->head++;
	mov	r0,#_serial_tx_long_b_196608_187
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	lcall	__gptrget
	mov	r7,a
	inc	r7
	mov	r0,#_serial_tx_long_b_196608_187
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	mov	a,r7
	lcall	__gptrput
;	./fifo.h:64: status = true;
00120$:
;	spi1_alt2/serial.c:239: fifo_put(&output_buffer, tx_long & 0xff);
	mov	r0,#_serial_tx_long_tx_long_65536_162
	mov	r1,#_serial_tx_long_data_byte_196608_198
	movx	a,@r0
	movx	@r1,a
	mov	r0,#_serial_tx_long_b_196608_198
	mov	a,#_output_buffer
	movx	@r0,a
	inc	r0
	mov	a,#(_output_buffer >> 8)
	movx	@r0,a
	inc	r0
	clr	a
	movx	@r0,a
;	./fifo.h:59: if (b) {
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jnz	00229$
	ret
00229$:
;	./fifo.h:61: if (!fifo_full(b)) {
	mov	r2,#_output_buffer
	mov	r3,#(_output_buffer >> 8)
	mov	r4,#0x00
;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jz	00143$
;	./fifo.h:28: return (b ? (b->head - b->tail) : 0);
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jz	00145$
	push	ar2
	push	ar3
	push	ar4
	mov	dptr,#_output_buffer
	movx	a,@dptr
	mov	r4,a
	mov	dptr,#(_output_buffer + 0x0001)
	mov	b,#0x00
	lcall	__gptrget
	mov	r3,a
	mov	a,r4
	clr	c
	subb	a,r3
	mov	r4,a
	mov	_serial_tx_long_sloc1_1_0,r4
	mov	(_serial_tx_long_sloc1_1_0 + 1),#0x00
	pop	ar4
	pop	ar3
	pop	ar2
	sjmp	00146$
00145$:
	clr	a
	mov	_serial_tx_long_sloc1_1_0,a
	mov	(_serial_tx_long_sloc1_1_0 + 1),a
00146$:
	mov	r7,_serial_tx_long_sloc1_1_0
;	./fifo.h:46: return (b ? (fifo_count(b) == b->buffer_len) : true);
	mov	a,#0x05
	add	a,r2
	mov	r2,a
	clr	a
	addc	a,r3
	mov	r3,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r2,a
	mov	r0,#_serial_tx_long___1966080018_327680_200
	mov	a,r7
	cjne	a,ar2,00232$
	mov	a,#0x01
	sjmp	00233$
00232$:
	clr	a
00233$:
	movx	@r0,a
	sjmp	00144$
00143$:
	mov	r0,#_serial_tx_long___1966080018_327680_200
	mov	a,#0x01
	movx	@r0,a
00144$:
;	./fifo.h:61: if (!fifo_full(b)) {
	mov	r0,#_serial_tx_long___1966080018_327680_200
	movx	a,@r0
	jz	00234$
	ret
00234$:
;	./fifo.h:62: b->buffer[b->head % b->buffer_len] = data_byte;
	mov	r0,#_serial_tx_long_b_196608_198
	movx	a,@r0
	add	a,#0x02
	mov	r2,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r4,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r2,a
	inc	dptr
	lcall	__gptrget
	mov	r3,a
	inc	dptr
	lcall	__gptrget
	mov	r4,a
	mov	r0,#_serial_tx_long_b_196608_198
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	lcall	__gptrget
	mov	_serial_tx_long_sloc1_1_0,a
	mov	r0,#_serial_tx_long_b_196608_198
	movx	a,@r0
	add	a,#0x05
	mov	r5,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r6,a
	inc	r0
	movx	a,@r0
	mov	r7,a
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	r5,a
	mov	b,r5
	mov	a,_serial_tx_long_sloc1_1_0
	div	ab
	mov	a,b
	add	a,r2
	mov	r2,a
	clr	a
	addc	a,r3
	mov	r3,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	r0,#_serial_tx_long_data_byte_196608_198
	movx	a,@r0
	lcall	__gptrput
;	./fifo.h:63: b->head++;
	mov	r0,#_serial_tx_long_b_196608_198
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	lcall	__gptrget
	mov	r7,a
	inc	r7
	mov	r0,#_serial_tx_long_b_196608_198
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	mov	a,r7
;	spi1_alt2/serial.c:239: fifo_put(&output_buffer, tx_long & 0xff);
;	spi1_alt2/serial.c:240: }
	ljmp	__gptrput
;------------------------------------------------------------
;Allocation info for local variables in function 'serial_flush'
;------------------------------------------------------------
;	spi1_alt2/serial.c:242: void serial_flush()
;	-----------------------------------------
;	 function serial_flush
;	-----------------------------------------
_serial_flush:
;	spi1_alt2/serial.c:246: if (fifo_empty(&output_buffer)) {
;	./fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jz	00124$
;	./fifo.h:28: return (b ? (b->head - b->tail) : 0);
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jz	00126$
	mov	dptr,#_output_buffer
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#(_output_buffer + 0x0001)
	mov	b,#0x00
	lcall	__gptrget
	mov	r6,a
	mov	a,r7
	clr	c
	subb	a,r6
	mov	r6,a
	mov	r7,#0x00
	sjmp	00127$
00126$:
	mov	r6,#0x00
	mov	r7,#0x00
00127$:
;	./fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
	mov	r0,#_serial_flush___1310720063_131072_208
	mov	a,r6
	cjne	a,#0x01,00178$
00178$:
	clr	a
	rlc	a
	movx	@r0,a
	sjmp	00125$
00124$:
	mov	r0,#_serial_flush___1310720063_131072_208
	mov	a,#0x01
	movx	@r0,a
00125$:
;	spi1_alt2/serial.c:246: if (fifo_empty(&output_buffer)) {
	mov	r0,#_serial_flush___1310720063_131072_208
	movx	a,@r0
	jz	00102$
;	spi1_alt2/serial.c:247: return;
	ret
00102$:
;	spi1_alt2/serial.c:251: read_timer(&start_time);
;	./timer.h:14: EA = 0;
;	assignBit
	clr	_EA
;	./timer.h:15: *result = __timerCounter;
	mov	r0,#_serial_flush_start_time_65536_208
	mov	r1,#___timerCounter
	movx	a,@r1
	movx	@r0,a
	inc	r0
	inc	r1
	movx	a,@r1
	movx	@r0,a
	inc	r0
	inc	r1
	movx	a,@r1
	movx	@r0,a
	inc	r0
	inc	r1
	movx	a,@r1
	movx	@r0,a
;	./timer.h:16: EA = 1;
;	assignBit
	setb	_EA
;	spi1_alt2/serial.c:252: ready_to_send = 1;
	mov	r0,#_ready_to_send
	mov	a,#0x01
	movx	@r0,a
;	spi1_alt2/serial.c:253: while(!fifo_empty(&output_buffer) && !subg_rfspy_should_exit) {
00106$:
;	./fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jz	00128$
;	./fifo.h:28: return (b ? (b->head - b->tail) : 0);
	mov	a,#_output_buffer
	orl	a,#(_output_buffer >> 8)
	jz	00130$
	mov	dptr,#_output_buffer
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#(_output_buffer + 0x0001)
	mov	b,#0x00
	lcall	__gptrget
	mov	r6,a
	mov	a,r7
	clr	c
	subb	a,r6
	mov	r6,a
	mov	r7,#0x00
	sjmp	00131$
00130$:
	mov	r6,#0x00
	mov	r7,#0x00
00131$:
;	./fifo.h:32: return (b ? (fifo_count(b) == 0) : true);
	mov	r0,#_serial_flush___1310720068_131072_208
	mov	a,r6
	cjne	a,#0x01,00182$
00182$:
	clr	a
	rlc	a
	movx	@r0,a
	sjmp	00129$
00128$:
	mov	r0,#_serial_flush___1310720068_131072_208
	mov	a,#0x01
	movx	@r0,a
00129$:
;	spi1_alt2/serial.c:253: while(!fifo_empty(&output_buffer) && !subg_rfspy_should_exit) {
	mov	r0,#_serial_flush___1310720068_131072_208
	movx	a,@r0
	jnz	00112$
	mov	dptr,#_subg_rfspy_should_exit
	movx	a,@dptr
	jnz	00112$
;	./timer.h:22: EA = 0;
;	assignBit
	clr	_EA
;	./timer.h:23: rval = (__timerCounter - start_time) > duration;
	mov	r0,#___timerCounter
	mov	r1,#_serial_flush_start_time_65536_208
	movx	a,@r1
	mov	b,a
	clr	c
	movx	a,@r0
	subb	a,b
	mov	r4,a
	inc	r1
	movx	a,@r1
	mov	b,a
	inc	r0
	movx	a,@r0
	subb	a,b
	mov	r5,a
	inc	r1
	movx	a,@r1
	mov	b,a
	inc	r0
	movx	a,@r0
	subb	a,b
	mov	r6,a
	inc	r1
	movx	a,@r1
	mov	b,a
	inc	r0
	movx	a,@r0
	subb	a,b
	mov	r7,a
	mov	r0,#_serial_flush_rval_327680_231
	clr	c
	mov	a,#0x88
	subb	a,r4
	mov	a,#0x13
	subb	a,r5
	clr	a
	subb	a,r6
	clr	a
	subb	a,r7
	clr	a
	rlc	a
	movx	@r0,a
;	./timer.h:24: EA = 1;
;	assignBit
	setb	_EA
;	spi1_alt2/serial.c:255: if (check_elapsed(start_time, FLUSH_TIMEOUT_MS)) {
	mov	r0,#_serial_flush_rval_327680_231
	movx	a,@r0
	jnz	00185$
	ljmp	00106$
00185$:
;	spi1_alt2/serial.c:261: while(slave_send_size != 0 && !subg_rfspy_should_exit) {
00112$:
	mov	r0,#_slave_send_size
	movx	a,@r0
	jz	00114$
	mov	dptr,#_subg_rfspy_should_exit
	movx	a,@dptr
	jnz	00114$
;	./timer.h:22: EA = 0;
;	assignBit
	clr	_EA
;	./timer.h:23: rval = (__timerCounter - start_time) > duration;
	mov	r0,#___timerCounter
	mov	r1,#_serial_flush_start_time_65536_208
	movx	a,@r1
	mov	b,a
	clr	c
	movx	a,@r0
	subb	a,b
	mov	r4,a
	inc	r1
	movx	a,@r1
	mov	b,a
	inc	r0
	movx	a,@r0
	subb	a,b
	mov	r5,a
	inc	r1
	movx	a,@r1
	mov	b,a
	inc	r0
	movx	a,@r0
	subb	a,b
	mov	r6,a
	inc	r1
	movx	a,@r1
	mov	b,a
	inc	r0
	movx	a,@r0
	subb	a,b
	mov	r7,a
	mov	r0,#_serial_flush_rval_327680_234
	clr	c
	mov	a,#0x88
	subb	a,r4
	mov	a,#0x13
	subb	a,r5
	clr	a
	subb	a,r6
	clr	a
	subb	a,r7
	clr	a
	rlc	a
	movx	@r0,a
;	./timer.h:24: EA = 1;
;	assignBit
	setb	_EA
;	spi1_alt2/serial.c:263: if (check_elapsed(start_time, FLUSH_TIMEOUT_MS)) {
	mov	r0,#_serial_flush_rval_327680_234
	movx	a,@r0
	jz	00112$
;	spi1_alt2/serial.c:264: break;
00114$:
;	spi1_alt2/serial.c:267: ready_to_send = 0;
	mov	r0,#_ready_to_send
	clr	a
	movx	@r0,a
;	spi1_alt2/serial.c:268: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'serial_tx_str'
;------------------------------------------------------------
;	spi1_alt2/serial.c:270: void serial_tx_str(const char *str) {
;	-----------------------------------------
;	 function serial_tx_str
;	-----------------------------------------
_serial_tx_str:
	mov	r5,dpl
	mov	r6,dph
	mov	r7,b
;	spi1_alt2/serial.c:271: while(*str != 0) {
00101$:
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	r4,a
	jz	00103$
;	spi1_alt2/serial.c:272: serial_tx_byte(*str);
	mov	dpl,r4
	push	ar7
	push	ar6
	push	ar5
	lcall	_serial_tx_byte
	pop	ar5
	pop	ar6
	pop	ar7
;	spi1_alt2/serial.c:273: str++;
	inc	r5
	cjne	r5,#0x00,00101$
	inc	r6
	sjmp	00101$
00103$:
;	spi1_alt2/serial.c:275: serial_flush();
;	spi1_alt2/serial.c:276: }
	ljmp	_serial_flush
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)
