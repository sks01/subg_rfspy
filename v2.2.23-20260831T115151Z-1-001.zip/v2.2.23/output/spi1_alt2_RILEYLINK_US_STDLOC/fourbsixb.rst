                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.0.2 #11662 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module fourbsixb
                                      6 	.optsdcc -mmcs51 --model-medium
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _MODE
                                     12 	.globl _RE
                                     13 	.globl _SLAVE
                                     14 	.globl _FE
                                     15 	.globl _ERR
                                     16 	.globl _RX_BYTE
                                     17 	.globl _TX_BYTE
                                     18 	.globl _ACTIVE
                                     19 	.globl _B_7
                                     20 	.globl _B_6
                                     21 	.globl _B_5
                                     22 	.globl _B_4
                                     23 	.globl _B_3
                                     24 	.globl _B_2
                                     25 	.globl _B_1
                                     26 	.globl _B_0
                                     27 	.globl _WDTIF
                                     28 	.globl _P1IF
                                     29 	.globl _UTX1IF
                                     30 	.globl _UTX0IF
                                     31 	.globl _P2IF
                                     32 	.globl _ACC_7
                                     33 	.globl _ACC_6
                                     34 	.globl _ACC_5
                                     35 	.globl _ACC_4
                                     36 	.globl _ACC_3
                                     37 	.globl _ACC_2
                                     38 	.globl _ACC_1
                                     39 	.globl _ACC_0
                                     40 	.globl _OVFIM
                                     41 	.globl _T4CH1IF
                                     42 	.globl _T4CH0IF
                                     43 	.globl _T4OVFIF
                                     44 	.globl _T3CH1IF
                                     45 	.globl _T3CH0IF
                                     46 	.globl _T3OVFIF
                                     47 	.globl _CY
                                     48 	.globl _AC
                                     49 	.globl _F0
                                     50 	.globl _RS1
                                     51 	.globl _RS0
                                     52 	.globl _OV
                                     53 	.globl _F1
                                     54 	.globl _P
                                     55 	.globl _STIF
                                     56 	.globl _P0IF
                                     57 	.globl _T4IF
                                     58 	.globl _T3IF
                                     59 	.globl _T2IF
                                     60 	.globl _T1IF
                                     61 	.globl _DMAIF
                                     62 	.globl _P0IE
                                     63 	.globl _T4IE
                                     64 	.globl _T3IE
                                     65 	.globl _T2IE
                                     66 	.globl _T1IE
                                     67 	.globl _DMAIE
                                     68 	.globl _EA
                                     69 	.globl _STIE
                                     70 	.globl _ENCIE
                                     71 	.globl _URX1IE
                                     72 	.globl _URX0IE
                                     73 	.globl _ADCIE
                                     74 	.globl _RFTXRXIE
                                     75 	.globl _P2_7
                                     76 	.globl _P2_6
                                     77 	.globl _P2_5
                                     78 	.globl _P2_4
                                     79 	.globl _P2_3
                                     80 	.globl _P2_2
                                     81 	.globl _P2_1
                                     82 	.globl _P2_0
                                     83 	.globl _ENCIF_1
                                     84 	.globl _ENCIF_0
                                     85 	.globl _P1_7
                                     86 	.globl _P1_6
                                     87 	.globl _P1_5
                                     88 	.globl _P1_4
                                     89 	.globl _P1_3
                                     90 	.globl _P1_2
                                     91 	.globl _P1_1
                                     92 	.globl _P1_0
                                     93 	.globl _URX1IF
                                     94 	.globl _ADCIF
                                     95 	.globl _URX0IF
                                     96 	.globl _IT1
                                     97 	.globl _RFTXRXIF
                                     98 	.globl _IT0
                                     99 	.globl _P0_7
                                    100 	.globl _P0_6
                                    101 	.globl _P0_5
                                    102 	.globl _P0_4
                                    103 	.globl _P0_3
                                    104 	.globl _P0_2
                                    105 	.globl _P0_1
                                    106 	.globl _P0_0
                                    107 	.globl _P2DIR
                                    108 	.globl _P1DIR
                                    109 	.globl _P0DIR
                                    110 	.globl _U1GCR
                                    111 	.globl _U1UCR
                                    112 	.globl _U1BAUD
                                    113 	.globl _U1DBUF
                                    114 	.globl _U1CSR
                                    115 	.globl _P2INP
                                    116 	.globl _P1INP
                                    117 	.globl _P2SEL
                                    118 	.globl _P1SEL
                                    119 	.globl _P0SEL
                                    120 	.globl _ADCCFG
                                    121 	.globl _PERCFG
                                    122 	.globl _B
                                    123 	.globl _T4CC1
                                    124 	.globl _T4CCTL1
                                    125 	.globl _T4CC0
                                    126 	.globl _T4CCTL0
                                    127 	.globl _T4CTL
                                    128 	.globl _T4CNT
                                    129 	.globl _RFIF
                                    130 	.globl _IRCON2
                                    131 	.globl _T1CCTL2
                                    132 	.globl _T1CCTL1
                                    133 	.globl _T1CCTL0
                                    134 	.globl _T1CTL
                                    135 	.globl _T1CNTH
                                    136 	.globl _T1CNTL
                                    137 	.globl _RFST
                                    138 	.globl _ACC
                                    139 	.globl _T1CC2H
                                    140 	.globl _T1CC2L
                                    141 	.globl _T1CC1H
                                    142 	.globl _T1CC1L
                                    143 	.globl _T1CC0H
                                    144 	.globl _T1CC0L
                                    145 	.globl _RFD
                                    146 	.globl _TIMIF
                                    147 	.globl _DMAREQ
                                    148 	.globl _DMAARM
                                    149 	.globl _DMA0CFGH
                                    150 	.globl _DMA0CFGL
                                    151 	.globl _DMA1CFGH
                                    152 	.globl _DMA1CFGL
                                    153 	.globl _DMAIRQ
                                    154 	.globl _PSW
                                    155 	.globl _T3CC1
                                    156 	.globl _T3CCTL1
                                    157 	.globl _T3CC0
                                    158 	.globl _T3CCTL0
                                    159 	.globl _T3CTL
                                    160 	.globl _T3CNT
                                    161 	.globl _WDCTL
                                    162 	.globl __SFRC8
                                    163 	.globl _MEMCTR
                                    164 	.globl _CLKCON
                                    165 	.globl _U0GCR
                                    166 	.globl _U0UCR
                                    167 	.globl __SFRC3
                                    168 	.globl _U0BAUD
                                    169 	.globl _U0DBUF
                                    170 	.globl _IRCON
                                    171 	.globl __SFRBF
                                    172 	.globl _SLEEP
                                    173 	.globl _RNDH
                                    174 	.globl _RNDL
                                    175 	.globl _ADCH
                                    176 	.globl _ADCL
                                    177 	.globl _IP1
                                    178 	.globl _IEN1
                                    179 	.globl __SFRB7
                                    180 	.globl _ADCCON3
                                    181 	.globl _ADCCON2
                                    182 	.globl _ADCCON1
                                    183 	.globl _ENCCS
                                    184 	.globl _ENCDO
                                    185 	.globl _ENCDI
                                    186 	.globl __SFRB0
                                    187 	.globl _FWDATA
                                    188 	.globl _FCTL
                                    189 	.globl _FADDRH
                                    190 	.globl _FADDRL
                                    191 	.globl _FWT
                                    192 	.globl __SFRAA
                                    193 	.globl _IP0
                                    194 	.globl _IEN0
                                    195 	.globl __SFRA7
                                    196 	.globl _WORTIME1
                                    197 	.globl _WORTIME0
                                    198 	.globl _WOREVT1
                                    199 	.globl _WOREVT0
                                    200 	.globl _WORCTRL
                                    201 	.globl _WORIRQ
                                    202 	.globl _P2
                                    203 	.globl __SFR9F
                                    204 	.globl _T2CTL
                                    205 	.globl _T2PR
                                    206 	.globl _T2CT
                                    207 	.globl _S1CON
                                    208 	.globl _IEN2
                                    209 	.globl __SFR99
                                    210 	.globl _S0CON
                                    211 	.globl __SFR97
                                    212 	.globl __SFR96
                                    213 	.globl __SFR95
                                    214 	.globl __SFR94
                                    215 	.globl __XPAGE
                                    216 	.globl _MPAGE
                                    217 	.globl _DPS
                                    218 	.globl _RFIM
                                    219 	.globl _P1
                                    220 	.globl _P0INP
                                    221 	.globl __SFR8E
                                    222 	.globl _P1IEN
                                    223 	.globl _PICTL
                                    224 	.globl _P2IFG
                                    225 	.globl _P1IFG
                                    226 	.globl _P0IFG
                                    227 	.globl _TCON
                                    228 	.globl _PCON
                                    229 	.globl _U0CSR
                                    230 	.globl _DPH1
                                    231 	.globl _DPL1
                                    232 	.globl _DPH0
                                    233 	.globl _DPL0
                                    234 	.globl _SP
                                    235 	.globl _P0
                                    236 	.globl _X_P2DIR
                                    237 	.globl _X_P1DIR
                                    238 	.globl _X_P0DIR
                                    239 	.globl _X_U1GCR
                                    240 	.globl _X_U1UCR
                                    241 	.globl _X_U1BAUD
                                    242 	.globl _X_U1DBUF
                                    243 	.globl _X_U1CSR
                                    244 	.globl _X_P2INP
                                    245 	.globl _X_P1INP
                                    246 	.globl _X_P2SEL
                                    247 	.globl _X_P1SEL
                                    248 	.globl _X_P0SEL
                                    249 	.globl _X_ADCCFG
                                    250 	.globl _X_PERCFG
                                    251 	.globl __NA_B
                                    252 	.globl _X_T4CC1
                                    253 	.globl _X_T4CCTL1
                                    254 	.globl _X_T4CC0
                                    255 	.globl _X_T4CCTL0
                                    256 	.globl _X_T4CTL
                                    257 	.globl _X_T4CNT
                                    258 	.globl _X_RFIF
                                    259 	.globl __NA_IRCON2
                                    260 	.globl _X_T1CCTL2
                                    261 	.globl _X_T1CCTL1
                                    262 	.globl _X_T1CCTL0
                                    263 	.globl _X_T1CTL
                                    264 	.globl _X_T1CNTH
                                    265 	.globl _X_T1CNTL
                                    266 	.globl _X_RFST
                                    267 	.globl __NA_ACC
                                    268 	.globl _X_T1CC2H
                                    269 	.globl _X_T1CC2L
                                    270 	.globl _X_T1CC1H
                                    271 	.globl _X_T1CC1L
                                    272 	.globl _X_T1CC0H
                                    273 	.globl _X_T1CC0L
                                    274 	.globl _X_RFD
                                    275 	.globl _X_TIMIF
                                    276 	.globl _X_DMAREQ
                                    277 	.globl _X_DMAARM
                                    278 	.globl _X_DMA0CFGH
                                    279 	.globl _X_DMA0CFGL
                                    280 	.globl _X_DMA1CFGH
                                    281 	.globl _X_DMA1CFGL
                                    282 	.globl _X_DMAIRQ
                                    283 	.globl __NA_PSW
                                    284 	.globl _X_T3CC1
                                    285 	.globl _X_T3CCTL1
                                    286 	.globl _X_T3CC0
                                    287 	.globl _X_T3CCTL0
                                    288 	.globl _X_T3CTL
                                    289 	.globl _X_T3CNT
                                    290 	.globl _X_WDCTL
                                    291 	.globl __X_SFRC8
                                    292 	.globl _X_MEMCTR
                                    293 	.globl _X_CLKCON
                                    294 	.globl _X_U0GCR
                                    295 	.globl _X_U0UCR
                                    296 	.globl __X_SFRC3
                                    297 	.globl _X_U0BAUD
                                    298 	.globl _X_U0DBUF
                                    299 	.globl __NA_IRCON
                                    300 	.globl __X_SFRBF
                                    301 	.globl _X_SLEEP
                                    302 	.globl _X_RNDH
                                    303 	.globl _X_RNDL
                                    304 	.globl _X_ADCH
                                    305 	.globl _X_ADCL
                                    306 	.globl __NA_IP1
                                    307 	.globl __NA_IEN1
                                    308 	.globl __X_SFRB7
                                    309 	.globl _X_ADCCON3
                                    310 	.globl _X_ADCCON2
                                    311 	.globl _X_ADCCON1
                                    312 	.globl _X_ENCCS
                                    313 	.globl _X_ENCDO
                                    314 	.globl _X_ENCDI
                                    315 	.globl __X_SFRB0
                                    316 	.globl _X_FWDATA
                                    317 	.globl _X_FCTL
                                    318 	.globl _X_FADDRH
                                    319 	.globl _X_FADDRL
                                    320 	.globl _X_FWT
                                    321 	.globl __X_SFRAA
                                    322 	.globl __NA_IP0
                                    323 	.globl __NA_IEN0
                                    324 	.globl __X_SFRA7
                                    325 	.globl _X_WORTIME1
                                    326 	.globl _X_WORTIME0
                                    327 	.globl _X_WOREVT1
                                    328 	.globl _X_WOREVT0
                                    329 	.globl _X_WORCTRL
                                    330 	.globl _X_WORIRQ
                                    331 	.globl __NA_P2
                                    332 	.globl __X_SFR9F
                                    333 	.globl _X_T2CTL
                                    334 	.globl _X_T2PR
                                    335 	.globl _X_T2CT
                                    336 	.globl __NA_S1CON
                                    337 	.globl __NA_IEN2
                                    338 	.globl __X_SFR99
                                    339 	.globl __NA_S0CON
                                    340 	.globl __X_SFR97
                                    341 	.globl __X_SFR96
                                    342 	.globl __X_SFR95
                                    343 	.globl __X_SFR94
                                    344 	.globl _X_MPAGE
                                    345 	.globl __NA_DPS
                                    346 	.globl _X_RFIM
                                    347 	.globl __NA_P1
                                    348 	.globl _X_P0INP
                                    349 	.globl __X_SFR8E
                                    350 	.globl _X_P1IEN
                                    351 	.globl _X_PICTL
                                    352 	.globl _X_P2IFG
                                    353 	.globl _X_P1IFG
                                    354 	.globl _X_P0IFG
                                    355 	.globl __NA_TCON
                                    356 	.globl __NA_PCON
                                    357 	.globl _X_U0CSR
                                    358 	.globl __NA_DPH1
                                    359 	.globl __NA_DPL1
                                    360 	.globl __NA_DPH0
                                    361 	.globl __NA_DPL0
                                    362 	.globl __NA_SP
                                    363 	.globl __NA_P0
                                    364 	.globl _I2SCLKF2
                                    365 	.globl _I2SCLKF1
                                    366 	.globl _I2SCLKF0
                                    367 	.globl _I2SSTAT
                                    368 	.globl _I2SWCNT
                                    369 	.globl _I2SDATH
                                    370 	.globl _I2SDATL
                                    371 	.globl _I2SCFG1
                                    372 	.globl _I2SCFG0
                                    373 	.globl _VCO_VC_DAC
                                    374 	.globl _PKTSTATUS
                                    375 	.globl _MARCSTATE
                                    376 	.globl _RSSI
                                    377 	.globl _LQI
                                    378 	.globl _FREQEST
                                    379 	.globl _VERSION
                                    380 	.globl _PARTNUM
                                    381 	.globl __XREGDF35
                                    382 	.globl __XREGDF34
                                    383 	.globl __XREGDF33
                                    384 	.globl __XREGDF32
                                    385 	.globl _IOCFG0
                                    386 	.globl _IOCFG1
                                    387 	.globl _IOCFG2
                                    388 	.globl _PA_TABLE0
                                    389 	.globl _PA_TABLE1
                                    390 	.globl _PA_TABLE2
                                    391 	.globl _PA_TABLE3
                                    392 	.globl _PA_TABLE4
                                    393 	.globl _PA_TABLE5
                                    394 	.globl _PA_TABLE6
                                    395 	.globl _PA_TABLE7
                                    396 	.globl __XREGDF26
                                    397 	.globl _TEST0
                                    398 	.globl _TEST1
                                    399 	.globl _TEST2
                                    400 	.globl __XREGDF22
                                    401 	.globl __XREGDF21
                                    402 	.globl __XREGDF20
                                    403 	.globl _FSCAL0
                                    404 	.globl _FSCAL1
                                    405 	.globl _FSCAL2
                                    406 	.globl _FSCAL3
                                    407 	.globl _FREND0
                                    408 	.globl _FREND1
                                    409 	.globl _AGCCTRL0
                                    410 	.globl _AGCCTRL1
                                    411 	.globl _AGCCTRL2
                                    412 	.globl _BSCFG
                                    413 	.globl _FOCCFG
                                    414 	.globl _MCSM0
                                    415 	.globl _MCSM1
                                    416 	.globl _MCSM2
                                    417 	.globl _DEVIATN
                                    418 	.globl _MDMCFG0
                                    419 	.globl _MDMCFG1
                                    420 	.globl _MDMCFG2
                                    421 	.globl _MDMCFG3
                                    422 	.globl _MDMCFG4
                                    423 	.globl _FREQ0
                                    424 	.globl _FREQ1
                                    425 	.globl _FREQ2
                                    426 	.globl _FSCTRL0
                                    427 	.globl _FSCTRL1
                                    428 	.globl _CHANNR
                                    429 	.globl _ADDR
                                    430 	.globl _PKTCTRL0
                                    431 	.globl _PKTCTRL1
                                    432 	.globl _PKTLEN
                                    433 	.globl _SYNC0
                                    434 	.globl _SYNC1
                                    435 	.globl _MDMCTRL0H
                                    436 	.globl _fourbsixb_init_encoder
                                    437 	.globl _fourbsixb_add_raw_byte
                                    438 	.globl _fourbsixb_next_encoded_byte
                                    439 	.globl _fourbsixb_init_decoder
                                    440 	.globl _fourbsixb_add_encoded_byte
                                    441 	.globl _fourbsixb_next_decoded_byte
                                    442 ;--------------------------------------------------------
                                    443 ; special function registers
                                    444 ;--------------------------------------------------------
                                    445 	.area RSEG    (ABS,DATA)
      000000                        446 	.org 0x0000
                           000080   447 _P0	=	0x0080
                           000081   448 _SP	=	0x0081
                           000082   449 _DPL0	=	0x0082
                           000083   450 _DPH0	=	0x0083
                           000084   451 _DPL1	=	0x0084
                           000085   452 _DPH1	=	0x0085
                           000086   453 _U0CSR	=	0x0086
                           000087   454 _PCON	=	0x0087
                           000088   455 _TCON	=	0x0088
                           000089   456 _P0IFG	=	0x0089
                           00008A   457 _P1IFG	=	0x008a
                           00008B   458 _P2IFG	=	0x008b
                           00008C   459 _PICTL	=	0x008c
                           00008D   460 _P1IEN	=	0x008d
                           00008E   461 __SFR8E	=	0x008e
                           00008F   462 _P0INP	=	0x008f
                           000090   463 _P1	=	0x0090
                           000091   464 _RFIM	=	0x0091
                           000092   465 _DPS	=	0x0092
                           000093   466 _MPAGE	=	0x0093
                           000093   467 __XPAGE	=	0x0093
                           000094   468 __SFR94	=	0x0094
                           000095   469 __SFR95	=	0x0095
                           000096   470 __SFR96	=	0x0096
                           000097   471 __SFR97	=	0x0097
                           000098   472 _S0CON	=	0x0098
                           000099   473 __SFR99	=	0x0099
                           00009A   474 _IEN2	=	0x009a
                           00009B   475 _S1CON	=	0x009b
                           00009C   476 _T2CT	=	0x009c
                           00009D   477 _T2PR	=	0x009d
                           00009E   478 _T2CTL	=	0x009e
                           00009F   479 __SFR9F	=	0x009f
                           0000A0   480 _P2	=	0x00a0
                           0000A1   481 _WORIRQ	=	0x00a1
                           0000A2   482 _WORCTRL	=	0x00a2
                           0000A3   483 _WOREVT0	=	0x00a3
                           0000A4   484 _WOREVT1	=	0x00a4
                           0000A5   485 _WORTIME0	=	0x00a5
                           0000A6   486 _WORTIME1	=	0x00a6
                           0000A7   487 __SFRA7	=	0x00a7
                           0000A8   488 _IEN0	=	0x00a8
                           0000A9   489 _IP0	=	0x00a9
                           0000AA   490 __SFRAA	=	0x00aa
                           0000AB   491 _FWT	=	0x00ab
                           0000AC   492 _FADDRL	=	0x00ac
                           0000AD   493 _FADDRH	=	0x00ad
                           0000AE   494 _FCTL	=	0x00ae
                           0000AF   495 _FWDATA	=	0x00af
                           0000B0   496 __SFRB0	=	0x00b0
                           0000B1   497 _ENCDI	=	0x00b1
                           0000B2   498 _ENCDO	=	0x00b2
                           0000B3   499 _ENCCS	=	0x00b3
                           0000B4   500 _ADCCON1	=	0x00b4
                           0000B5   501 _ADCCON2	=	0x00b5
                           0000B6   502 _ADCCON3	=	0x00b6
                           0000B7   503 __SFRB7	=	0x00b7
                           0000B8   504 _IEN1	=	0x00b8
                           0000B9   505 _IP1	=	0x00b9
                           0000BA   506 _ADCL	=	0x00ba
                           0000BB   507 _ADCH	=	0x00bb
                           0000BC   508 _RNDL	=	0x00bc
                           0000BD   509 _RNDH	=	0x00bd
                           0000BE   510 _SLEEP	=	0x00be
                           0000BF   511 __SFRBF	=	0x00bf
                           0000C0   512 _IRCON	=	0x00c0
                           0000C1   513 _U0DBUF	=	0x00c1
                           0000C2   514 _U0BAUD	=	0x00c2
                           0000C3   515 __SFRC3	=	0x00c3
                           0000C4   516 _U0UCR	=	0x00c4
                           0000C5   517 _U0GCR	=	0x00c5
                           0000C6   518 _CLKCON	=	0x00c6
                           0000C7   519 _MEMCTR	=	0x00c7
                           0000C8   520 __SFRC8	=	0x00c8
                           0000C9   521 _WDCTL	=	0x00c9
                           0000CA   522 _T3CNT	=	0x00ca
                           0000CB   523 _T3CTL	=	0x00cb
                           0000CC   524 _T3CCTL0	=	0x00cc
                           0000CD   525 _T3CC0	=	0x00cd
                           0000CE   526 _T3CCTL1	=	0x00ce
                           0000CF   527 _T3CC1	=	0x00cf
                           0000D0   528 _PSW	=	0x00d0
                           0000D1   529 _DMAIRQ	=	0x00d1
                           0000D2   530 _DMA1CFGL	=	0x00d2
                           0000D3   531 _DMA1CFGH	=	0x00d3
                           0000D4   532 _DMA0CFGL	=	0x00d4
                           0000D5   533 _DMA0CFGH	=	0x00d5
                           0000D6   534 _DMAARM	=	0x00d6
                           0000D7   535 _DMAREQ	=	0x00d7
                           0000D8   536 _TIMIF	=	0x00d8
                           0000D9   537 _RFD	=	0x00d9
                           0000DA   538 _T1CC0L	=	0x00da
                           0000DB   539 _T1CC0H	=	0x00db
                           0000DC   540 _T1CC1L	=	0x00dc
                           0000DD   541 _T1CC1H	=	0x00dd
                           0000DE   542 _T1CC2L	=	0x00de
                           0000DF   543 _T1CC2H	=	0x00df
                           0000E0   544 _ACC	=	0x00e0
                           0000E1   545 _RFST	=	0x00e1
                           0000E2   546 _T1CNTL	=	0x00e2
                           0000E3   547 _T1CNTH	=	0x00e3
                           0000E4   548 _T1CTL	=	0x00e4
                           0000E5   549 _T1CCTL0	=	0x00e5
                           0000E6   550 _T1CCTL1	=	0x00e6
                           0000E7   551 _T1CCTL2	=	0x00e7
                           0000E8   552 _IRCON2	=	0x00e8
                           0000E9   553 _RFIF	=	0x00e9
                           0000EA   554 _T4CNT	=	0x00ea
                           0000EB   555 _T4CTL	=	0x00eb
                           0000EC   556 _T4CCTL0	=	0x00ec
                           0000ED   557 _T4CC0	=	0x00ed
                           0000EE   558 _T4CCTL1	=	0x00ee
                           0000EF   559 _T4CC1	=	0x00ef
                           0000F0   560 _B	=	0x00f0
                           0000F1   561 _PERCFG	=	0x00f1
                           0000F2   562 _ADCCFG	=	0x00f2
                           0000F3   563 _P0SEL	=	0x00f3
                           0000F4   564 _P1SEL	=	0x00f4
                           0000F5   565 _P2SEL	=	0x00f5
                           0000F6   566 _P1INP	=	0x00f6
                           0000F7   567 _P2INP	=	0x00f7
                           0000F8   568 _U1CSR	=	0x00f8
                           0000F9   569 _U1DBUF	=	0x00f9
                           0000FA   570 _U1BAUD	=	0x00fa
                           0000FB   571 _U1UCR	=	0x00fb
                           0000FC   572 _U1GCR	=	0x00fc
                           0000FD   573 _P0DIR	=	0x00fd
                           0000FE   574 _P1DIR	=	0x00fe
                           0000FF   575 _P2DIR	=	0x00ff
                                    576 ;--------------------------------------------------------
                                    577 ; special function bits
                                    578 ;--------------------------------------------------------
                                    579 	.area RSEG    (ABS,DATA)
      000000                        580 	.org 0x0000
                           000080   581 _P0_0	=	0x0080
                           000081   582 _P0_1	=	0x0081
                           000082   583 _P0_2	=	0x0082
                           000083   584 _P0_3	=	0x0083
                           000084   585 _P0_4	=	0x0084
                           000085   586 _P0_5	=	0x0085
                           000086   587 _P0_6	=	0x0086
                           000087   588 _P0_7	=	0x0087
                           000088   589 _IT0	=	0x0088
                           000089   590 _RFTXRXIF	=	0x0089
                           00008A   591 _IT1	=	0x008a
                           00008B   592 _URX0IF	=	0x008b
                           00008D   593 _ADCIF	=	0x008d
                           00008F   594 _URX1IF	=	0x008f
                           000090   595 _P1_0	=	0x0090
                           000091   596 _P1_1	=	0x0091
                           000092   597 _P1_2	=	0x0092
                           000093   598 _P1_3	=	0x0093
                           000094   599 _P1_4	=	0x0094
                           000095   600 _P1_5	=	0x0095
                           000096   601 _P1_6	=	0x0096
                           000097   602 _P1_7	=	0x0097
                           000098   603 _ENCIF_0	=	0x0098
                           000099   604 _ENCIF_1	=	0x0099
                           0000A0   605 _P2_0	=	0x00a0
                           0000A1   606 _P2_1	=	0x00a1
                           0000A2   607 _P2_2	=	0x00a2
                           0000A3   608 _P2_3	=	0x00a3
                           0000A4   609 _P2_4	=	0x00a4
                           0000A5   610 _P2_5	=	0x00a5
                           0000A6   611 _P2_6	=	0x00a6
                           0000A7   612 _P2_7	=	0x00a7
                           0000A8   613 _RFTXRXIE	=	0x00a8
                           0000A9   614 _ADCIE	=	0x00a9
                           0000AA   615 _URX0IE	=	0x00aa
                           0000AB   616 _URX1IE	=	0x00ab
                           0000AC   617 _ENCIE	=	0x00ac
                           0000AD   618 _STIE	=	0x00ad
                           0000AF   619 _EA	=	0x00af
                           0000B8   620 _DMAIE	=	0x00b8
                           0000B9   621 _T1IE	=	0x00b9
                           0000BA   622 _T2IE	=	0x00ba
                           0000BB   623 _T3IE	=	0x00bb
                           0000BC   624 _T4IE	=	0x00bc
                           0000BD   625 _P0IE	=	0x00bd
                           0000C0   626 _DMAIF	=	0x00c0
                           0000C1   627 _T1IF	=	0x00c1
                           0000C2   628 _T2IF	=	0x00c2
                           0000C3   629 _T3IF	=	0x00c3
                           0000C4   630 _T4IF	=	0x00c4
                           0000C5   631 _P0IF	=	0x00c5
                           0000C7   632 _STIF	=	0x00c7
                           0000D0   633 _P	=	0x00d0
                           0000D1   634 _F1	=	0x00d1
                           0000D2   635 _OV	=	0x00d2
                           0000D3   636 _RS0	=	0x00d3
                           0000D4   637 _RS1	=	0x00d4
                           0000D5   638 _F0	=	0x00d5
                           0000D6   639 _AC	=	0x00d6
                           0000D7   640 _CY	=	0x00d7
                           0000D8   641 _T3OVFIF	=	0x00d8
                           0000D9   642 _T3CH0IF	=	0x00d9
                           0000DA   643 _T3CH1IF	=	0x00da
                           0000DB   644 _T4OVFIF	=	0x00db
                           0000DC   645 _T4CH0IF	=	0x00dc
                           0000DD   646 _T4CH1IF	=	0x00dd
                           0000DE   647 _OVFIM	=	0x00de
                           0000E0   648 _ACC_0	=	0x00e0
                           0000E1   649 _ACC_1	=	0x00e1
                           0000E2   650 _ACC_2	=	0x00e2
                           0000E3   651 _ACC_3	=	0x00e3
                           0000E4   652 _ACC_4	=	0x00e4
                           0000E5   653 _ACC_5	=	0x00e5
                           0000E6   654 _ACC_6	=	0x00e6
                           0000E7   655 _ACC_7	=	0x00e7
                           0000E8   656 _P2IF	=	0x00e8
                           0000E9   657 _UTX0IF	=	0x00e9
                           0000EA   658 _UTX1IF	=	0x00ea
                           0000EB   659 _P1IF	=	0x00eb
                           0000EC   660 _WDTIF	=	0x00ec
                           0000F0   661 _B_0	=	0x00f0
                           0000F1   662 _B_1	=	0x00f1
                           0000F2   663 _B_2	=	0x00f2
                           0000F3   664 _B_3	=	0x00f3
                           0000F4   665 _B_4	=	0x00f4
                           0000F5   666 _B_5	=	0x00f5
                           0000F6   667 _B_6	=	0x00f6
                           0000F7   668 _B_7	=	0x00f7
                           0000F8   669 _ACTIVE	=	0x00f8
                           0000F9   670 _TX_BYTE	=	0x00f9
                           0000FA   671 _RX_BYTE	=	0x00fa
                           0000FB   672 _ERR	=	0x00fb
                           0000FC   673 _FE	=	0x00fc
                           0000FD   674 _SLAVE	=	0x00fd
                           0000FE   675 _RE	=	0x00fe
                           0000FF   676 _MODE	=	0x00ff
                                    677 ;--------------------------------------------------------
                                    678 ; overlayable register banks
                                    679 ;--------------------------------------------------------
                                    680 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        681 	.ds 8
                                    682 ;--------------------------------------------------------
                                    683 ; internal ram data
                                    684 ;--------------------------------------------------------
                                    685 	.area DSEG    (DATA)
                                    686 ;--------------------------------------------------------
                                    687 ; overlayable items in internal ram 
                                    688 ;--------------------------------------------------------
                                    689 ;--------------------------------------------------------
                                    690 ; indirectly addressable internal ram data
                                    691 ;--------------------------------------------------------
                                    692 	.area ISEG    (DATA)
                                    693 ;--------------------------------------------------------
                                    694 ; absolute internal ram data
                                    695 ;--------------------------------------------------------
                                    696 	.area IABS    (ABS,DATA)
                                    697 	.area IABS    (ABS,DATA)
                                    698 ;--------------------------------------------------------
                                    699 ; bit data
                                    700 ;--------------------------------------------------------
                                    701 	.area BSEG    (BIT)
                                    702 ;--------------------------------------------------------
                                    703 ; paged external ram data
                                    704 ;--------------------------------------------------------
                                    705 	.area PSEG    (PAG,XDATA)
                                    706 ;--------------------------------------------------------
                                    707 ; external ram data
                                    708 ;--------------------------------------------------------
                                    709 	.area XSEG    (XDATA)
                           00DF02   710 _MDMCTRL0H	=	0xdf02
                           00DF00   711 _SYNC1	=	0xdf00
                           00DF01   712 _SYNC0	=	0xdf01
                           00DF02   713 _PKTLEN	=	0xdf02
                           00DF03   714 _PKTCTRL1	=	0xdf03
                           00DF04   715 _PKTCTRL0	=	0xdf04
                           00DF05   716 _ADDR	=	0xdf05
                           00DF06   717 _CHANNR	=	0xdf06
                           00DF07   718 _FSCTRL1	=	0xdf07
                           00DF08   719 _FSCTRL0	=	0xdf08
                           00DF09   720 _FREQ2	=	0xdf09
                           00DF0A   721 _FREQ1	=	0xdf0a
                           00DF0B   722 _FREQ0	=	0xdf0b
                           00DF0C   723 _MDMCFG4	=	0xdf0c
                           00DF0D   724 _MDMCFG3	=	0xdf0d
                           00DF0E   725 _MDMCFG2	=	0xdf0e
                           00DF0F   726 _MDMCFG1	=	0xdf0f
                           00DF10   727 _MDMCFG0	=	0xdf10
                           00DF11   728 _DEVIATN	=	0xdf11
                           00DF12   729 _MCSM2	=	0xdf12
                           00DF13   730 _MCSM1	=	0xdf13
                           00DF14   731 _MCSM0	=	0xdf14
                           00DF15   732 _FOCCFG	=	0xdf15
                           00DF16   733 _BSCFG	=	0xdf16
                           00DF17   734 _AGCCTRL2	=	0xdf17
                           00DF18   735 _AGCCTRL1	=	0xdf18
                           00DF19   736 _AGCCTRL0	=	0xdf19
                           00DF1A   737 _FREND1	=	0xdf1a
                           00DF1B   738 _FREND0	=	0xdf1b
                           00DF1C   739 _FSCAL3	=	0xdf1c
                           00DF1D   740 _FSCAL2	=	0xdf1d
                           00DF1E   741 _FSCAL1	=	0xdf1e
                           00DF1F   742 _FSCAL0	=	0xdf1f
                           00DF20   743 __XREGDF20	=	0xdf20
                           00DF21   744 __XREGDF21	=	0xdf21
                           00DF22   745 __XREGDF22	=	0xdf22
                           00DF23   746 _TEST2	=	0xdf23
                           00DF24   747 _TEST1	=	0xdf24
                           00DF25   748 _TEST0	=	0xdf25
                           00DF26   749 __XREGDF26	=	0xdf26
                           00DF27   750 _PA_TABLE7	=	0xdf27
                           00DF28   751 _PA_TABLE6	=	0xdf28
                           00DF29   752 _PA_TABLE5	=	0xdf29
                           00DF2A   753 _PA_TABLE4	=	0xdf2a
                           00DF2B   754 _PA_TABLE3	=	0xdf2b
                           00DF2C   755 _PA_TABLE2	=	0xdf2c
                           00DF2D   756 _PA_TABLE1	=	0xdf2d
                           00DF2E   757 _PA_TABLE0	=	0xdf2e
                           00DF2F   758 _IOCFG2	=	0xdf2f
                           00DF30   759 _IOCFG1	=	0xdf30
                           00DF31   760 _IOCFG0	=	0xdf31
                           00DF32   761 __XREGDF32	=	0xdf32
                           00DF33   762 __XREGDF33	=	0xdf33
                           00DF34   763 __XREGDF34	=	0xdf34
                           00DF35   764 __XREGDF35	=	0xdf35
                           00DF36   765 _PARTNUM	=	0xdf36
                           00DF37   766 _VERSION	=	0xdf37
                           00DF38   767 _FREQEST	=	0xdf38
                           00DF39   768 _LQI	=	0xdf39
                           00DF3A   769 _RSSI	=	0xdf3a
                           00DF3B   770 _MARCSTATE	=	0xdf3b
                           00DF3C   771 _PKTSTATUS	=	0xdf3c
                           00DF3D   772 _VCO_VC_DAC	=	0xdf3d
                           00DF40   773 _I2SCFG0	=	0xdf40
                           00DF41   774 _I2SCFG1	=	0xdf41
                           00DF42   775 _I2SDATL	=	0xdf42
                           00DF43   776 _I2SDATH	=	0xdf43
                           00DF44   777 _I2SWCNT	=	0xdf44
                           00DF45   778 _I2SSTAT	=	0xdf45
                           00DF46   779 _I2SCLKF0	=	0xdf46
                           00DF47   780 _I2SCLKF1	=	0xdf47
                           00DF48   781 _I2SCLKF2	=	0xdf48
                           00DF80   782 __NA_P0	=	0xdf80
                           00DF81   783 __NA_SP	=	0xdf81
                           00DF82   784 __NA_DPL0	=	0xdf82
                           00DF83   785 __NA_DPH0	=	0xdf83
                           00DF84   786 __NA_DPL1	=	0xdf84
                           00DF85   787 __NA_DPH1	=	0xdf85
                           00DF86   788 _X_U0CSR	=	0xdf86
                           00DF87   789 __NA_PCON	=	0xdf87
                           00DF88   790 __NA_TCON	=	0xdf88
                           00DF89   791 _X_P0IFG	=	0xdf89
                           00DF8A   792 _X_P1IFG	=	0xdf8a
                           00DF8B   793 _X_P2IFG	=	0xdf8b
                           00DF8C   794 _X_PICTL	=	0xdf8c
                           00DF8D   795 _X_P1IEN	=	0xdf8d
                           00DF8E   796 __X_SFR8E	=	0xdf8e
                           00DF8F   797 _X_P0INP	=	0xdf8f
                           00DF90   798 __NA_P1	=	0xdf90
                           00DF91   799 _X_RFIM	=	0xdf91
                           00DF92   800 __NA_DPS	=	0xdf92
                           00DF93   801 _X_MPAGE	=	0xdf93
                           00DF94   802 __X_SFR94	=	0xdf94
                           00DF95   803 __X_SFR95	=	0xdf95
                           00DF96   804 __X_SFR96	=	0xdf96
                           00DF97   805 __X_SFR97	=	0xdf97
                           00DF98   806 __NA_S0CON	=	0xdf98
                           00DF99   807 __X_SFR99	=	0xdf99
                           00DF9A   808 __NA_IEN2	=	0xdf9a
                           00DF9B   809 __NA_S1CON	=	0xdf9b
                           00DF9C   810 _X_T2CT	=	0xdf9c
                           00DF9D   811 _X_T2PR	=	0xdf9d
                           00DF9E   812 _X_T2CTL	=	0xdf9e
                           00DF9F   813 __X_SFR9F	=	0xdf9f
                           00DFA0   814 __NA_P2	=	0xdfa0
                           00DFA1   815 _X_WORIRQ	=	0xdfa1
                           00DFA2   816 _X_WORCTRL	=	0xdfa2
                           00DFA3   817 _X_WOREVT0	=	0xdfa3
                           00DFA4   818 _X_WOREVT1	=	0xdfa4
                           00DFA5   819 _X_WORTIME0	=	0xdfa5
                           00DFA6   820 _X_WORTIME1	=	0xdfa6
                           00DFA7   821 __X_SFRA7	=	0xdfa7
                           00DFA8   822 __NA_IEN0	=	0xdfa8
                           00DFA9   823 __NA_IP0	=	0xdfa9
                           00DFAA   824 __X_SFRAA	=	0xdfaa
                           00DFAB   825 _X_FWT	=	0xdfab
                           00DFAC   826 _X_FADDRL	=	0xdfac
                           00DFAD   827 _X_FADDRH	=	0xdfad
                           00DFAE   828 _X_FCTL	=	0xdfae
                           00DFAF   829 _X_FWDATA	=	0xdfaf
                           00DFB0   830 __X_SFRB0	=	0xdfb0
                           00DFB1   831 _X_ENCDI	=	0xdfb1
                           00DFB2   832 _X_ENCDO	=	0xdfb2
                           00DFB3   833 _X_ENCCS	=	0xdfb3
                           00DFB4   834 _X_ADCCON1	=	0xdfb4
                           00DFB5   835 _X_ADCCON2	=	0xdfb5
                           00DFB6   836 _X_ADCCON3	=	0xdfb6
                           00DFB7   837 __X_SFRB7	=	0xdfb7
                           00DFB8   838 __NA_IEN1	=	0xdfb8
                           00DFB9   839 __NA_IP1	=	0xdfb9
                           00DFBA   840 _X_ADCL	=	0xdfba
                           00DFBB   841 _X_ADCH	=	0xdfbb
                           00DFBC   842 _X_RNDL	=	0xdfbc
                           00DFBD   843 _X_RNDH	=	0xdfbd
                           00DFBE   844 _X_SLEEP	=	0xdfbe
                           00DFBF   845 __X_SFRBF	=	0xdfbf
                           00DFC0   846 __NA_IRCON	=	0xdfc0
                           00DFC1   847 _X_U0DBUF	=	0xdfc1
                           00DFC2   848 _X_U0BAUD	=	0xdfc2
                           00DFC3   849 __X_SFRC3	=	0xdfc3
                           00DFC4   850 _X_U0UCR	=	0xdfc4
                           00DFC5   851 _X_U0GCR	=	0xdfc5
                           00DFC6   852 _X_CLKCON	=	0xdfc6
                           00DFC7   853 _X_MEMCTR	=	0xdfc7
                           00DFC8   854 __X_SFRC8	=	0xdfc8
                           00DFC9   855 _X_WDCTL	=	0xdfc9
                           00DFCA   856 _X_T3CNT	=	0xdfca
                           00DFCB   857 _X_T3CTL	=	0xdfcb
                           00DFCC   858 _X_T3CCTL0	=	0xdfcc
                           00DFCD   859 _X_T3CC0	=	0xdfcd
                           00DFCE   860 _X_T3CCTL1	=	0xdfce
                           00DFCF   861 _X_T3CC1	=	0xdfcf
                           00DFD0   862 __NA_PSW	=	0xdfd0
                           00DFD1   863 _X_DMAIRQ	=	0xdfd1
                           00DFD2   864 _X_DMA1CFGL	=	0xdfd2
                           00DFD3   865 _X_DMA1CFGH	=	0xdfd3
                           00DFD4   866 _X_DMA0CFGL	=	0xdfd4
                           00DFD5   867 _X_DMA0CFGH	=	0xdfd5
                           00DFD6   868 _X_DMAARM	=	0xdfd6
                           00DFD7   869 _X_DMAREQ	=	0xdfd7
                           00DFD8   870 _X_TIMIF	=	0xdfd8
                           00DFD9   871 _X_RFD	=	0xdfd9
                           00DFDA   872 _X_T1CC0L	=	0xdfda
                           00DFDB   873 _X_T1CC0H	=	0xdfdb
                           00DFDC   874 _X_T1CC1L	=	0xdfdc
                           00DFDD   875 _X_T1CC1H	=	0xdfdd
                           00DFDE   876 _X_T1CC2L	=	0xdfde
                           00DFDF   877 _X_T1CC2H	=	0xdfdf
                           00DFE0   878 __NA_ACC	=	0xdfe0
                           00DFE1   879 _X_RFST	=	0xdfe1
                           00DFE2   880 _X_T1CNTL	=	0xdfe2
                           00DFE3   881 _X_T1CNTH	=	0xdfe3
                           00DFE4   882 _X_T1CTL	=	0xdfe4
                           00DFE5   883 _X_T1CCTL0	=	0xdfe5
                           00DFE6   884 _X_T1CCTL1	=	0xdfe6
                           00DFE7   885 _X_T1CCTL2	=	0xdfe7
                           00DFE8   886 __NA_IRCON2	=	0xdfe8
                           00DFE9   887 _X_RFIF	=	0xdfe9
                           00DFEA   888 _X_T4CNT	=	0xdfea
                           00DFEB   889 _X_T4CTL	=	0xdfeb
                           00DFEC   890 _X_T4CCTL0	=	0xdfec
                           00DFED   891 _X_T4CC0	=	0xdfed
                           00DFEE   892 _X_T4CCTL1	=	0xdfee
                           00DFEF   893 _X_T4CC1	=	0xdfef
                           00DFF0   894 __NA_B	=	0xdff0
                           00DFF1   895 _X_PERCFG	=	0xdff1
                           00DFF2   896 _X_ADCCFG	=	0xdff2
                           00DFF3   897 _X_P0SEL	=	0xdff3
                           00DFF4   898 _X_P1SEL	=	0xdff4
                           00DFF5   899 _X_P2SEL	=	0xdff5
                           00DFF6   900 _X_P1INP	=	0xdff6
                           00DFF7   901 _X_P2INP	=	0xdff7
                           00DFF8   902 _X_U1CSR	=	0xdff8
                           00DFF9   903 _X_U1DBUF	=	0xdff9
                           00DFFA   904 _X_U1BAUD	=	0xdffa
                           00DFFB   905 _X_U1UCR	=	0xdffb
                           00DFFC   906 _X_U1GCR	=	0xdffc
                           00DFFD   907 _X_P0DIR	=	0xdffd
                           00DFFE   908 _X_P1DIR	=	0xdffe
                           00DFFF   909 _X_P2DIR	=	0xdfff
                                    910 ;--------------------------------------------------------
                                    911 ; absolute external ram data
                                    912 ;--------------------------------------------------------
                                    913 	.area XABS    (ABS,XDATA)
                                    914 ;--------------------------------------------------------
                                    915 ; external initialized ram data
                                    916 ;--------------------------------------------------------
                                    917 	.area XISEG   (XDATA)
      00F319                        918 _codes:
      00F319                        919 	.ds 16
                                    920 	.area HOME    (CODE)
                                    921 	.area GSINIT0 (CODE)
                                    922 	.area GSINIT1 (CODE)
                                    923 	.area GSINIT2 (CODE)
                                    924 	.area GSINIT3 (CODE)
                                    925 	.area GSINIT4 (CODE)
                                    926 	.area GSINIT5 (CODE)
                                    927 	.area GSINIT  (CODE)
                                    928 	.area GSFINAL (CODE)
                                    929 	.area CSEG    (CODE)
                                    930 ;--------------------------------------------------------
                                    931 ; global & static initialisations
                                    932 ;--------------------------------------------------------
                                    933 	.area HOME    (CODE)
                                    934 	.area GSINIT  (CODE)
                                    935 	.area GSFINAL (CODE)
                                    936 	.area GSINIT  (CODE)
                                    937 ;--------------------------------------------------------
                                    938 ; Home
                                    939 ;--------------------------------------------------------
                                    940 	.area HOME    (CODE)
                                    941 	.area HOME    (CODE)
                                    942 ;--------------------------------------------------------
                                    943 ; code
                                    944 ;--------------------------------------------------------
                                    945 	.area CSEG    (CODE)
                                    946 ;------------------------------------------------------------
                                    947 ;Allocation info for local variables in function 'fourbsixb_init_encoder'
                                    948 ;------------------------------------------------------------
                                    949 ;	fourbsixb.c:8: void fourbsixb_init_encoder(EncoderState *state) {
                                    950 ;	-----------------------------------------
                                    951 ;	 function fourbsixb_init_encoder
                                    952 ;	-----------------------------------------
      0012C1                        953 _fourbsixb_init_encoder:
                           000007   954 	ar7 = 0x07
                           000006   955 	ar6 = 0x06
                           000005   956 	ar5 = 0x05
                           000004   957 	ar4 = 0x04
                           000003   958 	ar3 = 0x03
                           000002   959 	ar2 = 0x02
                           000001   960 	ar1 = 0x01
                           000000   961 	ar0 = 0x00
                                    962 ;	fourbsixb.c:9: state->fourbsixb.acc = 0;
      0012C1 AD 82            [24]  963 	mov	r5,dpl
      0012C3 AE 83            [24]  964 	mov	r6,dph
      0012C5 AF F0            [24]  965 	mov	r7,b
      0012C7 E4               [12]  966 	clr	a
      0012C8 12 2D 8A         [24]  967 	lcall	__gptrput
      0012CB A3               [24]  968 	inc	dptr
      0012CC 12 2D 8A         [24]  969 	lcall	__gptrput
                                    970 ;	fourbsixb.c:10: state->fourbsixb.bits_avail = 0;
      0012CF 74 02            [12]  971 	mov	a,#0x02
      0012D1 2D               [12]  972 	add	a,r5
      0012D2 FD               [12]  973 	mov	r5,a
      0012D3 E4               [12]  974 	clr	a
      0012D4 3E               [12]  975 	addc	a,r6
      0012D5 FE               [12]  976 	mov	r6,a
      0012D6 8D 82            [24]  977 	mov	dpl,r5
      0012D8 8E 83            [24]  978 	mov	dph,r6
      0012DA 8F F0            [24]  979 	mov	b,r7
      0012DC E4               [12]  980 	clr	a
                                    981 ;	fourbsixb.c:11: }
      0012DD 02 2D 8A         [24]  982 	ljmp	__gptrput
                                    983 ;------------------------------------------------------------
                                    984 ;Allocation info for local variables in function 'fourbsixb_add_raw_byte'
                                    985 ;------------------------------------------------------------
                                    986 ;raw                       Allocated to stack - _bp -3
                                    987 ;state                     Allocated to stack - _bp +1
                                    988 ;new_bits                  Allocated to registers r4 r3 
                                    989 ;------------------------------------------------------------
                                    990 ;	fourbsixb.c:13: void fourbsixb_add_raw_byte(EncoderState *state, uint8_t raw) __reentrant {
                                    991 ;	-----------------------------------------
                                    992 ;	 function fourbsixb_add_raw_byte
                                    993 ;	-----------------------------------------
      0012E0                        994 _fourbsixb_add_raw_byte:
      0012E0 C0 18            [24]  995 	push	_bp
      0012E2 85 81 18         [24]  996 	mov	_bp,sp
      0012E5 C0 82            [24]  997 	push	dpl
      0012E7 C0 83            [24]  998 	push	dph
      0012E9 C0 F0            [24]  999 	push	b
                                   1000 ;	fourbsixb.c:14: uint16_t new_bits = (codes[raw >> 4] << 6) | codes[raw & 0xf];
      0012EB E5 18            [12] 1001 	mov	a,_bp
      0012ED 24 FD            [12] 1002 	add	a,#0xfd
      0012EF F8               [12] 1003 	mov	r0,a
      0012F0 E6               [12] 1004 	mov	a,@r0
      0012F1 C4               [12] 1005 	swap	a
      0012F2 54 0F            [12] 1006 	anl	a,#0x0f
      0012F4 24 19            [12] 1007 	add	a,#_codes
      0012F6 F5 82            [12] 1008 	mov	dpl,a
      0012F8 E4               [12] 1009 	clr	a
      0012F9 34 F3            [12] 1010 	addc	a,#(_codes >> 8)
      0012FB F5 83            [12] 1011 	mov	dph,a
      0012FD E0               [24] 1012 	movx	a,@dptr
      0012FE FC               [12] 1013 	mov	r4,a
      0012FF E4               [12] 1014 	clr	a
      001300 C3               [12] 1015 	clr	c
      001301 CC               [12] 1016 	xch	a,r4
      001302 13               [12] 1017 	rrc	a
      001303 CC               [12] 1018 	xch	a,r4
      001304 13               [12] 1019 	rrc	a
      001305 A2 E0            [12] 1020 	mov	c,acc.0
      001307 CC               [12] 1021 	xch	a,r4
      001308 13               [12] 1022 	rrc	a
      001309 CC               [12] 1023 	xch	a,r4
      00130A 13               [12] 1024 	rrc	a
      00130B CC               [12] 1025 	xch	a,r4
      00130C FB               [12] 1026 	mov	r3,a
      00130D E5 18            [12] 1027 	mov	a,_bp
      00130F 24 FD            [12] 1028 	add	a,#0xfd
      001311 F8               [12] 1029 	mov	r0,a
      001312 86 02            [24] 1030 	mov	ar2,@r0
      001314 53 02 0F         [24] 1031 	anl	ar2,#0x0f
      001317 7F 00            [12] 1032 	mov	r7,#0x00
      001319 EA               [12] 1033 	mov	a,r2
      00131A 24 19            [12] 1034 	add	a,#_codes
      00131C F5 82            [12] 1035 	mov	dpl,a
      00131E EF               [12] 1036 	mov	a,r7
      00131F 34 F3            [12] 1037 	addc	a,#(_codes >> 8)
      001321 F5 83            [12] 1038 	mov	dph,a
      001323 E0               [24] 1039 	movx	a,@dptr
      001324 7E 00            [12] 1040 	mov	r6,#0x00
      001326 42 04            [12] 1041 	orl	ar4,a
      001328 EE               [12] 1042 	mov	a,r6
      001329 42 03            [12] 1043 	orl	ar3,a
                                   1044 ;	fourbsixb.c:15: state->fourbsixb.acc = (state->fourbsixb.acc << 12) | new_bits;
      00132B A8 18            [24] 1045 	mov	r0,_bp
      00132D 08               [12] 1046 	inc	r0
      00132E 86 82            [24] 1047 	mov	dpl,@r0
      001330 08               [12] 1048 	inc	r0
      001331 86 83            [24] 1049 	mov	dph,@r0
      001333 08               [12] 1050 	inc	r0
      001334 86 F0            [24] 1051 	mov	b,@r0
      001336 12 2E 55         [24] 1052 	lcall	__gptrget
      001339 FE               [12] 1053 	mov	r6,a
      00133A A3               [24] 1054 	inc	dptr
      00133B 12 2E 55         [24] 1055 	lcall	__gptrget
      00133E EE               [12] 1056 	mov	a,r6
      00133F C4               [12] 1057 	swap	a
      001340 54 F0            [12] 1058 	anl	a,#0xf0
      001342 FF               [12] 1059 	mov	r7,a
      001343 E4               [12] 1060 	clr	a
      001344 42 04            [12] 1061 	orl	ar4,a
      001346 EF               [12] 1062 	mov	a,r7
      001347 42 03            [12] 1063 	orl	ar3,a
      001349 A8 18            [24] 1064 	mov	r0,_bp
      00134B 08               [12] 1065 	inc	r0
      00134C 86 82            [24] 1066 	mov	dpl,@r0
      00134E 08               [12] 1067 	inc	r0
      00134F 86 83            [24] 1068 	mov	dph,@r0
      001351 08               [12] 1069 	inc	r0
      001352 86 F0            [24] 1070 	mov	b,@r0
      001354 EC               [12] 1071 	mov	a,r4
      001355 12 2D 8A         [24] 1072 	lcall	__gptrput
      001358 A3               [24] 1073 	inc	dptr
      001359 EB               [12] 1074 	mov	a,r3
      00135A 12 2D 8A         [24] 1075 	lcall	__gptrput
                                   1076 ;	fourbsixb.c:16: state->fourbsixb.bits_avail += 12;
      00135D A8 18            [24] 1077 	mov	r0,_bp
      00135F 08               [12] 1078 	inc	r0
      001360 74 02            [12] 1079 	mov	a,#0x02
      001362 26               [12] 1080 	add	a,@r0
      001363 FD               [12] 1081 	mov	r5,a
      001364 E4               [12] 1082 	clr	a
      001365 08               [12] 1083 	inc	r0
      001366 36               [12] 1084 	addc	a,@r0
      001367 FE               [12] 1085 	mov	r6,a
      001368 08               [12] 1086 	inc	r0
      001369 86 07            [24] 1087 	mov	ar7,@r0
      00136B 8D 82            [24] 1088 	mov	dpl,r5
      00136D 8E 83            [24] 1089 	mov	dph,r6
      00136F 8F F0            [24] 1090 	mov	b,r7
      001371 12 2E 55         [24] 1091 	lcall	__gptrget
      001374 24 0C            [12] 1092 	add	a,#0x0c
      001376 8D 82            [24] 1093 	mov	dpl,r5
      001378 8E 83            [24] 1094 	mov	dph,r6
      00137A 8F F0            [24] 1095 	mov	b,r7
      00137C 12 2D 8A         [24] 1096 	lcall	__gptrput
                                   1097 ;	fourbsixb.c:17: }
      00137F 85 18 81         [24] 1098 	mov	sp,_bp
      001382 D0 18            [24] 1099 	pop	_bp
      001384 22               [24] 1100 	ret
                                   1101 ;------------------------------------------------------------
                                   1102 ;Allocation info for local variables in function 'fourbsixb_next_encoded_byte'
                                   1103 ;------------------------------------------------------------
                                   1104 ;encoded                   Allocated to stack - _bp -5
                                   1105 ;flush                     Allocated to stack - _bp -6
                                   1106 ;state                     Allocated to stack - _bp +1
                                   1107 ;sloc0                     Allocated to stack - _bp +4
                                   1108 ;sloc1                     Allocated to stack - _bp +5
                                   1109 ;sloc2                     Allocated to stack - _bp +4
                                   1110 ;------------------------------------------------------------
                                   1111 ;	fourbsixb.c:19: uint8_t fourbsixb_next_encoded_byte(EncoderState *state, uint8_t *encoded, bool flush) __reentrant {
                                   1112 ;	-----------------------------------------
                                   1113 ;	 function fourbsixb_next_encoded_byte
                                   1114 ;	-----------------------------------------
      001385                       1115 _fourbsixb_next_encoded_byte:
      001385 C0 18            [24] 1116 	push	_bp
      001387 85 81 18         [24] 1117 	mov	_bp,sp
      00138A C0 82            [24] 1118 	push	dpl
      00138C C0 83            [24] 1119 	push	dph
      00138E C0 F0            [24] 1120 	push	b
      001390 05 81            [12] 1121 	inc	sp
      001392 05 81            [12] 1122 	inc	sp
      001394 05 81            [12] 1123 	inc	sp
                                   1124 ;	fourbsixb.c:20: if (state->fourbsixb.bits_avail < 8 && !flush) {
      001396 A8 18            [24] 1125 	mov	r0,_bp
      001398 08               [12] 1126 	inc	r0
      001399 74 02            [12] 1127 	mov	a,#0x02
      00139B 26               [12] 1128 	add	a,@r0
      00139C FA               [12] 1129 	mov	r2,a
      00139D E4               [12] 1130 	clr	a
      00139E 08               [12] 1131 	inc	r0
      00139F 36               [12] 1132 	addc	a,@r0
      0013A0 FB               [12] 1133 	mov	r3,a
      0013A1 08               [12] 1134 	inc	r0
      0013A2 86 04            [24] 1135 	mov	ar4,@r0
      0013A4 8A 82            [24] 1136 	mov	dpl,r2
      0013A6 8B 83            [24] 1137 	mov	dph,r3
      0013A8 8C F0            [24] 1138 	mov	b,r4
      0013AA 12 2E 55         [24] 1139 	lcall	__gptrget
      0013AD FD               [12] 1140 	mov	r5,a
      0013AE BD 08 00         [24] 1141 	cjne	r5,#0x08,00132$
      0013B1                       1142 00132$:
      0013B1 E4               [12] 1143 	clr	a
      0013B2 33               [12] 1144 	rlc	a
      0013B3 FF               [12] 1145 	mov	r7,a
      0013B4 60 0D            [24] 1146 	jz	00102$
      0013B6 E5 18            [12] 1147 	mov	a,_bp
      0013B8 24 FA            [12] 1148 	add	a,#0xfa
      0013BA F8               [12] 1149 	mov	r0,a
      0013BB E6               [12] 1150 	mov	a,@r0
                                   1151 ;	fourbsixb.c:21: return 0;
      0013BC 70 05            [24] 1152 	jnz	00102$
      0013BE F5 82            [12] 1153 	mov	dpl,a
      0013C0 02 14 8F         [24] 1154 	ljmp	00110$
      0013C3                       1155 00102$:
                                   1156 ;	fourbsixb.c:23: if (state->fourbsixb.bits_avail == 0) {
      0013C3 ED               [12] 1157 	mov	a,r5
                                   1158 ;	fourbsixb.c:24: return 0;
      0013C4 70 05            [24] 1159 	jnz	00105$
      0013C6 F5 82            [12] 1160 	mov	dpl,a
      0013C8 02 14 8F         [24] 1161 	ljmp	00110$
      0013CB                       1162 00105$:
                                   1163 ;	fourbsixb.c:26: if (flush && state->fourbsixb.bits_avail < 8) {
      0013CB E5 18            [12] 1164 	mov	a,_bp
      0013CD 24 FA            [12] 1165 	add	a,#0xfa
      0013CF F8               [12] 1166 	mov	r0,a
      0013D0 E6               [12] 1167 	mov	a,@r0
      0013D1 60 57            [24] 1168 	jz	00107$
      0013D3 EF               [12] 1169 	mov	a,r7
      0013D4 60 54            [24] 1170 	jz	00107$
                                   1171 ;	fourbsixb.c:27: *encoded = state->fourbsixb.acc << (8-state->fourbsixb.bits_avail);
      0013D6 E5 18            [12] 1172 	mov	a,_bp
      0013D8 24 FB            [12] 1173 	add	a,#0xfb
      0013DA F8               [12] 1174 	mov	r0,a
      0013DB E5 18            [12] 1175 	mov	a,_bp
      0013DD 24 04            [12] 1176 	add	a,#0x04
      0013DF F9               [12] 1177 	mov	r1,a
      0013E0 E6               [12] 1178 	mov	a,@r0
      0013E1 F7               [12] 1179 	mov	@r1,a
      0013E2 08               [12] 1180 	inc	r0
      0013E3 09               [12] 1181 	inc	r1
      0013E4 E6               [12] 1182 	mov	a,@r0
      0013E5 F7               [12] 1183 	mov	@r1,a
      0013E6 08               [12] 1184 	inc	r0
      0013E7 09               [12] 1185 	inc	r1
      0013E8 E6               [12] 1186 	mov	a,@r0
      0013E9 F7               [12] 1187 	mov	@r1,a
      0013EA A8 18            [24] 1188 	mov	r0,_bp
      0013EC 08               [12] 1189 	inc	r0
      0013ED 86 82            [24] 1190 	mov	dpl,@r0
      0013EF 08               [12] 1191 	inc	r0
      0013F0 86 83            [24] 1192 	mov	dph,@r0
      0013F2 08               [12] 1193 	inc	r0
      0013F3 86 F0            [24] 1194 	mov	b,@r0
      0013F5 12 2E 55         [24] 1195 	lcall	__gptrget
      0013F8 FF               [12] 1196 	mov	r7,a
      0013F9 8D 06            [24] 1197 	mov	ar6,r5
      0013FB 74 08            [12] 1198 	mov	a,#0x08
      0013FD C3               [12] 1199 	clr	c
      0013FE 9E               [12] 1200 	subb	a,r6
      0013FF FE               [12] 1201 	mov	r6,a
      001400 8E F0            [24] 1202 	mov	b,r6
      001402 05 F0            [12] 1203 	inc	b
      001404 EF               [12] 1204 	mov	a,r7
      001405 80 02            [24] 1205 	sjmp	00140$
      001407                       1206 00138$:
      001407 25 E0            [12] 1207 	add	a,acc
      001409                       1208 00140$:
      001409 D5 F0 FB         [24] 1209 	djnz	b,00138$
      00140C FE               [12] 1210 	mov	r6,a
      00140D E5 18            [12] 1211 	mov	a,_bp
      00140F 24 04            [12] 1212 	add	a,#0x04
      001411 F8               [12] 1213 	mov	r0,a
      001412 86 82            [24] 1214 	mov	dpl,@r0
      001414 08               [12] 1215 	inc	r0
      001415 86 83            [24] 1216 	mov	dph,@r0
      001417 08               [12] 1217 	inc	r0
      001418 86 F0            [24] 1218 	mov	b,@r0
      00141A EE               [12] 1219 	mov	a,r6
      00141B 12 2D 8A         [24] 1220 	lcall	__gptrput
                                   1221 ;	fourbsixb.c:28: state->fourbsixb.bits_avail = 0;
      00141E 8A 82            [24] 1222 	mov	dpl,r2
      001420 8B 83            [24] 1223 	mov	dph,r3
      001422 8C F0            [24] 1224 	mov	b,r4
      001424 E4               [12] 1225 	clr	a
      001425 12 2D 8A         [24] 1226 	lcall	__gptrput
      001428 80 62            [24] 1227 	sjmp	00108$
      00142A                       1228 00107$:
                                   1229 ;	fourbsixb.c:30: *encoded = state->fourbsixb.acc >> (state->fourbsixb.bits_avail-8);
      00142A E5 18            [12] 1230 	mov	a,_bp
      00142C 24 FB            [12] 1231 	add	a,#0xfb
      00142E F8               [12] 1232 	mov	r0,a
      00142F E5 18            [12] 1233 	mov	a,_bp
      001431 24 04            [12] 1234 	add	a,#0x04
      001433 F9               [12] 1235 	mov	r1,a
      001434 E6               [12] 1236 	mov	a,@r0
      001435 F7               [12] 1237 	mov	@r1,a
      001436 08               [12] 1238 	inc	r0
      001437 09               [12] 1239 	inc	r1
      001438 E6               [12] 1240 	mov	a,@r0
      001439 F7               [12] 1241 	mov	@r1,a
      00143A 08               [12] 1242 	inc	r0
      00143B 09               [12] 1243 	inc	r1
      00143C E6               [12] 1244 	mov	a,@r0
      00143D F7               [12] 1245 	mov	@r1,a
      00143E A8 18            [24] 1246 	mov	r0,_bp
      001440 08               [12] 1247 	inc	r0
      001441 86 82            [24] 1248 	mov	dpl,@r0
      001443 08               [12] 1249 	inc	r0
      001444 86 83            [24] 1250 	mov	dph,@r0
      001446 08               [12] 1251 	inc	r0
      001447 86 F0            [24] 1252 	mov	b,@r0
      001449 12 2E 55         [24] 1253 	lcall	__gptrget
      00144C FE               [12] 1254 	mov	r6,a
      00144D A3               [24] 1255 	inc	dptr
      00144E 12 2E 55         [24] 1256 	lcall	__gptrget
      001451 FF               [12] 1257 	mov	r7,a
      001452 ED               [12] 1258 	mov	a,r5
      001453 24 F8            [12] 1259 	add	a,#0xf8
      001455 FD               [12] 1260 	mov	r5,a
      001456 8D F0            [24] 1261 	mov	b,r5
      001458 05 F0            [12] 1262 	inc	b
      00145A 80 07            [24] 1263 	sjmp	00142$
      00145C                       1264 00141$:
      00145C C3               [12] 1265 	clr	c
      00145D EF               [12] 1266 	mov	a,r7
      00145E 13               [12] 1267 	rrc	a
      00145F FF               [12] 1268 	mov	r7,a
      001460 EE               [12] 1269 	mov	a,r6
      001461 13               [12] 1270 	rrc	a
      001462 FE               [12] 1271 	mov	r6,a
      001463                       1272 00142$:
      001463 D5 F0 F6         [24] 1273 	djnz	b,00141$
      001466 E5 18            [12] 1274 	mov	a,_bp
      001468 24 04            [12] 1275 	add	a,#0x04
      00146A F8               [12] 1276 	mov	r0,a
      00146B 86 82            [24] 1277 	mov	dpl,@r0
      00146D 08               [12] 1278 	inc	r0
      00146E 86 83            [24] 1279 	mov	dph,@r0
      001470 08               [12] 1280 	inc	r0
      001471 86 F0            [24] 1281 	mov	b,@r0
      001473 EE               [12] 1282 	mov	a,r6
      001474 12 2D 8A         [24] 1283 	lcall	__gptrput
                                   1284 ;	fourbsixb.c:31: state->fourbsixb.bits_avail -= 8;
      001477 8A 82            [24] 1285 	mov	dpl,r2
      001479 8B 83            [24] 1286 	mov	dph,r3
      00147B 8C F0            [24] 1287 	mov	b,r4
      00147D 12 2E 55         [24] 1288 	lcall	__gptrget
      001480 24 F8            [12] 1289 	add	a,#0xf8
      001482 FF               [12] 1290 	mov	r7,a
      001483 8A 82            [24] 1291 	mov	dpl,r2
      001485 8B 83            [24] 1292 	mov	dph,r3
      001487 8C F0            [24] 1293 	mov	b,r4
      001489 12 2D 8A         [24] 1294 	lcall	__gptrput
      00148C                       1295 00108$:
                                   1296 ;	fourbsixb.c:33: return 1;
      00148C 75 82 01         [24] 1297 	mov	dpl,#0x01
      00148F                       1298 00110$:
                                   1299 ;	fourbsixb.c:34: }
      00148F 85 18 81         [24] 1300 	mov	sp,_bp
      001492 D0 18            [24] 1301 	pop	_bp
      001494 22               [24] 1302 	ret
                                   1303 ;------------------------------------------------------------
                                   1304 ;Allocation info for local variables in function 'fourbsixb_init_decoder'
                                   1305 ;------------------------------------------------------------
                                   1306 ;	fourbsixb.c:36: void fourbsixb_init_decoder(DecoderState *state) {
                                   1307 ;	-----------------------------------------
                                   1308 ;	 function fourbsixb_init_decoder
                                   1309 ;	-----------------------------------------
      001495                       1310 _fourbsixb_init_decoder:
                                   1311 ;	fourbsixb.c:37: state->fourbsixb.input_acc = 0;
      001495 AD 82            [24] 1312 	mov	r5,dpl
      001497 AE 83            [24] 1313 	mov	r6,dph
      001499 AF F0            [24] 1314 	mov	r7,b
      00149B E4               [12] 1315 	clr	a
      00149C 12 2D 8A         [24] 1316 	lcall	__gptrput
      00149F A3               [24] 1317 	inc	dptr
      0014A0 12 2D 8A         [24] 1318 	lcall	__gptrput
                                   1319 ;	fourbsixb.c:38: state->fourbsixb.input_bits_avail = 0;
      0014A3 74 02            [12] 1320 	mov	a,#0x02
      0014A5 2D               [12] 1321 	add	a,r5
      0014A6 FA               [12] 1322 	mov	r2,a
      0014A7 E4               [12] 1323 	clr	a
      0014A8 3E               [12] 1324 	addc	a,r6
      0014A9 FB               [12] 1325 	mov	r3,a
      0014AA 8F 04            [24] 1326 	mov	ar4,r7
      0014AC 8A 82            [24] 1327 	mov	dpl,r2
      0014AE 8B 83            [24] 1328 	mov	dph,r3
      0014B0 8C F0            [24] 1329 	mov	b,r4
      0014B2 E4               [12] 1330 	clr	a
      0014B3 12 2D 8A         [24] 1331 	lcall	__gptrput
                                   1332 ;	fourbsixb.c:39: state->fourbsixb.output_acc = 0;
      0014B6 74 03            [12] 1333 	mov	a,#0x03
      0014B8 2D               [12] 1334 	add	a,r5
      0014B9 FA               [12] 1335 	mov	r2,a
      0014BA E4               [12] 1336 	clr	a
      0014BB 3E               [12] 1337 	addc	a,r6
      0014BC FB               [12] 1338 	mov	r3,a
      0014BD 8F 04            [24] 1339 	mov	ar4,r7
      0014BF 8A 82            [24] 1340 	mov	dpl,r2
      0014C1 8B 83            [24] 1341 	mov	dph,r3
      0014C3 8C F0            [24] 1342 	mov	b,r4
      0014C5 E4               [12] 1343 	clr	a
      0014C6 12 2D 8A         [24] 1344 	lcall	__gptrput
      0014C9 A3               [24] 1345 	inc	dptr
      0014CA 12 2D 8A         [24] 1346 	lcall	__gptrput
                                   1347 ;	fourbsixb.c:40: state->fourbsixb.output_bits_avail = 0;
      0014CD 74 05            [12] 1348 	mov	a,#0x05
      0014CF 2D               [12] 1349 	add	a,r5
      0014D0 FD               [12] 1350 	mov	r5,a
      0014D1 E4               [12] 1351 	clr	a
      0014D2 3E               [12] 1352 	addc	a,r6
      0014D3 FE               [12] 1353 	mov	r6,a
      0014D4 8D 82            [24] 1354 	mov	dpl,r5
      0014D6 8E 83            [24] 1355 	mov	dph,r6
      0014D8 8F F0            [24] 1356 	mov	b,r7
      0014DA E4               [12] 1357 	clr	a
                                   1358 ;	fourbsixb.c:41: }
      0014DB 02 2D 8A         [24] 1359 	ljmp	__gptrput
                                   1360 ;------------------------------------------------------------
                                   1361 ;Allocation info for local variables in function 'fourbsixb_add_encoded_byte'
                                   1362 ;------------------------------------------------------------
                                   1363 ;encoded                   Allocated to stack - _bp -3
                                   1364 ;state                     Allocated to stack - _bp +1
                                   1365 ;code                      Allocated to registers r4 
                                   1366 ;i                         Allocated to registers r3 
                                   1367 ;sloc0                     Allocated to stack - _bp +4
                                   1368 ;------------------------------------------------------------
                                   1369 ;	fourbsixb.c:43: uint8_t fourbsixb_add_encoded_byte(DecoderState *state, uint8_t encoded) __reentrant {
                                   1370 ;	-----------------------------------------
                                   1371 ;	 function fourbsixb_add_encoded_byte
                                   1372 ;	-----------------------------------------
      0014DE                       1373 _fourbsixb_add_encoded_byte:
      0014DE C0 18            [24] 1374 	push	_bp
      0014E0 85 81 18         [24] 1375 	mov	_bp,sp
      0014E3 C0 82            [24] 1376 	push	dpl
      0014E5 C0 83            [24] 1377 	push	dph
      0014E7 C0 F0            [24] 1378 	push	b
      0014E9 05 81            [12] 1379 	inc	sp
      0014EB 05 81            [12] 1380 	inc	sp
                                   1381 ;	fourbsixb.c:45: state->fourbsixb.input_acc = (state->fourbsixb.input_acc << 8) | encoded;
      0014ED A8 18            [24] 1382 	mov	r0,_bp
      0014EF 08               [12] 1383 	inc	r0
      0014F0 86 82            [24] 1384 	mov	dpl,@r0
      0014F2 08               [12] 1385 	inc	r0
      0014F3 86 83            [24] 1386 	mov	dph,@r0
      0014F5 08               [12] 1387 	inc	r0
      0014F6 86 F0            [24] 1388 	mov	b,@r0
      0014F8 12 2E 55         [24] 1389 	lcall	__gptrget
      0014FB FB               [12] 1390 	mov	r3,a
      0014FC A3               [24] 1391 	inc	dptr
      0014FD 12 2E 55         [24] 1392 	lcall	__gptrget
      001500 8B 04            [24] 1393 	mov	ar4,r3
      001502 7B 00            [12] 1394 	mov	r3,#0x00
      001504 E5 18            [12] 1395 	mov	a,_bp
      001506 24 FD            [12] 1396 	add	a,#0xfd
      001508 F8               [12] 1397 	mov	r0,a
      001509 86 02            [24] 1398 	mov	ar2,@r0
      00150B 7F 00            [12] 1399 	mov	r7,#0x00
      00150D EA               [12] 1400 	mov	a,r2
      00150E 42 03            [12] 1401 	orl	ar3,a
      001510 EF               [12] 1402 	mov	a,r7
      001511 42 04            [12] 1403 	orl	ar4,a
      001513 A8 18            [24] 1404 	mov	r0,_bp
      001515 08               [12] 1405 	inc	r0
      001516 86 82            [24] 1406 	mov	dpl,@r0
      001518 08               [12] 1407 	inc	r0
      001519 86 83            [24] 1408 	mov	dph,@r0
      00151B 08               [12] 1409 	inc	r0
      00151C 86 F0            [24] 1410 	mov	b,@r0
      00151E EB               [12] 1411 	mov	a,r3
      00151F 12 2D 8A         [24] 1412 	lcall	__gptrput
      001522 A3               [24] 1413 	inc	dptr
      001523 EC               [12] 1414 	mov	a,r4
      001524 12 2D 8A         [24] 1415 	lcall	__gptrput
                                   1416 ;	fourbsixb.c:46: state->fourbsixb.input_bits_avail += 8;
      001527 A8 18            [24] 1417 	mov	r0,_bp
      001529 08               [12] 1418 	inc	r0
      00152A 74 02            [12] 1419 	mov	a,#0x02
      00152C 26               [12] 1420 	add	a,@r0
      00152D FD               [12] 1421 	mov	r5,a
      00152E E4               [12] 1422 	clr	a
      00152F 08               [12] 1423 	inc	r0
      001530 36               [12] 1424 	addc	a,@r0
      001531 FE               [12] 1425 	mov	r6,a
      001532 08               [12] 1426 	inc	r0
      001533 86 07            [24] 1427 	mov	ar7,@r0
      001535 8D 82            [24] 1428 	mov	dpl,r5
      001537 8E 83            [24] 1429 	mov	dph,r6
      001539 8F F0            [24] 1430 	mov	b,r7
      00153B 12 2E 55         [24] 1431 	lcall	__gptrget
      00153E 24 08            [12] 1432 	add	a,#0x08
      001540 FC               [12] 1433 	mov	r4,a
      001541 8D 82            [24] 1434 	mov	dpl,r5
      001543 8E 83            [24] 1435 	mov	dph,r6
      001545 8F F0            [24] 1436 	mov	b,r7
      001547 12 2D 8A         [24] 1437 	lcall	__gptrput
                                   1438 ;	fourbsixb.c:47: while (state->fourbsixb.input_bits_avail >= 6) {
      00154A                       1439 00106$:
      00154A 8D 82            [24] 1440 	mov	dpl,r5
      00154C 8E 83            [24] 1441 	mov	dph,r6
      00154E 8F F0            [24] 1442 	mov	b,r7
      001550 12 2E 55         [24] 1443 	lcall	__gptrget
      001553 FC               [12] 1444 	mov	r4,a
      001554 BC 06 00         [24] 1445 	cjne	r4,#0x06,00134$
      001557                       1446 00134$:
      001557 50 03            [24] 1447 	jnc	00135$
      001559 02 16 48         [24] 1448 	ljmp	00108$
      00155C                       1449 00135$:
                                   1450 ;	fourbsixb.c:48: code = (state->fourbsixb.input_acc >> (state->fourbsixb.input_bits_avail - 6)) & 0b111111;
      00155C A8 18            [24] 1451 	mov	r0,_bp
      00155E 08               [12] 1452 	inc	r0
      00155F 86 82            [24] 1453 	mov	dpl,@r0
      001561 08               [12] 1454 	inc	r0
      001562 86 83            [24] 1455 	mov	dph,@r0
      001564 08               [12] 1456 	inc	r0
      001565 86 F0            [24] 1457 	mov	b,@r0
      001567 12 2E 55         [24] 1458 	lcall	__gptrget
      00156A FB               [12] 1459 	mov	r3,a
      00156B A3               [24] 1460 	inc	dptr
      00156C 12 2E 55         [24] 1461 	lcall	__gptrget
      00156F FC               [12] 1462 	mov	r4,a
      001570 8D 82            [24] 1463 	mov	dpl,r5
      001572 8E 83            [24] 1464 	mov	dph,r6
      001574 8F F0            [24] 1465 	mov	b,r7
      001576 12 2E 55         [24] 1466 	lcall	__gptrget
      001579 24 FA            [12] 1467 	add	a,#0xfa
      00157B FA               [12] 1468 	mov	r2,a
      00157C 8A F0            [24] 1469 	mov	b,r2
      00157E 05 F0            [12] 1470 	inc	b
      001580 80 07            [24] 1471 	sjmp	00137$
      001582                       1472 00136$:
      001582 C3               [12] 1473 	clr	c
      001583 EC               [12] 1474 	mov	a,r4
      001584 13               [12] 1475 	rrc	a
      001585 FC               [12] 1476 	mov	r4,a
      001586 EB               [12] 1477 	mov	a,r3
      001587 13               [12] 1478 	rrc	a
      001588 FB               [12] 1479 	mov	r3,a
      001589                       1480 00137$:
      001589 D5 F0 F6         [24] 1481 	djnz	b,00136$
      00158C 74 3F            [12] 1482 	mov	a,#0x3f
      00158E 5B               [12] 1483 	anl	a,r3
      00158F FC               [12] 1484 	mov	r4,a
                                   1485 ;	fourbsixb.c:49: state->fourbsixb.input_bits_avail -= 6;
      001590 8D 82            [24] 1486 	mov	dpl,r5
      001592 8E 83            [24] 1487 	mov	dph,r6
      001594 8F F0            [24] 1488 	mov	b,r7
      001596 12 2E 55         [24] 1489 	lcall	__gptrget
      001599 24 FA            [12] 1490 	add	a,#0xfa
      00159B 8D 82            [24] 1491 	mov	dpl,r5
      00159D 8E 83            [24] 1492 	mov	dph,r6
      00159F 8F F0            [24] 1493 	mov	b,r7
      0015A1 12 2D 8A         [24] 1494 	lcall	__gptrput
                                   1495 ;	fourbsixb.c:50: for (i=0; i<16; i++) {
      0015A4 7B 00            [12] 1496 	mov	r3,#0x00
      0015A6                       1497 00109$:
                                   1498 ;	fourbsixb.c:51: if (codes[i] == code) {
      0015A6 EB               [12] 1499 	mov	a,r3
      0015A7 24 19            [12] 1500 	add	a,#_codes
      0015A9 F5 82            [12] 1501 	mov	dpl,a
      0015AB E4               [12] 1502 	clr	a
      0015AC 34 F3            [12] 1503 	addc	a,#(_codes >> 8)
      0015AE F5 83            [12] 1504 	mov	dph,a
      0015B0 E0               [24] 1505 	movx	a,@dptr
      0015B1 FA               [12] 1506 	mov	r2,a
      0015B2 B5 04 02         [24] 1507 	cjne	a,ar4,00138$
      0015B5 80 06            [24] 1508 	sjmp	00103$
      0015B7                       1509 00138$:
                                   1510 ;	fourbsixb.c:50: for (i=0; i<16; i++) {
      0015B7 0B               [12] 1511 	inc	r3
      0015B8 BB 10 00         [24] 1512 	cjne	r3,#0x10,00139$
      0015BB                       1513 00139$:
      0015BB 40 E9            [24] 1514 	jc	00109$
      0015BD                       1515 00103$:
                                   1516 ;	fourbsixb.c:55: if (i == 16) {
      0015BD BB 10 06         [24] 1517 	cjne	r3,#0x10,00105$
                                   1518 ;	fourbsixb.c:56: return 1; // Encoding error
      0015C0 75 82 01         [24] 1519 	mov	dpl,#0x01
      0015C3 02 16 4B         [24] 1520 	ljmp	00111$
      0015C6                       1521 00105$:
                                   1522 ;	fourbsixb.c:58: state->fourbsixb.output_acc = (state->fourbsixb.output_acc << 4) | i;
      0015C6 C0 05            [24] 1523 	push	ar5
      0015C8 C0 06            [24] 1524 	push	ar6
      0015CA C0 07            [24] 1525 	push	ar7
      0015CC A8 18            [24] 1526 	mov	r0,_bp
      0015CE 08               [12] 1527 	inc	r0
      0015CF 74 03            [12] 1528 	mov	a,#0x03
      0015D1 26               [12] 1529 	add	a,@r0
      0015D2 FA               [12] 1530 	mov	r2,a
      0015D3 E4               [12] 1531 	clr	a
      0015D4 08               [12] 1532 	inc	r0
      0015D5 36               [12] 1533 	addc	a,@r0
      0015D6 FC               [12] 1534 	mov	r4,a
      0015D7 08               [12] 1535 	inc	r0
      0015D8 86 07            [24] 1536 	mov	ar7,@r0
      0015DA 8A 82            [24] 1537 	mov	dpl,r2
      0015DC 8C 83            [24] 1538 	mov	dph,r4
      0015DE 8F F0            [24] 1539 	mov	b,r7
      0015E0 12 2E 55         [24] 1540 	lcall	__gptrget
      0015E3 FD               [12] 1541 	mov	r5,a
      0015E4 A3               [24] 1542 	inc	dptr
      0015E5 12 2E 55         [24] 1543 	lcall	__gptrget
      0015E8 FE               [12] 1544 	mov	r6,a
      0015E9 E5 18            [12] 1545 	mov	a,_bp
      0015EB 24 04            [12] 1546 	add	a,#0x04
      0015ED F8               [12] 1547 	mov	r0,a
      0015EE A6 05            [24] 1548 	mov	@r0,ar5
      0015F0 EE               [12] 1549 	mov	a,r6
      0015F1 C4               [12] 1550 	swap	a
      0015F2 54 F0            [12] 1551 	anl	a,#0xf0
      0015F4 C6               [12] 1552 	xch	a,@r0
      0015F5 C4               [12] 1553 	swap	a
      0015F6 C6               [12] 1554 	xch	a,@r0
      0015F7 66               [12] 1555 	xrl	a,@r0
      0015F8 C6               [12] 1556 	xch	a,@r0
      0015F9 54 F0            [12] 1557 	anl	a,#0xf0
      0015FB C6               [12] 1558 	xch	a,@r0
      0015FC 66               [12] 1559 	xrl	a,@r0
      0015FD 08               [12] 1560 	inc	r0
      0015FE F6               [12] 1561 	mov	@r0,a
      0015FF 7E 00            [12] 1562 	mov	r6,#0x00
      001601 E5 18            [12] 1563 	mov	a,_bp
      001603 24 04            [12] 1564 	add	a,#0x04
      001605 F8               [12] 1565 	mov	r0,a
      001606 E6               [12] 1566 	mov	a,@r0
      001607 42 03            [12] 1567 	orl	ar3,a
      001609 08               [12] 1568 	inc	r0
      00160A E6               [12] 1569 	mov	a,@r0
      00160B 42 06            [12] 1570 	orl	ar6,a
      00160D 8A 82            [24] 1571 	mov	dpl,r2
      00160F 8C 83            [24] 1572 	mov	dph,r4
      001611 8F F0            [24] 1573 	mov	b,r7
      001613 EB               [12] 1574 	mov	a,r3
      001614 12 2D 8A         [24] 1575 	lcall	__gptrput
      001617 A3               [24] 1576 	inc	dptr
      001618 EE               [12] 1577 	mov	a,r6
      001619 12 2D 8A         [24] 1578 	lcall	__gptrput
                                   1579 ;	fourbsixb.c:59: state->fourbsixb.output_bits_avail += 4;
      00161C A8 18            [24] 1580 	mov	r0,_bp
      00161E 08               [12] 1581 	inc	r0
      00161F 74 05            [12] 1582 	mov	a,#0x05
      001621 26               [12] 1583 	add	a,@r0
      001622 FD               [12] 1584 	mov	r5,a
      001623 E4               [12] 1585 	clr	a
      001624 08               [12] 1586 	inc	r0
      001625 36               [12] 1587 	addc	a,@r0
      001626 FE               [12] 1588 	mov	r6,a
      001627 08               [12] 1589 	inc	r0
      001628 86 07            [24] 1590 	mov	ar7,@r0
      00162A 8D 82            [24] 1591 	mov	dpl,r5
      00162C 8E 83            [24] 1592 	mov	dph,r6
      00162E 8F F0            [24] 1593 	mov	b,r7
      001630 12 2E 55         [24] 1594 	lcall	__gptrget
      001633 24 04            [12] 1595 	add	a,#0x04
      001635 FC               [12] 1596 	mov	r4,a
      001636 8D 82            [24] 1597 	mov	dpl,r5
      001638 8E 83            [24] 1598 	mov	dph,r6
      00163A 8F F0            [24] 1599 	mov	b,r7
      00163C 12 2D 8A         [24] 1600 	lcall	__gptrput
      00163F D0 07            [24] 1601 	pop	ar7
      001641 D0 06            [24] 1602 	pop	ar6
      001643 D0 05            [24] 1603 	pop	ar5
      001645 02 15 4A         [24] 1604 	ljmp	00106$
      001648                       1605 00108$:
                                   1606 ;	fourbsixb.c:61: return 0;
      001648 75 82 00         [24] 1607 	mov	dpl,#0x00
      00164B                       1608 00111$:
                                   1609 ;	fourbsixb.c:62: }
      00164B 85 18 81         [24] 1610 	mov	sp,_bp
      00164E D0 18            [24] 1611 	pop	_bp
      001650 22               [24] 1612 	ret
                                   1613 ;------------------------------------------------------------
                                   1614 ;Allocation info for local variables in function 'fourbsixb_next_decoded_byte'
                                   1615 ;------------------------------------------------------------
                                   1616 ;decoded                   Allocated to stack - _bp -5
                                   1617 ;state                     Allocated to registers r5 r6 r7 
                                   1618 ;sloc0                     Allocated to stack - _bp +1
                                   1619 ;sloc1                     Allocated to stack - _bp +2
                                   1620 ;------------------------------------------------------------
                                   1621 ;	fourbsixb.c:64: uint8_t fourbsixb_next_decoded_byte(DecoderState *state, uint8_t *decoded) __reentrant {
                                   1622 ;	-----------------------------------------
                                   1623 ;	 function fourbsixb_next_decoded_byte
                                   1624 ;	-----------------------------------------
      001651                       1625 _fourbsixb_next_decoded_byte:
      001651 C0 18            [24] 1626 	push	_bp
      001653 E5 81            [12] 1627 	mov	a,sp
      001655 F5 18            [12] 1628 	mov	_bp,a
      001657 24 04            [12] 1629 	add	a,#0x04
      001659 F5 81            [12] 1630 	mov	sp,a
      00165B AD 82            [24] 1631 	mov	r5,dpl
      00165D AE 83            [24] 1632 	mov	r6,dph
      00165F AF F0            [24] 1633 	mov	r7,b
                                   1634 ;	fourbsixb.c:65: if (state->fourbsixb.output_bits_avail < 8) {
      001661 74 05            [12] 1635 	mov	a,#0x05
      001663 2D               [12] 1636 	add	a,r5
      001664 FA               [12] 1637 	mov	r2,a
      001665 E4               [12] 1638 	clr	a
      001666 3E               [12] 1639 	addc	a,r6
      001667 FB               [12] 1640 	mov	r3,a
      001668 8F 04            [24] 1641 	mov	ar4,r7
      00166A 8A 82            [24] 1642 	mov	dpl,r2
      00166C 8B 83            [24] 1643 	mov	dph,r3
      00166E 8C F0            [24] 1644 	mov	b,r4
      001670 A8 18            [24] 1645 	mov	r0,_bp
      001672 08               [12] 1646 	inc	r0
      001673 12 2E 55         [24] 1647 	lcall	__gptrget
      001676 F6               [12] 1648 	mov	@r0,a
      001677 A8 18            [24] 1649 	mov	r0,_bp
      001679 08               [12] 1650 	inc	r0
      00167A B6 08 00         [24] 1651 	cjne	@r0,#0x08,00109$
      00167D                       1652 00109$:
      00167D 50 05            [24] 1653 	jnc	00102$
                                   1654 ;	fourbsixb.c:66: return 0;
      00167F 75 82 00         [24] 1655 	mov	dpl,#0x00
      001682 80 68            [24] 1656 	sjmp	00103$
      001684                       1657 00102$:
                                   1658 ;	fourbsixb.c:68: *decoded = state->fourbsixb.output_acc >> (state->fourbsixb.output_bits_avail - 8);
      001684 E5 18            [12] 1659 	mov	a,_bp
      001686 24 FB            [12] 1660 	add	a,#0xfb
      001688 F8               [12] 1661 	mov	r0,a
      001689 A9 18            [24] 1662 	mov	r1,_bp
      00168B 09               [12] 1663 	inc	r1
      00168C 09               [12] 1664 	inc	r1
      00168D E6               [12] 1665 	mov	a,@r0
      00168E F7               [12] 1666 	mov	@r1,a
      00168F 08               [12] 1667 	inc	r0
      001690 09               [12] 1668 	inc	r1
      001691 E6               [12] 1669 	mov	a,@r0
      001692 F7               [12] 1670 	mov	@r1,a
      001693 08               [12] 1671 	inc	r0
      001694 09               [12] 1672 	inc	r1
      001695 E6               [12] 1673 	mov	a,@r0
      001696 F7               [12] 1674 	mov	@r1,a
      001697 74 03            [12] 1675 	mov	a,#0x03
      001699 2D               [12] 1676 	add	a,r5
      00169A FD               [12] 1677 	mov	r5,a
      00169B E4               [12] 1678 	clr	a
      00169C 3E               [12] 1679 	addc	a,r6
      00169D FE               [12] 1680 	mov	r6,a
      00169E 8D 82            [24] 1681 	mov	dpl,r5
      0016A0 8E 83            [24] 1682 	mov	dph,r6
      0016A2 8F F0            [24] 1683 	mov	b,r7
      0016A4 12 2E 55         [24] 1684 	lcall	__gptrget
      0016A7 FD               [12] 1685 	mov	r5,a
      0016A8 A3               [24] 1686 	inc	dptr
      0016A9 12 2E 55         [24] 1687 	lcall	__gptrget
      0016AC FE               [12] 1688 	mov	r6,a
      0016AD A8 18            [24] 1689 	mov	r0,_bp
      0016AF 08               [12] 1690 	inc	r0
      0016B0 E6               [12] 1691 	mov	a,@r0
      0016B1 24 F8            [12] 1692 	add	a,#0xf8
      0016B3 FF               [12] 1693 	mov	r7,a
      0016B4 8F F0            [24] 1694 	mov	b,r7
      0016B6 05 F0            [12] 1695 	inc	b
      0016B8 80 07            [24] 1696 	sjmp	00112$
      0016BA                       1697 00111$:
      0016BA C3               [12] 1698 	clr	c
      0016BB EE               [12] 1699 	mov	a,r6
      0016BC 13               [12] 1700 	rrc	a
      0016BD FE               [12] 1701 	mov	r6,a
      0016BE ED               [12] 1702 	mov	a,r5
      0016BF 13               [12] 1703 	rrc	a
      0016C0 FD               [12] 1704 	mov	r5,a
      0016C1                       1705 00112$:
      0016C1 D5 F0 F6         [24] 1706 	djnz	b,00111$
      0016C4 A8 18            [24] 1707 	mov	r0,_bp
      0016C6 08               [12] 1708 	inc	r0
      0016C7 08               [12] 1709 	inc	r0
      0016C8 86 82            [24] 1710 	mov	dpl,@r0
      0016CA 08               [12] 1711 	inc	r0
      0016CB 86 83            [24] 1712 	mov	dph,@r0
      0016CD 08               [12] 1713 	inc	r0
      0016CE 86 F0            [24] 1714 	mov	b,@r0
      0016D0 ED               [12] 1715 	mov	a,r5
      0016D1 12 2D 8A         [24] 1716 	lcall	__gptrput
                                   1717 ;	fourbsixb.c:69: state->fourbsixb.output_bits_avail -= 8;
      0016D4 8A 82            [24] 1718 	mov	dpl,r2
      0016D6 8B 83            [24] 1719 	mov	dph,r3
      0016D8 8C F0            [24] 1720 	mov	b,r4
      0016DA 12 2E 55         [24] 1721 	lcall	__gptrget
      0016DD 24 F8            [12] 1722 	add	a,#0xf8
      0016DF FF               [12] 1723 	mov	r7,a
      0016E0 8A 82            [24] 1724 	mov	dpl,r2
      0016E2 8B 83            [24] 1725 	mov	dph,r3
      0016E4 8C F0            [24] 1726 	mov	b,r4
      0016E6 12 2D 8A         [24] 1727 	lcall	__gptrput
                                   1728 ;	fourbsixb.c:70: return 1;
      0016E9 75 82 01         [24] 1729 	mov	dpl,#0x01
      0016EC                       1730 00103$:
                                   1731 ;	fourbsixb.c:71: }
      0016EC 85 18 81         [24] 1732 	mov	sp,_bp
      0016EF D0 18            [24] 1733 	pop	_bp
      0016F1 22               [24] 1734 	ret
                                   1735 	.area CSEG    (CODE)
                                   1736 	.area CONST   (CODE)
                                   1737 	.area XINIT   (CODE)
      002E87                       1738 __xinit__codes:
      002E87 15                    1739 	.db #0x15	; 21
      002E88 31                    1740 	.db #0x31	; 49	'1'
      002E89 32                    1741 	.db #0x32	; 50	'2'
      002E8A 23                    1742 	.db #0x23	; 35
      002E8B 34                    1743 	.db #0x34	; 52	'4'
      002E8C 25                    1744 	.db #0x25	; 37
      002E8D 26                    1745 	.db #0x26	; 38
      002E8E 16                    1746 	.db #0x16	; 22
      002E8F 1A                    1747 	.db #0x1a	; 26
      002E90 19                    1748 	.db #0x19	; 25
      002E91 2A                    1749 	.db #0x2a	; 42
      002E92 0B                    1750 	.db #0x0b	; 11
      002E93 2C                    1751 	.db #0x2c	; 44
      002E94 0D                    1752 	.db #0x0d	; 13
      002E95 0E                    1753 	.db #0x0e	; 14
      002E96 1C                    1754 	.db #0x1c	; 28
                                   1755 	.area CABS    (ABS,CODE)
