                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.0.2 #11662 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module commands
                                      6 	.optsdcc -mmcs51 --model-medium
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _cmd_get_reset
                                     12 	.globl _cmd_get_statistics
                                     13 	.globl _cmd_reset_radio_config
                                     14 	.globl _cmd_set_preamble
                                     15 	.globl _cmd_led
                                     16 	.globl _cmd_reset
                                     17 	.globl _cmd_update_register
                                     18 	.globl _cmd_read_register
                                     19 	.globl _cmd_send_and_listen
                                     20 	.globl _cmd_send_packet
                                     21 	.globl _cmd_get_version
                                     22 	.globl _cmd_get_state
                                     23 	.globl _cmd_get_packet
                                     24 	.globl _cmd_set_mode_registers
                                     25 	.globl _cmd_set_sw_encoding
                                     26 	.globl _radio_set_preamble
                                     27 	.globl _set_encoding_type
                                     28 	.globl _send_from_tx_buf
                                     29 	.globl _send_packet_from_serial
                                     30 	.globl _get_packet_and_write_to_serial
                                     31 	.globl _configure_radio
                                     32 	.globl _serial_rx_avail
                                     33 	.globl _serial_rx_long
                                     34 	.globl _serial_rx_word
                                     35 	.globl _serial_rx_byte
                                     36 	.globl _serial_flush
                                     37 	.globl _serial_tx_str
                                     38 	.globl _serial_tx_long
                                     39 	.globl _serial_tx_word
                                     40 	.globl _serial_tx_byte
                                     41 	.globl _mode_registers_add
                                     42 	.globl _mode_registers_clear
                                     43 	.globl _set_register
                                     44 	.globl _get_register
                                     45 	.globl _MODE
                                     46 	.globl _RE
                                     47 	.globl _SLAVE
                                     48 	.globl _FE
                                     49 	.globl _ERR
                                     50 	.globl _RX_BYTE
                                     51 	.globl _TX_BYTE
                                     52 	.globl _ACTIVE
                                     53 	.globl _B_7
                                     54 	.globl _B_6
                                     55 	.globl _B_5
                                     56 	.globl _B_4
                                     57 	.globl _B_3
                                     58 	.globl _B_2
                                     59 	.globl _B_1
                                     60 	.globl _B_0
                                     61 	.globl _WDTIF
                                     62 	.globl _P1IF
                                     63 	.globl _UTX1IF
                                     64 	.globl _UTX0IF
                                     65 	.globl _P2IF
                                     66 	.globl _ACC_7
                                     67 	.globl _ACC_6
                                     68 	.globl _ACC_5
                                     69 	.globl _ACC_4
                                     70 	.globl _ACC_3
                                     71 	.globl _ACC_2
                                     72 	.globl _ACC_1
                                     73 	.globl _ACC_0
                                     74 	.globl _OVFIM
                                     75 	.globl _T4CH1IF
                                     76 	.globl _T4CH0IF
                                     77 	.globl _T4OVFIF
                                     78 	.globl _T3CH1IF
                                     79 	.globl _T3CH0IF
                                     80 	.globl _T3OVFIF
                                     81 	.globl _CY
                                     82 	.globl _AC
                                     83 	.globl _F0
                                     84 	.globl _RS1
                                     85 	.globl _RS0
                                     86 	.globl _OV
                                     87 	.globl _F1
                                     88 	.globl _P
                                     89 	.globl _STIF
                                     90 	.globl _P0IF
                                     91 	.globl _T4IF
                                     92 	.globl _T3IF
                                     93 	.globl _T2IF
                                     94 	.globl _T1IF
                                     95 	.globl _DMAIF
                                     96 	.globl _P0IE
                                     97 	.globl _T4IE
                                     98 	.globl _T3IE
                                     99 	.globl _T2IE
                                    100 	.globl _T1IE
                                    101 	.globl _DMAIE
                                    102 	.globl _EA
                                    103 	.globl _STIE
                                    104 	.globl _ENCIE
                                    105 	.globl _URX1IE
                                    106 	.globl _URX0IE
                                    107 	.globl _ADCIE
                                    108 	.globl _RFTXRXIE
                                    109 	.globl _P2_7
                                    110 	.globl _P2_6
                                    111 	.globl _P2_5
                                    112 	.globl _P2_4
                                    113 	.globl _P2_3
                                    114 	.globl _P2_2
                                    115 	.globl _P2_1
                                    116 	.globl _P2_0
                                    117 	.globl _ENCIF_1
                                    118 	.globl _ENCIF_0
                                    119 	.globl _P1_7
                                    120 	.globl _P1_6
                                    121 	.globl _P1_5
                                    122 	.globl _P1_4
                                    123 	.globl _P1_3
                                    124 	.globl _P1_2
                                    125 	.globl _P1_1
                                    126 	.globl _P1_0
                                    127 	.globl _URX1IF
                                    128 	.globl _ADCIF
                                    129 	.globl _URX0IF
                                    130 	.globl _IT1
                                    131 	.globl _RFTXRXIF
                                    132 	.globl _IT0
                                    133 	.globl _P0_7
                                    134 	.globl _P0_6
                                    135 	.globl _P0_5
                                    136 	.globl _P0_4
                                    137 	.globl _P0_3
                                    138 	.globl _P0_2
                                    139 	.globl _P0_1
                                    140 	.globl _P0_0
                                    141 	.globl _P2DIR
                                    142 	.globl _P1DIR
                                    143 	.globl _P0DIR
                                    144 	.globl _U1GCR
                                    145 	.globl _U1UCR
                                    146 	.globl _U1BAUD
                                    147 	.globl _U1DBUF
                                    148 	.globl _U1CSR
                                    149 	.globl _P2INP
                                    150 	.globl _P1INP
                                    151 	.globl _P2SEL
                                    152 	.globl _P1SEL
                                    153 	.globl _P0SEL
                                    154 	.globl _ADCCFG
                                    155 	.globl _PERCFG
                                    156 	.globl _B
                                    157 	.globl _T4CC1
                                    158 	.globl _T4CCTL1
                                    159 	.globl _T4CC0
                                    160 	.globl _T4CCTL0
                                    161 	.globl _T4CTL
                                    162 	.globl _T4CNT
                                    163 	.globl _RFIF
                                    164 	.globl _IRCON2
                                    165 	.globl _T1CCTL2
                                    166 	.globl _T1CCTL1
                                    167 	.globl _T1CCTL0
                                    168 	.globl _T1CTL
                                    169 	.globl _T1CNTH
                                    170 	.globl _T1CNTL
                                    171 	.globl _RFST
                                    172 	.globl _ACC
                                    173 	.globl _T1CC2H
                                    174 	.globl _T1CC2L
                                    175 	.globl _T1CC1H
                                    176 	.globl _T1CC1L
                                    177 	.globl _T1CC0H
                                    178 	.globl _T1CC0L
                                    179 	.globl _RFD
                                    180 	.globl _TIMIF
                                    181 	.globl _DMAREQ
                                    182 	.globl _DMAARM
                                    183 	.globl _DMA0CFGH
                                    184 	.globl _DMA0CFGL
                                    185 	.globl _DMA1CFGH
                                    186 	.globl _DMA1CFGL
                                    187 	.globl _DMAIRQ
                                    188 	.globl _PSW
                                    189 	.globl _T3CC1
                                    190 	.globl _T3CCTL1
                                    191 	.globl _T3CC0
                                    192 	.globl _T3CCTL0
                                    193 	.globl _T3CTL
                                    194 	.globl _T3CNT
                                    195 	.globl _WDCTL
                                    196 	.globl __SFRC8
                                    197 	.globl _MEMCTR
                                    198 	.globl _CLKCON
                                    199 	.globl _U0GCR
                                    200 	.globl _U0UCR
                                    201 	.globl __SFRC3
                                    202 	.globl _U0BAUD
                                    203 	.globl _U0DBUF
                                    204 	.globl _IRCON
                                    205 	.globl __SFRBF
                                    206 	.globl _SLEEP
                                    207 	.globl _RNDH
                                    208 	.globl _RNDL
                                    209 	.globl _ADCH
                                    210 	.globl _ADCL
                                    211 	.globl _IP1
                                    212 	.globl _IEN1
                                    213 	.globl __SFRB7
                                    214 	.globl _ADCCON3
                                    215 	.globl _ADCCON2
                                    216 	.globl _ADCCON1
                                    217 	.globl _ENCCS
                                    218 	.globl _ENCDO
                                    219 	.globl _ENCDI
                                    220 	.globl __SFRB0
                                    221 	.globl _FWDATA
                                    222 	.globl _FCTL
                                    223 	.globl _FADDRH
                                    224 	.globl _FADDRL
                                    225 	.globl _FWT
                                    226 	.globl __SFRAA
                                    227 	.globl _IP0
                                    228 	.globl _IEN0
                                    229 	.globl __SFRA7
                                    230 	.globl _WORTIME1
                                    231 	.globl _WORTIME0
                                    232 	.globl _WOREVT1
                                    233 	.globl _WOREVT0
                                    234 	.globl _WORCTRL
                                    235 	.globl _WORIRQ
                                    236 	.globl _P2
                                    237 	.globl __SFR9F
                                    238 	.globl _T2CTL
                                    239 	.globl _T2PR
                                    240 	.globl _T2CT
                                    241 	.globl _S1CON
                                    242 	.globl _IEN2
                                    243 	.globl __SFR99
                                    244 	.globl _S0CON
                                    245 	.globl __SFR97
                                    246 	.globl __SFR96
                                    247 	.globl __SFR95
                                    248 	.globl __SFR94
                                    249 	.globl __XPAGE
                                    250 	.globl _MPAGE
                                    251 	.globl _DPS
                                    252 	.globl _RFIM
                                    253 	.globl _P1
                                    254 	.globl _P0INP
                                    255 	.globl __SFR8E
                                    256 	.globl _P1IEN
                                    257 	.globl _PICTL
                                    258 	.globl _P2IFG
                                    259 	.globl _P1IFG
                                    260 	.globl _P0IFG
                                    261 	.globl _TCON
                                    262 	.globl _PCON
                                    263 	.globl _U0CSR
                                    264 	.globl _DPH1
                                    265 	.globl _DPL1
                                    266 	.globl _DPH0
                                    267 	.globl _DPL0
                                    268 	.globl _SP
                                    269 	.globl _P0
                                    270 	.globl _handlers
                                    271 	.globl _X_P2DIR
                                    272 	.globl _X_P1DIR
                                    273 	.globl _X_P0DIR
                                    274 	.globl _X_U1GCR
                                    275 	.globl _X_U1UCR
                                    276 	.globl _X_U1BAUD
                                    277 	.globl _X_U1DBUF
                                    278 	.globl _X_U1CSR
                                    279 	.globl _X_P2INP
                                    280 	.globl _X_P1INP
                                    281 	.globl _X_P2SEL
                                    282 	.globl _X_P1SEL
                                    283 	.globl _X_P0SEL
                                    284 	.globl _X_ADCCFG
                                    285 	.globl _X_PERCFG
                                    286 	.globl __NA_B
                                    287 	.globl _X_T4CC1
                                    288 	.globl _X_T4CCTL1
                                    289 	.globl _X_T4CC0
                                    290 	.globl _X_T4CCTL0
                                    291 	.globl _X_T4CTL
                                    292 	.globl _X_T4CNT
                                    293 	.globl _X_RFIF
                                    294 	.globl __NA_IRCON2
                                    295 	.globl _X_T1CCTL2
                                    296 	.globl _X_T1CCTL1
                                    297 	.globl _X_T1CCTL0
                                    298 	.globl _X_T1CTL
                                    299 	.globl _X_T1CNTH
                                    300 	.globl _X_T1CNTL
                                    301 	.globl _X_RFST
                                    302 	.globl __NA_ACC
                                    303 	.globl _X_T1CC2H
                                    304 	.globl _X_T1CC2L
                                    305 	.globl _X_T1CC1H
                                    306 	.globl _X_T1CC1L
                                    307 	.globl _X_T1CC0H
                                    308 	.globl _X_T1CC0L
                                    309 	.globl _X_RFD
                                    310 	.globl _X_TIMIF
                                    311 	.globl _X_DMAREQ
                                    312 	.globl _X_DMAARM
                                    313 	.globl _X_DMA0CFGH
                                    314 	.globl _X_DMA0CFGL
                                    315 	.globl _X_DMA1CFGH
                                    316 	.globl _X_DMA1CFGL
                                    317 	.globl _X_DMAIRQ
                                    318 	.globl __NA_PSW
                                    319 	.globl _X_T3CC1
                                    320 	.globl _X_T3CCTL1
                                    321 	.globl _X_T3CC0
                                    322 	.globl _X_T3CCTL0
                                    323 	.globl _X_T3CTL
                                    324 	.globl _X_T3CNT
                                    325 	.globl _X_WDCTL
                                    326 	.globl __X_SFRC8
                                    327 	.globl _X_MEMCTR
                                    328 	.globl _X_CLKCON
                                    329 	.globl _X_U0GCR
                                    330 	.globl _X_U0UCR
                                    331 	.globl __X_SFRC3
                                    332 	.globl _X_U0BAUD
                                    333 	.globl _X_U0DBUF
                                    334 	.globl __NA_IRCON
                                    335 	.globl __X_SFRBF
                                    336 	.globl _X_SLEEP
                                    337 	.globl _X_RNDH
                                    338 	.globl _X_RNDL
                                    339 	.globl _X_ADCH
                                    340 	.globl _X_ADCL
                                    341 	.globl __NA_IP1
                                    342 	.globl __NA_IEN1
                                    343 	.globl __X_SFRB7
                                    344 	.globl _X_ADCCON3
                                    345 	.globl _X_ADCCON2
                                    346 	.globl _X_ADCCON1
                                    347 	.globl _X_ENCCS
                                    348 	.globl _X_ENCDO
                                    349 	.globl _X_ENCDI
                                    350 	.globl __X_SFRB0
                                    351 	.globl _X_FWDATA
                                    352 	.globl _X_FCTL
                                    353 	.globl _X_FADDRH
                                    354 	.globl _X_FADDRL
                                    355 	.globl _X_FWT
                                    356 	.globl __X_SFRAA
                                    357 	.globl __NA_IP0
                                    358 	.globl __NA_IEN0
                                    359 	.globl __X_SFRA7
                                    360 	.globl _X_WORTIME1
                                    361 	.globl _X_WORTIME0
                                    362 	.globl _X_WOREVT1
                                    363 	.globl _X_WOREVT0
                                    364 	.globl _X_WORCTRL
                                    365 	.globl _X_WORIRQ
                                    366 	.globl __NA_P2
                                    367 	.globl __X_SFR9F
                                    368 	.globl _X_T2CTL
                                    369 	.globl _X_T2PR
                                    370 	.globl _X_T2CT
                                    371 	.globl __NA_S1CON
                                    372 	.globl __NA_IEN2
                                    373 	.globl __X_SFR99
                                    374 	.globl __NA_S0CON
                                    375 	.globl __X_SFR97
                                    376 	.globl __X_SFR96
                                    377 	.globl __X_SFR95
                                    378 	.globl __X_SFR94
                                    379 	.globl _X_MPAGE
                                    380 	.globl __NA_DPS
                                    381 	.globl _X_RFIM
                                    382 	.globl __NA_P1
                                    383 	.globl _X_P0INP
                                    384 	.globl __X_SFR8E
                                    385 	.globl _X_P1IEN
                                    386 	.globl _X_PICTL
                                    387 	.globl _X_P2IFG
                                    388 	.globl _X_P1IFG
                                    389 	.globl _X_P0IFG
                                    390 	.globl __NA_TCON
                                    391 	.globl __NA_PCON
                                    392 	.globl _X_U0CSR
                                    393 	.globl __NA_DPH1
                                    394 	.globl __NA_DPL1
                                    395 	.globl __NA_DPH0
                                    396 	.globl __NA_DPL0
                                    397 	.globl __NA_SP
                                    398 	.globl __NA_P0
                                    399 	.globl _I2SCLKF2
                                    400 	.globl _I2SCLKF1
                                    401 	.globl _I2SCLKF0
                                    402 	.globl _I2SSTAT
                                    403 	.globl _I2SWCNT
                                    404 	.globl _I2SDATH
                                    405 	.globl _I2SDATL
                                    406 	.globl _I2SCFG1
                                    407 	.globl _I2SCFG0
                                    408 	.globl _VCO_VC_DAC
                                    409 	.globl _PKTSTATUS
                                    410 	.globl _MARCSTATE
                                    411 	.globl _RSSI
                                    412 	.globl _LQI
                                    413 	.globl _FREQEST
                                    414 	.globl _VERSION
                                    415 	.globl _PARTNUM
                                    416 	.globl __XREGDF35
                                    417 	.globl __XREGDF34
                                    418 	.globl __XREGDF33
                                    419 	.globl __XREGDF32
                                    420 	.globl _IOCFG0
                                    421 	.globl _IOCFG1
                                    422 	.globl _IOCFG2
                                    423 	.globl _PA_TABLE0
                                    424 	.globl _PA_TABLE1
                                    425 	.globl _PA_TABLE2
                                    426 	.globl _PA_TABLE3
                                    427 	.globl _PA_TABLE4
                                    428 	.globl _PA_TABLE5
                                    429 	.globl _PA_TABLE6
                                    430 	.globl _PA_TABLE7
                                    431 	.globl __XREGDF26
                                    432 	.globl _TEST0
                                    433 	.globl _TEST1
                                    434 	.globl _TEST2
                                    435 	.globl __XREGDF22
                                    436 	.globl __XREGDF21
                                    437 	.globl __XREGDF20
                                    438 	.globl _FSCAL0
                                    439 	.globl _FSCAL1
                                    440 	.globl _FSCAL2
                                    441 	.globl _FSCAL3
                                    442 	.globl _FREND0
                                    443 	.globl _FREND1
                                    444 	.globl _AGCCTRL0
                                    445 	.globl _AGCCTRL1
                                    446 	.globl _AGCCTRL2
                                    447 	.globl _BSCFG
                                    448 	.globl _FOCCFG
                                    449 	.globl _MCSM0
                                    450 	.globl _MCSM1
                                    451 	.globl _MCSM2
                                    452 	.globl _DEVIATN
                                    453 	.globl _MDMCFG0
                                    454 	.globl _MDMCFG1
                                    455 	.globl _MDMCFG2
                                    456 	.globl _MDMCFG3
                                    457 	.globl _MDMCFG4
                                    458 	.globl _FREQ0
                                    459 	.globl _FREQ1
                                    460 	.globl _FREQ2
                                    461 	.globl _FSCTRL0
                                    462 	.globl _FSCTRL1
                                    463 	.globl _CHANNR
                                    464 	.globl _ADDR
                                    465 	.globl _PKTCTRL0
                                    466 	.globl _PKTCTRL1
                                    467 	.globl _PKTLEN
                                    468 	.globl _SYNC0
                                    469 	.globl _SYNC1
                                    470 	.globl _MDMCTRL0H
                                    471 	.globl _use_pktlen
                                    472 	.globl _reset_status
                                    473 	.globl _interrupting_cmd
                                    474 	.globl _get_command
                                    475 	.globl _do_cmd
                                    476 ;--------------------------------------------------------
                                    477 ; special function registers
                                    478 ;--------------------------------------------------------
                                    479 	.area RSEG    (ABS,DATA)
      000000                        480 	.org 0x0000
                           000080   481 _P0	=	0x0080
                           000081   482 _SP	=	0x0081
                           000082   483 _DPL0	=	0x0082
                           000083   484 _DPH0	=	0x0083
                           000084   485 _DPL1	=	0x0084
                           000085   486 _DPH1	=	0x0085
                           000086   487 _U0CSR	=	0x0086
                           000087   488 _PCON	=	0x0087
                           000088   489 _TCON	=	0x0088
                           000089   490 _P0IFG	=	0x0089
                           00008A   491 _P1IFG	=	0x008a
                           00008B   492 _P2IFG	=	0x008b
                           00008C   493 _PICTL	=	0x008c
                           00008D   494 _P1IEN	=	0x008d
                           00008E   495 __SFR8E	=	0x008e
                           00008F   496 _P0INP	=	0x008f
                           000090   497 _P1	=	0x0090
                           000091   498 _RFIM	=	0x0091
                           000092   499 _DPS	=	0x0092
                           000093   500 _MPAGE	=	0x0093
                           000093   501 __XPAGE	=	0x0093
                           000094   502 __SFR94	=	0x0094
                           000095   503 __SFR95	=	0x0095
                           000096   504 __SFR96	=	0x0096
                           000097   505 __SFR97	=	0x0097
                           000098   506 _S0CON	=	0x0098
                           000099   507 __SFR99	=	0x0099
                           00009A   508 _IEN2	=	0x009a
                           00009B   509 _S1CON	=	0x009b
                           00009C   510 _T2CT	=	0x009c
                           00009D   511 _T2PR	=	0x009d
                           00009E   512 _T2CTL	=	0x009e
                           00009F   513 __SFR9F	=	0x009f
                           0000A0   514 _P2	=	0x00a0
                           0000A1   515 _WORIRQ	=	0x00a1
                           0000A2   516 _WORCTRL	=	0x00a2
                           0000A3   517 _WOREVT0	=	0x00a3
                           0000A4   518 _WOREVT1	=	0x00a4
                           0000A5   519 _WORTIME0	=	0x00a5
                           0000A6   520 _WORTIME1	=	0x00a6
                           0000A7   521 __SFRA7	=	0x00a7
                           0000A8   522 _IEN0	=	0x00a8
                           0000A9   523 _IP0	=	0x00a9
                           0000AA   524 __SFRAA	=	0x00aa
                           0000AB   525 _FWT	=	0x00ab
                           0000AC   526 _FADDRL	=	0x00ac
                           0000AD   527 _FADDRH	=	0x00ad
                           0000AE   528 _FCTL	=	0x00ae
                           0000AF   529 _FWDATA	=	0x00af
                           0000B0   530 __SFRB0	=	0x00b0
                           0000B1   531 _ENCDI	=	0x00b1
                           0000B2   532 _ENCDO	=	0x00b2
                           0000B3   533 _ENCCS	=	0x00b3
                           0000B4   534 _ADCCON1	=	0x00b4
                           0000B5   535 _ADCCON2	=	0x00b5
                           0000B6   536 _ADCCON3	=	0x00b6
                           0000B7   537 __SFRB7	=	0x00b7
                           0000B8   538 _IEN1	=	0x00b8
                           0000B9   539 _IP1	=	0x00b9
                           0000BA   540 _ADCL	=	0x00ba
                           0000BB   541 _ADCH	=	0x00bb
                           0000BC   542 _RNDL	=	0x00bc
                           0000BD   543 _RNDH	=	0x00bd
                           0000BE   544 _SLEEP	=	0x00be
                           0000BF   545 __SFRBF	=	0x00bf
                           0000C0   546 _IRCON	=	0x00c0
                           0000C1   547 _U0DBUF	=	0x00c1
                           0000C2   548 _U0BAUD	=	0x00c2
                           0000C3   549 __SFRC3	=	0x00c3
                           0000C4   550 _U0UCR	=	0x00c4
                           0000C5   551 _U0GCR	=	0x00c5
                           0000C6   552 _CLKCON	=	0x00c6
                           0000C7   553 _MEMCTR	=	0x00c7
                           0000C8   554 __SFRC8	=	0x00c8
                           0000C9   555 _WDCTL	=	0x00c9
                           0000CA   556 _T3CNT	=	0x00ca
                           0000CB   557 _T3CTL	=	0x00cb
                           0000CC   558 _T3CCTL0	=	0x00cc
                           0000CD   559 _T3CC0	=	0x00cd
                           0000CE   560 _T3CCTL1	=	0x00ce
                           0000CF   561 _T3CC1	=	0x00cf
                           0000D0   562 _PSW	=	0x00d0
                           0000D1   563 _DMAIRQ	=	0x00d1
                           0000D2   564 _DMA1CFGL	=	0x00d2
                           0000D3   565 _DMA1CFGH	=	0x00d3
                           0000D4   566 _DMA0CFGL	=	0x00d4
                           0000D5   567 _DMA0CFGH	=	0x00d5
                           0000D6   568 _DMAARM	=	0x00d6
                           0000D7   569 _DMAREQ	=	0x00d7
                           0000D8   570 _TIMIF	=	0x00d8
                           0000D9   571 _RFD	=	0x00d9
                           0000DA   572 _T1CC0L	=	0x00da
                           0000DB   573 _T1CC0H	=	0x00db
                           0000DC   574 _T1CC1L	=	0x00dc
                           0000DD   575 _T1CC1H	=	0x00dd
                           0000DE   576 _T1CC2L	=	0x00de
                           0000DF   577 _T1CC2H	=	0x00df
                           0000E0   578 _ACC	=	0x00e0
                           0000E1   579 _RFST	=	0x00e1
                           0000E2   580 _T1CNTL	=	0x00e2
                           0000E3   581 _T1CNTH	=	0x00e3
                           0000E4   582 _T1CTL	=	0x00e4
                           0000E5   583 _T1CCTL0	=	0x00e5
                           0000E6   584 _T1CCTL1	=	0x00e6
                           0000E7   585 _T1CCTL2	=	0x00e7
                           0000E8   586 _IRCON2	=	0x00e8
                           0000E9   587 _RFIF	=	0x00e9
                           0000EA   588 _T4CNT	=	0x00ea
                           0000EB   589 _T4CTL	=	0x00eb
                           0000EC   590 _T4CCTL0	=	0x00ec
                           0000ED   591 _T4CC0	=	0x00ed
                           0000EE   592 _T4CCTL1	=	0x00ee
                           0000EF   593 _T4CC1	=	0x00ef
                           0000F0   594 _B	=	0x00f0
                           0000F1   595 _PERCFG	=	0x00f1
                           0000F2   596 _ADCCFG	=	0x00f2
                           0000F3   597 _P0SEL	=	0x00f3
                           0000F4   598 _P1SEL	=	0x00f4
                           0000F5   599 _P2SEL	=	0x00f5
                           0000F6   600 _P1INP	=	0x00f6
                           0000F7   601 _P2INP	=	0x00f7
                           0000F8   602 _U1CSR	=	0x00f8
                           0000F9   603 _U1DBUF	=	0x00f9
                           0000FA   604 _U1BAUD	=	0x00fa
                           0000FB   605 _U1UCR	=	0x00fb
                           0000FC   606 _U1GCR	=	0x00fc
                           0000FD   607 _P0DIR	=	0x00fd
                           0000FE   608 _P1DIR	=	0x00fe
                           0000FF   609 _P2DIR	=	0x00ff
                                    610 ;--------------------------------------------------------
                                    611 ; special function bits
                                    612 ;--------------------------------------------------------
                                    613 	.area RSEG    (ABS,DATA)
      000000                        614 	.org 0x0000
                           000080   615 _P0_0	=	0x0080
                           000081   616 _P0_1	=	0x0081
                           000082   617 _P0_2	=	0x0082
                           000083   618 _P0_3	=	0x0083
                           000084   619 _P0_4	=	0x0084
                           000085   620 _P0_5	=	0x0085
                           000086   621 _P0_6	=	0x0086
                           000087   622 _P0_7	=	0x0087
                           000088   623 _IT0	=	0x0088
                           000089   624 _RFTXRXIF	=	0x0089
                           00008A   625 _IT1	=	0x008a
                           00008B   626 _URX0IF	=	0x008b
                           00008D   627 _ADCIF	=	0x008d
                           00008F   628 _URX1IF	=	0x008f
                           000090   629 _P1_0	=	0x0090
                           000091   630 _P1_1	=	0x0091
                           000092   631 _P1_2	=	0x0092
                           000093   632 _P1_3	=	0x0093
                           000094   633 _P1_4	=	0x0094
                           000095   634 _P1_5	=	0x0095
                           000096   635 _P1_6	=	0x0096
                           000097   636 _P1_7	=	0x0097
                           000098   637 _ENCIF_0	=	0x0098
                           000099   638 _ENCIF_1	=	0x0099
                           0000A0   639 _P2_0	=	0x00a0
                           0000A1   640 _P2_1	=	0x00a1
                           0000A2   641 _P2_2	=	0x00a2
                           0000A3   642 _P2_3	=	0x00a3
                           0000A4   643 _P2_4	=	0x00a4
                           0000A5   644 _P2_5	=	0x00a5
                           0000A6   645 _P2_6	=	0x00a6
                           0000A7   646 _P2_7	=	0x00a7
                           0000A8   647 _RFTXRXIE	=	0x00a8
                           0000A9   648 _ADCIE	=	0x00a9
                           0000AA   649 _URX0IE	=	0x00aa
                           0000AB   650 _URX1IE	=	0x00ab
                           0000AC   651 _ENCIE	=	0x00ac
                           0000AD   652 _STIE	=	0x00ad
                           0000AF   653 _EA	=	0x00af
                           0000B8   654 _DMAIE	=	0x00b8
                           0000B9   655 _T1IE	=	0x00b9
                           0000BA   656 _T2IE	=	0x00ba
                           0000BB   657 _T3IE	=	0x00bb
                           0000BC   658 _T4IE	=	0x00bc
                           0000BD   659 _P0IE	=	0x00bd
                           0000C0   660 _DMAIF	=	0x00c0
                           0000C1   661 _T1IF	=	0x00c1
                           0000C2   662 _T2IF	=	0x00c2
                           0000C3   663 _T3IF	=	0x00c3
                           0000C4   664 _T4IF	=	0x00c4
                           0000C5   665 _P0IF	=	0x00c5
                           0000C7   666 _STIF	=	0x00c7
                           0000D0   667 _P	=	0x00d0
                           0000D1   668 _F1	=	0x00d1
                           0000D2   669 _OV	=	0x00d2
                           0000D3   670 _RS0	=	0x00d3
                           0000D4   671 _RS1	=	0x00d4
                           0000D5   672 _F0	=	0x00d5
                           0000D6   673 _AC	=	0x00d6
                           0000D7   674 _CY	=	0x00d7
                           0000D8   675 _T3OVFIF	=	0x00d8
                           0000D9   676 _T3CH0IF	=	0x00d9
                           0000DA   677 _T3CH1IF	=	0x00da
                           0000DB   678 _T4OVFIF	=	0x00db
                           0000DC   679 _T4CH0IF	=	0x00dc
                           0000DD   680 _T4CH1IF	=	0x00dd
                           0000DE   681 _OVFIM	=	0x00de
                           0000E0   682 _ACC_0	=	0x00e0
                           0000E1   683 _ACC_1	=	0x00e1
                           0000E2   684 _ACC_2	=	0x00e2
                           0000E3   685 _ACC_3	=	0x00e3
                           0000E4   686 _ACC_4	=	0x00e4
                           0000E5   687 _ACC_5	=	0x00e5
                           0000E6   688 _ACC_6	=	0x00e6
                           0000E7   689 _ACC_7	=	0x00e7
                           0000E8   690 _P2IF	=	0x00e8
                           0000E9   691 _UTX0IF	=	0x00e9
                           0000EA   692 _UTX1IF	=	0x00ea
                           0000EB   693 _P1IF	=	0x00eb
                           0000EC   694 _WDTIF	=	0x00ec
                           0000F0   695 _B_0	=	0x00f0
                           0000F1   696 _B_1	=	0x00f1
                           0000F2   697 _B_2	=	0x00f2
                           0000F3   698 _B_3	=	0x00f3
                           0000F4   699 _B_4	=	0x00f4
                           0000F5   700 _B_5	=	0x00f5
                           0000F6   701 _B_6	=	0x00f6
                           0000F7   702 _B_7	=	0x00f7
                           0000F8   703 _ACTIVE	=	0x00f8
                           0000F9   704 _TX_BYTE	=	0x00f9
                           0000FA   705 _RX_BYTE	=	0x00fa
                           0000FB   706 _ERR	=	0x00fb
                           0000FC   707 _FE	=	0x00fc
                           0000FD   708 _SLAVE	=	0x00fd
                           0000FE   709 _RE	=	0x00fe
                           0000FF   710 _MODE	=	0x00ff
                                    711 ;--------------------------------------------------------
                                    712 ; overlayable register banks
                                    713 ;--------------------------------------------------------
                                    714 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        715 	.ds 8
                                    716 ;--------------------------------------------------------
                                    717 ; internal ram data
                                    718 ;--------------------------------------------------------
                                    719 	.area DSEG    (DATA)
                                    720 ;--------------------------------------------------------
                                    721 ; overlayable items in internal ram 
                                    722 ;--------------------------------------------------------
                                    723 ;--------------------------------------------------------
                                    724 ; indirectly addressable internal ram data
                                    725 ;--------------------------------------------------------
                                    726 	.area ISEG    (DATA)
                                    727 ;--------------------------------------------------------
                                    728 ; absolute internal ram data
                                    729 ;--------------------------------------------------------
                                    730 	.area IABS    (ABS,DATA)
                                    731 	.area IABS    (ABS,DATA)
                                    732 ;--------------------------------------------------------
                                    733 ; bit data
                                    734 ;--------------------------------------------------------
                                    735 	.area BSEG    (BIT)
                                    736 ;--------------------------------------------------------
                                    737 ; paged external ram data
                                    738 ;--------------------------------------------------------
                                    739 	.area PSEG    (PAG,XDATA)
      00F049                        740 _interrupting_cmd::
      00F049                        741 	.ds 1
      00F04A                        742 _reset_status::
      00F04A                        743 	.ds 1
      00F04B                        744 _use_pktlen::
      00F04B                        745 	.ds 1
      00F04C                        746 _cmd_set_mode_registers_count_65536_34:
      00F04C                        747 	.ds 1
      00F04D                        748 _cmd_set_mode_registers_addr_65536_34:
      00F04D                        749 	.ds 1
      00F04E                        750 _cmd_send_packet_repeat_count_65536_44:
      00F04E                        751 	.ds 1
      00F04F                        752 _cmd_send_and_listen_send_channel_65536_45:
      00F04F                        753 	.ds 1
      00F050                        754 _cmd_send_and_listen_delay_ms_65536_45:
      00F050                        755 	.ds 2
      00F052                        756 _cmd_send_and_listen_listen_channel_65536_45:
      00F052                        757 	.ds 1
      00F053                        758 _cmd_send_and_listen_preamble_extend_ms_65536_45:
      00F053                        759 	.ds 2
      00F055                        760 _cmd_send_and_listen_len_65536_45:
      00F055                        761 	.ds 1
      00F056                        762 _cmd_get_statistics_uptime_ms_65536_55:
      00F056                        763 	.ds 4
                                    764 ;--------------------------------------------------------
                                    765 ; external ram data
                                    766 ;--------------------------------------------------------
                                    767 	.area XSEG    (XDATA)
                           00DF02   768 _MDMCTRL0H	=	0xdf02
                           00DF00   769 _SYNC1	=	0xdf00
                           00DF01   770 _SYNC0	=	0xdf01
                           00DF02   771 _PKTLEN	=	0xdf02
                           00DF03   772 _PKTCTRL1	=	0xdf03
                           00DF04   773 _PKTCTRL0	=	0xdf04
                           00DF05   774 _ADDR	=	0xdf05
                           00DF06   775 _CHANNR	=	0xdf06
                           00DF07   776 _FSCTRL1	=	0xdf07
                           00DF08   777 _FSCTRL0	=	0xdf08
                           00DF09   778 _FREQ2	=	0xdf09
                           00DF0A   779 _FREQ1	=	0xdf0a
                           00DF0B   780 _FREQ0	=	0xdf0b
                           00DF0C   781 _MDMCFG4	=	0xdf0c
                           00DF0D   782 _MDMCFG3	=	0xdf0d
                           00DF0E   783 _MDMCFG2	=	0xdf0e
                           00DF0F   784 _MDMCFG1	=	0xdf0f
                           00DF10   785 _MDMCFG0	=	0xdf10
                           00DF11   786 _DEVIATN	=	0xdf11
                           00DF12   787 _MCSM2	=	0xdf12
                           00DF13   788 _MCSM1	=	0xdf13
                           00DF14   789 _MCSM0	=	0xdf14
                           00DF15   790 _FOCCFG	=	0xdf15
                           00DF16   791 _BSCFG	=	0xdf16
                           00DF17   792 _AGCCTRL2	=	0xdf17
                           00DF18   793 _AGCCTRL1	=	0xdf18
                           00DF19   794 _AGCCTRL0	=	0xdf19
                           00DF1A   795 _FREND1	=	0xdf1a
                           00DF1B   796 _FREND0	=	0xdf1b
                           00DF1C   797 _FSCAL3	=	0xdf1c
                           00DF1D   798 _FSCAL2	=	0xdf1d
                           00DF1E   799 _FSCAL1	=	0xdf1e
                           00DF1F   800 _FSCAL0	=	0xdf1f
                           00DF20   801 __XREGDF20	=	0xdf20
                           00DF21   802 __XREGDF21	=	0xdf21
                           00DF22   803 __XREGDF22	=	0xdf22
                           00DF23   804 _TEST2	=	0xdf23
                           00DF24   805 _TEST1	=	0xdf24
                           00DF25   806 _TEST0	=	0xdf25
                           00DF26   807 __XREGDF26	=	0xdf26
                           00DF27   808 _PA_TABLE7	=	0xdf27
                           00DF28   809 _PA_TABLE6	=	0xdf28
                           00DF29   810 _PA_TABLE5	=	0xdf29
                           00DF2A   811 _PA_TABLE4	=	0xdf2a
                           00DF2B   812 _PA_TABLE3	=	0xdf2b
                           00DF2C   813 _PA_TABLE2	=	0xdf2c
                           00DF2D   814 _PA_TABLE1	=	0xdf2d
                           00DF2E   815 _PA_TABLE0	=	0xdf2e
                           00DF2F   816 _IOCFG2	=	0xdf2f
                           00DF30   817 _IOCFG1	=	0xdf30
                           00DF31   818 _IOCFG0	=	0xdf31
                           00DF32   819 __XREGDF32	=	0xdf32
                           00DF33   820 __XREGDF33	=	0xdf33
                           00DF34   821 __XREGDF34	=	0xdf34
                           00DF35   822 __XREGDF35	=	0xdf35
                           00DF36   823 _PARTNUM	=	0xdf36
                           00DF37   824 _VERSION	=	0xdf37
                           00DF38   825 _FREQEST	=	0xdf38
                           00DF39   826 _LQI	=	0xdf39
                           00DF3A   827 _RSSI	=	0xdf3a
                           00DF3B   828 _MARCSTATE	=	0xdf3b
                           00DF3C   829 _PKTSTATUS	=	0xdf3c
                           00DF3D   830 _VCO_VC_DAC	=	0xdf3d
                           00DF40   831 _I2SCFG0	=	0xdf40
                           00DF41   832 _I2SCFG1	=	0xdf41
                           00DF42   833 _I2SDATL	=	0xdf42
                           00DF43   834 _I2SDATH	=	0xdf43
                           00DF44   835 _I2SWCNT	=	0xdf44
                           00DF45   836 _I2SSTAT	=	0xdf45
                           00DF46   837 _I2SCLKF0	=	0xdf46
                           00DF47   838 _I2SCLKF1	=	0xdf47
                           00DF48   839 _I2SCLKF2	=	0xdf48
                           00DF80   840 __NA_P0	=	0xdf80
                           00DF81   841 __NA_SP	=	0xdf81
                           00DF82   842 __NA_DPL0	=	0xdf82
                           00DF83   843 __NA_DPH0	=	0xdf83
                           00DF84   844 __NA_DPL1	=	0xdf84
                           00DF85   845 __NA_DPH1	=	0xdf85
                           00DF86   846 _X_U0CSR	=	0xdf86
                           00DF87   847 __NA_PCON	=	0xdf87
                           00DF88   848 __NA_TCON	=	0xdf88
                           00DF89   849 _X_P0IFG	=	0xdf89
                           00DF8A   850 _X_P1IFG	=	0xdf8a
                           00DF8B   851 _X_P2IFG	=	0xdf8b
                           00DF8C   852 _X_PICTL	=	0xdf8c
                           00DF8D   853 _X_P1IEN	=	0xdf8d
                           00DF8E   854 __X_SFR8E	=	0xdf8e
                           00DF8F   855 _X_P0INP	=	0xdf8f
                           00DF90   856 __NA_P1	=	0xdf90
                           00DF91   857 _X_RFIM	=	0xdf91
                           00DF92   858 __NA_DPS	=	0xdf92
                           00DF93   859 _X_MPAGE	=	0xdf93
                           00DF94   860 __X_SFR94	=	0xdf94
                           00DF95   861 __X_SFR95	=	0xdf95
                           00DF96   862 __X_SFR96	=	0xdf96
                           00DF97   863 __X_SFR97	=	0xdf97
                           00DF98   864 __NA_S0CON	=	0xdf98
                           00DF99   865 __X_SFR99	=	0xdf99
                           00DF9A   866 __NA_IEN2	=	0xdf9a
                           00DF9B   867 __NA_S1CON	=	0xdf9b
                           00DF9C   868 _X_T2CT	=	0xdf9c
                           00DF9D   869 _X_T2PR	=	0xdf9d
                           00DF9E   870 _X_T2CTL	=	0xdf9e
                           00DF9F   871 __X_SFR9F	=	0xdf9f
                           00DFA0   872 __NA_P2	=	0xdfa0
                           00DFA1   873 _X_WORIRQ	=	0xdfa1
                           00DFA2   874 _X_WORCTRL	=	0xdfa2
                           00DFA3   875 _X_WOREVT0	=	0xdfa3
                           00DFA4   876 _X_WOREVT1	=	0xdfa4
                           00DFA5   877 _X_WORTIME0	=	0xdfa5
                           00DFA6   878 _X_WORTIME1	=	0xdfa6
                           00DFA7   879 __X_SFRA7	=	0xdfa7
                           00DFA8   880 __NA_IEN0	=	0xdfa8
                           00DFA9   881 __NA_IP0	=	0xdfa9
                           00DFAA   882 __X_SFRAA	=	0xdfaa
                           00DFAB   883 _X_FWT	=	0xdfab
                           00DFAC   884 _X_FADDRL	=	0xdfac
                           00DFAD   885 _X_FADDRH	=	0xdfad
                           00DFAE   886 _X_FCTL	=	0xdfae
                           00DFAF   887 _X_FWDATA	=	0xdfaf
                           00DFB0   888 __X_SFRB0	=	0xdfb0
                           00DFB1   889 _X_ENCDI	=	0xdfb1
                           00DFB2   890 _X_ENCDO	=	0xdfb2
                           00DFB3   891 _X_ENCCS	=	0xdfb3
                           00DFB4   892 _X_ADCCON1	=	0xdfb4
                           00DFB5   893 _X_ADCCON2	=	0xdfb5
                           00DFB6   894 _X_ADCCON3	=	0xdfb6
                           00DFB7   895 __X_SFRB7	=	0xdfb7
                           00DFB8   896 __NA_IEN1	=	0xdfb8
                           00DFB9   897 __NA_IP1	=	0xdfb9
                           00DFBA   898 _X_ADCL	=	0xdfba
                           00DFBB   899 _X_ADCH	=	0xdfbb
                           00DFBC   900 _X_RNDL	=	0xdfbc
                           00DFBD   901 _X_RNDH	=	0xdfbd
                           00DFBE   902 _X_SLEEP	=	0xdfbe
                           00DFBF   903 __X_SFRBF	=	0xdfbf
                           00DFC0   904 __NA_IRCON	=	0xdfc0
                           00DFC1   905 _X_U0DBUF	=	0xdfc1
                           00DFC2   906 _X_U0BAUD	=	0xdfc2
                           00DFC3   907 __X_SFRC3	=	0xdfc3
                           00DFC4   908 _X_U0UCR	=	0xdfc4
                           00DFC5   909 _X_U0GCR	=	0xdfc5
                           00DFC6   910 _X_CLKCON	=	0xdfc6
                           00DFC7   911 _X_MEMCTR	=	0xdfc7
                           00DFC8   912 __X_SFRC8	=	0xdfc8
                           00DFC9   913 _X_WDCTL	=	0xdfc9
                           00DFCA   914 _X_T3CNT	=	0xdfca
                           00DFCB   915 _X_T3CTL	=	0xdfcb
                           00DFCC   916 _X_T3CCTL0	=	0xdfcc
                           00DFCD   917 _X_T3CC0	=	0xdfcd
                           00DFCE   918 _X_T3CCTL1	=	0xdfce
                           00DFCF   919 _X_T3CC1	=	0xdfcf
                           00DFD0   920 __NA_PSW	=	0xdfd0
                           00DFD1   921 _X_DMAIRQ	=	0xdfd1
                           00DFD2   922 _X_DMA1CFGL	=	0xdfd2
                           00DFD3   923 _X_DMA1CFGH	=	0xdfd3
                           00DFD4   924 _X_DMA0CFGL	=	0xdfd4
                           00DFD5   925 _X_DMA0CFGH	=	0xdfd5
                           00DFD6   926 _X_DMAARM	=	0xdfd6
                           00DFD7   927 _X_DMAREQ	=	0xdfd7
                           00DFD8   928 _X_TIMIF	=	0xdfd8
                           00DFD9   929 _X_RFD	=	0xdfd9
                           00DFDA   930 _X_T1CC0L	=	0xdfda
                           00DFDB   931 _X_T1CC0H	=	0xdfdb
                           00DFDC   932 _X_T1CC1L	=	0xdfdc
                           00DFDD   933 _X_T1CC1H	=	0xdfdd
                           00DFDE   934 _X_T1CC2L	=	0xdfde
                           00DFDF   935 _X_T1CC2H	=	0xdfdf
                           00DFE0   936 __NA_ACC	=	0xdfe0
                           00DFE1   937 _X_RFST	=	0xdfe1
                           00DFE2   938 _X_T1CNTL	=	0xdfe2
                           00DFE3   939 _X_T1CNTH	=	0xdfe3
                           00DFE4   940 _X_T1CTL	=	0xdfe4
                           00DFE5   941 _X_T1CCTL0	=	0xdfe5
                           00DFE6   942 _X_T1CCTL1	=	0xdfe6
                           00DFE7   943 _X_T1CCTL2	=	0xdfe7
                           00DFE8   944 __NA_IRCON2	=	0xdfe8
                           00DFE9   945 _X_RFIF	=	0xdfe9
                           00DFEA   946 _X_T4CNT	=	0xdfea
                           00DFEB   947 _X_T4CTL	=	0xdfeb
                           00DFEC   948 _X_T4CCTL0	=	0xdfec
                           00DFED   949 _X_T4CC0	=	0xdfed
                           00DFEE   950 _X_T4CCTL1	=	0xdfee
                           00DFEF   951 _X_T4CC1	=	0xdfef
                           00DFF0   952 __NA_B	=	0xdff0
                           00DFF1   953 _X_PERCFG	=	0xdff1
                           00DFF2   954 _X_ADCCFG	=	0xdff2
                           00DFF3   955 _X_P0SEL	=	0xdff3
                           00DFF4   956 _X_P1SEL	=	0xdff4
                           00DFF5   957 _X_P2SEL	=	0xdff5
                           00DFF6   958 _X_P1INP	=	0xdff6
                           00DFF7   959 _X_P2INP	=	0xdff7
                           00DFF8   960 _X_U1CSR	=	0xdff8
                           00DFF9   961 _X_U1DBUF	=	0xdff9
                           00DFFA   962 _X_U1BAUD	=	0xdffa
                           00DFFB   963 _X_U1UCR	=	0xdffb
                           00DFFC   964 _X_U1GCR	=	0xdffc
                           00DFFD   965 _X_P0DIR	=	0xdffd
                           00DFFE   966 _X_P1DIR	=	0xdffe
                           00DFFF   967 _X_P2DIR	=	0xdfff
                                    968 ;--------------------------------------------------------
                                    969 ; absolute external ram data
                                    970 ;--------------------------------------------------------
                                    971 	.area XABS    (ABS,XDATA)
                                    972 ;--------------------------------------------------------
                                    973 ; external initialized ram data
                                    974 ;--------------------------------------------------------
                                    975 	.area XISEG   (XDATA)
      00F329                        976 _handlers::
      00F329                        977 	.ds 32
                                    978 	.area HOME    (CODE)
                                    979 	.area GSINIT0 (CODE)
                                    980 	.area GSINIT1 (CODE)
                                    981 	.area GSINIT2 (CODE)
                                    982 	.area GSINIT3 (CODE)
                                    983 	.area GSINIT4 (CODE)
                                    984 	.area GSINIT5 (CODE)
                                    985 	.area GSINIT  (CODE)
                                    986 	.area GSFINAL (CODE)
                                    987 	.area CSEG    (CODE)
                                    988 ;--------------------------------------------------------
                                    989 ; global & static initialisations
                                    990 ;--------------------------------------------------------
                                    991 	.area HOME    (CODE)
                                    992 	.area GSINIT  (CODE)
                                    993 	.area GSFINAL (CODE)
                                    994 	.area GSINIT  (CODE)
                                    995 ;	commands.c:19: uint8_t interrupting_cmd = 0;
      0000F2 78 49            [12]  996 	mov	r0,#_interrupting_cmd
      0000F4 E4               [12]  997 	clr	a
      0000F5 F2               [24]  998 	movx	@r0,a
                                    999 ;	commands.c:20: uint8_t reset_status = 0;
      0000F6 78 4A            [12] 1000 	mov	r0,#_reset_status
      0000F8 F2               [24] 1001 	movx	@r0,a
                                   1002 ;	commands.c:24: uint8_t use_pktlen = 0;
      0000F9 78 4B            [12] 1003 	mov	r0,#_use_pktlen
      0000FB F2               [24] 1004 	movx	@r0,a
                                   1005 ;--------------------------------------------------------
                                   1006 ; Home
                                   1007 ;--------------------------------------------------------
                                   1008 	.area HOME    (CODE)
                                   1009 	.area HOME    (CODE)
                                   1010 ;--------------------------------------------------------
                                   1011 ; code
                                   1012 ;--------------------------------------------------------
                                   1013 	.area CSEG    (CODE)
                                   1014 ;------------------------------------------------------------
                                   1015 ;Allocation info for local variables in function 'get_command'
                                   1016 ;------------------------------------------------------------
                                   1017 ;	commands.c:30: void get_command() {
                                   1018 ;	-----------------------------------------
                                   1019 ;	 function get_command
                                   1020 ;	-----------------------------------------
      0016F2                       1021 _get_command:
                           000007  1022 	ar7 = 0x07
                           000006  1023 	ar6 = 0x06
                           000005  1024 	ar5 = 0x05
                           000004  1025 	ar4 = 0x04
                           000003  1026 	ar3 = 0x03
                           000002  1027 	ar2 = 0x02
                           000001  1028 	ar1 = 0x01
                           000000  1029 	ar0 = 0x00
                                   1030 ;	commands.c:32: cmd = serial_rx_byte();
      0016F2 12 22 ED         [24] 1031 	lcall	_serial_rx_byte
                                   1032 ;	commands.c:33: do_cmd(cmd);
      0016F5 12 1B 11         [24] 1033 	lcall	_do_cmd
                                   1034 ;	commands.c:34: if (interrupting_cmd) {
      0016F8 78 49            [12] 1035 	mov	r0,#_interrupting_cmd
      0016FA E2               [24] 1036 	movx	a,@r0
      0016FB 60 0C            [24] 1037 	jz	00103$
                                   1038 ;	commands.c:35: do_cmd(interrupting_cmd);
      0016FD 78 49            [12] 1039 	mov	r0,#_interrupting_cmd
      0016FF E2               [24] 1040 	movx	a,@r0
      001700 F5 82            [12] 1041 	mov	dpl,a
      001702 12 1B 11         [24] 1042 	lcall	_do_cmd
                                   1043 ;	commands.c:36: interrupting_cmd = 0;
      001705 78 49            [12] 1044 	mov	r0,#_interrupting_cmd
      001707 E4               [12] 1045 	clr	a
      001708 F2               [24] 1046 	movx	@r0,a
      001709                       1047 00103$:
                                   1048 ;	commands.c:38: }
      001709 22               [24] 1049 	ret
                                   1050 ;------------------------------------------------------------
                                   1051 ;Allocation info for local variables in function 'cmd_set_sw_encoding'
                                   1052 ;------------------------------------------------------------
                                   1053 ;	commands.c:40: void cmd_set_sw_encoding() {
                                   1054 ;	-----------------------------------------
                                   1055 ;	 function cmd_set_sw_encoding
                                   1056 ;	-----------------------------------------
      00170A                       1057 _cmd_set_sw_encoding:
                                   1058 ;	commands.c:43: reset_status = 1;	//this is the command that BLE executes when testing communication with CC, use it to signal that CC was not restarted after BLE
      00170A 78 4A            [12] 1059 	mov	r0,#_reset_status
      00170C 74 01            [12] 1060 	mov	a,#0x01
      00170E F2               [24] 1061 	movx	@r0,a
                                   1062 ;	commands.c:45: encoding_type = serial_rx_byte();
      00170F 12 22 ED         [24] 1063 	lcall	_serial_rx_byte
                                   1064 ;	commands.c:46: if (set_encoding_type(encoding_type)) {
      001712 12 02 CB         [24] 1065 	lcall	_set_encoding_type
      001715 E5 82            [12] 1066 	mov	a,dpl
      001717 60 08            [24] 1067 	jz	00102$
                                   1068 ;	commands.c:47: serial_tx_byte(RESPONSE_CODE_SUCCESS);
      001719 75 82 DD         [24] 1069 	mov	dpl,#0xdd
      00171C 12 24 7F         [24] 1070 	lcall	_serial_tx_byte
      00171F 80 06            [24] 1071 	sjmp	00103$
      001721                       1072 00102$:
                                   1073 ;	commands.c:49: serial_tx_byte(RESPONSE_CODE_PARAM_ERROR); // Error: encoding type not supported
      001721 75 82 11         [24] 1074 	mov	dpl,#0x11
      001724 12 24 7F         [24] 1075 	lcall	_serial_tx_byte
      001727                       1076 00103$:
                                   1077 ;	commands.c:51: serial_flush();
                                   1078 ;	commands.c:52: }
      001727 02 2B DC         [24] 1079 	ljmp	_serial_flush
                                   1080 ;------------------------------------------------------------
                                   1081 ;Allocation info for local variables in function 'cmd_set_mode_registers'
                                   1082 ;------------------------------------------------------------
                                   1083 ;	commands.c:54: void cmd_set_mode_registers() {
                                   1084 ;	-----------------------------------------
                                   1085 ;	 function cmd_set_mode_registers
                                   1086 ;	-----------------------------------------
      00172A                       1087 _cmd_set_mode_registers:
                                   1088 ;	commands.c:62: register_mode = serial_rx_byte();
      00172A 12 22 ED         [24] 1089 	lcall	_serial_rx_byte
      00172D AF 82            [24] 1090 	mov	r7,dpl
                                   1091 ;	commands.c:63: count = serial_rx_avail() / 2;
      00172F C0 07            [24] 1092 	push	ar7
      001731 12 22 DD         [24] 1093 	lcall	_serial_rx_avail
      001734 AE 82            [24] 1094 	mov	r6,dpl
      001736 7D 00            [12] 1095 	mov	r5,#0x00
      001738 78 B2            [12] 1096 	mov	r0,#__divsint_PARM_2
      00173A 74 02            [12] 1097 	mov	a,#0x02
      00173C F2               [24] 1098 	movx	@r0,a
      00173D 08               [12] 1099 	inc	r0
      00173E E4               [12] 1100 	clr	a
      00173F F2               [24] 1101 	movx	@r0,a
      001740 8E 82            [24] 1102 	mov	dpl,r6
      001742 8D 83            [24] 1103 	mov	dph,r5
      001744 12 2D A5         [24] 1104 	lcall	__divsint
      001747 AD 82            [24] 1105 	mov	r5,dpl
      001749 AE 83            [24] 1106 	mov	r6,dph
      00174B D0 07            [24] 1107 	pop	ar7
      00174D 78 4C            [12] 1108 	mov	r0,#_cmd_set_mode_registers_count_65536_34
      00174F ED               [12] 1109 	mov	a,r5
      001750 F2               [24] 1110 	movx	@r0,a
                                   1111 ;	commands.c:65: switch(register_mode) {
      001751 BF 01 02         [24] 1112 	cjne	r7,#0x01,00140$
      001754 80 05            [24] 1113 	sjmp	00101$
      001756                       1114 00140$:
                                   1115 ;	commands.c:66: case RegisterModeTx:
      001756 BF 02 12         [24] 1116 	cjne	r7,#0x02,00103$
      001759 80 08            [24] 1117 	sjmp	00102$
      00175B                       1118 00101$:
                                   1119 ;	commands.c:67: registers = &tx_registers;
      00175B 7C EB            [12] 1120 	mov	r4,#_tx_registers
      00175D 7E F1            [12] 1121 	mov	r6,#(_tx_registers >> 8)
      00175F 7F 00            [12] 1122 	mov	r7,#0x00
                                   1123 ;	commands.c:68: break;
                                   1124 ;	commands.c:69: case RegisterModeRx:
      001761 80 0E            [24] 1125 	sjmp	00104$
      001763                       1126 00102$:
                                   1127 ;	commands.c:70: registers = &rx_registers;
      001763 7C FC            [12] 1128 	mov	r4,#_rx_registers
      001765 7E F1            [12] 1129 	mov	r6,#(_rx_registers >> 8)
      001767 7F 00            [12] 1130 	mov	r7,#0x00
                                   1131 ;	commands.c:71: break;
                                   1132 ;	commands.c:72: default:
      001769 80 06            [24] 1133 	sjmp	00104$
      00176B                       1134 00103$:
                                   1135 ;	commands.c:73: registers = 0x0;
      00176B 7C 00            [12] 1136 	mov	r4,#0x00
      00176D 7E 00            [12] 1137 	mov	r6,#0x00
      00176F 7F 00            [12] 1138 	mov	r7,#0x00
                                   1139 ;	commands.c:75: }
      001771                       1140 00104$:
                                   1141 ;	commands.c:77: if (registers != NULL) {
      001771 EC               [12] 1142 	mov	a,r4
      001772 4E               [12] 1143 	orl	a,r6
      001773 60 15            [24] 1144 	jz	00120$
                                   1145 ;	commands.c:78: mode_registers_clear(registers);
      001775 8C 82            [24] 1146 	mov	dpl,r4
      001777 8E 83            [24] 1147 	mov	dph,r6
      001779 8F F0            [24] 1148 	mov	b,r7
      00177B C0 07            [24] 1149 	push	ar7
      00177D C0 06            [24] 1150 	push	ar6
      00177F C0 04            [24] 1151 	push	ar4
      001781 12 1E FC         [24] 1152 	lcall	_mode_registers_clear
      001784 D0 04            [24] 1153 	pop	ar4
      001786 D0 06            [24] 1154 	pop	ar6
      001788 D0 07            [24] 1155 	pop	ar7
                                   1156 ;	commands.c:80: for (i=0; i<count; i++) {
      00178A                       1157 00120$:
      00178A 7A 00            [12] 1158 	mov	r2,#0x00
      00178C 7B 00            [12] 1159 	mov	r3,#0x00
      00178E                       1160 00111$:
      00178E C0 04            [24] 1161 	push	ar4
      001790 C0 06            [24] 1162 	push	ar6
      001792 C0 07            [24] 1163 	push	ar7
      001794 78 4C            [12] 1164 	mov	r0,#_cmd_set_mode_registers_count_65536_34
      001796 E2               [24] 1165 	movx	a,@r0
      001797 FE               [12] 1166 	mov	r6,a
      001798 7F 00            [12] 1167 	mov	r7,#0x00
      00179A C3               [12] 1168 	clr	c
      00179B EA               [12] 1169 	mov	a,r2
      00179C 9E               [12] 1170 	subb	a,r6
      00179D EB               [12] 1171 	mov	a,r3
      00179E 64 80            [12] 1172 	xrl	a,#0x80
      0017A0 8F F0            [24] 1173 	mov	b,r7
      0017A2 63 F0 80         [24] 1174 	xrl	b,#0x80
      0017A5 95 F0            [12] 1175 	subb	a,b
      0017A7 D0 07            [24] 1176 	pop	ar7
      0017A9 D0 06            [24] 1177 	pop	ar6
      0017AB D0 04            [24] 1178 	pop	ar4
      0017AD 50 53            [24] 1179 	jnc	00109$
                                   1180 ;	commands.c:81: addr = serial_rx_byte();
      0017AF C0 07            [24] 1181 	push	ar7
      0017B1 C0 06            [24] 1182 	push	ar6
      0017B3 C0 04            [24] 1183 	push	ar4
      0017B5 C0 03            [24] 1184 	push	ar3
      0017B7 C0 02            [24] 1185 	push	ar2
      0017B9 12 22 ED         [24] 1186 	lcall	_serial_rx_byte
      0017BC 78 4D            [12] 1187 	mov	r0,#_cmd_set_mode_registers_addr_65536_34
      0017BE E5 82            [12] 1188 	mov	a,dpl
      0017C0 F2               [24] 1189 	movx	@r0,a
                                   1190 ;	commands.c:82: value = serial_rx_byte();
      0017C1 12 22 ED         [24] 1191 	lcall	_serial_rx_byte
      0017C4 AD 82            [24] 1192 	mov	r5,dpl
      0017C6 D0 02            [24] 1193 	pop	ar2
      0017C8 D0 03            [24] 1194 	pop	ar3
      0017CA D0 04            [24] 1195 	pop	ar4
      0017CC D0 06            [24] 1196 	pop	ar6
      0017CE D0 07            [24] 1197 	pop	ar7
                                   1198 ;	commands.c:83: if (registers != NULL) {
      0017D0 EC               [12] 1199 	mov	a,r4
      0017D1 4E               [12] 1200 	orl	a,r6
      0017D2 60 27            [24] 1201 	jz	00112$
                                   1202 ;	commands.c:84: mode_registers_add(registers, addr, value);
      0017D4 78 4D            [12] 1203 	mov	r0,#_cmd_set_mode_registers_addr_65536_34
      0017D6 79 5B            [12] 1204 	mov	r1,#_mode_registers_add_PARM_2
      0017D8 E2               [24] 1205 	movx	a,@r0
      0017D9 F3               [24] 1206 	movx	@r1,a
      0017DA 78 5C            [12] 1207 	mov	r0,#_mode_registers_add_PARM_3
      0017DC ED               [12] 1208 	mov	a,r5
      0017DD F2               [24] 1209 	movx	@r0,a
      0017DE 8C 82            [24] 1210 	mov	dpl,r4
      0017E0 8E 83            [24] 1211 	mov	dph,r6
      0017E2 8F F0            [24] 1212 	mov	b,r7
      0017E4 C0 07            [24] 1213 	push	ar7
      0017E6 C0 06            [24] 1214 	push	ar6
      0017E8 C0 04            [24] 1215 	push	ar4
      0017EA C0 03            [24] 1216 	push	ar3
      0017EC C0 02            [24] 1217 	push	ar2
      0017EE 12 1F 00         [24] 1218 	lcall	_mode_registers_add
      0017F1 D0 02            [24] 1219 	pop	ar2
      0017F3 D0 03            [24] 1220 	pop	ar3
      0017F5 D0 04            [24] 1221 	pop	ar4
      0017F7 D0 06            [24] 1222 	pop	ar6
      0017F9 D0 07            [24] 1223 	pop	ar7
      0017FB                       1224 00112$:
                                   1225 ;	commands.c:80: for (i=0; i<count; i++) {
      0017FB 0A               [12] 1226 	inc	r2
      0017FC BA 00 8F         [24] 1227 	cjne	r2,#0x00,00111$
      0017FF 0B               [12] 1228 	inc	r3
      001800 80 8C            [24] 1229 	sjmp	00111$
      001802                       1230 00109$:
                                   1231 ;	commands.c:87: serial_tx_byte(RESPONSE_CODE_SUCCESS);
      001802 75 82 DD         [24] 1232 	mov	dpl,#0xdd
      001805 12 24 7F         [24] 1233 	lcall	_serial_tx_byte
                                   1234 ;	commands.c:88: serial_flush();
                                   1235 ;	commands.c:89: }
      001808 02 2B DC         [24] 1236 	ljmp	_serial_flush
                                   1237 ;------------------------------------------------------------
                                   1238 ;Allocation info for local variables in function 'cmd_get_packet'
                                   1239 ;------------------------------------------------------------
                                   1240 ;	commands.c:91: void cmd_get_packet() {
                                   1241 ;	-----------------------------------------
                                   1242 ;	 function cmd_get_packet
                                   1243 ;	-----------------------------------------
      00180B                       1244 _cmd_get_packet:
                                   1245 ;	commands.c:95: channel = serial_rx_byte();
      00180B 12 22 ED         [24] 1246 	lcall	_serial_rx_byte
      00180E AF 82            [24] 1247 	mov	r7,dpl
                                   1248 ;	commands.c:96: timeout_ms = serial_rx_long();
      001810 C0 07            [24] 1249 	push	ar7
      001812 12 24 40         [24] 1250 	lcall	_serial_rx_long
      001815 AB 82            [24] 1251 	mov	r3,dpl
      001817 AC 83            [24] 1252 	mov	r4,dph
      001819 AD F0            [24] 1253 	mov	r5,b
      00181B FE               [12] 1254 	mov	r6,a
      00181C D0 07            [24] 1255 	pop	ar7
                                   1256 ;	commands.c:97: result = get_packet_and_write_to_serial(channel, timeout_ms, use_pktlen);
      00181E 78 17            [12] 1257 	mov	r0,#_get_packet_and_write_to_serial_PARM_2
      001820 EB               [12] 1258 	mov	a,r3
      001821 F2               [24] 1259 	movx	@r0,a
      001822 08               [12] 1260 	inc	r0
      001823 EC               [12] 1261 	mov	a,r4
      001824 F2               [24] 1262 	movx	@r0,a
      001825 08               [12] 1263 	inc	r0
      001826 ED               [12] 1264 	mov	a,r5
      001827 F2               [24] 1265 	movx	@r0,a
      001828 08               [12] 1266 	inc	r0
      001829 EE               [12] 1267 	mov	a,r6
      00182A F2               [24] 1268 	movx	@r0,a
      00182B 78 4B            [12] 1269 	mov	r0,#_use_pktlen
      00182D 79 1B            [12] 1270 	mov	r1,#_get_packet_and_write_to_serial_PARM_3
      00182F E2               [24] 1271 	movx	a,@r0
      001830 F3               [24] 1272 	movx	@r1,a
      001831 8F 82            [24] 1273 	mov	dpl,r7
      001833 12 07 D4         [24] 1274 	lcall	_get_packet_and_write_to_serial
                                   1275 ;	commands.c:98: if (result != 0) {
      001836 E5 82            [12] 1276 	mov	a,dpl
      001838 FE               [12] 1277 	mov	r6,a
      001839 60 05            [24] 1278 	jz	00102$
                                   1279 ;	commands.c:99: serial_tx_byte(result);
      00183B 8E 82            [24] 1280 	mov	dpl,r6
      00183D 12 24 7F         [24] 1281 	lcall	_serial_tx_byte
      001840                       1282 00102$:
                                   1283 ;	commands.c:101: serial_flush();
                                   1284 ;	commands.c:102: }
      001840 02 2B DC         [24] 1285 	ljmp	_serial_flush
                                   1286 ;------------------------------------------------------------
                                   1287 ;Allocation info for local variables in function 'cmd_get_state'
                                   1288 ;------------------------------------------------------------
                                   1289 ;	commands.c:104: void cmd_get_state() {
                                   1290 ;	-----------------------------------------
                                   1291 ;	 function cmd_get_state
                                   1292 ;	-----------------------------------------
      001843                       1293 _cmd_get_state:
                                   1294 ;	commands.c:105: serial_tx_byte(RESPONSE_CODE_SUCCESS);
      001843 75 82 DD         [24] 1295 	mov	dpl,#0xdd
      001846 12 24 7F         [24] 1296 	lcall	_serial_tx_byte
                                   1297 ;	commands.c:106: serial_tx_str("OK");
      001849 90 2E 75         [24] 1298 	mov	dptr,#___str_0
      00184C 75 F0 80         [24] 1299 	mov	b,#0x80
                                   1300 ;	commands.c:107: }
      00184F 02 2D 09         [24] 1301 	ljmp	_serial_tx_str
                                   1302 ;------------------------------------------------------------
                                   1303 ;Allocation info for local variables in function 'cmd_get_version'
                                   1304 ;------------------------------------------------------------
                                   1305 ;	commands.c:109: void cmd_get_version() {
                                   1306 ;	-----------------------------------------
                                   1307 ;	 function cmd_get_version
                                   1308 ;	-----------------------------------------
      001852                       1309 _cmd_get_version:
                                   1310 ;	commands.c:110: serial_tx_byte(RESPONSE_CODE_SUCCESS);
      001852 75 82 DD         [24] 1311 	mov	dpl,#0xdd
      001855 12 24 7F         [24] 1312 	lcall	_serial_tx_byte
                                   1313 ;	commands.c:111: serial_tx_str(SUBG_RFSPY_VERSION);
      001858 90 2E 78         [24] 1314 	mov	dptr,#___str_1
      00185B 75 F0 80         [24] 1315 	mov	b,#0x80
                                   1316 ;	commands.c:112: }
      00185E 02 2D 09         [24] 1317 	ljmp	_serial_tx_str
                                   1318 ;------------------------------------------------------------
                                   1319 ;Allocation info for local variables in function 'cmd_send_packet'
                                   1320 ;------------------------------------------------------------
                                   1321 ;	commands.c:114: void cmd_send_packet() {
                                   1322 ;	-----------------------------------------
                                   1323 ;	 function cmd_send_packet
                                   1324 ;	-----------------------------------------
      001861                       1325 _cmd_send_packet:
                                   1326 ;	commands.c:120: channel = serial_rx_byte();
      001861 12 22 ED         [24] 1327 	lcall	_serial_rx_byte
      001864 AF 82            [24] 1328 	mov	r7,dpl
                                   1329 ;	commands.c:121: repeat_count = serial_rx_byte();
      001866 C0 07            [24] 1330 	push	ar7
      001868 12 22 ED         [24] 1331 	lcall	_serial_rx_byte
      00186B 78 4E            [12] 1332 	mov	r0,#_cmd_send_packet_repeat_count_65536_44
      00186D E5 82            [12] 1333 	mov	a,dpl
      00186F F2               [24] 1334 	movx	@r0,a
                                   1335 ;	commands.c:122: delay_ms = serial_rx_word();
      001870 12 24 20         [24] 1336 	lcall	_serial_rx_word
      001873 AC 82            [24] 1337 	mov	r4,dpl
      001875 AD 83            [24] 1338 	mov	r5,dph
                                   1339 ;	commands.c:123: preamble_extend_ms = serial_rx_word();
      001877 C0 05            [24] 1340 	push	ar5
      001879 C0 04            [24] 1341 	push	ar4
      00187B 12 24 20         [24] 1342 	lcall	_serial_rx_word
      00187E AA 82            [24] 1343 	mov	r2,dpl
      001880 AB 83            [24] 1344 	mov	r3,dph
                                   1345 ;	commands.c:124: len = serial_rx_avail();
      001882 C0 03            [24] 1346 	push	ar3
      001884 C0 02            [24] 1347 	push	ar2
      001886 12 22 DD         [24] 1348 	lcall	_serial_rx_avail
      001889 AE 82            [24] 1349 	mov	r6,dpl
      00188B D0 02            [24] 1350 	pop	ar2
      00188D D0 03            [24] 1351 	pop	ar3
      00188F D0 04            [24] 1352 	pop	ar4
      001891 D0 05            [24] 1353 	pop	ar5
      001893 D0 07            [24] 1354 	pop	ar7
                                   1355 ;	commands.c:125: send_packet_from_serial(channel, repeat_count, delay_ms, preamble_extend_ms, len);
      001895 78 4E            [12] 1356 	mov	r0,#_cmd_send_packet_repeat_count_65536_44
      001897 79 06            [12] 1357 	mov	r1,#_send_packet_from_serial_PARM_2
      001899 E2               [24] 1358 	movx	a,@r0
      00189A F3               [24] 1359 	movx	@r1,a
      00189B 78 07            [12] 1360 	mov	r0,#_send_packet_from_serial_PARM_3
      00189D EC               [12] 1361 	mov	a,r4
      00189E F2               [24] 1362 	movx	@r0,a
      00189F 08               [12] 1363 	inc	r0
      0018A0 ED               [12] 1364 	mov	a,r5
      0018A1 F2               [24] 1365 	movx	@r0,a
      0018A2 78 09            [12] 1366 	mov	r0,#_send_packet_from_serial_PARM_4
      0018A4 EA               [12] 1367 	mov	a,r2
      0018A5 F2               [24] 1368 	movx	@r0,a
      0018A6 08               [12] 1369 	inc	r0
      0018A7 EB               [12] 1370 	mov	a,r3
      0018A8 F2               [24] 1371 	movx	@r0,a
      0018A9 78 0B            [12] 1372 	mov	r0,#_send_packet_from_serial_PARM_5
      0018AB EE               [12] 1373 	mov	a,r6
      0018AC F2               [24] 1374 	movx	@r0,a
      0018AD 8F 82            [24] 1375 	mov	dpl,r7
      0018AF 12 05 4C         [24] 1376 	lcall	_send_packet_from_serial
                                   1377 ;	commands.c:126: serial_tx_byte(RESPONSE_CODE_SUCCESS);
      0018B2 75 82 DD         [24] 1378 	mov	dpl,#0xdd
      0018B5 12 24 7F         [24] 1379 	lcall	_serial_tx_byte
                                   1380 ;	commands.c:127: serial_flush();
                                   1381 ;	commands.c:128: }
      0018B8 02 2B DC         [24] 1382 	ljmp	_serial_flush
                                   1383 ;------------------------------------------------------------
                                   1384 ;Allocation info for local variables in function 'cmd_send_and_listen'
                                   1385 ;------------------------------------------------------------
                                   1386 ;	commands.c:131: void cmd_send_and_listen() {
                                   1387 ;	-----------------------------------------
                                   1388 ;	 function cmd_send_and_listen
                                   1389 ;	-----------------------------------------
      0018BB                       1390 _cmd_send_and_listen:
                                   1391 ;	commands.c:142: send_channel = serial_rx_byte();
      0018BB 12 22 ED         [24] 1392 	lcall	_serial_rx_byte
      0018BE 78 4F            [12] 1393 	mov	r0,#_cmd_send_and_listen_send_channel_65536_45
      0018C0 E5 82            [12] 1394 	mov	a,dpl
      0018C2 F2               [24] 1395 	movx	@r0,a
                                   1396 ;	commands.c:143: repeat_count = serial_rx_byte();
      0018C3 12 22 ED         [24] 1397 	lcall	_serial_rx_byte
      0018C6 AF 82            [24] 1398 	mov	r7,dpl
                                   1399 ;	commands.c:144: delay_ms = serial_rx_word();
      0018C8 C0 07            [24] 1400 	push	ar7
      0018CA 12 24 20         [24] 1401 	lcall	_serial_rx_word
      0018CD 78 50            [12] 1402 	mov	r0,#_cmd_send_and_listen_delay_ms_65536_45
      0018CF E5 82            [12] 1403 	mov	a,dpl
      0018D1 F2               [24] 1404 	movx	@r0,a
      0018D2 08               [12] 1405 	inc	r0
      0018D3 E5 83            [12] 1406 	mov	a,dph
      0018D5 F2               [24] 1407 	movx	@r0,a
                                   1408 ;	commands.c:145: listen_channel = serial_rx_byte();
      0018D6 12 22 ED         [24] 1409 	lcall	_serial_rx_byte
      0018D9 78 52            [12] 1410 	mov	r0,#_cmd_send_and_listen_listen_channel_65536_45
      0018DB E5 82            [12] 1411 	mov	a,dpl
      0018DD F2               [24] 1412 	movx	@r0,a
                                   1413 ;	commands.c:146: timeout_ms = serial_rx_long();
      0018DE 12 24 40         [24] 1414 	lcall	_serial_rx_long
      0018E1 AA 82            [24] 1415 	mov	r2,dpl
      0018E3 AC 83            [24] 1416 	mov	r4,dph
      0018E5 AD F0            [24] 1417 	mov	r5,b
      0018E7 FE               [12] 1418 	mov	r6,a
                                   1419 ;	commands.c:147: retry_count = serial_rx_byte();
      0018E8 C0 06            [24] 1420 	push	ar6
      0018EA C0 05            [24] 1421 	push	ar5
      0018EC C0 04            [24] 1422 	push	ar4
      0018EE C0 02            [24] 1423 	push	ar2
      0018F0 12 22 ED         [24] 1424 	lcall	_serial_rx_byte
      0018F3 AB 82            [24] 1425 	mov	r3,dpl
      0018F5 D0 02            [24] 1426 	pop	ar2
                                   1427 ;	commands.c:148: preamble_extend_ms = serial_rx_word();
      0018F7 C0 03            [24] 1428 	push	ar3
      0018F9 C0 02            [24] 1429 	push	ar2
      0018FB 12 24 20         [24] 1430 	lcall	_serial_rx_word
      0018FE 78 53            [12] 1431 	mov	r0,#_cmd_send_and_listen_preamble_extend_ms_65536_45
      001900 E5 82            [12] 1432 	mov	a,dpl
      001902 F2               [24] 1433 	movx	@r0,a
      001903 08               [12] 1434 	inc	r0
      001904 E5 83            [12] 1435 	mov	a,dph
      001906 F2               [24] 1436 	movx	@r0,a
                                   1437 ;	commands.c:149: len = serial_rx_avail();
      001907 12 22 DD         [24] 1438 	lcall	_serial_rx_avail
      00190A 78 55            [12] 1439 	mov	r0,#_cmd_send_and_listen_len_65536_45
      00190C E5 82            [12] 1440 	mov	a,dpl
      00190E F2               [24] 1441 	movx	@r0,a
      00190F D0 02            [24] 1442 	pop	ar2
      001911 D0 03            [24] 1443 	pop	ar3
      001913 D0 04            [24] 1444 	pop	ar4
      001915 D0 05            [24] 1445 	pop	ar5
      001917 D0 06            [24] 1446 	pop	ar6
      001919 D0 07            [24] 1447 	pop	ar7
                                   1448 ;	commands.c:151: send_packet_from_serial(send_channel, repeat_count, delay_ms, preamble_extend_ms, len);
      00191B 78 06            [12] 1449 	mov	r0,#_send_packet_from_serial_PARM_2
      00191D EF               [12] 1450 	mov	a,r7
      00191E F2               [24] 1451 	movx	@r0,a
      00191F 78 50            [12] 1452 	mov	r0,#_cmd_send_and_listen_delay_ms_65536_45
      001921 79 07            [12] 1453 	mov	r1,#_send_packet_from_serial_PARM_3
      001923 E2               [24] 1454 	movx	a,@r0
      001924 F3               [24] 1455 	movx	@r1,a
      001925 08               [12] 1456 	inc	r0
      001926 E2               [24] 1457 	movx	a,@r0
      001927 09               [12] 1458 	inc	r1
      001928 F3               [24] 1459 	movx	@r1,a
      001929 78 53            [12] 1460 	mov	r0,#_cmd_send_and_listen_preamble_extend_ms_65536_45
      00192B 79 09            [12] 1461 	mov	r1,#_send_packet_from_serial_PARM_4
      00192D E2               [24] 1462 	movx	a,@r0
      00192E F3               [24] 1463 	movx	@r1,a
      00192F 08               [12] 1464 	inc	r0
      001930 E2               [24] 1465 	movx	a,@r0
      001931 09               [12] 1466 	inc	r1
      001932 F3               [24] 1467 	movx	@r1,a
      001933 78 55            [12] 1468 	mov	r0,#_cmd_send_and_listen_len_65536_45
      001935 79 0B            [12] 1469 	mov	r1,#_send_packet_from_serial_PARM_5
      001937 E2               [24] 1470 	movx	a,@r0
      001938 F3               [24] 1471 	movx	@r1,a
      001939 78 4F            [12] 1472 	mov	r0,#_cmd_send_and_listen_send_channel_65536_45
      00193B E2               [24] 1473 	movx	a,@r0
      00193C F5 82            [12] 1474 	mov	dpl,a
      00193E C0 06            [24] 1475 	push	ar6
      001940 C0 05            [24] 1476 	push	ar5
      001942 C0 04            [24] 1477 	push	ar4
      001944 C0 03            [24] 1478 	push	ar3
      001946 C0 02            [24] 1479 	push	ar2
      001948 12 05 4C         [24] 1480 	lcall	_send_packet_from_serial
      00194B D0 02            [24] 1481 	pop	ar2
      00194D D0 03            [24] 1482 	pop	ar3
      00194F D0 04            [24] 1483 	pop	ar4
      001951 D0 05            [24] 1484 	pop	ar5
      001953 D0 06            [24] 1485 	pop	ar6
                                   1486 ;	commands.c:152: result = get_packet_and_write_to_serial(listen_channel, timeout_ms, use_pktlen);
      001955 78 17            [12] 1487 	mov	r0,#_get_packet_and_write_to_serial_PARM_2
      001957 EA               [12] 1488 	mov	a,r2
      001958 F2               [24] 1489 	movx	@r0,a
      001959 08               [12] 1490 	inc	r0
      00195A EC               [12] 1491 	mov	a,r4
      00195B F2               [24] 1492 	movx	@r0,a
      00195C 08               [12] 1493 	inc	r0
      00195D ED               [12] 1494 	mov	a,r5
      00195E F2               [24] 1495 	movx	@r0,a
      00195F 08               [12] 1496 	inc	r0
      001960 EE               [12] 1497 	mov	a,r6
      001961 F2               [24] 1498 	movx	@r0,a
      001962 78 4B            [12] 1499 	mov	r0,#_use_pktlen
      001964 79 1B            [12] 1500 	mov	r1,#_get_packet_and_write_to_serial_PARM_3
      001966 E2               [24] 1501 	movx	a,@r0
      001967 F3               [24] 1502 	movx	@r1,a
      001968 78 52            [12] 1503 	mov	r0,#_cmd_send_and_listen_listen_channel_65536_45
      00196A E2               [24] 1504 	movx	a,@r0
      00196B F5 82            [12] 1505 	mov	dpl,a
      00196D C0 06            [24] 1506 	push	ar6
      00196F C0 05            [24] 1507 	push	ar5
      001971 C0 04            [24] 1508 	push	ar4
      001973 C0 03            [24] 1509 	push	ar3
      001975 C0 02            [24] 1510 	push	ar2
      001977 12 07 D4         [24] 1511 	lcall	_get_packet_and_write_to_serial
      00197A AF 82            [24] 1512 	mov	r7,dpl
      00197C D0 02            [24] 1513 	pop	ar2
      00197E D0 03            [24] 1514 	pop	ar3
      001980 D0 04            [24] 1515 	pop	ar4
      001982 D0 05            [24] 1516 	pop	ar5
      001984 D0 06            [24] 1517 	pop	ar6
                                   1518 ;	commands.c:154: while (result == RESPONSE_CODE_RX_TIMEOUT && retry_count > 0) {
      001986                       1519 00102$:
      001986 BF AA 5D         [24] 1520 	cjne	r7,#0xaa,00104$
      001989 EB               [12] 1521 	mov	a,r3
      00198A 60 5A            [24] 1522 	jz	00104$
                                   1523 ;	commands.c:155: send_from_tx_buf(send_channel, preamble_extend_ms);
      00198C 78 53            [12] 1524 	mov	r0,#_cmd_send_and_listen_preamble_extend_ms_65536_45
      00198E 79 15            [12] 1525 	mov	r1,#_send_from_tx_buf_PARM_2
      001990 E2               [24] 1526 	movx	a,@r0
      001991 F3               [24] 1527 	movx	@r1,a
      001992 08               [12] 1528 	inc	r0
      001993 E2               [24] 1529 	movx	a,@r0
      001994 09               [12] 1530 	inc	r1
      001995 F3               [24] 1531 	movx	@r1,a
      001996 78 4F            [12] 1532 	mov	r0,#_cmd_send_and_listen_send_channel_65536_45
      001998 E2               [24] 1533 	movx	a,@r0
      001999 F5 82            [12] 1534 	mov	dpl,a
      00199B C0 06            [24] 1535 	push	ar6
      00199D C0 05            [24] 1536 	push	ar5
      00199F C0 04            [24] 1537 	push	ar4
      0019A1 C0 03            [24] 1538 	push	ar3
      0019A3 C0 02            [24] 1539 	push	ar2
      0019A5 12 06 D8         [24] 1540 	lcall	_send_from_tx_buf
      0019A8 D0 02            [24] 1541 	pop	ar2
      0019AA D0 03            [24] 1542 	pop	ar3
      0019AC D0 04            [24] 1543 	pop	ar4
      0019AE D0 05            [24] 1544 	pop	ar5
      0019B0 D0 06            [24] 1545 	pop	ar6
                                   1546 ;	commands.c:156: result = get_packet_and_write_to_serial(listen_channel, timeout_ms, use_pktlen);
      0019B2 78 17            [12] 1547 	mov	r0,#_get_packet_and_write_to_serial_PARM_2
      0019B4 EA               [12] 1548 	mov	a,r2
      0019B5 F2               [24] 1549 	movx	@r0,a
      0019B6 08               [12] 1550 	inc	r0
      0019B7 EC               [12] 1551 	mov	a,r4
      0019B8 F2               [24] 1552 	movx	@r0,a
      0019B9 08               [12] 1553 	inc	r0
      0019BA ED               [12] 1554 	mov	a,r5
      0019BB F2               [24] 1555 	movx	@r0,a
      0019BC 08               [12] 1556 	inc	r0
      0019BD EE               [12] 1557 	mov	a,r6
      0019BE F2               [24] 1558 	movx	@r0,a
      0019BF 78 4B            [12] 1559 	mov	r0,#_use_pktlen
      0019C1 79 1B            [12] 1560 	mov	r1,#_get_packet_and_write_to_serial_PARM_3
      0019C3 E2               [24] 1561 	movx	a,@r0
      0019C4 F3               [24] 1562 	movx	@r1,a
      0019C5 78 52            [12] 1563 	mov	r0,#_cmd_send_and_listen_listen_channel_65536_45
      0019C7 E2               [24] 1564 	movx	a,@r0
      0019C8 F5 82            [12] 1565 	mov	dpl,a
      0019CA C0 06            [24] 1566 	push	ar6
      0019CC C0 05            [24] 1567 	push	ar5
      0019CE C0 04            [24] 1568 	push	ar4
      0019D0 C0 03            [24] 1569 	push	ar3
      0019D2 C0 02            [24] 1570 	push	ar2
      0019D4 12 07 D4         [24] 1571 	lcall	_get_packet_and_write_to_serial
      0019D7 AF 82            [24] 1572 	mov	r7,dpl
      0019D9 D0 02            [24] 1573 	pop	ar2
      0019DB D0 03            [24] 1574 	pop	ar3
      0019DD D0 04            [24] 1575 	pop	ar4
      0019DF D0 05            [24] 1576 	pop	ar5
      0019E1 D0 06            [24] 1577 	pop	ar6
                                   1578 ;	commands.c:157: retry_count--;
      0019E3 1B               [12] 1579 	dec	r3
      0019E4 80 A0            [24] 1580 	sjmp	00102$
      0019E6                       1581 00104$:
                                   1582 ;	commands.c:160: if (result != 0) {
      0019E6 EF               [12] 1583 	mov	a,r7
      0019E7 60 05            [24] 1584 	jz	00106$
                                   1585 ;	commands.c:162: serial_tx_byte(result);
      0019E9 8F 82            [24] 1586 	mov	dpl,r7
      0019EB 12 24 7F         [24] 1587 	lcall	_serial_tx_byte
      0019EE                       1588 00106$:
                                   1589 ;	commands.c:164: serial_flush();
                                   1590 ;	commands.c:165: }
      0019EE 02 2B DC         [24] 1591 	ljmp	_serial_flush
                                   1592 ;------------------------------------------------------------
                                   1593 ;Allocation info for local variables in function 'cmd_read_register'
                                   1594 ;------------------------------------------------------------
                                   1595 ;	commands.c:167: void cmd_read_register() {
                                   1596 ;	-----------------------------------------
                                   1597 ;	 function cmd_read_register
                                   1598 ;	-----------------------------------------
      0019F1                       1599 _cmd_read_register:
                                   1600 ;	commands.c:170: addr = serial_rx_byte();
      0019F1 12 22 ED         [24] 1601 	lcall	_serial_rx_byte
                                   1602 ;	commands.c:171: value = get_register(addr);
      0019F4 12 1B 96         [24] 1603 	lcall	_get_register
      0019F7 AF 82            [24] 1604 	mov	r7,dpl
                                   1605 ;	commands.c:172: serial_tx_byte(RESPONSE_CODE_SUCCESS);
      0019F9 75 82 DD         [24] 1606 	mov	dpl,#0xdd
      0019FC C0 07            [24] 1607 	push	ar7
      0019FE 12 24 7F         [24] 1608 	lcall	_serial_tx_byte
      001A01 D0 07            [24] 1609 	pop	ar7
                                   1610 ;	commands.c:173: serial_tx_byte(value);
      001A03 8F 82            [24] 1611 	mov	dpl,r7
      001A05 12 24 7F         [24] 1612 	lcall	_serial_tx_byte
                                   1613 ;	commands.c:174: serial_flush();
                                   1614 ;	commands.c:175: }
      001A08 02 2B DC         [24] 1615 	ljmp	_serial_flush
                                   1616 ;------------------------------------------------------------
                                   1617 ;Allocation info for local variables in function 'cmd_update_register'
                                   1618 ;------------------------------------------------------------
                                   1619 ;	commands.c:177: void cmd_update_register() {
                                   1620 ;	-----------------------------------------
                                   1621 ;	 function cmd_update_register
                                   1622 ;	-----------------------------------------
      001A0B                       1623 _cmd_update_register:
                                   1624 ;	commands.c:181: addr = serial_rx_byte();
      001A0B 12 22 ED         [24] 1625 	lcall	_serial_rx_byte
      001A0E AF 82            [24] 1626 	mov	r7,dpl
                                   1627 ;	commands.c:182: value = serial_rx_byte();
      001A10 C0 07            [24] 1628 	push	ar7
      001A12 12 22 ED         [24] 1629 	lcall	_serial_rx_byte
      001A15 AE 82            [24] 1630 	mov	r6,dpl
      001A17 D0 07            [24] 1631 	pop	ar7
                                   1632 ;	commands.c:183: rval = set_register(addr, value);
      001A19 78 5A            [12] 1633 	mov	r0,#_set_register_PARM_2
      001A1B EE               [12] 1634 	mov	a,r6
      001A1C F2               [24] 1635 	movx	@r0,a
      001A1D 8F 82            [24] 1636 	mov	dpl,r7
      001A1F C0 07            [24] 1637 	push	ar7
      001A21 12 1D 24         [24] 1638 	lcall	_set_register
      001A24 AE 82            [24] 1639 	mov	r6,dpl
      001A26 D0 07            [24] 1640 	pop	ar7
                                   1641 ;	commands.c:186: if (addr == 0x02) {
      001A28 BF 02 05         [24] 1642 	cjne	r7,#0x02,00102$
                                   1643 ;	commands.c:187: use_pktlen = 1;
      001A2B 78 4B            [12] 1644 	mov	r0,#_use_pktlen
      001A2D 74 01            [12] 1645 	mov	a,#0x01
      001A2F F2               [24] 1646 	movx	@r0,a
      001A30                       1647 00102$:
                                   1648 ;	commands.c:190: serial_tx_byte(rval);
      001A30 8E 82            [24] 1649 	mov	dpl,r6
      001A32 12 24 7F         [24] 1650 	lcall	_serial_tx_byte
                                   1651 ;	commands.c:191: serial_flush();
                                   1652 ;	commands.c:192: }
      001A35 02 2B DC         [24] 1653 	ljmp	_serial_flush
                                   1654 ;------------------------------------------------------------
                                   1655 ;Allocation info for local variables in function 'cmd_reset'
                                   1656 ;------------------------------------------------------------
                                   1657 ;	commands.c:194: void cmd_reset() {
                                   1658 ;	-----------------------------------------
                                   1659 ;	 function cmd_reset
                                   1660 ;	-----------------------------------------
      001A38                       1661 _cmd_reset:
                                   1662 ;	commands.c:195: EA = 0;
                                   1663 ;	assignBit
      001A38 C2 AF            [12] 1664 	clr	_EA
                                   1665 ;	commands.c:196: WDCTL = BIT3 | BIT1 | BIT0; 	//enabled WDT and set the duration to mninimum. A reset should follow in 1-2ms, there is nothing to clear WDT
      001A3A 75 C9 0B         [24] 1666 	mov	_WDCTL,#0x0b
                                   1667 ;	commands.c:197: while(1);						//stay here until WDT resets 
      001A3D                       1668 00102$:
                                   1669 ;	commands.c:198: }
      001A3D 80 FE            [24] 1670 	sjmp	00102$
                                   1671 ;------------------------------------------------------------
                                   1672 ;Allocation info for local variables in function 'cmd_led'
                                   1673 ;------------------------------------------------------------
                                   1674 ;	commands.c:200: void cmd_led() {
                                   1675 ;	-----------------------------------------
                                   1676 ;	 function cmd_led
                                   1677 ;	-----------------------------------------
      001A3F                       1678 _cmd_led:
                                   1679 ;	commands.c:203: led = serial_rx_byte();
      001A3F 12 22 ED         [24] 1680 	lcall	_serial_rx_byte
                                   1681 ;	commands.c:204: mode = serial_rx_byte();
      001A42 12 22 ED         [24] 1682 	lcall	_serial_rx_byte
                                   1683 ;	commands.c:205: serial_tx_byte(RESPONSE_CODE_SUCCESS);
      001A45 75 82 DD         [24] 1684 	mov	dpl,#0xdd
      001A48 12 24 7F         [24] 1685 	lcall	_serial_tx_byte
                                   1686 ;	commands.c:206: serial_flush();
                                   1687 ;	commands.c:207: }
      001A4B 02 2B DC         [24] 1688 	ljmp	_serial_flush
                                   1689 ;------------------------------------------------------------
                                   1690 ;Allocation info for local variables in function 'cmd_set_preamble'
                                   1691 ;------------------------------------------------------------
                                   1692 ;	commands.c:209: void cmd_set_preamble() {
                                   1693 ;	-----------------------------------------
                                   1694 ;	 function cmd_set_preamble
                                   1695 ;	-----------------------------------------
      001A4E                       1696 _cmd_set_preamble:
                                   1697 ;	commands.c:211: preamble_word = serial_rx_word();
      001A4E 12 24 20         [24] 1698 	lcall	_serial_rx_word
                                   1699 ;	commands.c:212: radio_set_preamble(preamble_word);
      001A51 12 0B E4         [24] 1700 	lcall	_radio_set_preamble
                                   1701 ;	commands.c:213: serial_tx_byte(RESPONSE_CODE_SUCCESS);
      001A54 75 82 DD         [24] 1702 	mov	dpl,#0xdd
      001A57 12 24 7F         [24] 1703 	lcall	_serial_tx_byte
                                   1704 ;	commands.c:214: serial_flush();
                                   1705 ;	commands.c:215: }
      001A5A 02 2B DC         [24] 1706 	ljmp	_serial_flush
                                   1707 ;------------------------------------------------------------
                                   1708 ;Allocation info for local variables in function 'cmd_reset_radio_config'
                                   1709 ;------------------------------------------------------------
                                   1710 ;	commands.c:217: void cmd_reset_radio_config() {
                                   1711 ;	-----------------------------------------
                                   1712 ;	 function cmd_reset_radio_config
                                   1713 ;	-----------------------------------------
      001A5D                       1714 _cmd_reset_radio_config:
                                   1715 ;	commands.c:218: configure_radio();
      001A5D 12 01 C7         [24] 1716 	lcall	_configure_radio
                                   1717 ;	commands.c:219: set_encoding_type(EncodingTypeNone);
      001A60 75 82 00         [24] 1718 	mov	dpl,#0x00
      001A63 12 02 CB         [24] 1719 	lcall	_set_encoding_type
                                   1720 ;	commands.c:220: radio_set_preamble(0);
      001A66 90 00 00         [24] 1721 	mov	dptr,#0x0000
      001A69 12 0B E4         [24] 1722 	lcall	_radio_set_preamble
                                   1723 ;	commands.c:221: serial_tx_byte(RESPONSE_CODE_SUCCESS);
      001A6C 75 82 DD         [24] 1724 	mov	dpl,#0xdd
      001A6F 12 24 7F         [24] 1725 	lcall	_serial_tx_byte
                                   1726 ;	commands.c:222: serial_flush();
                                   1727 ;	commands.c:223: }
      001A72 02 2B DC         [24] 1728 	ljmp	_serial_flush
                                   1729 ;------------------------------------------------------------
                                   1730 ;Allocation info for local variables in function 'cmd_get_statistics'
                                   1731 ;------------------------------------------------------------
                                   1732 ;	commands.c:225: void cmd_get_statistics()
                                   1733 ;	-----------------------------------------
                                   1734 ;	 function cmd_get_statistics
                                   1735 ;	-----------------------------------------
      001A75                       1736 _cmd_get_statistics:
                                   1737 ;	commands.c:229: serial_tx_byte(RESPONSE_CODE_SUCCESS);
      001A75 75 82 DD         [24] 1738 	mov	dpl,#0xdd
      001A78 12 24 7F         [24] 1739 	lcall	_serial_tx_byte
                                   1740 ;	commands.c:230: read_timer(&uptime_ms);
                                   1741 ;	timer.h:14: EA = 0;
                                   1742 ;	assignBit
      001A7B C2 AF            [12] 1743 	clr	_EA
                                   1744 ;	timer.h:15: *result = __timerCounter;
      001A7D 78 56            [12] 1745 	mov	r0,#_cmd_get_statistics_uptime_ms_65536_55
      001A7F 79 2E            [12] 1746 	mov	r1,#___timerCounter
      001A81 E3               [24] 1747 	movx	a,@r1
      001A82 F2               [24] 1748 	movx	@r0,a
      001A83 08               [12] 1749 	inc	r0
      001A84 09               [12] 1750 	inc	r1
      001A85 E3               [24] 1751 	movx	a,@r1
      001A86 F2               [24] 1752 	movx	@r0,a
      001A87 08               [12] 1753 	inc	r0
      001A88 09               [12] 1754 	inc	r1
      001A89 E3               [24] 1755 	movx	a,@r1
      001A8A F2               [24] 1756 	movx	@r0,a
      001A8B 08               [12] 1757 	inc	r0
      001A8C 09               [12] 1758 	inc	r1
      001A8D E3               [24] 1759 	movx	a,@r1
      001A8E F2               [24] 1760 	movx	@r0,a
                                   1761 ;	timer.h:16: EA = 1;
                                   1762 ;	assignBit
      001A8F D2 AF            [12] 1763 	setb	_EA
                                   1764 ;	commands.c:231: serial_tx_long(uptime_ms);
      001A91 78 56            [12] 1765 	mov	r0,#_cmd_get_statistics_uptime_ms_65536_55
      001A93 E2               [24] 1766 	movx	a,@r0
      001A94 F5 82            [12] 1767 	mov	dpl,a
      001A96 08               [12] 1768 	inc	r0
      001A97 E2               [24] 1769 	movx	a,@r0
      001A98 F5 83            [12] 1770 	mov	dph,a
      001A9A 08               [12] 1771 	inc	r0
      001A9B E2               [24] 1772 	movx	a,@r0
      001A9C F5 F0            [12] 1773 	mov	b,a
      001A9E 08               [12] 1774 	inc	r0
      001A9F E2               [24] 1775 	movx	a,@r0
      001AA0 12 27 A1         [24] 1776 	lcall	_serial_tx_long
                                   1777 ;	commands.c:232: serial_tx_word(radio_rx_overflow_count);
      001AA3 78 65            [12] 1778 	mov	r0,#_radio_rx_overflow_count
      001AA5 E2               [24] 1779 	movx	a,@r0
      001AA6 F5 82            [12] 1780 	mov	dpl,a
      001AA8 08               [12] 1781 	inc	r0
      001AA9 E2               [24] 1782 	movx	a,@r0
      001AAA F5 83            [12] 1783 	mov	dph,a
      001AAC 12 25 84         [24] 1784 	lcall	_serial_tx_word
                                   1785 ;	commands.c:233: serial_tx_word(radio_rx_fifo_overflow_count);
      001AAF 78 67            [12] 1786 	mov	r0,#_radio_rx_fifo_overflow_count
      001AB1 E2               [24] 1787 	movx	a,@r0
      001AB2 F5 82            [12] 1788 	mov	dpl,a
      001AB4 08               [12] 1789 	inc	r0
      001AB5 E2               [24] 1790 	movx	a,@r0
      001AB6 F5 83            [12] 1791 	mov	dph,a
      001AB8 12 25 84         [24] 1792 	lcall	_serial_tx_word
                                   1793 ;	commands.c:234: serial_tx_word(packet_rx_count);
      001ABB 78 69            [12] 1794 	mov	r0,#_packet_rx_count
      001ABD E2               [24] 1795 	movx	a,@r0
      001ABE F5 82            [12] 1796 	mov	dpl,a
      001AC0 08               [12] 1797 	inc	r0
      001AC1 E2               [24] 1798 	movx	a,@r0
      001AC2 F5 83            [12] 1799 	mov	dph,a
      001AC4 12 25 84         [24] 1800 	lcall	_serial_tx_word
                                   1801 ;	commands.c:235: serial_tx_word(packet_tx_count);
      001AC7 78 6B            [12] 1802 	mov	r0,#_packet_tx_count
      001AC9 E2               [24] 1803 	movx	a,@r0
      001ACA F5 82            [12] 1804 	mov	dpl,a
      001ACC 08               [12] 1805 	inc	r0
      001ACD E2               [24] 1806 	movx	a,@r0
      001ACE F5 83            [12] 1807 	mov	dph,a
      001AD0 12 25 84         [24] 1808 	lcall	_serial_tx_word
                                   1809 ;	commands.c:236: serial_tx_word(crc_failure_count);
      001AD3 78 6D            [12] 1810 	mov	r0,#_crc_failure_count
      001AD5 E2               [24] 1811 	movx	a,@r0
      001AD6 F5 82            [12] 1812 	mov	dpl,a
      001AD8 08               [12] 1813 	inc	r0
      001AD9 E2               [24] 1814 	movx	a,@r0
      001ADA F5 83            [12] 1815 	mov	dph,a
      001ADC 12 25 84         [24] 1816 	lcall	_serial_tx_word
                                   1817 ;	commands.c:237: serial_tx_word(spi_sync_failure_count);
      001ADF 78 6F            [12] 1818 	mov	r0,#_spi_sync_failure_count
      001AE1 E2               [24] 1819 	movx	a,@r0
      001AE2 F5 82            [12] 1820 	mov	dpl,a
      001AE4 08               [12] 1821 	inc	r0
      001AE5 E2               [24] 1822 	movx	a,@r0
      001AE6 F5 83            [12] 1823 	mov	dph,a
      001AE8 12 25 84         [24] 1824 	lcall	_serial_tx_word
                                   1825 ;	commands.c:238: serial_tx_word(0); // Placeholder
      001AEB 90 00 00         [24] 1826 	mov	dptr,#0x0000
      001AEE 12 25 84         [24] 1827 	lcall	_serial_tx_word
                                   1828 ;	commands.c:239: serial_tx_word(0); // Placeholder
      001AF1 90 00 00         [24] 1829 	mov	dptr,#0x0000
      001AF4 12 25 84         [24] 1830 	lcall	_serial_tx_word
                                   1831 ;	commands.c:240: serial_flush();
                                   1832 ;	commands.c:241: }
      001AF7 02 2B DC         [24] 1833 	ljmp	_serial_flush
                                   1834 ;------------------------------------------------------------
                                   1835 ;Allocation info for local variables in function 'cmd_get_reset'
                                   1836 ;------------------------------------------------------------
                                   1837 ;	commands.c:243: void cmd_get_reset()
                                   1838 ;	-----------------------------------------
                                   1839 ;	 function cmd_get_reset
                                   1840 ;	-----------------------------------------
      001AFA                       1841 _cmd_get_reset:
                                   1842 ;	commands.c:245: if (reset_status == 1) serial_tx_byte(RESPONSE_CODE_SUCCESS); //CC1110 was not reset after BLE
      001AFA 78 4A            [12] 1843 	mov	r0,#_reset_status
      001AFC E2               [24] 1844 	movx	a,@r0
      001AFD B4 01 08         [24] 1845 	cjne	a,#0x01,00102$
      001B00 75 82 DD         [24] 1846 	mov	dpl,#0xdd
      001B03 12 24 7F         [24] 1847 	lcall	_serial_tx_byte
      001B06 80 06            [24] 1848 	sjmp	00103$
      001B08                       1849 00102$:
                                   1850 ;	commands.c:246: else serial_tx_byte(RESPONSE_CODE_PARAM_ERROR);
      001B08 75 82 11         [24] 1851 	mov	dpl,#0x11
      001B0B 12 24 7F         [24] 1852 	lcall	_serial_tx_byte
      001B0E                       1853 00103$:
                                   1854 ;	commands.c:247: serial_flush();
                                   1855 ;	commands.c:248: }
      001B0E 02 2B DC         [24] 1856 	ljmp	_serial_flush
                                   1857 ;------------------------------------------------------------
                                   1858 ;Allocation info for local variables in function 'do_cmd'
                                   1859 ;------------------------------------------------------------
                                   1860 ;	commands.c:269: void do_cmd(uint8_t cmd) {
                                   1861 ;	-----------------------------------------
                                   1862 ;	 function do_cmd
                                   1863 ;	-----------------------------------------
      001B11                       1864 _do_cmd:
                                   1865 ;	commands.c:270: if (cmd > 0 && cmd < sizeof(handlers)/sizeof(handlers[0])) {
      001B11 E5 82            [12] 1866 	mov	a,dpl
      001B13 FF               [12] 1867 	mov	r7,a
      001B14 60 2C            [24] 1868 	jz	00101$
      001B16 BF 10 00         [24] 1869 	cjne	r7,#0x10,00127$
      001B19                       1870 00127$:
      001B19 50 27            [24] 1871 	jnc	00101$
                                   1872 ;	commands.c:272: handlers[cmd]();
      001B1B EF               [12] 1873 	mov	a,r7
      001B1C 75 F0 02         [24] 1874 	mov	b,#0x02
      001B1F A4               [48] 1875 	mul	ab
      001B20 24 29            [12] 1876 	add	a,#_handlers
      001B22 F5 82            [12] 1877 	mov	dpl,a
      001B24 74 F3            [12] 1878 	mov	a,#(_handlers >> 8)
      001B26 35 F0            [12] 1879 	addc	a,b
      001B28 F5 83            [12] 1880 	mov	dph,a
      001B2A E0               [24] 1881 	movx	a,@dptr
      001B2B FE               [12] 1882 	mov	r6,a
      001B2C A3               [24] 1883 	inc	dptr
      001B2D E0               [24] 1884 	movx	a,@dptr
      001B2E FF               [12] 1885 	mov	r7,a
      001B2F C0 07            [24] 1886 	push	ar7
      001B31 C0 06            [24] 1887 	push	ar6
      001B33 8E 82            [24] 1888 	mov	dpl,r6
      001B35 8F 83            [24] 1889 	mov	dph,r7
      001B37 12 00 89         [24] 1890 	lcall	__sdcc_call_dptr
      001B3A D0 06            [24] 1891 	pop	ar6
      001B3C D0 07            [24] 1892 	pop	ar7
                                   1893 ;	commands.c:274: CLKCON = 0xAC;  		//command finished, we can slow down now; CLKSPD = 1.5Mhz, TICKSPD = 750Khz
      001B3E 75 C6 AC         [24] 1894 	mov	_CLKCON,#0xac
                                   1895 ;	commands.c:278: while(serial_rx_avail() > 0) {
      001B41 22               [24] 1896 	ret
      001B42                       1897 00101$:
      001B42 12 22 DD         [24] 1898 	lcall	_serial_rx_avail
      001B45 E5 82            [12] 1899 	mov	a,dpl
      001B47 60 05            [24] 1900 	jz	00103$
                                   1901 ;	commands.c:279: serial_rx_byte();
      001B49 12 22 ED         [24] 1902 	lcall	_serial_rx_byte
      001B4C 80 F4            [24] 1903 	sjmp	00101$
      001B4E                       1904 00103$:
                                   1905 ;	commands.c:281: serial_tx_byte(RESPONSE_CODE_UNKNOWN_COMMAND);
      001B4E 75 82 22         [24] 1906 	mov	dpl,#0x22
      001B51 12 24 7F         [24] 1907 	lcall	_serial_tx_byte
                                   1908 ;	commands.c:282: serial_flush();
                                   1909 ;	commands.c:284: }
      001B54 02 2B DC         [24] 1910 	ljmp	_serial_flush
                                   1911 	.area CSEG    (CODE)
                                   1912 	.area CONST   (CODE)
                                   1913 	.area CONST   (CODE)
      002E75                       1914 ___str_0:
      002E75 4F 4B                 1915 	.ascii "OK"
      002E77 00                    1916 	.db 0x00
                                   1917 	.area CSEG    (CODE)
                                   1918 	.area CONST   (CODE)
      002E78                       1919 ___str_1:
      002E78 73 75 62 67 5F 72 66  1920 	.ascii "subg_rfspy 2.2"
             73 70 79 20 32 2E 32
      002E86 00                    1921 	.db 0x00
                                   1922 	.area CSEG    (CODE)
                                   1923 	.area XINIT   (CODE)
      002E97                       1924 __xinit__handlers:
      002E97 00 00                 1925 	.byte #0x00,#0x00
      002E99 43 18                 1926 	.byte _cmd_get_state, (_cmd_get_state >> 8)
      002E9B 52 18                 1927 	.byte _cmd_get_version, (_cmd_get_version >> 8)
      002E9D 0B 18                 1928 	.byte _cmd_get_packet, (_cmd_get_packet >> 8)
      002E9F 61 18                 1929 	.byte _cmd_send_packet, (_cmd_send_packet >> 8)
      002EA1 BB 18                 1930 	.byte _cmd_send_and_listen, (_cmd_send_and_listen >> 8)
      002EA3 0B 1A                 1931 	.byte _cmd_update_register, (_cmd_update_register >> 8)
      002EA5 38 1A                 1932 	.byte _cmd_reset, (_cmd_reset >> 8)
      002EA7 3F 1A                 1933 	.byte _cmd_led, (_cmd_led >> 8)
      002EA9 F1 19                 1934 	.byte _cmd_read_register, (_cmd_read_register >> 8)
      002EAB 2A 17                 1935 	.byte _cmd_set_mode_registers, (_cmd_set_mode_registers >> 8)
      002EAD 0A 17                 1936 	.byte _cmd_set_sw_encoding, (_cmd_set_sw_encoding >> 8)
      002EAF 4E 1A                 1937 	.byte _cmd_set_preamble, (_cmd_set_preamble >> 8)
      002EB1 5D 1A                 1938 	.byte _cmd_reset_radio_config, (_cmd_reset_radio_config >> 8)
      002EB3 75 1A                 1939 	.byte _cmd_get_statistics, (_cmd_get_statistics >> 8)
      002EB5 FA 1A                 1940 	.byte _cmd_get_reset, (_cmd_get_reset >> 8)
                                   1941 	.area CABS    (ABS,CODE)
